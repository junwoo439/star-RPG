package com.junwo.starrpg;

import com.mojang.blaze3d.vertex.*;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/** Original painted sprite atlas, animated on crossed planes and layered circles. */
public final class SpellVfx {
    public static final ResourceLocation ATLAS=ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,"textures/effect/spell_effects.png");
    public static void quad(PoseStack pose,VertexConsumer out,int cell,float width,float height,int color,float alpha){
        // The painted fire/water cells have glow from the row above at their top edge.
        // Trim only that transparent/stray margin through UVs; keep the original PNG intact.
        float top=cell==6||cell==7?0.020F:0.001F;
        float u=(cell%4)*0.25F+0.001F,v=(cell/4)*0.25F+top,span=0.248F,spanV=0.249F-top;
        float[][] pts={{-width,-height,u,v+spanV},{width,-height,u+span,v+spanV},{width,height,u+span,v},{-width,height,u,v}};
        for(int side=0;side<2;side++)for(int n=0;n<4;n++){
            var a=pts[side==0?n:3-n];out.addVertex(pose.last(),a[0],a[1],side==0?0.001F:-0.001F)
                .setColor((color>>16)&255,(color>>8)&255,color&255,(int)(Math.clamp(alpha,0,1)*255))
                .setUv(a[2],a[3]).setOverlay(OverlayTexture.NO_OVERLAY).setLight(15728880).setNormal(pose.last(),0,0,side==0?1:-1);
        }
    }
    private static void floor(PoseStack p,VertexConsumer out,int cell,int color,float radius,float y,float angle,float alpha){
        p.pushPose();p.translate(0,y,0);p.mulPose(Axis.XP.rotationDegrees(90));p.mulPose(Axis.ZP.rotationDegrees(angle));quad(p,out,cell,radius,radius,color,alpha);p.popPose();
    }
    private static void column(PoseStack p,VertexConsumer out,int cell,int color,float radius,float height,float angle,float alpha){
        for(int i=0;i<2;i++){p.pushPose();p.mulPose(Axis.YP.rotationDegrees(angle+i*90));p.translate(0,height*0.72,0);quad(p,out,cell,radius,height,color,alpha*(i==0?0.85F:0.65F));p.popPose();}
    }
    public static void draw(PoseStack p,MultiBufferSource buffers,int style,int color,float radius,float age,int life,float yaw,float pitch){
        if(style==37||style==38)WeaponTrailVfx.draw(p,buffers,style,color,radius,age,life,yaw,pitch);
        else CinematicVfx.draw(p,buffers,style,color,radius,age,life,yaw,pitch);
    }
}
