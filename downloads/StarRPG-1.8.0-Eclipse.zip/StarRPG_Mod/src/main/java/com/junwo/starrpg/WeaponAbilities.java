package com.junwo.starrpg;

import java.util.*;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.*;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.*;
import net.minecraft.world.item.component.ChargedProjectiles;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.*;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.living.*;
import net.neoforged.neoforge.event.entity.player.*;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;

@EventBusSubscriber(modid=StarRPG.MODID)
public final class WeaponAbilities {
    public static final ResourceKey<DamageType> DAGGER_DAMAGE=ResourceKey.create(Registries.DAMAGE_TYPE,ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,"dagger"));
    private static final class Cast {final ItemStack weapon;final int type;final long start;int next;final Set<UUID> waveHits=new HashSet<>();Cast(ItemStack w,int t,long s){weapon=w;type=t;start=s;}}
    private static final Map<UUID,Cast> CASTS=new HashMap<>();
    private static int type(ItemStack w){return w.getItem() instanceof StarDaggerItem?0:w.getItem() instanceof WarHammerItem?1:w.getItem() instanceof BowItem?2:w.getItem() instanceof CrossbowItem?3:w.getItem() instanceof SwordItem?4:-1;}
    public static boolean activate(Player p){
        if(p.level().isClientSide()||!p.isAlive()||p.isSpectator()||p.containerMenu!=p.inventoryMenu)return false;
        if(p.getMainHandItem().getItem() instanceof MagicStaffItem)return MagicSystem.meteor(p);
        var old=CASTS.get(p.getUUID());if(old!=null){if(old.type==3){cancel(p);return true;}return false;}
        if(ControlEffects.stunned(p))return false;var w=p.getMainHandItem();int t=type(w);if(t<0||!Careers.requireWeapon(p,w))return false;
        long now=p.level().getGameTime();String key="starrpg_skill_ready_"+t;
        if(p.getPersistentData().getLong(key)>now){p.displayClientMessage(Component.literal("무기 능력: "+(int)Math.ceil((p.getPersistentData().getLong(key)-now)/20.0)+"초 후 사용 가능"),true);return false;}
        if((t==2||t==3)&&!hasArrow(p,w)){p.displayClientMessage(Component.literal("화살이 필요합니다. 폭죽은 지원하지 않습니다."),true);return false;}
        if(t==1&&!p.onGround()){p.displayClientMessage(Component.literal("땅에 서서 사용하세요."),true);return false;}
        p.stopUsingItem();CASTS.put(p.getUUID(),new Cast(w,t,now));p.getPersistentData().putLong(key,now+new int[]{160,240,300,400,200}[t]);
        if(t==0)p.addEffect(new net.minecraft.world.effect.MobEffectInstance(ModEffects.COMBO,14,0,false,false,false));
        if(t==3)p.addEffect(new net.minecraft.world.effect.MobEffectInstance(ModEffects.BRACED,100,0,false,false,false));
        p.displayClientMessage(Component.literal(new String[]{"삼연격","지면 강타 준비","대형 화살 준비","고정 사격 5초 · R로 취소","검기 준비"}[t]),true);return true;
    }
    public static void cancel(Player p){CASTS.remove(p.getUUID());p.removeEffect(ModEffects.BRACED);p.removeEffect(ModEffects.COMBO);}
    public static LivingEntity target(Player p,double range,double dot){
        return p.level().getEntitiesOfClass(LivingEntity.class,p.getBoundingBox().inflate(range),e->CombatRules.canHarm(p,e)&&p.hasLineOfSight(e)&&p.distanceToSqr(e)<=range*range&&p.getLookAngle().dot(e.getEyePosition().subtract(p.getEyePosition()).normalize())>=dot)
                .stream().min(Comparator.comparingDouble(e->e.distanceToSqr(p))).orElse(null);
    }
    private static boolean hasArrow(Player p,ItemStack w){
        if(w.getItem() instanceof CrossbowItem && CrossbowItem.isCharged(w))return w.getOrDefault(DataComponents.CHARGED_PROJECTILES,ChargedProjectiles.EMPTY).getItems().stream().allMatch(a->a.getItem() instanceof ArrowItem);
        return p.getProjectile(w).getItem() instanceof ArrowItem || p.hasInfiniteMaterials();
    }
    private static ItemStack ammo(Player p,ItemStack w){var a=p.getProjectile(w);return a.getItem() instanceof ArrowItem?a:p.hasInfiniteMaterials()?new ItemStack(Items.ARROW):ItemStack.EMPTY;}
    public static boolean throwDagger(Player p,InteractionHand hand){
        var w=p.getItemInHand(hand);long now=p.level().getGameTime();
        if(p.level().isClientSide()||!p.isAlive()||p.isSpectator()||ControlEffects.stunned(p)||p.hasEffect(ModEffects.COMBO)||!(w.getItem() instanceof StarDaggerItem)||p.getPersistentData().getLong("starrpg_throw_ready")>now)return false;
        var entity=new ThrownDagger(p.level(),p,w.copyWithCount(1));entity.shootFromRotation(p,p.getXRot(),p.getYRot(),0,2.0F,0.2F);
        if(!Careers.requireWeapon(p,w)||!p.level().addFreshEntity(entity))return false;
        if(!p.hasInfiniteMaterials())w.shrink(1);p.getPersistentData().putLong("starrpg_throw_ready",now+120);p.swing(hand,true);CombatVisuals.sound(p,net.minecraft.sounds.SoundEvents.TRIDENT_THROW,0.65F,1.5F);return true;
    }
    @SubscribeEvent public static void tick(PlayerTickEvent.Post e){
        Player p=e.getEntity();if(p.level().isClientSide())return;var cast=CASTS.get(p.getUUID());if(cast==null){p.removeEffect(ModEffects.BRACED);p.removeEffect(ModEffects.COMBO);return;}
        if(!p.isAlive()||p.isSpectator()||ControlEffects.stunned(p)||p.getMainHandItem()!=cast.weapon||type(cast.weapon)!=cast.type||!Careers.qualified(p,cast.weapon)||p.containerMenu!=p.inventoryMenu){cancel(p);return;}
        int age=(int)(p.level().getGameTime()-cast.start);if(age<0){cancel(p);return;}
        switch(cast.type){
            case 0->{if(age>=cast.next&&cast.next<=12){
                var target=target(p,2.3,0.45);p.swing(InteractionHand.MAIN_HAND,true);arc(p,2.1,cast.next/6);CombatVisuals.sound(p,net.minecraft.sounds.SoundEvents.PLAYER_ATTACK_SWEEP,0.5F,0.9F+cast.next*0.05F);
                if(target!=null){float damage=(float)(p.getAttributeValue(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE)+EnhancementData.level(cast.weapon)*0.6)*0.6F;
                    // Short controlled combo bypasses vanilla hurt immunity only for its own hit, then restores it.
                    int immunity=target.invulnerableTime;target.invulnerableTime=0;CombatRules.runeDamage(p,target,damage);target.invulnerableTime=Math.max(immunity,target.invulnerableTime);
                }cast.next+=6;
            }if(age>=13)cancel(p);}
            case 1->{if(age<14){if(age%3==0)arc(p,0.8,age/3);}else if(age<=26){
                double radius=Math.min(4,(age-13)*0.32);ring(p,radius);if(age==14)CombatVisuals.sound(p,net.minecraft.sounds.SoundEvents.GENERIC_EXPLODE,0.5F,0.7F);
                for(var target:p.level().getEntitiesOfClass(LivingEntity.class,p.getBoundingBox().inflate(4,1.5,4),a->CombatRules.canHarm(p,a)&&p.hasLineOfSight(a)&&a.onGround()&&Math.abs(a.getY()-p.getY())<1.25)){
                    double d=target.position().subtract(p.position()).multiply(1,0,1).length();
                    if(d<=radius&&cast.waveHits.add(target.getUUID())){CombatRules.runeDamage(p,target,5);target.knockback(0.35,p.getX()-target.getX(),p.getZ()-target.getZ());}
                }
            }else cancel(p);}
            case 2->{if(age<20){if(age%4==0)arc(p,0.7,0);}else{
                var ammo=ammo(p,cast.weapon);if(!ammo.isEmpty()){
                    var arrow=new GiantArrow(p.level(),p,ammo.copyWithCount(1),cast.weapon);arrow.shootFromRotation(p,p.getXRot(),p.getYRot(),0,3,0.3F);
                    if(p.level().addFreshEntity(arrow)){if(!p.hasInfiniteMaterials())ammo.shrink(1);cast.weapon.hurtAndBreak(1,p,EquipmentSlot.MAINHAND);p.swing(InteractionHand.MAIN_HAND,true);CombatVisuals.sound(p,net.minecraft.sounds.SoundEvents.TRIDENT_THROW,0.8F,0.65F);}
                }cancel(p);
            }}
            case 3->{if(age>=100){cancel(p);return;}if(age>=cast.next){
                if(!hasArrow(p,cast.weapon)){cancel(p);return;}
                if(!CrossbowItem.isCharged(cast.weapon)){var ammo=ammo(p,cast.weapon);if(ammo.isEmpty()){cancel(p);return;}cast.weapon.set(DataComponents.CHARGED_PROJECTILES,ChargedProjectiles.of(List.of(ammo.copyWithCount(1))));if(!p.hasInfiniteMaterials())ammo.shrink(1);}
                ((CrossbowItem)cast.weapon.getItem()).performShooting((ServerLevel)p.level(),p,InteractionHand.MAIN_HAND,cast.weapon,3.15F,1,null);CombatVisuals.burst(p,ParticleTypes.CRIT,4);cast.next=age+10;
            }}
            case 4->{arc(p,Math.min(5,1+age*0.45),age);
                if(age>=6){for(var target:p.level().getEntitiesOfClass(LivingEntity.class,p.getBoundingBox().inflate(5),a->CombatRules.canHarm(p,a)&&p.hasLineOfSight(a)&&p.distanceToSqr(a)<=25&&p.getLookAngle().dot(a.getEyePosition().subtract(p.getEyePosition()).normalize())>=0.65).stream().limit(6).toList())CombatRules.runeDamage(p,target,(float)(p.getAttributeValue(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE)*0.75+EnhancementData.level(cast.weapon)*0.3));
                    CombatVisuals.sound(p,net.minecraft.sounds.SoundEvents.PLAYER_ATTACK_SWEEP,0.8F,0.6F);cancel(p);}
            }
        }
    }
    private static void ring(Player p,double r){for(int i=0;i<36;i++){double a=i*Math.PI*2/36;((ServerLevel)p.level()).sendParticles(ParticleTypes.CRIT,p.getX()+Math.cos(a)*r,p.getY()+0.15,p.getZ()+Math.sin(a)*r,1,0,0.05,0,0);}}
    public static void arc(Player p,double r,int phase){
        double yaw=Math.toRadians(p.getYRot());for(int i=-3;i<=3;i++){double a=yaw+i*0.16;((ServerLevel)p.level()).sendParticles(ParticleTypes.SWEEP_ATTACK,p.getX()-Math.sin(a)*r,p.getY()+1+Math.sin(i*0.4+phase)*0.25,p.getZ()+Math.cos(a)*r,1,0,0,0,0);}
    }
    @SubscribeEvent public static void loose(ArrowLooseEvent e){if(e.getBow().getItem() instanceof BowItem)e.setCharge((int)Math.floor(e.getCharge()*20.0/18));}
    @SubscribeEvent public static void reload(LivingEntityUseItemEvent.Tick e){
        if(e.getItem().getItem() instanceof CrossbowItem && e.getDuration()>1 && e.getDuration()%4==0)e.setDuration(e.getDuration()-1);
    }
    @SubscribeEvent(priority=EventPriority.HIGH) public static void arrow(EntityJoinLevelEvent e){
        if(e.getLevel().isClientSide()||!(e.getEntity() instanceof AbstractArrow a)||!(a.getOwner() instanceof Player p)||a instanceof ThrownDagger||a.getPersistentData().getBoolean("starrpg_arrow_adjusted"))return;
        var w=a.getWeaponItem();if(w==null||!(w.getItem() instanceof BowItem||w.getItem() instanceof CrossbowItem))return;
        double factor=1.10*(1+Careers.arrowBonus(p));var cast=CASTS.get(p.getUUID());
        if(cast!=null&&cast.type==3){factor*=0.6;a.getPersistentData().putFloat("starrpg_shot_power",(float)Math.sqrt(0.6));}
        a.setBaseDamage(a.getBaseDamage()*factor);a.getPersistentData().putBoolean("starrpg_arrow_adjusted",true);
    }
    @SubscribeEvent public static void logout(PlayerEvent.PlayerLoggedOutEvent e){cancel(e.getEntity());}
    @SubscribeEvent public static void changed(PlayerEvent.PlayerChangedDimensionEvent e){cancel(e.getEntity());}
    @SubscribeEvent public static void death(LivingDeathEvent e){if(e.getEntity() instanceof Player p)cancel(p);}
    @SubscribeEvent public static void clonePlayer(PlayerEvent.Clone e){
        for(String key:new String[]{"starrpg_skill_ready_0","starrpg_skill_ready_1","starrpg_skill_ready_2","starrpg_skill_ready_3","starrpg_skill_ready_4","starrpg_spell_ready","starrpg_heal_ready","starrpg_meteor_ready","starrpg_throw_ready","starrpg_career_ready","starrpg_element_ready","starrpg_control_immune"})
            if(e.getOriginal().getPersistentData().contains(key))e.getEntity().getPersistentData().putLong(key,e.getOriginal().getPersistentData().getLong(key));
        if(e.getOriginal().getPersistentData().contains("starrpg_mana"))e.getEntity().getPersistentData().putFloat("starrpg_mana",e.getOriginal().getPersistentData().getFloat("starrpg_mana"));
    }
    @SubscribeEvent public static void stop(ServerStoppedEvent e){CASTS.clear();}
}
