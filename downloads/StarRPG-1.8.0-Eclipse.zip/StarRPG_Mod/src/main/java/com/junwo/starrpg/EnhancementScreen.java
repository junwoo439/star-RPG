package com.junwo.starrpg;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.Minecraft;
import net.minecraft.world.item.ItemStack;

public class EnhancementScreen extends AbstractContainerScreen<EnhancementMenu> {

    public EnhancementScreen(EnhancementMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);

        this.imageWidth = 176;
        this.imageHeight = 218;
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        // 전체 메뉴 배경
        graphics.fill(
                this.leftPos,
                this.topPos,
                this.leftPos + this.imageWidth,
                this.topPos + this.imageHeight,
                0xFF303030
        );

        // 강화할 무기 슬롯
        drawSlot(graphics, this.leftPos + 34, this.topPos + 34);
        drawSlot(graphics, this.leftPos + 88, this.topPos + 34);
        drawSlot(graphics, this.leftPos + 142, this.topPos + 34);
        // 플레이어 인벤토리 슬롯 27칸
        for (int row = 0; row < 3; row++) {
            for (int column = 0; column < 9; column++) {
                drawSlot(
                        graphics,
                        this.leftPos + 8 + column * 18,
                        this.topPos + 135 + row * 18
                );
            }
        }

        // 핫바 슬롯 9칸
        for (int column = 0; column < 9; column++) {
            drawSlot(
                    graphics,
                    this.leftPos + 8 + column * 18,
                    this.topPos + 193
            );
        }
    }
    
    @Override
    protected void init() {
        super.init();

        this.addRenderableWidget(
                Button.builder(
                        Component.literal("강화 시도"),
                        button -> {
                            if (Minecraft.getInstance().gameMode != null) {
                                Minecraft.getInstance().gameMode.handleInventoryButtonClick(
                                        this.menu.containerId,
                                        0
                                );
                            }
                        }
                ).bounds(this.leftPos + 104, this.topPos + 83, 66, 20).build()
        );
    }
    
    private void drawSlot(GuiGraphics graphics, int x, int y) {
        // 바깥 테두리
        graphics.fill(x, y, x + 18, y + 18, 0xFF151515);

        // 밝은 안쪽 테두리
        graphics.fill(x + 1, y + 1, x + 17, y + 17, 0xFF888888);

        // 슬롯 내부
        graphics.fill(x + 2, y + 2, x + 16, y + 16, 0xFF3F3F3F);
    }
    @Override
    public void render(
            GuiGraphics graphics,
            int mouseX,
            int mouseY,
            float partialTick
    ) {
        super.render(graphics, mouseX, mouseY, partialTick);
        renderTooltip(graphics, mouseX, mouseY);
    }
    
    @Override
    protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
        graphics.drawString(this.font, "별빛 강화 테이블", 8, 6, 0xFFFFFF);

        graphics.drawString(this.font, "장비", 36, 18, 0xFFFFFF);
        graphics.drawString(this.font, "무기·방어구", 29, 28, 0xAAAAAA);

        graphics.drawString(this.font, "별가루", 82, 18, 0xFFFFFF);
        graphics.drawString(this.font, "재료", 91, 28, 0xAAAAAA);

        graphics.drawString(this.font, "별조각", 136, 18, 0xFFFFFF);
        graphics.drawString(this.font, "재료", 145, 28, 0xAAAAAA);
        ItemStack weapon = this.menu.getSlot(0).getItem();

        int level = EnhancementData.level(weapon);

        int requiredDust = EnhancementMenu.getRequiredDust(level);
        int successChance = EnhancementMenu.getSuccessChance(weapon);
        int requiredFragment = EnhancementMenu.getRequiredFragment(level);
        int destroyChance = EnhancementMenu.getDestroyChance(level);

        graphics.drawString(this.font, "현재 강화: +" + level, 8, 76, 0xFFFF55);
        graphics.drawString(this.font, "별가루: " + requiredDust + "개", 8, 86, 0xFFFFFF);
        graphics.drawString(this.font, "성공 확률: " + successChance + "%", 8, 96, 0xFFFF55);

        if (requiredFragment > 0) {
            graphics.drawString(
                    this.font,
                    "별조각: " + requiredFragment + "개",
                    8,
                    106,
                    0xFF55FF
            );
        }

        if (destroyChance > 0) {
            graphics.drawString(
                    this.font,
                    "파괴 확률: " + destroyChance + "%",
                    8,
                    116,
                    0xFF5555
            );
        }

        graphics.drawString(this.font, "실패: 유지 / 파괴 없음", 8, 116, 0xAAAAAA);
        graphics.drawString(this.font, "인벤토리", 8, 124, 0xFFFFFF);
    }
}
