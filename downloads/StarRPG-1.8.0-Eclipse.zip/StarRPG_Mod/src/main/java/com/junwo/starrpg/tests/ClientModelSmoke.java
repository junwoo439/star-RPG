package com.junwo.starrpg.tests;

import com.junwo.starrpg.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.*;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/** Opt-in dev-only verification. Excluded from the distributed mod JAR with all test classes. */
@EventBusSubscriber(modid=StarRPG.MODID,value=Dist.CLIENT)
public final class ClientModelSmoke {
    private static int ticks;private static boolean checked,captured;
    @SubscribeEvent public static void tick(ClientTickEvent.Post event){
        if(!Boolean.getBoolean("starrpg.clientSmoke"))return;
        var mc=Minecraft.getInstance();if(mc.getOverlay()!=null||mc.screen==null)return;
        if(!checked){
            var item=new ItemStack(StarRPG.MAGIC_STAFF.get());var model=mc.getItemRenderer().getModel(item,null,null,0);var random=RandomSource.create(1);
            int faces=model.getQuads(null,null,random).size();for(var direction:Direction.values())faces+=model.getQuads(null,direction,random).size();
            if(model==mc.getModelManager().getMissingModel()||faces<36)throw new IllegalStateException("Staff model missing or invisible: faces="+faces);
            StarRPG.LOGGER.info("CLIENT_MODEL_CHECK PASSED: magic_staff baked faces={}",faces);checked=true;
            mc.setScreen(new Preview(faces));return;
        }
        if(++ticks>=80&&!captured){captured=true;Screenshot.grab(mc.gameDirectory,"starrpg-1.8-model-check.png",mc.getMainRenderTarget(),message->{StarRPG.LOGGER.info("CLIENT_MODEL_SCREENSHOT: {}",message.getString());mc.execute(mc::stop);});}
    }
    private static final class Preview extends Screen {
        private final int faces;Preview(int faces){super(Component.literal("StarRPG model verification"));this.faces=faces;}
        @Override public void render(GuiGraphics g,int x,int y,float partial){
            g.fillGradient(0,0,width,height,0xFF251C37,0xFF101B29);
            g.drawCenteredString(font,"StarRPG 1.8 - actual client model",width/2,18,0xF0D8FF);
            g.drawCenteredString(font,"3D staff / baked faces: "+faces,width/2,34,0xB5C8D9);
            int left=width/2-110,top=60;
            g.fill(left-8,top-8,left+104,top+112,0xFF121B28);
            g.pose().pushPose();g.pose().translate(left,top,0);g.pose().scale(6,6,6);g.renderItem(new ItemStack(StarRPG.MAGIC_STAFF.get()),0,0);g.pose().popPose();
            g.pose().pushPose();g.pose().translate(width/2+32,top+18,0);g.pose().scale(3,3,3);g.renderItem(new ItemStack(Items.AMETHYST_SHARD),0,0);g.pose().popPose();
            g.pose().pushPose();g.pose().translate(width/2+90,top+18,0);g.pose().scale(3,3,3);g.renderItem(new ItemStack(Items.FIRE_CHARGE),0,0);g.pose().popPose();
            g.drawString(font,"Magic staff",left+12,top+122,0xDCC0FF);g.drawString(font,"Spell core textures",width/2+25,top+85,0xF1C183);
            g.drawCenteredString(font,"Real Minecraft rendering - no resource pack required",width/2,height-24,0xADC4D4);
        }
    }
}
