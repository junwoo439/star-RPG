package com.junwo.starrpg;

import java.util.*;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.*;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.phys.*;
import net.minecraft.world.level.ClipContext;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;

@EventBusSubscriber(modid=StarRPG.MODID)
public final class MagicSystem {
    public static final ResourceKey<DamageType> MAGIC_DAMAGE=ResourceKey.create(Registries.DAMAGE_TYPE,ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,"magic"));
    public static final String[] SPELLS={"마나탄","화염구","회복"};
    private record Meteor(ItemStack staff,Vec3 point,long ready,float damage){}
    private static final Map<UUID,Meteor> METEORS=new HashMap<>();
    public static int spell(ItemStack stack){return Math.clamp(stack.getOrDefault(DataComponents.CUSTOM_DATA,CustomData.EMPTY).copyTag().getInt("starrpg_spell"),0,2);}
    public static boolean choose(Player p,int id){
        if(p.level().isClientSide()||!p.isAlive()||p.isSpectator()||ControlEffects.stunned(p)||id<0||id>2||!(p.getMainHandItem().getItem() instanceof MagicStaffItem)||!Careers.requireWeapon(p,p.getMainHandItem()))return false;
        CustomData.update(DataComponents.CUSTOM_DATA,p.getMainHandItem(),t->t.putInt("starrpg_spell",id));
        p.displayClientMessage(Component.literal("선택 주문: "+SPELLS[id]),true);return true;
    }
    public static boolean cycle(Player p){return choose(p,(spell(p.getMainHandItem())+1)%3);}
    public static float maxMana(Player p){return (float)(100+10*Careers.power(p)+ArmorRuneEffects.grade(p,EquipmentSlot.HEAD,5)*8);}
    public static float mana(Player p){
        var tag=p.getPersistentData();if(!tag.contains("starrpg_mana"))tag.putFloat("starrpg_mana",100);
        float raw=tag.getFloat("starrpg_mana");return Float.isFinite(raw)?Math.clamp(raw,0,maxMana(p)):0;
    }
    public static void restore(Player p,float amount){p.getPersistentData().putFloat("starrpg_mana",Math.min(maxMana(p),mana(p)+Math.max(0,amount)));}
    private static boolean usable(Player p){return !p.level().isClientSide()&&p.isAlive()&&!p.isSpectator()&&!ControlEffects.stunned(p)&&p.containerMenu==p.inventoryMenu&&p.getMainHandItem().getItem() instanceof MagicStaffItem&&Careers.requireWeapon(p,p.getMainHandItem());}
    private static boolean ready(Player p,String key,int cost){
        if(p.getPersistentData().getLong(key)>p.level().getGameTime()){p.displayClientMessage(Component.literal("마법 재사용 대기 중"),true);return false;}
        if(mana(p)<cost){p.displayClientMessage(Component.literal("마나 부족: "+cost+" MP 필요"),true);return false;}return true;
    }
    private static void spend(Player p,String key,int cost,int ticks){
        p.getPersistentData().putFloat("starrpg_mana",mana(p)-cost);p.getPersistentData().putLong(key,p.level().getGameTime()+Math.max(5,(int)Math.ceil(ticks*(1-ExtendedRuneEffects.staff(p.getMainHandItem(),2)*0.03))));
        ExtendedRuneEffects.cast(p,p.getMainHandItem());
        p.getMainHandItem().hurtAndBreak(1,p,EquipmentSlot.MAINHAND);p.swing(net.minecraft.world.InteractionHand.MAIN_HAND,true);
    }
    public static int manaCost(Player p,int base){return Math.max(1,(int)Math.ceil(base*(1-ExtendedRuneEffects.staff(p.getMainHandItem(),1)*0.04)));}
    public static boolean cast(Player p){
        if(!usable(p)||METEORS.containsKey(p.getUUID()))return false;
        int spell=spell(p.getMainHandItem()),cost=manaCost(p,new int[]{8,18,25}[spell]);
        String key=spell==2?"starrpg_heal_ready":"starrpg_spell_ready";
        if(!ready(p,key,cost))return false;
        double power=Careers.power(p);float enhancement=EnhancementData.level(p.getMainHandItem())*0.3F;
        if(spell==2){
            if(p.getHealth()>=p.getMaxHealth()){p.displayClientMessage(Component.literal("이미 체력이 가득 찼습니다."),true);return false;}
            p.heal((float)(4+power*0.5));CombatVisuals.burst(p,ParticleTypes.HEART,7);spend(p,key,cost,160);
            CombatVisuals.sound(p,SoundEvents.AMETHYST_BLOCK_CHIME,0.8F,1.3F);return true;
        }
        var bolt=new MagicBolt(p.level(),p,spell,(float)((spell==0?5:8)+power)+enhancement);
        bolt.shootFromRotation(p,p.getXRot(),p.getYRot(),0,spell==0?1.8F:1.1F,0.3F);
        if(!p.level().addFreshEntity(bolt))return false;
        spend(p,key,cost,spell==0?10:30);CombatVisuals.sound(p,SoundEvents.EVOKER_CAST_SPELL,0.55F,spell==0?1.6F:0.8F);return true;
    }
    public static boolean meteor(Player p){
        if(!usable(p)||METEORS.containsKey(p.getUUID())||!ready(p,"starrpg_meteor_ready",manaCost(p,40)))return false;
        var target=WeaponAbilities.target(p,18,0.985);Vec3 point;
        if(target!=null)point=target.position();else{var hit=p.pick(18,0,false);if(hit.getType()!=HitResult.Type.BLOCK){p.displayClientMessage(Component.literal("18칸 안의 적 또는 지면을 조준하세요."),true);return false;}point=hit.getLocation().add(0,0.1,0);}
        float damage=(float)(10+2*Careers.power(p))+EnhancementData.level(p.getMainHandItem())*0.3F;
        METEORS.put(p.getUUID(),new Meteor(p.getMainHandItem(),point,p.level().getGameTime()+14,damage));
        spend(p,"starrpg_meteor_ready",manaCost(p,40),240);CombatVisuals.sound(p,SoundEvents.BEACON_POWER_SELECT,0.5F,1.5F);return true;
    }
    public static void damage(Player p,LivingEntity target,float amount,Entity projectile){
        if(!CombatRules.canHarm(p,target))return;
        target.hurt(new DamageSource(p.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(MAGIC_DAMAGE),projectile==null?p:projectile,p),amount);
    }
    public static boolean clearLine(ServerLevel level,Vec3 from,LivingEntity target,Entity context){
        return level.clip(new ClipContext(from,target.getEyePosition(),ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,context)).getType()==HitResult.Type.MISS;
    }
    public static void explode(Player p,Vec3 point,float damage,double radius,Entity source){
        var level=(ServerLevel)p.level();
        ItemStack weapon=source instanceof MagicBolt bolt?bolt.staff():p.getMainHandItem();
        radius+=ExtendedRuneEffects.staff(weapon,4)*0.1;final double range=radius;
        var targets=level.getEntitiesOfClass(LivingEntity.class,new AABB(point,point).inflate(radius),t->CombatRules.canHarm(p,t)&&t.position().distanceToSqr(point)<=range*range&&clearLine(level,point.add(0,0.3,0),t,p));
        targets.sort(Comparator.comparingDouble(t->t.distanceToSqr(point)));
        for(var target:targets.stream().limit(6).toList())damage(p,target,damage,source);
        CombatVisuals.at(level,point.add(0,0.5,0),ParticleTypes.FLAME,48,radius*0.4);
        CombatVisuals.at(level,point,ParticleTypes.EXPLOSION_EMITTER,1,0);
        CombatVisuals.ringAt(level,point,radius,ParticleTypes.END_ROD,36);
        level.playSound(null,point.x,point.y,point.z,SoundEvents.GENERIC_EXPLODE,net.minecraft.sounds.SoundSource.PLAYERS,0.55F,1.4F);
    }
    @SubscribeEvent public static void tick(PlayerTickEvent.Post e){
        Player p=e.getEntity();if(p.level().isClientSide()||p.getServer()==null)return;
        if(p.isAlive()&&Careers.profile(p).selected==3&&p.tickCount%20==0)restore(p,(float)(3+Careers.power(p)*0.5+ArmorRuneEffects.grade(p,EquipmentSlot.LEGS,6)*0.3+ExtendedRuneEffects.staff(p.getMainHandItem(),3)*0.4));
        var cast=METEORS.get(p.getUUID());if(cast==null)return;
        if(!p.isAlive()||ControlEffects.stunned(p)||p.getMainHandItem()!=cast.staff||!(cast.staff.getItem() instanceof MagicStaffItem)||!Careers.qualified(p,cast.staff)||p.containerMenu!=p.inventoryMenu){METEORS.remove(p.getUUID());return;}
        long left=cast.ready-p.level().getGameTime();var level=(ServerLevel)p.level();
        if(left>0){if(left%2==0){double a=left*Math.PI/3;if(left%4==0)CombatVisuals.ringAt(level,cast.point,3,ParticleTypes.END_ROD,36);CombatVisuals.at(level,cast.point.add(Math.cos(a)*2.5,0.2,Math.sin(a)*2.5),ParticleTypes.END_ROD,2,0);CombatVisuals.at(level,cast.point.add(0,Math.min(8,left*0.5),0),ParticleTypes.FLAME,14,0.4);}return;}
        METEORS.remove(p.getUUID());CombatVisuals.line(level,cast.point.add(0,8,0),cast.point,ParticleTypes.END_ROD,32);explode(p,cast.point,cast.damage,3,p);
    }
    @SubscribeEvent public static void logout(PlayerEvent.PlayerLoggedOutEvent e){METEORS.remove(e.getEntity().getUUID());}
    @SubscribeEvent public static void dimension(PlayerEvent.PlayerChangedDimensionEvent e){METEORS.remove(e.getEntity().getUUID());}
    @SubscribeEvent public static void death(LivingDeathEvent e){METEORS.remove(e.getEntity().getUUID());}
    @SubscribeEvent public static void stop(ServerStoppedEvent e){METEORS.clear();}
}
