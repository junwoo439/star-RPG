package com.junwo.starrpg;

import java.util.*;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.*;
import net.minecraft.world.effect.*;
import net.neoforged.bus.api.*;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.*;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

/** Equipment milestones are separate from profession milestones and use saved item data. */
@EventBusSubscriber(modid=StarRPG.MODID)
public final class WeaponAwakening {
    public static final String READY="starrpg_awakening_ready";
    public static final String[][] EFFECTS={
        {"기초 검술: 피해 +0.5","수호 검술: 적중 시 보호막 I 1초 / 8초","입문 무기는 +10까지","입문 무기는 +10까지","입문 무기는 +10까지"},
        {"기초 파쇄: 피해 +0.5","압박: 적중 시 약화 I 1.5초 / 8초","입문 무기는 +10까지","입문 무기는 +10까지","입문 무기는 +10까지"},
        {"암습: 후방 피해 +10%","신속: 적중 시 가속 I 1.5초 / 8초","Shift+R 그림자 절개: 돌진·전방 베기","깊은 암습: 후방 피해 추가 +10%","그림자 절개 강화: 피해 +25%·은신 2초"},
        {"단련: 최대 체력 +2","파쇄: 적중 시 약화 I 2초 / 8초","Shift+R 대지 파쇄: 4칸 충격파","담금질: 각성기에 보호막 I 3초","대지 파쇄 강화: 5칸·피해 +25%"},
        {"마력 그릇: 최대 마나 +10","응축: 기본 주문·유성 피해 +10%","Shift+R 성좌 광선: 18칸 / 25 MP","절약: 주문 마나 비용 -10%","성좌 광선 강화: 최대 3명·피해 +25%"},
        {"장병기: 근접 사거리 +0.3칸","틈새 찌르기: 피해 +1","Shift+R 성창 관통: 전방 6칸","숙련 장병기: 사거리 추가 +0.2칸","성창 관통 강화: 8칸·피해 +25%"},
        {"중량: 근접 피해 +1","광기: 내 체력 40% 미만 피해 +10%","Shift+R 붉은 소용돌이: 주변 4칸","피의 활력: 적중 시 최대 0.5 HP 회복 / 8초","소용돌이 강화: 피해 +25%·힘 II 2초"},
        {"축복: 최대 체력 +2","빛의 맥박: 적중 시 최대 0.5 HP 회복 / 8초","Shift+R 성역: 자신 4 HP 회복·주변 성광","정화: 성역이 독·위더·실명을 제거","성역 강화: 회복 6 HP·보호막 II 3초"},
        {"유령 걸음: 이동 속도 +2%","처형: 체력 40% 이하인 적에게 피해 +1","Shift+R 영혼 수확: 주변 피해·적중 회복","유령 걸음 강화: 이동 속도 추가 +2%","수확 강화: 회복 상한 4 HP·둔화 2초"},
        {"경량 주먹: 공격 속도 +3%","보법: 적중 시 가속 I 1.5초 / 8초","Shift+R 진공권: 전방 충격·둔화 1초","연환 숙련: 공격 속도 추가 +3%","진공권 강화: 피해 +25%·강한 밀치기"},
        {"강철 수호: 방어력 +1","방패 자세: 받는 피해 -5%","Shift+R 불굴 방벽: 저항 II 3초·밀치기","방패 자세 강화: 받는 피해 총 -10%","불굴 강화: 보호막 II 4초·피해 +25%"},
        {"정밀 사격: 완충 화살 피해 +5%","사냥 표식: 완충 명중 시 발광 1.5초 / 8초","Shift+R 별비: 화살 3개로 부채꼴 3발","정밀 사격 강화: 완충 피해 추가 +5%","별비 강화: 화살 5개로 부채꼴 5발"},
        {"강철 볼트: 화살 피해 +5%","장갑 관통: 방어력 8 이상 적에게 피해 +1","Shift+R 관통 포격: 화살 1개·최대 3명","장갑 관통 강화: 추가 피해 총 +2","관통 포격 강화: 최대 5명·피해 +25%"},
        {"해류: 자신이나 적이 젖으면 피해 +1","냉류: 충전 적중 시 둔화 I 1초 / 8초","Shift+R 해일: 주변 4칸 파동·수중 호흡","해류 강화: 젖은 전투 추가 피해 총 +2","해일 강화: 5칸·피해 +25%·적중 회복 1 HP"}
    };
    @SubscribeEvent public static void tooltip(net.neoforged.neoforge.event.entity.player.ItemTooltipEvent e){
        var w=e.getItemStack();int k=WeaponArt.kind(w);if(k<0)return;
        e.getToolTip().add(Component.literal("── 무기 강화 해금 ──").withStyle(net.minecraft.ChatFormatting.GOLD));
        int count=EnhancementData.unlimited(w)?5:2;
        for(int i=0;i<count;i++)e.getToolTip().add(Component.literal("+"+((i+1)*5)+" "+EFFECTS[k][i]).withStyle(stage(w)>i?net.minecraft.ChatFormatting.AQUA:net.minecraft.ChatFormatting.DARK_GRAY));
        if(count==5)e.getToolTip().add(Component.literal("Shift+R: 각성기 / 전용 직업 필요 · 삼지창 공용").withStyle(net.minecraft.ChatFormatting.GRAY));
    }
    public static void visual(Player p,ItemStack w){
        if(!(p.level() instanceof ServerLevel level))return;int k=WeaponArt.kind(w);if(k<0)return;
        ArcaneSigil.spawn(level,k==4?p.getEyePosition().add(p.getLookAngle()):p.position().add(0,0.08,0),p.getLookAngle(),k==4?1:0,WeaponArt.color(k),k==4?1.1F:1.8F,22);
        if(k==0||k==2||k==5||k==6||k==8||k==9)ArcaneSigil.spawn(level,p.getEyePosition().add(p.getLookAngle().scale(1.2)),p.getLookAngle(),2,WeaponArt.color(k),1.4F,14);
    }
    public static int stage(ItemStack w){return Math.min(5,EnhancementData.level(w)/5);}
    public static boolean allowed(Player p,ItemStack w){return WeaponArt.kind(w)>=0&&(Careers.tutorial(w)||w.getItem() instanceof TridentItem||Careers.qualified(p,w));}
    private static ItemStack sourceWeapon(net.minecraft.world.damagesource.DamageSource source,Player p){
        if(source.getDirectEntity() instanceof MagicBolt b)return b.staff();
        if(source.getDirectEntity() instanceof AbstractArrow a)return a.getWeaponItem()==null?ItemStack.EMPTY:a.getWeaponItem();
        return CombatRules.primary(source)||source.is(MagicSystem.MAGIC_DAMAGE)?p.getMainHandItem():ItemStack.EMPTY;
    }
    private static boolean charged(net.minecraft.world.damagesource.DamageSource source){
        if(source.getDirectEntity() instanceof AbstractArrow a)return !a.getPersistentData().contains("starrpg_shot_power")||a.getPersistentData().getFloat("starrpg_shot_power")>=0.9;
        return !CombatRules.primary(source)||CombatRules.charged(source);
    }
    @SubscribeEvent public static void damage(LivingIncomingDamageEvent e){
        if(e.getEntity().level().isClientSide())return;
        if(e.getEntity() instanceof Player defender&&allowed(defender,defender.getMainHandItem())&&WeaponArt.kind(defender.getMainHandItem())==10&&stage(defender.getMainHandItem())>=2
            &&!e.getSource().is(net.minecraft.tags.DamageTypeTags.BYPASSES_INVULNERABILITY))e.setAmount(e.getAmount()*(stage(defender.getMainHandItem())>=4?0.90F:0.95F));
        if(!(e.getSource().getEntity() instanceof Player p)||e.getSource().is(CombatRules.RUNE))return;
        var w=sourceWeapon(e.getSource(),p);int s=stage(w),k=WeaponArt.kind(w);if(s==0||!allowed(p,w)||!charged(e.getSource())||!CombatRules.canHarm(p,e.getEntity()))return;
        float add=0,multiply=1;var target=e.getEntity();
        switch(k){
            case 0,1->add=0.5F;
            case 2->{if(SpecialWeaponEffects.behind(p,target))multiply+=s>=4?0.2F:0.1F;}
            case 4->{if(s>=2&&e.getSource().is(MagicSystem.MAGIC_DAMAGE))multiply+=0.1F;}
            case 5->{if(s>=2)add=1;}
            case 6->{add=1;if(s>=2&&p.getHealth()<p.getMaxHealth()*0.4F)multiply+=0.1F;}
            case 8->{if(s>=2&&target.getHealth()<=target.getMaxHealth()*0.4F)add=1;}
            case 11->multiply+=s>=4?0.1F:0.05F;
            case 12->{multiply+=0.05F;if(s>=2&&target.getArmorValue()>=8)add=s>=4?2:1;}
            case 13->{if(p.isInWaterOrRain()||target.isInWaterOrRain())add=s>=4?2:1;}
        }
        e.setAmount(e.getAmount()*multiply+add);
    }
    @SubscribeEvent public static void hit(LivingDamageEvent.Post e){
        if(e.getEntity().level().isClientSide()||e.getNewDamage()<=0||!(e.getSource().getEntity() instanceof Player p)||e.getSource().is(CombatRules.RUNE))return;
        var w=sourceWeapon(e.getSource(),p);int s=stage(w),k=WeaponArt.kind(w);if(s<2||!allowed(p,w)||!charged(e.getSource())||!CombatRules.canHarmDead(p,e.getEntity()))return;
        if(!Set.of(0,1,2,3,6,7,9,11,13).contains(k)||(k==6&&s<4))return;
        long now=p.level().getGameTime();if(p.getPersistentData().getLong("starrpg_weapon_proc")>now)return;p.getPersistentData().putLong("starrpg_weapon_proc",now+160);
        switch(k){
            case 0->p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,20,0));
            case 1,3->e.getEntity().addEffect(new MobEffectInstance(MobEffects.WEAKNESS,k==1?30:40,0));
            case 2,9->p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED,30,0));
            case 6,7->p.heal(Math.min(0.5F,e.getNewDamage()*0.1F));
            case 11->e.getEntity().addEffect(new MobEffectInstance(MobEffects.GLOWING,30,0));
            case 13->e.getEntity().addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,20,0));
        }
    }
    private static void attr(Player p,net.minecraft.core.Holder<Attribute> a,String name,double value,AttributeModifier.Operation op){
        var instance=p.getAttribute(a);if(instance==null)return;var id=ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,name);
        if(value==0){instance.removeModifier(id);return;}var old=instance.getModifier(id);if(old==null||old.amount()!=value)instance.addOrUpdateTransientModifier(new AttributeModifier(id,value,op));
    }
    public static void attributes(Player p){
        var w=p.getMainHandItem();int s=allowed(p,w)?stage(w):0,k=WeaponArt.kind(w);
        attr(p,Attributes.MAX_HEALTH,"awakening_health",s>0&&(k==3||k==7)?2:0,AttributeModifier.Operation.ADD_VALUE);
        attr(p,Attributes.ARMOR,"awakening_armor",s>0&&k==10?1:0,AttributeModifier.Operation.ADD_VALUE);
        attr(p,Attributes.ENTITY_INTERACTION_RANGE,"awakening_reach",s>0&&k==5?(s>=4?0.5:0.3):0,AttributeModifier.Operation.ADD_VALUE);
        attr(p,Attributes.ATTACK_SPEED,"awakening_haste",s>0&&k==9?(s>=4?0.06:0.03):0,AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
        attr(p,Attributes.MOVEMENT_SPEED,"awakening_speed",s>0&&k==8?(s>=4?0.04:0.02):0,AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
        p.setHealth(Math.min(p.getHealth(),p.getMaxHealth()));
    }
    @SubscribeEvent public static void tick(PlayerTickEvent.Post e){if(!e.getEntity().level().isClientSide()&&e.getEntity().tickCount%5==0)attributes(e.getEntity());}
    public static int staffMana(Player p){return allowed(p,p.getMainHandItem())&&WeaponArt.kind(p.getMainHandItem())==4&&stage(p.getMainHandItem())>=1?10:0;}
    public static double manaFactor(Player p){return allowed(p,p.getMainHandItem())&&WeaponArt.kind(p.getMainHandItem())==4&&stage(p.getMainHandItem())>=4?0.9:1;}
    private static ItemStack ammo(Player p){return p.getInventory().items.stream().filter(w->w.getItem() instanceof ArrowItem).findFirst().orElse(ItemStack.EMPTY);}
    public static int arrowCount(Player p){return p.getInventory().items.stream().filter(w->w.getItem() instanceof ArrowItem).mapToInt(ItemStack::getCount).sum();}
    public static boolean activate(Player p){
        if(p.level().isClientSide()||!p.isAlive()||p.isSpectator()||ControlEffects.rooted(p)||p.hasEffect(ModEffects.COMBO)||p.hasEffect(ModEffects.BRACED)||p.containerMenu!=p.inventoryMenu)return false;
        var w=p.getMainHandItem();int s=stage(w),k=WeaponArt.kind(w);
        if(s<3||!EnhancementData.unlimited(w)||!allowed(p,w)){p.displayClientMessage(Component.literal("각성기: 해당 직업의 +15 이상 전문 무기가 필요합니다."),true);return false;}
        long now=p.level().getGameTime();if(p.getPersistentData().getLong(READY)>now){p.displayClientMessage(Component.literal("각성기 "+MagicSystem.cooldown(p,READY)),true);return false;}
        int arrows=k==11?(s>=5?5:3):k==12?1:0;
        if(arrows>0&&!p.hasInfiniteMaterials()&&arrowCount(p)<arrows){p.displayClientMessage(Component.literal("인벤토리에 화살 "+arrows+"개가 필요합니다."),true);return false;}
        if(k==4&&MagicSystem.mana(p)<25){p.displayClientMessage(Component.literal("성좌 광선: 25 MP 필요"),true);return false;}
        // Reserve the player-wide cooldown before dealing damage or spawning any projectile.
        p.getPersistentData().putLong(READY,now+(k==4||k==10?400:300));WeaponAbilities.cancel(p);p.stopUsingItem();
        if(k==4)p.getPersistentData().putFloat("starrpg_mana",MagicSystem.mana(p)-25);
        var level=(ServerLevel)p.level();int color=WeaponArt.color(k);float damage=(float)(7+EnhancementData.power(w)*0.4)*(s>=5?1.25F:1);
        double radius=k==4?18:k==5?(s>=5?8:6):k==2?3:k==9?5:s>=5&&(k==3||k==13)?5:4;
        boolean cone=k==2||k==5||k==9||k==10||k==4;
        if(arrows>0){
            for(int i=0;i<arrows;i++){
                var actual=ammo(p);var round=actual.isEmpty()?new ItemStack(Items.ARROW):actual.copyWithCount(1);
                var arrow=new GiantArrow(level,p,round,w.copyWithCount(1));arrow.getPersistentData().putBoolean("starrpg_awakened_arrow",true);
                arrow.getPersistentData().putInt("starrpg_awakened_pierce",k==12?(s>=5?4:2):0);arrow.setBaseDamage(k==12?(s>=5?3.5:2.8):1.8);
                arrow.shootFromRotation(p,p.getXRot(),p.getYRot()+(i-(arrows-1)/2F)*8,0,3,0);
                if(level.addFreshEntity(arrow)&&!p.hasInfiniteMaterials())actual.shrink(1);
            }
            ArcaneSigil.spawn(level,p.getEyePosition().add(p.getLookAngle()),p.getLookAngle(),1,color,1.2F,26);
        }else{
            var targets=level.getEntitiesOfClass(LivingEntity.class,p.getBoundingBox().inflate(radius),t->CombatRules.canHarm(p,t)&&p.hasLineOfSight(t)&&p.distanceToSqr(t)<=radius*radius
                &&(!cone||p.getLookAngle().dot(t.getEyePosition().subtract(p.getEyePosition()).normalize())>=(k==4?0.985:k==5?0.88:0.3))
                &&(k!=3||t.onGround()&&Math.abs(t.getY()-p.getY())<1.5));
            targets.sort(Comparator.comparingDouble(t->p.distanceToSqr(t)));int limit=k==4?(s>=5?3:1):6,hits=0;
            for(var t:targets.stream().limit(limit).toList()){
                float before=t.getHealth();CombatRules.runeDamage(p,t,damage*(k==7?0.65F:k==10?0.6F:1));
                if(t.getHealth()<before){hits++;
                    if(k==3||k==10||k==13||(k==9&&s>=5)){t.knockback(k==10?0.8:0.4,p.getX()-t.getX(),p.getZ()-t.getZ());t.hurtMarked=true;}
                    if(k==9||k==8&&s>=5)t.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,k==9?20:40,0));
                }
            }
            if(k==2){p.setDeltaMovement(p.getDeltaMovement().add(p.getLookAngle().multiply(1,0,1).normalize().scale(0.8)));p.hurtMarked=true;if(s>=5)p.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY,40,0));}
            if(k==3&&s>=4)p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,60,0));
            if(k==6&&s>=5)p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,40,1));
            if(k==7){p.heal(s>=5?6:4);if(s>=4){p.removeEffect(MobEffects.POISON);p.removeEffect(MobEffects.WITHER);p.removeEffect(MobEffects.BLINDNESS);}if(s>=5)p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,60,1));}
            if(k==8)p.heal(Math.min(s>=5?4:2,hits));
            if(k==10){p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,60,1));if(s>=5)p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,80,1));}
            if(k==13){p.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING,100,0));if(s>=5&&hits>0)p.heal(1);}
            ArcaneSigil.spawn(level,k==4?p.getEyePosition().add(p.getLookAngle()):p.position().add(0,0.12,0),p.getLookAngle(),k==4?1:0,color,k==4?2:(float)radius,32);
            if(k==2||k==5||k==6||k==8||k==9)ArcaneSigil.spawn(level,p.position().add(p.getLookAngle().scale(1.5)).add(0,1,0),p.getLookAngle(),2,color,2,18);
            if(k==4){var hit=p.pick(18,0,false);var end=hit.getType()==net.minecraft.world.phys.HitResult.Type.MISS?p.getEyePosition().add(p.getLookAngle().scale(18)):hit.getLocation();CombatVisuals.line(level,p.getEyePosition(),end,ParticleTypes.END_ROD,48);}
        }
        w.hurtAndBreak(1,p,EquipmentSlot.MAINHAND);p.swing(net.minecraft.world.InteractionHand.MAIN_HAND,true);CareerMilestones.onSkill(p);
        CombatVisuals.sound(p,net.minecraft.sounds.SoundEvents.AMETHYST_BLOCK_CHIME,0.8F,k==3?0.5F:1.2F);return true;
    }
}
