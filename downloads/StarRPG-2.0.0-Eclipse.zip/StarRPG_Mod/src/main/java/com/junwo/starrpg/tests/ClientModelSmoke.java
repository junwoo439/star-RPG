package com.junwo.starrpg.tests;

import com.junwo.starrpg.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.*;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

@EventBusSubscriber(modid=StarRPG.MODID,value=Dist.CLIENT)
public final class ClientModelSmoke {
    private static int ticks;private static boolean checked,captured;
    private static Item[] items(){return new Item[]{Items.IRON_SWORD,Items.IRON_AXE,StarRPG.STAR_DAGGER.get(),StarRPG.WAR_HAMMER.get(),StarRPG.MAGIC_STAFF.get(),StarRPG.STAR_SPEAR.get(),StarRPG.BERSERKER_BLADE.get(),StarRPG.SUN_SCEPTER.get(),StarRPG.SOUL_SCYTHE.get(),StarRPG.STAR_GAUNTLET.get(),StarRPG.AEGIS_BLADE.get(),Items.BOW,Items.CROSSBOW,Items.TRIDENT};}
    @SubscribeEvent public static void tick(ClientTickEvent.Post event){
        if(!Boolean.getBoolean("starrpg.clientSmoke"))return;
        var mc=Minecraft.getInstance();if(mc.getOverlay()!=null||mc.screen==null)return;
        if(!checked){
            for(Item weapon:items()){
                var model=mc.getItemRenderer().getModel(new ItemStack(weapon),null,null,0);
                if(model==mc.getModelManager().getMissingModel()||!model.isCustomRenderer()
                    ||!(net.neoforged.neoforge.client.extensions.common.IClientItemExtensions.of(weapon).getCustomRenderer() instanceof ArtisanItemRenderer))throw new IllegalStateException("Painted renderer missing: "+weapon);
                StarRPG.LOGGER.info("CLIENT_ART_CHECK PASSED: {}",weapon);
            }
            checked=true;mc.options.guiScale().set(1);mc.resizeDisplay();mc.setScreen(new Preview());return;
        }
        if(++ticks>=80&&!captured){captured=true;Screenshot.grab(mc.gameDirectory,"starrpg-2.0-art-check.png",mc.getMainRenderTarget(),message->{StarRPG.LOGGER.info("CLIENT_ART_SCREENSHOT: {}",message.getString());mc.execute(mc::stop);});}
    }
    private static final class Preview extends Screen {
        Preview(){super(Component.literal("StarRPG art verification"));}
        @Override public void render(GuiGraphics g,int x,int y,float partial){
            g.fillGradient(0,0,width,height,0xFF111A2D,0xFF181025);
            g.drawCenteredString(font,"StarRPG 2.0 - painted weapons & animated sigils",width/2,15,0xF0D8FF);
            String[] names={"Sword","Axe","Dagger","Hammer","Magic staff","Spear","Greatblade","Sun scepter","Soul scythe","Gauntlets","Aegis blade","Bow","Crossbow","Trident"};
            for(int i=0;i<14;i++){int bx=width/2-371+(i%7)*106,by=38+(i/7)*130;
                g.fill(bx,by,bx+100,by+124,0xFF0B1220);g.pose().pushPose();g.pose().translate(bx+10,by+5,0);g.pose().scale(5,5,5);g.renderItem(new ItemStack(items()[i]),0,0);g.pose().popPose();g.drawCenteredString(font,names[i],bx+50,by+110,0xC8D7EF);
            }
            g.flush();var buffers=Minecraft.getInstance().renderBuffers().bufferSource();
            for(int i=0;i<3;i++){g.pose().pushPose();g.pose().translate(width/2-240+i*240,365,100);g.pose().scale(38,-38,38);
                ArcaneSigilRenderer.draw(g.pose(),buffers,i==2?2:1,i==0?0xFFA050:i==1?0x75D8FF:0xBA8CFF,1.5F,ticks%20+8,45,-30,-18);buffers.endBatch();g.pose().popPose();}
            g.drawCenteredString(font,"Forge / constellation beam / soul crescent - same renderer used in combat",width/2,height-20,0xB9D5DC);
        }
    }
}
