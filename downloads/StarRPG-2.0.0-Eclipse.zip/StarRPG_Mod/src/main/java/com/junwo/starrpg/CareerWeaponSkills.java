package com.junwo.starrpg;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.effect.*;

public final class CareerWeaponSkills {
    public static boolean activate(Player p){
        if(p.level().isClientSide()||!p.isAlive()||p.isSpectator()||ControlEffects.stunned(p)||p.containerMenu!=p.inventoryMenu
                ||!(p.getMainHandItem().getItem() instanceof CareerWeaponItem w)||!Careers.qualified(p,p.getMainHandItem()))return false;
        long now=p.level().getGameTime();
        if(p.getPersistentData().getLong("starrpg_professional_ready")>now){p.displayClientMessage(Component.literal("R: "+MagicSystem.cooldown(p,"starrpg_professional_ready")),true);return false;}
        int job=w.job;double radius=job==0?4.5:job==6?5:job==8?2.8:3.5;
        var targets=p.level().getEntitiesOfClass(LivingEntity.class,p.getBoundingBox().inflate(radius),t->CombatRules.canHarm(p,t)&&p.hasLineOfSight(t)&&p.distanceToSqr(t)<=radius*radius
            &&(job==5||job==6||job==7||p.getLookAngle().dot(t.getEyePosition().subtract(p.getEyePosition()).normalize())>=(job==0?0.9:0.3)));
        targets.sort(java.util.Comparator.comparingDouble(t->p.distanceToSqr(t)));
        float damage=(float)(p.getAttributeValue(Attributes.ATTACK_DAMAGE)*0.9+EnhancementData.power(p.getMainHandItem())*0.5);
        if(job==5)damage*=p.getHealth()<p.getMaxHealth()*0.4?1.4F:1.1F;
        if(job==6){p.removeEffect(MobEffects.POISON);p.removeEffect(MobEffects.WITHER);p.heal(3);damage*=0.6F;}
        int hits=0;for(var t:targets.stream().limit(job==0?3:6).toList()){
            float before=t.getHealth();CombatRules.runeDamage(p,t,damage);
            if(t.getHealth()<before){hits++;if(job==9)t.knockback(1,p.getX()-t.getX(),p.getZ()-t.getZ());
                if(job==8)t.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,30,0));}
        }
        if(job==7&&hits>0)p.heal(Math.min(4,hits));
        var particles=job==6?ParticleTypes.END_ROD:job==7?ParticleTypes.SOUL:job==9?ParticleTypes.WAX_ON:ParticleTypes.CRIT;
        if(job==0)CombatVisuals.line((ServerLevel)p.level(),p.getEyePosition(),p.getEyePosition().add(p.getLookAngle().scale(radius)),particles,24);
        else CombatVisuals.circle(p,radius,particles);
        WeaponAbilities.arc(p,Math.min(3,radius),job);p.swing(net.minecraft.world.InteractionHand.MAIN_HAND,true);
        p.getMainHandItem().hurtAndBreak(1,p,net.minecraft.world.entity.EquipmentSlot.MAINHAND);
        p.getPersistentData().putLong("starrpg_professional_ready",now+(job==6?200:job==8?120:160));
        WeaponAwakening.visual(p,p.getMainHandItem());CareerMilestones.onSkill(p);return true;
    }
}
