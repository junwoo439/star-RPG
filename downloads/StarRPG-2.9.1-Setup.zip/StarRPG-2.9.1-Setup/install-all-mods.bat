@echo off
chcp 65001 >nul
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-dragon-mods.ps1" -IncludeAdventure
if errorlevel 1 (
  echo Installation failed. Existing files were preserved or restored.
  pause
  exit /b 1
)
echo Install all eight JARs from mods on BOTH the server and every client.
pause
