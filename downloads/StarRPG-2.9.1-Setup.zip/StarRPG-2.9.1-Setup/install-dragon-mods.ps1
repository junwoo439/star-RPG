param([string]$TargetDirectory = (Join-Path $PSScriptRoot 'mods'), [switch]$IncludeAdventure)
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Add-Type -AssemblyName System.IO.Compression.FileSystem
$manifest = Get-Content -Raw (Join-Path $PSScriptRoot 'dragon-mods-lock.json') | ConvertFrom-Json
$target = [IO.Path]::GetFullPath($TargetDirectory)
$stage = Join-Path $PSScriptRoot '.dragon-downloads'
[IO.Directory]::CreateDirectory($target) | Out-Null
[IO.Directory]::CreateDirectory($stage) | Out-Null
$artifacts = @($manifest.files)
if ($IncludeAdventure) {
    $adventure = Get-Content -Raw (Join-Path $PSScriptRoot 'adventure-mods-lock.json') | ConvertFrom-Json
    $artifacts += @($adventure.files)
    $unique = @{}
    foreach ($row in $artifacts) {
        if ($unique.ContainsKey($row.filename) -and $unique[$row.filename].sha512 -ne $row.sha512) { throw ('Conflicting pinned artifact: ' + $row.filename) }
        $unique[$row.filename] = $row
    }
    $artifacts = @($unique.Values | Sort-Object filename)
}
if ($manifest.starrpg) { $artifacts += $manifest.starrpg }
function Test-Artifact($path, $row) {
    return (Test-Path -LiteralPath $path) -and ((Get-Item -LiteralPath $path).Length -eq [long]$row.size) -and ((Get-FileHash -LiteralPath $path -Algorithm SHA512).Hash.ToLowerInvariant() -eq $row.sha512)
}
function Get-ModIds($path) {
    $zip = [IO.Compression.ZipFile]::OpenRead($path)
    try {
        $entry = $zip.GetEntry('META-INF/neoforge.mods.toml')
        if (-not $entry) { $entry = $zip.GetEntry('META-INF/mods.toml') }
        if (-not $entry) { return @() }
        $reader = [IO.StreamReader]::new($entry.Open())
        try { $text = $reader.ReadToEnd() } finally { $reader.Dispose() }
        $ids = @()
        foreach ($block in [regex]::Matches($text, '(?s)\[\[mods\]\](.*?)(?=\[\[|\z)')) {
            $match = [regex]::Match($block.Groups[1].Value, '(?m)^\s*modId\s*=\s*["'']([^"'']+)["'']')
            if ($match.Success) { $ids += $match.Groups[1].Value }
        }
        return $ids
    } finally { $zip.Dispose() }
}
# Verify every download before changing an existing mods directory.
foreach ($row in $artifacts) {
    if ($row.filename -notmatch '^[A-Za-z0-9._+\-]+\.jar$' -or $row.sha512 -notmatch '^[a-f0-9]{128}$') { throw 'Invalid pinned artifact' }
    $cached = Join-Path $stage $row.filename
    $local = Join-Path $PSScriptRoot $row.filename
    if ((Test-Artifact $local $row) -and -not (Test-Artifact $cached $row)) { Copy-Item -LiteralPath $local -Destination $cached -Force }
    if (-not (Test-Artifact $cached $row)) {
        $uri = [Uri]$row.url
        if ($uri.Scheme -ne 'https' -or $uri.Host -notin @('cdn.modrinth.com', 'github.com', 'raw.githubusercontent.com')) { throw 'Unexpected artifact host' }
        Write-Host ('Downloading ' + $row.filename)
        $partial = $cached + '.part'
        try {
            Invoke-WebRequest -UseBasicParsing -Uri $row.url -OutFile $partial -UserAgent 'StarRPG/2.9.1 dragon installer'
            if (-not (Test-Artifact $partial $row)) { throw ('Checksum mismatch: ' + $row.filename) }
            Move-Item -LiteralPath $partial -Destination $cached -Force
        } finally { if (Test-Path -LiteralPath $partial) { Remove-Item -LiteralPath $partial } }
    }
    $ids = @(Get-ModIds $cached)
    foreach ($expected in $row.modIds) { if ($expected -notin $ids) { throw ('Wrong loader/mod ID: ' + $row.filename) } }
}
$allIds = @($artifacts | ForEach-Object { $_.modIds })
$backup = Join-Path $PSScriptRoot ('dragon-mod-backup-' + [DateTime]::Now.ToString('yyyyMMdd-HHmmss-fff'))
$moved = @(); $installed = @()
try {
    foreach ($file in @(Get-ChildItem -LiteralPath $target -Filter '*.jar' -File)) {
        $ids = @(Get-ModIds $file.FullName)
        if (@($ids | Where-Object { $_ -in $allIds }).Count -gt 0) {
            [IO.Directory]::CreateDirectory($backup) | Out-Null
            $saved = Join-Path $backup $file.Name
            Move-Item -LiteralPath $file.FullName -Destination $saved
            $moved += [PSCustomObject]@{ Original=$file.FullName; Saved=$saved }
        }
    }
    foreach ($row in $artifacts) {
        $destination = Join-Path $target $row.filename
        if (Test-Path -LiteralPath $destination) { throw ('Unexpected conflicting file: ' + $destination) }
        Copy-Item -LiteralPath (Join-Path $stage $row.filename) -Destination $destination
        $installed += $destination
    }
} catch {
    foreach ($path in $installed) { Remove-Item -LiteralPath $path -ErrorAction SilentlyContinue }
    foreach ($item in $moved) { Move-Item -LiteralPath $item.Saved -Destination $item.Original -Force }
    throw
}
Write-Host ('Verified installation complete: ' + $target)
Write-Host ('Minecraft 1.21.1 / NeoForge 21.1.235 / Java 21. Install all ' + $artifacts.Count + ' verified JARs on server and all clients.')
