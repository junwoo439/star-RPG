@echo off
setlocal
pushd "%~dp0"
echo Preparing StarRPG for Eclipse. JDK 21 and Internet access are required.
call gradlew.bat -Declipse.application=org.eclipse.ui.ide.workbench eclipse neoForgeIdeSync prepareClientRun
if errorlevel 1 goto failed
echo.
echo Setup complete. Import this folder as an Existing Gradle Project in Eclipse.
echo Refresh Gradle Project, press F5, then run Java Application: StarRPG Client.
popd
pause
exit /b 0
:failed
echo.
echo Setup failed. Read the error above. Check JDK 21 and your Internet connection.
popd
pause
exit /b 1
