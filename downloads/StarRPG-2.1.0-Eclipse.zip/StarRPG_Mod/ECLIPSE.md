# Eclipse에서 StarRPG 실행하기

이 프로젝트는 StarRPG 2.1.0 수정 소스 전체를 포함합니다. Eclipse에서 Minecraft 클라이언트를 실행하고 **싱글플레이**로 테스트할 수 있습니다. 별도 서버 실행이나 서버 접속은 필요하지 않습니다.

## 처음 한 번 설정

1. ZIP을 새 폴더(예: `D:\StarRPG_Eclipse`)에 풉니다. `build.gradle`과 `src`가 있는 폴더가 프로젝트 폴더입니다. 기존 프로젝트와 월드는 보관하세요.
2. Java 21을 지원하는 최신 **Eclipse IDE for Java Developers**와 **JDK 21**을 사용합니다. Eclipse의 `Window > Preferences > Java > Installed JREs`에서 JDK 21을 등록하고 선택합니다. Eclipse 자체를 더 최신 Java로 실행하더라도 이 프로젝트의 Gradle JVM은 JDK 21로 지정합니다.
3. `File > Import > Gradle > Existing Gradle Project`에서 프로젝트 폴더를 선택합니다. Gradle distribution은 **Gradle wrapper**, Java home은 **JDK 21**로 지정하고 Finish를 누릅니다. Gradle 메뉴가 없다면 Eclipse Marketplace에서 **Buildship Gradle Integration**을 설치합니다.
4. 첫 동기화는 Minecraft/NeoForge 라이브러리와 게임 리소스를 다운로드하므로 인터넷 연결이 필요하며 시간이 걸립니다. 완료되면 프로젝트를 우클릭하여 `Gradle > Refresh Gradle Project`, 이어서 F5를 누릅니다.
5. `Run > Run Configurations > Java Application > StarRPG Client`를 선택하고 **Run**을 누릅니다. **Project > Build Automatically**가 켜져 있어야 수정한 코드가 반영됩니다.
6. 게임이 열리면 **Singleplayer(싱글플레이) > Create New World(새로운 세계 만들기)**를 선택합니다. 강화 테스트 명령어를 쓰려면 치트를 허용하세요.

기존 `StarRPG_Mod`가 이미 Eclipse에 등록되어 이름이 충돌하면 `File > Switch Workspace > Other`에서 새 작업 공간을 사용한 뒤 가져오세요. 기존 프로젝트 폴더를 지울 필요는 없습니다.

## 실행 항목이 보이지 않을 때

프로젝트 폴더에서 `setup-eclipse.bat`을 실행합니다. JAVA_HOME 또는 PATH에 JDK 21이 필요합니다. 성공 후 Eclipse에서 `Gradle > Refresh Gradle Project`와 F5를 누르고 위의 실행 항목을 다시 확인합니다. `.launch` 파일은 PC 경로에 맞춰 생성되므로 다른 PC의 생성 파일을 복사하지 마세요.

Eclipse의 `Window > Show View > Other > Gradle > Gradle Tasks`에서 프로젝트의 **runClient** 작업을 실행해도 게임이 열립니다. 목록이 비어 있으면 Gradle Tasks의 새로 고침을 누릅니다. 터미널에서는 `gradlew.bat runClient`를 사용합니다.

## 저장 위치와 추가 모드

- 테스트 월드: `run-client/saves`
- 게임 설정과 로그: `run-client/config`, `run-client/logs/latest.log`
- 추가 모드: `run-client/mods` (Minecraft 1.21.1 / NeoForge 호환 파일)
- StarRPG는 프로젝트 소스에서 자동 로드됩니다. `run-client/mods`에 별도 StarRPG JAR을 넣으면 중복되므로 넣지 마세요.
- `setup-adventure-eclipse.bat`으로 Twilight Forest, Mowzie, GeckoLib을 검증한 버전으로 자동 설치하고 Eclipse 실행 준비를 할 수 있습니다. StarRPG 자체는 추가 모드 없이도 실행할 수 있습니다.

현재 PC의 기존 월드를 자동으로 가져오지 않습니다. 새 테스트 월드를 만들어 확인하세요. 기존 강화 장비를 이전하는 방법과 밸런스 설정은 `BALANCE.md`에 있습니다.

Twilight Forest·Mowzie·GeckoLib만 설치하려면 `install-adventure-mods.bat` 또는 Gradle `installAdventureMods` 작업을 사용합니다. 현재 설치/검증 상태와 Ice and Fire의 호환 제한은 `MODS-1.5.1.md`를 확인하세요.

## 테스트 명령어

치트를 허용한 테스트 월드에서 장비를 손에 들고 `/starrpg setlevel 10`을 입력하면 강화 10단계를 설정합니다. `/starrpg difficulty`로 월드 단계와 누적 생존 시간을 확인합니다. `/starrpg worldtier 20`로 테스트 단계를 바꿀 수 있습니다. 기존 몬스터는 높은 단계로만 올라가므로 낮은 단계 비교는 **새로 소환한 몬스터**로 하세요. 자세한 테스트는 `TESTING-2.1.md`를 참고하세요.

`gradlew.bat build`로 배포 JAR을 만들 수 있습니다. `gradlew.bat runGameTestServer`는 개발자용 자동 테스트이며, 싱글플레이 실행에는 필요하지 않습니다.

2.1의 새 기능은 Shift+H 메뉴에서 시작합니다. R은 무기 능력, G는 직업 능력입니다. 새 수치와 인챈트 제거 정책은 BALANCE-2.1.md를 확인하세요.

전직 보상은 직업 확정 후 `/starrpg rank 6`, `/starrpg rank 11`, `/starrpg rank 16`으로 빠르게 확인할 수 있습니다. 전문 무기는 `/starrpg setlevel 100`도 지원합니다.

2.0의 새 무기 각성은 전문 무기를 든 채 `/starrpg setlevel 15` 후 Shift+R입니다. +20·25 단계에서 추가 능력을 확인하세요.
