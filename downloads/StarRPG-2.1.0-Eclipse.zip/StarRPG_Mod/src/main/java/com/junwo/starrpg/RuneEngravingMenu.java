package com.junwo.starrpg;

import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;

public class RuneEngravingMenu extends AbstractContainerMenu {

    private final Player owner;
    private final SimpleContainer engravingInventory = new SimpleContainer(2);

    public RuneEngravingMenu(int containerId, Inventory playerInventory) {
        super(ModMenus.RUNE_ENGRAVING_MENU.get(), containerId);
        owner=playerInventory.player;

        // 0번: 검, 도끼 또는 플레이어 방어구
        this.addSlot(new Slot(engravingInventory, 0, 53, 35) {
            @Override
            public boolean mayPlace(ItemStack stack) {
                return RuneWeaponType.forItem(stack) != null;
            }

            @Override
            public int getMaxStackSize() {
                return 1;
            }
        });

        // 1번: 별의 룬
        this.addSlot(new Slot(engravingInventory, 1, 107, 35) {
            @Override
            public boolean mayPlace(ItemStack stack) {
                return RuneItemHelper.isRune(stack);
            }

            @Override
            public int getMaxStackSize() {
                return 1;
            }
        });

        // 플레이어 인벤토리
        for (int row = 0; row < 3; row++) {
            for (int column = 0; column < 9; column++) {
                this.addSlot(new Slot(
                        playerInventory,
                        column + row * 9 + 9,
                        79 + column * 18,
                        142 + row * 18
                ));
            }
        }

        // 핫바
        for (int column = 0; column < 9; column++) {
            this.addSlot(new Slot(
                    playerInventory,
                    column,
                    79 + column * 18,
                    200
            ));
        }
    }

    @Override
    public boolean stillValid(Player player) {
        return player==owner && player.isAlive();
    }

    @Override
    public void removed(Player player) {
        super.removed(player);
        this.clearContainer(player, engravingInventory);
    }
    @Override
    public boolean clickMenuButton(Player player, int buttonId) {
        if (player.level().isClientSide() || buttonId != 0 || player!=owner || !player.isAlive() || player.isSpectator() || ControlEffects.stunned(player)) {
            return false;
        }

        ItemStack weapon = engravingInventory.getItem(0);
        ItemStack rune = engravingInventory.getItem(1);

        if (weapon.isEmpty()) {
            player.sendSystemMessage(
                    net.minecraft.network.chat.Component.literal(
                            "각인할 무기 또는 방어구를 넣어 주세요."
                    )
            );
            return false;
        }

        if (rune.isEmpty()) {
            player.sendSystemMessage(
                    net.minecraft.network.chat.Component.literal(
                            "별의 룬을 넣어 주세요."
                    )
            );
            return false;
        }

        RuneWeaponType weaponType = RuneWeaponType.forItem(weapon);
        if (weaponType == null) {
            player.sendSystemMessage(net.minecraft.network.chat.Component.literal("검·도끼·활·석궁·삼지창·지팡이·방어구에 각인할 수 있습니다."));
            return false;
        }

        RuneRarity rarity = RuneItemHelper.getRarity(rune);

        if (rarity == null) {
            player.sendSystemMessage(
                    net.minecraft.network.chat.Component.literal(
                            "올바른 별의 룬을 넣어 주세요."
                    )
            );
            return false;
        }

        RuneEffect effect = RuneEffectManager.getRandomEffect(
                rarity,
                weaponType,
                player.getRandom()
        );

        if (effect == null) {
            player.sendSystemMessage(
                    net.minecraft.network.chat.Component.literal(
                            "룬 효과를 찾지 못했습니다."
                    )
            );
            return false;
        }

        RuneDataHelper.setRuneEffect(weapon, effect);
        net.minecraft.world.item.component.CustomData.update(net.minecraft.core.component.DataComponents.CUSTOM_DATA,weapon,t->t.remove("starrpg_bow_element"));
        EnhancementLore.update(weapon);
        rune.shrink(1);

        player.sendSystemMessage(
                net.minecraft.network.chat.Component.literal(
                        effect.getRarity().getKoreanName()
                                + " 효과 각인: "
                                + effect.getKoreanName()
                )
        );

        this.broadcastChanges();
        return true;
    }

    @Override
    public ItemStack quickMoveStack(Player player, int slotIndex) {
        if (slotIndex < 0 || slotIndex >= slots.size()) return ItemStack.EMPTY;
        Slot slot = slots.get(slotIndex);
        if (!slot.hasItem()) return ItemStack.EMPTY;
        ItemStack stack = slot.getItem();
        ItemStack original = stack.copy();
        if (slotIndex < 2) {
            if (!moveItemStackTo(stack, 2, slots.size(), true)) return ItemStack.EMPTY;
        } else if (RuneItemHelper.isRune(stack)) {
            if (!moveItemStackTo(stack, 1, 2, false)) return ItemStack.EMPTY;
        } else if (RuneWeaponType.forItem(stack) != null) {
            if (!moveItemStackTo(stack, 0, 1, false)) return ItemStack.EMPTY;
        } else return ItemStack.EMPTY;
        if (stack.isEmpty()) slot.set(ItemStack.EMPTY); else slot.setChanged();
        if (stack.getCount() == original.getCount()) return ItemStack.EMPTY;
        slot.onTake(player, stack);
        return original;
    }
}
