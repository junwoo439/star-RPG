package com.junwo.starrpg;

import net.minecraft.core.component.DataComponents;
import net.minecraft.core.Holder;
import net.minecraft.world.item.*;
import net.minecraft.world.item.enchantment.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.*;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.*;
import net.neoforged.neoforge.event.enchanting.EnchantmentLevelSetEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.player.AttackEntityEvent;
import net.neoforged.neoforge.event.tick.*;

/** Lazy migration: active equipment, dropped items and opened slots lose vanilla enchantments. */
@EventBusSubscriber(modid=StarRPG.MODID)
public final class VanillaEnchantments {
    private static boolean vanilla(Holder<Enchantment> holder){return holder.unwrapKey().map(k->k.location().getNamespace().equals("minecraft")).orElse(false);}
    public static boolean strip(ItemStack stack){
        if(stack.isEmpty()||!Config.NO_VANILLA_ENCHANTMENTS.get())return false;boolean changed=false;
        for(var component:java.util.List.of(DataComponents.ENCHANTMENTS,DataComponents.STORED_ENCHANTMENTS)){
            var enchantments=stack.get(component);if(enchantments==null||enchantments.keySet().stream().noneMatch(VanillaEnchantments::vanilla))continue;
            var mutable=new ItemEnchantments.Mutable(enchantments);mutable.removeIf(VanillaEnchantments::vanilla);stack.set(component,mutable.toImmutable());changed=true;
        }return changed;
    }
    @SubscribeEvent public static void enchant(EnchantmentLevelSetEvent e){if(Config.NO_VANILLA_ENCHANTMENTS.get())e.setEnchantLevel(0);}
    @SubscribeEvent public static void anvil(AnvilUpdateEvent e){
        if(Config.NO_VANILLA_ENCHANTMENTS.get() && e.getRight().getOrDefault(DataComponents.STORED_ENCHANTMENTS,ItemEnchantments.EMPTY).keySet().stream().anyMatch(VanillaEnchantments::vanilla))e.setCanceled(true);
    }
    @SubscribeEvent(priority=EventPriority.HIGHEST) public static void attack(AttackEntityEvent e){if(!e.getEntity().level().isClientSide())strip(e.getEntity().getMainHandItem());}
    @SubscribeEvent public static void join(EntityJoinLevelEvent e){if(!e.getLevel().isClientSide()&&e.getEntity() instanceof ItemEntity item)strip(item.getItem());}
    @SubscribeEvent public static void tick(EntityTickEvent.Pre e){
        if(e.getEntity().level().isClientSide()||!Config.NO_VANILLA_ENCHANTMENTS.get())return;
        if(e.getEntity() instanceof LivingEntity living)for(ItemStack item:living.getAllSlots())strip(item);
        if(e.getEntity() instanceof ItemEntity item && item.tickCount%20==0)strip(item.getItem());
        if(e.getEntity() instanceof Player p){
            for(ItemStack item:p.getInventory().items)strip(item);strip(p.containerMenu.getCarried());
            for(var slot:p.containerMenu.slots)if(strip(slot.getItem()))slot.setChanged();
        }
    }
}
