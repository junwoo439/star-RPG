package com.junwo.starrpg;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.tick.EntityTickEvent;

@EventBusSubscriber(modid=StarRPG.MODID)
public final class MobTraits {
    private static boolean enabled() { return Config.MOB_SCALING.get() && Config.MOB_TRAITS.get(); }
    @SubscribeEvent public static void arrowSpawn(EntityJoinLevelEvent event) {
        if (!event.getLevel().isClientSide() && event.getEntity() instanceof AbstractArrow arrow) prepareArrow(arrow);
    }
    public static void prepareArrow(AbstractArrow arrow) {
        if (!enabled() || !(arrow.getOwner() instanceof Skeleton skeleton) || skeleton.getType()!=EntityType.SKELETON) return;
        int tier=Math.min(5,MonsterProgression.tier(skeleton));long now=arrow.level().getGameTime();
        if (tier<2 || skeleton.getPersistentData().getLong("starrpg_frost_ready")>now) return;
        arrow.getPersistentData().putInt("starrpg_frost_ticks",20+tier*10);
        skeleton.getPersistentData().putLong("starrpg_frost_ready",now+160);
    }
    @SubscribeEvent public static void tick(EntityTickEvent.Post event) {
        if (!enabled() || !(event.getEntity().level() instanceof ServerLevel level)) return;
        if (event.getEntity() instanceof AbstractArrow arrow && arrow.getPersistentData().contains("starrpg_frost_ticks")
                && arrow.getDeltaMovement().lengthSqr()>0.01 && arrow.tickCount%2==0)
            level.sendParticles(ParticleTypes.SNOWFLAKE,arrow.getX(),arrow.getY(),arrow.getZ(),1,0.02,0.02,0.02,0);
        if (event.getEntity() instanceof Spider spider && spider.getType()==EntityType.SPIDER) updateSpider(spider);
    }
    public static void updateSpider(Spider spider) {
        var data=spider.getPersistentData();
        if (!enabled() || MonsterProgression.tier(spider)<2 || spider.isNoAi() || !spider.isAlive()
                || !(spider.getTarget() instanceof Player player) || !validTarget(spider,player)
                || spider.distanceToSqr(player)<9 || spider.distanceToSqr(player)>49 || !spider.onGround()) {
            data.remove("starrpg_pounce_cast"); data.remove("starrpg_pounce_target"); return;
        }
        long now=spider.level().getGameTime();
        if (data.getLong("starrpg_pounce_ready")>now) return;
        if (!data.contains("starrpg_pounce_cast")) {
            data.putLong("starrpg_pounce_cast",now+16);data.putUUID("starrpg_pounce_target",player.getUUID());
            spider.playSound(SoundEvents.SPIDER_AMBIENT,1,1.5F);
        } else if (!data.hasUUID("starrpg_pounce_target") || !data.getUUID("starrpg_pounce_target").equals(player.getUUID())) {
            data.remove("starrpg_pounce_cast");data.remove("starrpg_pounce_target");
        } else if (now>=data.getLong("starrpg_pounce_cast")) {
            var direction=player.position().subtract(spider.position()).multiply(1,0,1).normalize();
            spider.setDeltaMovement(direction.scale(0.6+Math.min(5,MonsterProgression.tier(spider))*0.06).add(0,0.45,0));
            spider.hasImpulse=true;spider.hurtMarked=true;
            data.putLong("starrpg_pounce_venom",now+40);
            data.putLong("starrpg_pounce_ready",now+140);
            data.remove("starrpg_pounce_cast");data.remove("starrpg_pounce_target");
        } else if (spider.tickCount%4==0) {
            ((ServerLevel)spider.level()).sendParticles(ParticleTypes.HAPPY_VILLAGER,spider.getX(),spider.getY()+0.6,spider.getZ(),3,0.3,0.1,0.3,0);
        }
    }
    private static boolean validTarget(net.minecraft.world.entity.Mob mob,Player player) {
        return player.isAlive() && !player.isCreative() && !player.isSpectator() && !mob.isAlliedTo(player) && mob.hasLineOfSight(player);
    }
    @SubscribeEvent public static void hit(LivingDamageEvent.Post event) {
        if (!enabled() || event.getNewDamage()<=0 || !(event.getEntity() instanceof Player player)
                || player.isCreative() || player.isSpectator()) return;
        long now=player.level().getGameTime();
        if (event.getSource().getDirectEntity() instanceof AbstractArrow arrow && arrow.getOwner() instanceof Skeleton skeleton
                && validTarget(skeleton,player)) {
            int ticks=arrow.getPersistentData().getInt("starrpg_frost_ticks");
            if (ticks>0 && player.getPersistentData().getLong("starrpg_frost_guard")<=now) {
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,Math.min(70,ticks),0));
                player.getPersistentData().putLong("starrpg_frost_guard",now+100);
            }
        } else if (event.getSource().getDirectEntity() instanceof Spider spider && spider.getType()==EntityType.SPIDER
                && validTarget(spider,player) && spider.getPersistentData().getLong("starrpg_pounce_venom")>now
                && player.getPersistentData().getLong("starrpg_venom_guard")<=now) {
            player.addEffect(new MobEffectInstance(MobEffects.POISON,20+Math.min(5,MonsterProgression.tier(spider))*10,0));
            player.getPersistentData().putLong("starrpg_venom_guard",now+100);
            spider.getPersistentData().remove("starrpg_pounce_venom");
        }
    }
}
