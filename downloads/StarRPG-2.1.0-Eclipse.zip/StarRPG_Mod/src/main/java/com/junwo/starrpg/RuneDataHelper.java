package com.junwo.starrpg;

import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;

public class RuneDataHelper {

    private static final String RUNE_EFFECT_KEY = "starrpg_rune_effect";

    public static void setRuneEffect(
            ItemStack stack,
            RuneEffect effect
    ) {
        CustomData customData = stack.getOrDefault(
                DataComponents.CUSTOM_DATA,
                CustomData.EMPTY
        );

        CompoundTag tag = customData.copyTag();

        tag.putString(
                RUNE_EFFECT_KEY,
                effect.name()
        );

        stack.set(
                DataComponents.CUSTOM_DATA,
                CustomData.of(tag)
        );
    }

    public static RuneEffect getRuneEffect(ItemStack stack) {
        CustomData customData = stack.getOrDefault(
                DataComponents.CUSTOM_DATA,
                CustomData.EMPTY
        );

        CompoundTag tag = customData.copyTag();

        if (!tag.contains(RUNE_EFFECT_KEY)) {
            return null;
        }

        String effectName = tag.getString(RUNE_EFFECT_KEY);

        try {
            return RuneEffect.valueOf(effectName);
        } catch (IllegalArgumentException exception) {
            return null;
        }
    }

    public static boolean hasRuneEffect(ItemStack stack) {
        return getRuneEffect(stack) != null;
    }
}