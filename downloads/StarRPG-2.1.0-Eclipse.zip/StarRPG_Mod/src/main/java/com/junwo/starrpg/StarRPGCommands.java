package com.junwo.starrpg;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

@EventBusSubscriber(modid = StarRPG.MODID)
public final class StarRPGCommands {
    @SubscribeEvent
    public static void register(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("starrpg")
            .then(Commands.literal("setlevel").requires(s -> s.hasPermission(2))
                .then(Commands.argument("level", IntegerArgumentType.integer(0)).executes(ctx -> {
                    var player = ctx.getSource().getPlayerOrException();
                    var item = player.getMainHandItem();
                    if (!EnhancementData.supports(item)) { ctx.getSource().sendFailure(Component.literal("장비를 손에 들어 주세요.")); return 0; }
                    EnhancementData.setLevel(item, IntegerArgumentType.getInteger(ctx,"level"));
                    EnhancementLore.update(item);
                    ctx.getSource().sendSuccess(() -> Component.literal("장비 강화 데이터 적용 완료"), true);
                    return 1;
                })))
            .then(Commands.literal("rank").requires(s -> s.hasPermission(2))
                .then(Commands.argument("rank",IntegerArgumentType.integer(1)).executes(ctx->{
                    var player=ctx.getSource().getPlayerOrException();var c=Careers.profile(player);
                    if(c.selected<0){ctx.getSource().sendFailure(Component.literal("먼저 메뉴에서 직업을 확정하세요."));return 0;}
                    c.ranks[c.selected]=IntegerArgumentType.getInteger(ctx,"rank");CareerData.get(player.getServer()).setDirty();Careers.updateAttributes(player);
                    ctx.getSource().sendSuccess(()->Component.literal(Careers.NAMES[c.selected]+" "+c.rank()+"차 적용 / 전직 완료 "+(c.rank()-1)+"회"),false);return 1;
                })))
            .then(Commands.literal("mods").executes(ctx -> {
                for (String id : new String[]{"starrpg","mowziesmobs","geckolib","twilightforest","iceandfire"}) {
                    var container = net.neoforged.fml.ModList.get().getModContainerById(id);
                    String status = container.map(c -> "로드됨 " + c.getModInfo().getVersion()).orElse("설치되지 않음");
                    ctx.getSource().sendSuccess(() -> Component.literal(id + ": " + status), false);
                }
                return 1;
            }))
            .then(Commands.literal("difficulty").executes(ctx -> {
                WorldDifficulty world = WorldDifficulty.get(ctx.getSource().getServer());
                ctx.getSource().sendSuccess(() -> Component.literal("월드 난이도: " + world.tier()
                        + " / " + "무한" + " | 새 몬스터: " + Math.max(0,world.tier()-2) + "~" + world.tier() + "단계" + " | 누적 생존 시간: " + world.activeTicks() / 1200
                        + "분 | 단계당 " + Config.MINUTES_PER_TIER.get() + "분"), false);
                return 1;
            }))
            .then(Commands.literal("worldtier").requires(s -> s.hasPermission(2))
                .then(Commands.argument("tier", IntegerArgumentType.integer(0)).executes(ctx -> {
                    WorldDifficulty world = WorldDifficulty.get(ctx.getSource().getServer());
                    world.setTier(IntegerArgumentType.getInteger(ctx, "tier"));
                    ctx.getSource().sendSuccess(() -> Component.literal("월드 난이도 " + world.tier()
                            + "단계로 설정. 기존 몬스터는 내려가지 않으므로 새 몬스터로 비교하세요."), true);
                    return 1;
                }))));
    }
}
