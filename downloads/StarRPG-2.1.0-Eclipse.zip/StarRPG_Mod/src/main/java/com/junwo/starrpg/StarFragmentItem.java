package com.junwo.starrpg;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.*;

/** Crafting/enhancement material; the menu is now opened by an enchanting table. */
public class StarFragmentItem extends Item {
    public StarFragmentItem(Properties properties){super(properties);}
    @Override public void appendHoverText(ItemStack stack,TooltipContext context,List<Component> lines,TooltipFlag flag){super.appendHoverText(stack,context,lines,flag);lines.add(Component.literal("강화 재료 · 인챈트 테이블에서 장비 강화"));}
}
