package com.junwo.starrpg;

import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.*;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.common.util.FakePlayer;
import net.neoforged.neoforge.event.entity.living.LivingDropsEvent;

@EventBusSubscriber(modid=StarRPG.MODID)
public final class Economy {
    public enum Product {
        DUST("별가루"), FRAGMENT("별조각"), RUNE("일반 룬"), BREAD("빵"), BEEF("스테이크"), TORCH("횃불"), ARROW("화살"), LOG("참나무 원목"),
        COAL("석탄"), IRON("철 주괴"), GLASS("유리"), LEATHER("가죽"), PEARL("엔더 진주"), BUCKET("물 양동이"),
        BED("흰색 침대"), SHIELD("방패"), AMETHYST("자수정 조각"), QUARTZ("네더 석영"), GOLD("금 주괴"), REDSTONE("레드스톤"), SOUL_SAND("영혼 모래"), COPPER("구리 주괴"), FLINT("부싯돌");
        public final String label;
        Product(String label) { this.label=label; }
        public int price() { return switch(this) {
            case DUST -> Math.min(30000,Config.DUST_PRICE.get()*Config.MATERIAL_PRICE_MULTIPLIER.get()); case FRAGMENT -> Math.min(30000,Config.FRAGMENT_PRICE.get()*Config.MATERIAL_PRICE_MULTIPLIER.get()); case RUNE -> Config.RUNE_PRICE.get();
            default -> Math.max(basePrice(),SellPrices.unit(stack(1))*2);
        }; }
        private int basePrice(){return switch(this){case BREAD->12;case BEEF->24;case TORCH->3;case ARROW->5;case LOG->12;case COAL->12;case IRON->50;case GLASS->8;case LEATHER->25;case PEARL->180;case BUCKET->180;case BED->80;case SHIELD->150;case AMETHYST->40;case QUARTZ->30;case GOLD->80;case REDSTONE->20;case SOUL_SAND->30;case COPPER->12;case FLINT->12;default->0;};}
        public ItemStack stack(int count) { return new ItemStack(switch(this) {
            case DUST -> StarRPG.STAR_DUST.get(); case FRAGMENT -> StarRPG.STAR_FRAGMENT.get(); case RUNE -> StarRPG.COMMON_RUNE.get();
            case BREAD->net.minecraft.world.item.Items.BREAD;case BEEF->net.minecraft.world.item.Items.COOKED_BEEF;case TORCH->net.minecraft.world.item.Items.TORCH;case ARROW->net.minecraft.world.item.Items.ARROW;case LOG->net.minecraft.world.item.Items.OAK_LOG;case COAL->net.minecraft.world.item.Items.COAL;case IRON->net.minecraft.world.item.Items.IRON_INGOT;case GLASS->net.minecraft.world.item.Items.GLASS;case LEATHER->net.minecraft.world.item.Items.LEATHER;case PEARL->net.minecraft.world.item.Items.ENDER_PEARL;case BUCKET->net.minecraft.world.item.Items.WATER_BUCKET;case BED->net.minecraft.world.item.Items.WHITE_BED;case SHIELD->net.minecraft.world.item.Items.SHIELD;case AMETHYST->net.minecraft.world.item.Items.AMETHYST_SHARD;case QUARTZ->net.minecraft.world.item.Items.QUARTZ;case GOLD->net.minecraft.world.item.Items.GOLD_INGOT;case REDSTONE->net.minecraft.world.item.Items.REDSTONE;case SOUL_SAND->net.minecraft.world.item.Items.SOUL_SAND;case COPPER->net.minecraft.world.item.Items.COPPER_INGOT;case FLINT->net.minecraft.world.item.Items.FLINT;
        },count); }
    }
    public enum Purchase { OK, DISABLED, INVALID, NO_MONEY, NO_SPACE }
    public static Purchase buy(Player player, Product product, int count) {
        if (player.level().isClientSide() || player.getServer()==null || product==null || count<1 || count>64) return Purchase.INVALID;
        if (!Config.ECONOMY_ENABLED.get()) return Purchase.DISABLED;
        ItemStack stack=product.stack(count);
        int cost=product.price()*count;
        StarWallet wallet=StarWallet.get(player.getServer());
        if (wallet.balance(player.getUUID()) < cost) return Purchase.NO_MONEY;
        if (!fits(player,stack)) return Purchase.NO_SPACE;
        // All callers run on the server thread. Validate the whole delivery before touching either side.
        if (!wallet.debit(player.getUUID(),cost)) return Purchase.NO_MONEY;
        deliver(player,stack);
        player.getInventory().setChanged(); player.containerMenu.broadcastChanges();
        return Purchase.OK;
    }
    public static boolean fits(Player player, ItemStack stack) {
        int room=0;
        for (ItemStack slot:player.getInventory().items) {
            if (slot.isEmpty()) room+=stack.getMaxStackSize();
            else if (ItemStack.isSameItemSameComponents(slot,stack)) room+=Math.max(0,slot.getMaxStackSize()-slot.getCount());
            if (room>=stack.getCount()) return true;
        }
        return false;
    }
    private static void deliver(Player player, ItemStack stack) {
        var slots=player.getInventory().items;
        for (ItemStack slot:slots) {
            if (!slot.isEmpty() && ItemStack.isSameItemSameComponents(slot,stack)) {
                int n=Math.min(stack.getCount(),Math.max(0,slot.getMaxStackSize()-slot.getCount()));slot.grow(n);stack.shrink(n);
                if (stack.isEmpty()) return;
            }
        }
        for (int i=0;i<slots.size() && !stack.isEmpty();i++) if (slots.get(i).isEmpty()) slots.set(i,stack.split(Math.min(stack.getCount(),stack.getMaxStackSize())));
    }
    public static Component feedback(Purchase result, Product product, int count) {
        return Component.literal(switch(result) {
            case OK -> product.label+" "+count+"개 구입: -"+(product.price()*count)+" G";
            case NO_MONEY -> "골드가 부족합니다.";
            case NO_SPACE -> "인벤토리 공간이 부족합니다. 골드는 차감되지 않았습니다.";
            case DISABLED -> "현재 경제 기능이 꺼져 있습니다.";
            case INVALID -> "구매 수량은 1~64개입니다.";
        });
    }
    @SubscribeEvent(priority=EventPriority.LOWEST)
    public static void reward(LivingDropsEvent event) {
        var mob=event.getEntity();
        if (mob.level().isClientSide() || !Config.ECONOMY_ENABLED.get() || !MonsterProgression.eligible(mob)
                || !(event.getSource().getEntity() instanceof Player player) || player instanceof FakePlayer
                || player.isCreative() || player.isSpectator() || player.getServer()==null
                || player.isAlliedTo(mob) || mob.isAlliedTo(player) || mob.getPersistentData().getBoolean("starrpg_gold_paid")) return;
        mob.getPersistentData().putBoolean("starrpg_gold_paid",true);
        boolean boss=mob.getType().is(MonsterProgression.BOSSES);
        int tier=MonsterProgression.tier(mob), amount=(int)Math.min(10000L,boss?200L+tier*40L:4L+tier*2L);
        int added=StarWallet.get(player.getServer()).huntingReward(player.getUUID(),amount,boss,player.getServer().overworld().getGameTime());
        if (added>0) player.displayClientMessage(Component.literal("+"+added+" G | 잔액 "+StarWallet.get(player.getServer()).balance(player.getUUID())+" G"),true);
    }
}
