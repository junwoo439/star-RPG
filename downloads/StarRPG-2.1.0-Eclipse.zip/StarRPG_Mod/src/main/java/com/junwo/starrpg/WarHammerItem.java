package com.junwo.starrpg;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.*;

public final class WarHammerItem extends AxeItem {
    public WarHammerItem(Properties properties) { super(Tiers.IRON,properties.attributes(AxeItem.createAttributes(Tiers.IRON,3,-3.2F))); }
    @Override public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> lines, TooltipFlag flag) {
        super.appendHoverText(stack,context,lines,flag);
        lines.add(Component.literal("주 손 최대 체력 +6 / 충전 공격: 전방 범위 피해"));
        lines.add(Component.literal("R: 지면 충격파 / 도끼 룬 사용"));
    }
}
