package com.junwo.starrpg;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.neoforged.neoforge.registries.*;

public final class ModEffects {
    public static final DeferredRegister<MobEffect> EFFECTS=DeferredRegister.create(Registries.MOB_EFFECT,StarRPG.MODID);
    private static class Effect extends MobEffect {
        Effect(int color,boolean stop) {
            super(MobEffectCategory.HARMFUL,color);
            if(stop)addAttributeModifier(Attributes.MOVEMENT_SPEED,ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,"control_"+color),-1,AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
        }
    }
    public static final DeferredHolder<MobEffect,MobEffect> ROOT=EFFECTS.register("root",()->new Effect(0x65CBFF,true));
    public static final DeferredHolder<MobEffect,MobEffect> STUN=EFFECTS.register("stun",()->new Effect(0xFFE35A,true));
    public static final DeferredHolder<MobEffect,MobEffect> REVERSE_MOVE=EFFECTS.register("reverse_move",()->new Effect(0x6B3C98,false));
    public static final DeferredHolder<MobEffect,MobEffect> REVERSE_LOOK=EFFECTS.register("reverse_look",()->new Effect(0xFFF7BF,false));
    public static final DeferredHolder<MobEffect,MobEffect> BRACED=EFFECTS.register("braced",()->new Effect(0x86654A,true));
    public static final DeferredHolder<MobEffect,MobEffect> COMBO=EFFECTS.register("dagger_combo",()->new Effect(0xB0EDFF,false));
}
