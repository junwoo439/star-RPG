package com.junwo.starrpg;

import java.util.*;
import net.minecraft.util.RandomSource;

/** First draw a rarity from 10,000 exact integer tickets, then one of that rarity's eight effects. */
public final class RuneEffectManager {
    private static final int[][] WEIGHTS={
        {7000,2500,490,10,0},
        {2000,6500,1400,99,1},
        {500,2000,7000,490,10},
        {10,490,2000,7000,500},
        {1,9,490,2500,7000}
    };
    public static int weight(RuneRarity source,RuneRarity result){return WEIGHTS[source.ordinal()][result.ordinal()];}
    public static RuneRarity rarityAt(RuneRarity source,int ticket){
        if(ticket<0||ticket>=10000)throw new IllegalArgumentException("ticket outside [0,10000)");
        int sum=0;for(var rarity:RuneRarity.values()){sum+=weight(source,rarity);if(ticket<sum)return rarity;}throw new IllegalStateException("Invalid weights");
    }
    public static String odds(RuneRarity source){
        var text=new StringBuilder();for(var rarity:RuneRarity.values())text.append(rarity.getKoreanName()).append(" ").append(String.format(Locale.ROOT,"%.2f",weight(source,rarity)/100.0)).append("%\n");return text.toString();
    }
    public static List<RuneEffect> getPossibleEffects(RuneRarity rarity,RuneWeaponType type){return Arrays.stream(RuneEffect.values()).filter(e->e.getRarity()==rarity&&e.getWeaponType()==type).toList();}
    public static RuneEffect getRandomEffect(RuneRarity source,RuneWeaponType type,RandomSource random){
        if(source==null||type==null)return null;
        var result=rarityAt(source,random.nextInt(10000));var pool=getPossibleEffects(result,type);
        return pool.isEmpty()?null:pool.get(random.nextInt(pool.size()));
    }
}
