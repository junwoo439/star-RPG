package com.junwo.starrpg;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/** One persistent clock for the whole world, including all dimensions. */
@EventBusSubscriber(modid = StarRPG.MODID)
public final class WorldDifficulty extends SavedData {
    private long activeTicks;

    public static WorldDifficulty get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(
                new SavedData.Factory<>(WorldDifficulty::new, WorldDifficulty::load), "starrpg_world_difficulty");
    }

    public static WorldDifficulty load(CompoundTag tag, HolderLookup.Provider registries) {
        WorldDifficulty data = new WorldDifficulty();
        data.activeTicks = Math.max(0, tag.getLong("activeTicks"));
        return data;
    }

    @Override public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        tag.putLong("activeTicks", activeTicks);
        return tag;
    }

    public long activeTicks() { return activeTicks; }
    public int tier() { return tierAt(activeTicks); }
    public static int tierAt(long ticks) {
        return (int) Math.clamp(ticks / (Config.MINUTES_PER_TIER.get() * 1200L), 0L, Integer.MAX_VALUE);
    }

    public void advance(boolean active) {
        if (active && activeTicks < Long.MAX_VALUE) { activeTicks++; setDirty(); }
    }

    /** Explicit operator test/reset command; ordinary gear changes never affect the clock. */
    public void setTier(int tier) {
        activeTicks = (long)Math.max(0,tier) * Config.MINUTES_PER_TIER.get() * 1200L;
        setDirty();
    }

    @SubscribeEvent public static void tick(ServerTickEvent.Post event) {
        if (!Config.MOB_SCALING.get()) return;
        MinecraftServer server = event.getServer();
        WorldDifficulty data = get(server);
        int before = data.tier();
        data.advance(server.getPlayerList().getPlayers().stream()
                .anyMatch(p -> p.isAlive() && !p.isCreative() && !p.isSpectator()));
        if (data.tier() != before) server.getPlayerList().broadcastSystemMessage(
                Component.literal("[StarRPG] 월드 난이도가 " + data.tier() + "단계로 상승했습니다."), false);
    }
}
