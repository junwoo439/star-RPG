package com.junwo.starrpg;

import net.minecraft.world.item.*;

public enum RuneWeaponType {
    STAFF, SWORD, AXE, BOW, CROSSBOW, TRIDENT, HELMET, CHESTPLATE, LEGGINGS, BOOTS;

    public static RuneWeaponType forItem(ItemStack stack) {
        if (stack.getItem() instanceof MagicStaffItem) return STAFF;
        if (stack.getItem() instanceof SwordItem) return SWORD;
        if (stack.getItem() instanceof AxeItem) return AXE;
        if (stack.getItem() instanceof BowItem) return BOW;
        if (stack.getItem() instanceof CrossbowItem) return CROSSBOW;
        if (stack.getItem() instanceof TridentItem) return TRIDENT;
        if (stack.getItem() instanceof ArmorItem armor) return switch (armor.getEquipmentSlot()) {
            case HEAD -> HELMET;
            case CHEST -> CHESTPLATE;
            case LEGS -> LEGGINGS;
            case FEET -> BOOTS;
            default -> null;
        };
        return null;
    }
    public boolean isArmor() { return this == HELMET || this == CHESTPLATE || this == LEGGINGS || this == BOOTS; }
    public boolean isRanged() { return this == BOW || this == CROSSBOW || this == TRIDENT; }
}
