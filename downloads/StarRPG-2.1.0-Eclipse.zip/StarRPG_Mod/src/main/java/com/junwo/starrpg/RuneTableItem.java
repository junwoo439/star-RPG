package com.junwo.starrpg;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class RuneTableItem extends Item {

    public RuneTableItem(Properties properties) {
        super(properties);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, java.util.List<Component> lines,
                                net.minecraft.world.item.TooltipFlag flag) {
        super.appendHoverText(stack, context, lines, flag);
        lines.add(Component.literal("우클릭: 근접·원거리 무기·방어구 룬 각인"));
        lines.add(Component.literal("조합: 별가루 4 + 자수정 조각 4 + 별조각 1"));
        lines.add(Component.literal("같거나 높은 등급 룬 1개로 무작위 재각인"));
    }

    @Override
    public InteractionResultHolder<ItemStack> use(
            Level level,
            Player player,
            InteractionHand hand
    ) {
        ItemStack itemStack = player.getItemInHand(hand);

        if (!level.isClientSide() && player instanceof ServerPlayer serverPlayer) {
            serverPlayer.openMenu(
                    new SimpleMenuProvider(
                            (containerId, playerInventory, openedPlayer) ->
                                    new RuneEngravingMenu(
                                            containerId,
                                            playerInventory
                                    ),
                            Component.literal("별의 룬 각인")
                    )
            );
        }

        return InteractionResultHolder.sidedSuccess(
                itemStack,
                level.isClientSide()
        );
    }
}
