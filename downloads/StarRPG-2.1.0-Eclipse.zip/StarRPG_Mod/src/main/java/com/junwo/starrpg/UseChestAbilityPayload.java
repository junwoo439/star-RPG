package com.junwo.starrpg;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record UseChestAbilityPayload()
        implements CustomPacketPayload {

    public static final UseChestAbilityPayload INSTANCE =
            new UseChestAbilityPayload();

    public static final Type<UseChestAbilityPayload> TYPE =
            new Type<>(
                    ResourceLocation.fromNamespaceAndPath(
                            StarRPG.MODID,
                            "use_chest_ability"
                    )
            );

    public static final StreamCodec<
            ByteBuf,
            UseChestAbilityPayload
    > STREAM_CODEC = StreamCodec.unit(INSTANCE);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(
            UseChestAbilityPayload payload,
            IPayloadContext context
    ) {
        if (context.player() instanceof ServerPlayer player) {
            ChestAbilityManager.tryUse(player);
        }
    }
}