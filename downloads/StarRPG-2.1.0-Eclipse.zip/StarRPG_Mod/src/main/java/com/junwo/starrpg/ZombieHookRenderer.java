package com.junwo.starrpg;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.minecraft.world.entity.LivingEntity;

/** Render the hook item and a short-lived fishing line to its zombie owner. */
public final class ZombieHookRenderer extends ThrownItemRenderer<ZombieHook> {
    public ZombieHookRenderer(EntityRendererProvider.Context context) { super(context); }
    @Override public void render(ZombieHook hook, float yaw, float partialTick, PoseStack pose,
                                 MultiBufferSource buffers, int light) {
        super.render(hook, yaw, partialTick, pose, buffers, light);
        if (!(hook.getOwner() instanceof LivingEntity owner)) return;
        double angle = Math.toRadians(owner.getYRot());
        var hand = owner.getEyePosition(partialTick).add(-Math.cos(angle)*0.35-Math.sin(angle)*0.45,
                -0.35, -Math.sin(angle)*0.35+Math.cos(angle)*0.45);
        var delta = hand.subtract(hook.getPosition(partialTick));
        if (delta.lengthSqr() < 0.001) return;
        var normal = delta.normalize();
        var vertices = buffers.getBuffer(RenderType.lineStrip());
        for (int i=0; i<=16; i++) {
            float t=i/16.0F;
            vertices.addVertex(pose.last(), (float)delta.x*t, (float)(delta.y*t-0.1*Math.sin(Math.PI*t)), (float)delta.z*t)
                    .setColor(0xFF303030).setNormal(pose.last(), (float)normal.x, (float)normal.y, (float)normal.z);
        }
    }
}
