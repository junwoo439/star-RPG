package com.junwo.starrpg.tests;

import com.junwo.starrpg.*;
import java.util.*;
import net.minecraft.gametest.framework.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.item.*;
import net.minecraft.world.effect.*;
import net.minecraft.world.level.GameType;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.*;

@GameTestHolder(StarRPG.MODID)
@PrefixGameTestTemplate(false)
public class ElementalCareersGameTests {
    private static Player player(GameTestHelper h,int job,Item item,int level){
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(2.5,2,2.5)));p.setYRot(0);p.setXRot(0);
        p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(item));EnhancementData.setLevel(p.getMainHandItem(),level);
        if(job>=0){var c=Careers.profile(p);c.selected=job;c.ranks[job]=1;}return p;
    }
    private static LivingEntity dummy(GameTestHelper h,float hp){var target=EntityType.COW.create(h.getLevel());target.getAttribute(Attributes.MAX_HEALTH).setBaseValue(hp);target.setHealth(hp);return target;}
    @GameTest(template="empty") public static void plusTwentyFiveMeleeOneShotsTierFiveCommonMonsters(GameTestHelper h){
        Item[] items={StarRPG.STAR_DAGGER.get(),StarRPG.WAR_HAMMER.get(),StarRPG.STAR_SPEAR.get(),StarRPG.BERSERKER_BLADE.get(),StarRPG.SUN_SCEPTER.get(),StarRPG.SOUL_SCYTHE.get(),StarRPG.STAR_GAUNTLET.get(),StarRPG.AEGIS_BLADE.get(),Items.TRIDENT};
        for(var item:items){var p=player(h,Careers.weaponJob(item.getDefaultInstance()),item,25);
            for(var type:List.of(EntityType.ZOMBIE,EntityType.SKELETON,EntityType.SPIDER,EntityType.CREEPER)){
                var mob=type.create(h.getLevel());MonsterProgression.applyTier(mob,5);float hp=mob.getHealth();
                mob.hurt(h.getLevel().damageSources().playerAttack(p),4);
                h.assertTrue(!mob.isAlive(),"+25 melee failed " + item + " / " + type + " HP " + hp + " -> " + mob.getHealth());
            }
        }h.succeed();
    }
    @GameTest(template="empty") public static void plusTwentyFiveRangedAndEveryMageOneShotTierFive(GameTestHelper h){
        for(var type:List.of(EntityType.ZOMBIE,EntityType.SKELETON,EntityType.SPIDER,EntityType.CREEPER)){
            for(var item:List.of(Items.BOW,Items.CROSSBOW)){
                var p=player(h,2,item,25);var mob=type.create(h.getLevel());MonsterProgression.applyTier(mob,5);
                var arrow=new Arrow(h.getLevel(),p,new ItemStack(Items.ARROW),p.getMainHandItem().copy());arrow.setDeltaMovement(0,0,3);RangedRuneEffects.prepare(arrow);
                mob.hurt(h.getLevel().damageSources().arrow(arrow,p),6);h.assertTrue(!mob.isAlive(),"+25 ranged failed "+item+" / "+type+" remains "+mob.getHealth());
            }
            for(int job:new int[]{3,10,11,12,13,14,15}){
                var p=player(h,job,StarRPG.MAGIC_STAFF.get(),25);var mob=type.create(h.getLevel());MonsterProgression.applyTier(mob,5);
                var bolt=new MagicBolt(h.getLevel(),p,0,30);MagicSystem.damage(p,mob,30,bolt);
                h.assertTrue(!mob.isAlive(),"+25 basic mage bolt failed "+job+" / "+type);
            }
        }h.succeed();
    }
    @GameTest(template="empty") public static void huntingGrowthExcludesBossesPlayersPetsAndKeepsInfiniteDifficulty(GameTestHelper h){
        var p=player(h,1,StarRPG.STAR_DAGGER.get(),25);var w=p.getMainHandItem();
        h.assertTrue(JobWeaponTraits.huntingFactor(w,EntityType.ZOMBIE.create(h.getLevel()))==3,"+25 hunting factor wrong");
        h.assertTrue(JobWeaponTraits.huntingFactor(w,EntityType.WITHER.create(h.getLevel()))==1&&JobWeaponTraits.huntingFactor(w,p)==1&&JobWeaponTraits.huntingFactor(w,dummy(h,20))==1,"Hunting bonus leaked to bosses/PvP/passive mobs");
        var giant=EntityType.ZOMBIE.create(h.getLevel());MonsterProgression.applyTier(giant,500);giant.hurt(h.getLevel().damageSources().playerAttack(p),4);h.assertTrue(giant.isAlive(),"+25 secretly guarantees all tiers die");
        double previous=0;for(int n:new int[]{1,5,10,15,20,25,26,100,100000,Integer.MAX_VALUE}){EnhancementData.setLevel(w,n);double value=EnhancementData.combatPower(w);h.assertTrue(value>previous&&Double.isFinite(value),"Non-monotonic/overflow enhancement "+n);previous=value;}h.succeed();
    }
    @GameTest(template="empty") public static void sixSchoolsSaveAndMenuPreserveWideNumbersAndActionIds(GameTestHelper h){
        var p=player(h,3,StarRPG.MAGIC_STAFF.get(),0);var c=Careers.profile(p);var materials=new HashSet<Item>();
        for(int job=10;job<16;job++){c.ranks[job]=80000+job;c.xp[job]=700000+job;c.mastery[job]=900000+job;materials.add(Careers.material(job));}
        var menu=new MaterialShopMenu(1,p.getInventory());var loaded=CareerData.load(CareerData.get(p.getServer()).save(new CompoundTag(),h.getLevel().registryAccess()),h.getLevel().registryAccess()).profile(p.getUUID());
        for(int job=10;job<16;job++)h.assertTrue(menu.previewRank(job)==80000+job&&menu.previewXp(job)==700000+job&&menu.previewMastery(job)==900000+job&&loaded.ranks[job]==80000+job,"School data overlap/truncation "+job);
        h.assertTrue(materials.size()==6&&c.selected==3,"Preview changed selection or school materials identical");
        StarWallet.get(p.getServer()).credit(p.getUUID(),1000);h.assertTrue(menu.clickMenuButton(p,210)&&c.selected==10,"New school action collided with advance");
        int rank=c.rank();h.assertTrue(!menu.clickMenuButton(p,50)&&c.selected==10&&c.rank()==rank,"Old advance button selected a school");
        h.assertTrue(!menu.clickMenuButton(p,216),"Out of bounds selection accepted");h.succeed();
    }
    @GameTest(template="empty") public static void everySchoolCastsThreeSpellsAndSharesCooldown(GameTestHelper h){
        for(int job=10;job<16;job++){
            var p=player(h,job,StarRPG.MAGIC_STAFF.get(),0);h.assertTrue(Careers.qualified(p,p.getMainHandItem())&&MagicSystem.cast(p),"School cannot cast "+job);
            var bolt=h.getLevel().getEntitiesOfClass(MagicBolt.class,p.getBoundingBox().inflate(4),b->b.getOwner()==p).getFirst();h.assertTrue(bolt.school()==job-9,"Wrong projectile school");bolt.discard();
            p.getPersistentData().putLong("starrpg_spell_ready",0);MagicSystem.choose(p,1);h.assertTrue(MagicSystem.cast(p),"Area spell failed "+job);
            h.getLevel().getEntitiesOfClass(MagicBolt.class,p.getBoundingBox().inflate(4),b->b.getOwner()==p).forEach(Entity::discard);
            p.setHealth(8);MagicSystem.choose(p,2);h.assertTrue(MagicSystem.cast(p)&&!MagicSystem.cast(p),"Support spell/cooldown failed "+job);
            h.assertTrue(Careers.cast(p)&&!Careers.cast(p),"School G failed "+job);
            var c=Careers.profile(p);c.selected=job==15?10:job+1;c.ranks[c.selected]=1;
            h.assertTrue(!MagicSystem.cast(p),"School swap bypassed support cooldown");
        }h.succeed();
    }
    @GameTest(template="empty") public static void projectileSchoolAndHighDamageSurviveSave(GameTestHelper h){
        var p=player(h,10,StarRPG.MAGIC_STAFF.get(),100);var bolt=new MagicBolt(h.getLevel(),p,1,123);
        var nbt=new CompoundTag();bolt.saveWithoutId(nbt);var copy=new MagicBolt(ModEntities.MAGIC_BOLT.get(),h.getLevel());copy.load(nbt);var second=new CompoundTag();copy.saveWithoutId(second);
        Careers.profile(p).selected=14;h.assertTrue(copy.school()==1&&second.getFloat("spellDamage")==123&&EnhancementData.level(copy.staff())==100,"Projectile snapshot changed/truncated");
        h.assertTrue(!Careers.trialMatches(p,dummy(h,20),new net.minecraft.world.damagesource.DamageSource(h.getLevel().registryAccess().registryOrThrow(net.minecraft.core.registries.Registries.DAMAGE_TYPE).getHolderOrThrow(MagicSystem.MAGIC_DAMAGE),bolt,p)),"Fire spell granted dark school mastery after swap");h.succeed();
    }
    @GameTest(template="empty") public static void careerBleedExistsWithoutRunesAndDoesNotTriggerForForeignWeapons(GameTestHelper h){
        for(int job:new int[]{0,1,2,5}){
            var item=job==0?StarRPG.STAR_SPEAR.get():job==1?StarRPG.STAR_DAGGER.get():job==2?Items.BOW:StarRPG.BERSERKER_BLADE.get();
            var p=player(h,job,item,0);var target=dummy(h,100);JobWeaponTraits.apply(p,p.getMainHandItem(),target,8,0);
            h.assertTrue(EnhancementEffects.hasBleed(target),"Missing rune-free bleed "+job);
            var other=dummy(h,100);JobWeaponTraits.apply(p,p.getMainHandItem(),other,8,0);h.assertTrue(!EnhancementEffects.hasBleed(other),"Bleed ignored player-wide cooldown");
            p.getPersistentData().putLong("starrpg_job_trait_ready",0);Careers.profile(p).selected=3;JobWeaponTraits.apply(p,p.getMainHandItem(),other,8,0);h.assertTrue(!EnhancementEffects.hasBleed(other),"Foreign career gained inherent trait");
        }h.succeed();
    }
    @GameTest(template="empty") public static void lifestealUsesActualHealthDamageAndCapsWithoutRecursiveRunes(GameTestHelper h){
        var p=player(h,7,StarRPG.SOUL_SCYTHE.get(),25);p.setHealth(8);var target=dummy(h,1);target.hurt(h.getLevel().damageSources().playerAttack(p),100);
        h.assertTrue(Math.abs(p.getHealth()-8.1F)<0.01,"Overkill or legacy sword healing inflated siphon: "+p.getHealth());
        var other=dummy(h,200);other.hurt(h.getLevel().damageSources().playerAttack(p),10);h.assertTrue(Math.abs(p.getHealth()-8.1F)<0.01,"Siphon cooldown ignored");
        p.getPersistentData().putLong("starrpg_job_siphon_ready",0);other.invulnerableTime=0;CombatRules.runeDamage(p,other,5);h.assertTrue(Math.abs(p.getHealth()-8.1F)<0.01,"Secondary damage recursively healed");
        other.invulnerableTime=0;other.hurt(h.getLevel().damageSources().playerAttack(p),80);h.assertTrue(Math.abs(p.getHealth()-10.1F)<0.01,"Siphon cap wrong: "+p.getHealth());h.succeed();
    }
    @GameTest(template="empty") public static void schoolHitsHaveDistinctTraitsAndProtectPets(GameTestHelper h){
        for(int job=10;job<16;job++){
            var p=player(h,job,StarRPG.MAGIC_STAFF.get(),0);p.setHealth(8);var t=dummy(h,100);MagicSystem.damage(p,t,10,new MagicBolt(h.getLevel(),p,0,10));
            h.assertTrue(switch(job){case 10->t.isOnFire();case 11->t.hasEffect(MobEffects.MOVEMENT_SLOWDOWN);case 12->t.getEffect(MobEffects.MOVEMENT_SLOWDOWN)!=null&&t.getEffect(MobEffects.MOVEMENT_SLOWDOWN).getAmplifier()==1;case 13->t.hasEffect(MobEffects.WEAKNESS);case 14->Math.abs(p.getHealth()-9)<0.01;default->t.hasEffect(MobEffects.GLOWING)&&Math.abs(p.getHealth()-8.5F)<0.01;},"Missing school trait "+job);
            var pet=EntityType.WOLF.create(h.getLevel());pet.setTame(true,true);float hp=pet.getHealth();p.getPersistentData().putLong("starrpg_job_trait_ready",0);JobWeaponTraits.apply(p,p.getMainHandItem(),pet,10,job-9);MagicSystem.damage(p,pet,10,p);h.assertTrue(pet.getHealth()==hp&&!pet.isOnFire()&&!pet.hasEffect(MobEffects.MOVEMENT_SLOWDOWN),"Trait harmed pet");
        }h.succeed();
    }
    @GameTest(template="hook_arena",timeoutTicks=45) public static void schoolSwitchCancelsPendingUltimate(GameTestHelper h){
        var p=player(h,12,StarRPG.MAGIC_STAFF.get(),0);var t=h.spawn(EntityType.COW,2,2,6);t.setNoAi(true);t.setNoGravity(true);t.getAttribute(Attributes.MAX_HEALTH).setBaseValue(200);t.setHealth(200);
        h.assertTrue(MagicSystem.meteor(p),"Ice ultimate failed");Careers.profile(p).selected=10;MagicSystem.tick(new net.neoforged.neoforge.event.tick.PlayerTickEvent.Post(p));
        h.runAfterDelay(18,()->{MagicSystem.tick(new net.neoforged.neoforge.event.tick.PlayerTickEvent.Post(p));h.assertTrue(t.getHealth()==200,"Switching school completed stale ultimate");h.succeed();});
    }
    @GameTest(template="hook_arena",timeoutTicks=45) public static void sixSchoolUltimatesAllDealActualDamage(GameTestHelper h){
        var target=h.spawn(EntityType.COW,2,2,6);target.setNoAi(true);target.setNoGravity(true);target.getAttribute(Attributes.MAX_HEALTH).setBaseValue(300);target.setHealth(300);
        var players=new ArrayList<Player>();for(int job=10;job<16;job++){var p=player(h,job,StarRPG.MAGIC_STAFF.get(),0);players.add(p);h.assertTrue(MagicSystem.meteor(p),"Ultimate cannot start "+job);}
        h.runAfterDelay(16,()->{for(var p:players){target.invulnerableTime=0;float before=target.getHealth();MagicSystem.tick(new net.neoforged.neoforge.event.tick.PlayerTickEvent.Post(p));h.assertTrue(target.getHealth()<before,"Ultimate did no damage "+Careers.profile(p).selected);}h.succeed();});
    }

}
