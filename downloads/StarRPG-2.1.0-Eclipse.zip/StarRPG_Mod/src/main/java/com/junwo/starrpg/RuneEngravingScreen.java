package com.junwo.starrpg;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.*;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

public final class RuneEngravingScreen extends AbstractContainerScreen<RuneEngravingMenu> {
    private Button engrave,preview;private int previewRank;
    private static final int[] COLORS={0xD5D9E0,0x6FBFFF,0xC895FF,0xFFCC66,0xFF7FA2};
    public RuneEngravingScreen(RuneEngravingMenu menu,Inventory inventory,Component title){super(menu,inventory,title);imageWidth=320;imageHeight=230;}
    @Override protected void init(){
        super.init();engrave=addRenderableWidget(Button.builder(Component.literal("룬 각인·교체"),b->{if(minecraft!=null&&minecraft.gameMode!=null)minecraft.gameMode.handleInventoryButtonClick(menu.containerId,0);}).bounds(leftPos+30,topPos+85,120,20).build());
        preview=addRenderableWidget(Button.builder(Component.literal("효과: 일반"),b->{previewRank=(previewRank+1)%5;updatePreview();}).bounds(leftPos+203,topPos+109,104,18).build());updatePreview();
    }
    private void updatePreview(){
        var rank=RuneRarity.values()[previewRank];preview.setMessage(Component.literal("효과: "+rank.getKoreanName()));
        var type=RuneWeaponType.forItem(menu.getSlot(0).getItem());StringBuilder text=new StringBuilder(rank.getKoreanName()+" 결과의 후보 (각 12.5%)\n");
        if(type==null)text.append("장비를 넣으면 후보 8종을 표시합니다.");else for(var effect:RuneEffectManager.getPossibleEffects(rank,type))text.append("• ").append(effect.getKoreanName()).append('\n');
        preview.setTooltip(Tooltip.create(Component.literal(text.toString())));
    }
    @Override protected void containerTick(){super.containerTick();engrave.active=RuneWeaponType.forItem(menu.getSlot(0).getItem())!=null&&RuneItemHelper.isRune(menu.getSlot(1).getItem());updatePreview();}
    @Override protected void renderBg(GuiGraphics g,float partial,int x,int y){
        g.fillGradient(leftPos,topPos,leftPos+imageWidth,topPos+imageHeight,0xFF282038,0xFF121721);
        g.fill(leftPos+8,topPos+24,leftPos+163,topPos+110,0xFF171221);g.fill(leftPos+171,topPos+24,leftPos+312,topPos+105,0xFF171221);
        g.fill(leftPos+8,topPos+23,leftPos+312,topPos+24,0xFFB18CE1);
        for(var slot:menu.slots)g.fill(leftPos+slot.x-1,topPos+slot.y-1,leftPos+slot.x+17,topPos+slot.y+17,0xFF080C13);
    }
    private void text(GuiGraphics g,String s,int x,int y,int color){g.drawString(font,s,x,y,color,false);}
    @Override protected void renderLabels(GuiGraphics g,int x,int y){
        text(g,"별의 룬 각인",10,9,0xEDD7FF);text(g,"장비",52,25,0xD5D9E0);text(g,"사용 룬",103,25,0xD5D9E0);
        text(g,"등급 추첨 → 8종 중 1종",19,67,0xB9ADC9);text(g,"결과 등급 확률",181,28,0xEDD7FF);
        var source=RuneItemHelper.getRarity(menu.getSlot(1).getItem());
        for(var rank:RuneRarity.values())text(g,rank.getKoreanName()+"  "+(source==null?"—":String.format(java.util.Locale.ROOT,"%.2f%%",RuneEffectManager.weight(source,rank)/100.0)),181,42+rank.ordinal()*12,COLORS[rank.ordinal()]);
        text(g,"기존 효과 교체 · 등급 하락 가능",10,113,0xFFAE8B);text(g,"장비 1개에 효과 1개 / 룬 1개 소모",10,128,0xA9B6C6);
    }
    @Override public void render(GuiGraphics g,int x,int y,float partial){super.render(g,x,y,partial);renderTooltip(g,x,y);}
}
