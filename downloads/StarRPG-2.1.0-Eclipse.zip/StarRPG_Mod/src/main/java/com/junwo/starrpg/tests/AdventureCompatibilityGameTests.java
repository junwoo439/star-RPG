package com.junwo.starrpg.tests;

import com.junwo.starrpg.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.gametest.framework.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.GameType;
import net.neoforged.fml.ModList;
import net.neoforged.neoforge.event.entity.living.LivingDropsEvent;
import net.neoforged.neoforge.gametest.*;

@GameTestHolder(StarRPG.MODID)
@PrefixGameTestTemplate(false)
public class AdventureCompatibilityGameTests {
    private static LivingEntity boss(GameTestHelper h,String id) {
        var key=ResourceLocation.parse(id);
        h.assertTrue(BuiltInRegistries.ENTITY_TYPE.containsKey(key),"Missing entity: "+id);
        var type=BuiltInRegistries.ENTITY_TYPE.get(key);
        h.assertTrue(type.is(MonsterProgression.BOSSES),"Missing boss tag: "+id);
        var entity=type.create(h.getLevel());
        h.assertTrue(entity instanceof LivingEntity,"Boss is not living: "+id);
        return (LivingEntity)entity;
    }
    @GameTest(template="empty") public static void twilightBossIdsAndScaling(GameTestHelper h) {
        if(!ModList.get().isLoaded("twilightforest")){h.succeed();return;}
        for(String id:new String[]{"naga","lich","minoshroom","hydra","knight_phantom","ur_ghast","alpha_yeti","snow_queen"}) {
            var mob=boss(h,"twilightforest:"+id);float base=mob.getMaxHealth();
            MonsterProgression.applyTier(mob,4);
            h.assertTrue(MonsterProgression.eligible(mob) && MonsterProgression.tier(mob)==4,"Boss not scalable: "+id);
            h.assertTrue(Math.abs(mob.getMaxHealth()-base*1.6)<0.02,"Wrong boss health scaling: "+id);
        }
        h.succeed();
    }
    @GameTest(template="empty") public static void mowzieBossIdsAndDependencies(GameTestHelper h) {
        if(!ModList.get().isLoaded("mowziesmobs")){h.succeed();return;}
        h.assertTrue(ModList.get().isLoaded("geckolib"),"Mowzie missing GeckoLib");
        for(String id:new String[]{"ferrous_wroughtnaut","frostmaw","umvuthi","sculptor"}) {
            var mob=boss(h,"mowziesmobs:"+id);
            h.assertTrue(MonsterProgression.eligible(mob),"Boss not eligible: "+id);
        }
        h.succeed();
    }
    @GameTest(template="empty") public static void twilightGoldAndMaterials(GameTestHelper h) {
        if(!ModList.get().isLoaded("twilightforest")){h.succeed();return;}
        var mob=boss(h,"twilightforest:naga");MonsterProgression.applyTier(mob,4);
        var player=h.makeMockPlayer(GameType.SURVIVAL);var wallet=StarWallet.get(player.getServer());
        int old=wallet.balance(player.getUUID());if(old>0)wallet.debit(player.getUUID(),old);
        var drops=new java.util.ArrayList<net.minecraft.world.entity.item.ItemEntity>();
        var event=new LivingDropsEvent(mob,h.getLevel().damageSources().playerAttack(player),drops,true);
        Economy.reward(event);Economy.reward(event);MobDropEvents.onLivingDrops(event);
        h.assertTrue(wallet.balance(player.getUUID())==360,"External boss gold missing/duplicated");
        h.assertTrue(drops.stream().anyMatch(e->e.getItem().is(StarRPG.STAR_FRAGMENT.get())),"External boss material reward missing");h.succeed();
    }
}
