package com.junwo.starrpg;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.*;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.bus.api.*;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

@EventBusSubscriber(modid=StarRPG.MODID)
public final class EnhancementTableAccess {
    @SubscribeEvent(priority=EventPriority.HIGH) public static void open(PlayerInteractEvent.RightClickBlock e){
        if(e.getHand()!=InteractionHand.MAIN_HAND||!e.getLevel().getBlockState(e.getPos()).is(Blocks.ENCHANTING_TABLE))return;
        if(e.getEntity().isSpectator()||!e.getEntity().isAlive()||ControlEffects.stunned(e.getEntity()))return;
        e.setCanceled(true);e.setCancellationResult(InteractionResult.sidedSuccess(e.getLevel().isClientSide()));
        if(e.getEntity() instanceof ServerPlayer p)p.openMenu(new SimpleMenuProvider((id,inv,player)->new EnhancementMenu(id,inv,ContainerLevelAccess.create(e.getLevel(),e.getPos())),Component.literal("별빛 강화 테이블")));
    }
}
