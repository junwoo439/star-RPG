package com.junwo.starrpg;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.*;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.*;
import net.neoforged.neoforge.event.tick.EntityTickEvent;

@EventBusSubscriber(modid=StarRPG.MODID)
public final class SpecialWeaponEffects {
    private static final ResourceLocation HEALTH=ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,"hammer_health");
    public static boolean behind(Player p,LivingEntity target){return p.position().subtract(target.position()).multiply(1,0,1).normalize().dot(target.getLookAngle().multiply(1,0,1).normalize())<-0.5;}
    @SubscribeEvent(priority=EventPriority.LOW) public static void incoming(LivingIncomingDamageEvent e){
        if(!CombatRules.primary(e.getSource())||!CombatRules.charged(e.getSource())||!(e.getSource().getEntity() instanceof Player p)||!(p.getMainHandItem().getItem() instanceof StarDaggerItem)||!CombatRules.canHarm(p,e.getEntity()))return;
        long now=p.level().getGameTime();if(p.getPersistentData().getLong("starrpg_dagger_ready")>now)return;
        if(behind(p,e.getEntity())){e.setAmount(e.getAmount()*1.2F);p.getPersistentData().putLong("starrpg_dagger_ready",now+60);}
    }
    @SubscribeEvent public static void hit(LivingDamageEvent.Post e){
        if(e.getNewDamage()<=0||!CombatRules.primary(e.getSource())||!CombatRules.charged(e.getSource())||!(e.getSource().getEntity() instanceof Player p)||!(p.getMainHandItem().getItem() instanceof WarHammerItem))return;
        long now=p.level().getGameTime();if(p.getPersistentData().getLong("starrpg_sweep_ready")>now)return;p.getPersistentData().putLong("starrpg_sweep_ready",now+20);
        float damage=(float)(p.getAttributeValue(Attributes.ATTACK_DAMAGE)+EnhancementData.combatPower(p.getMainHandItem()))*0.4F;
        p.level().getEntitiesOfClass(LivingEntity.class,p.getBoundingBox().inflate(3),target->target!=e.getEntity()&&CombatRules.canHarm(p,target)&&p.hasLineOfSight(target)&&p.distanceToSqr(target)<=9&&p.getLookAngle().dot(target.getEyePosition().subtract(p.getEyePosition()).normalize())>=0.25)
            .stream().sorted(java.util.Comparator.comparingDouble(t->t.distanceToSqr(p))).limit(8).forEach(t->CombatRules.runeDamage(p,t,damage));
        WeaponAbilities.arc(p,2,0);
    }
    @SubscribeEvent public static void tick(EntityTickEvent.Post e){
        if(e.getEntity().level().isClientSide()||!(e.getEntity() instanceof LivingEntity living))return;
        if(living.getPersistentData().contains("starrpg_hammer_until")){var armor=living.getAttribute(Attributes.ARMOR);if(armor!=null)armor.removeModifier(ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,"hammer_break"));living.getPersistentData().remove("starrpg_hammer_until");}
        if(living instanceof Player p){
            var health=p.getAttribute(Attributes.MAX_HEALTH);boolean holding=p.getMainHandItem().getItem() instanceof WarHammerItem;
            if(holding&&health.getModifier(HEALTH)==null)health.addOrUpdateTransientModifier(new AttributeModifier(HEALTH,6,AttributeModifier.Operation.ADD_VALUE));
            if(!holding&&health.getModifier(HEALTH)!=null)health.removeModifier(HEALTH);
            if(p.getHealth()>p.getMaxHealth())p.setHealth(p.getMaxHealth());
        }
    }
}
