package com.junwo.starrpg;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.EntityTickEvent;

@EventBusSubscriber(modid = StarRPG.MODID)
public final class ZombieHookAttack {
    @SubscribeEvent public static void tick(EntityTickEvent.Post event) {
        if (event.getEntity() instanceof Zombie zombie && zombie.level() instanceof ServerLevel) update(zombie);
    }
    public static void update(Zombie zombie) {
        var data = zombie.getPersistentData();
        if (!Config.MOB_SCALING.get() || !Config.ZOMBIE_HOOKS.get() || zombie.isNoAi() || !zombie.isAlive()
                || !zombie.getMainHandItem().is(Items.FISHING_ROD)
                || !(zombie.getTarget() instanceof Player player) || !player.isAlive() || player.isCreative()
                || player.isSpectator() || zombie.isAlliedTo(player) || !zombie.hasLineOfSight(player)
                || zombie.distanceToSqr(player) < 16 || zombie.distanceToSqr(player) > 196) {
            data.remove("starrpg_hook_cast"); data.remove("starrpg_hook_target"); return;
        }
        long now = zombie.level().getGameTime();
        if (data.getLong("starrpg_hook_cooldown") > now) return;
        if (!data.contains("starrpg_hook_cast")) {
            data.putLong("starrpg_hook_cast", now + 20);
            data.putUUID("starrpg_hook_target", player.getUUID());
            zombie.swing(InteractionHand.MAIN_HAND);
            zombie.playSound(SoundEvents.FISHING_BOBBER_THROW, 1.0F, 0.7F);
        } else if (!data.hasUUID("starrpg_hook_target") || !data.getUUID("starrpg_hook_target").equals(player.getUUID())) {
            data.remove("starrpg_hook_cast"); data.remove("starrpg_hook_target");
        } else if (now >= data.getLong("starrpg_hook_cast")) {
            ZombieHook hook = new ZombieHook(zombie.level(), zombie);
            var aim = player.getBoundingBox().getCenter().subtract(hook.position());
            hook.shoot(aim.x, aim.y, aim.z, 1.2F, 0);
            zombie.level().addFreshEntity(hook);
            zombie.swing(InteractionHand.MAIN_HAND);
            data.remove("starrpg_hook_cast"); data.remove("starrpg_hook_target");
            data.putLong("starrpg_hook_cooldown", now + Config.HOOK_COOLDOWN.get() * 20L);
        } else if (zombie.tickCount % 4 == 0) {
            ((ServerLevel)zombie.level()).sendParticles(ParticleTypes.CRIT, zombie.getX(), zombie.getEyeY(), zombie.getZ(), 3, 0.2,0.1,0.2,0.02);
        }
    }
}
