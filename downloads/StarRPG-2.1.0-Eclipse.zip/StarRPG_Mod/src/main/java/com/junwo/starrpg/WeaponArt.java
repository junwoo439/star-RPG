package com.junwo.starrpg;

import net.minecraft.world.item.*;

/** Atlas cell IDs double as stable weapon-family IDs. Never inferred from display names. */
public final class WeaponArt {
    public static int kind(ItemStack w){
        if(w.getItem() instanceof StarDaggerItem)return 2;
        if(w.getItem() instanceof WarHammerItem)return 3;
        if(w.getItem() instanceof MagicStaffItem)return 4;
        if(w.getItem() instanceof CareerWeaponItem item)return switch(item.job){case 0->5;case 5->6;case 6->7;case 7->8;case 8->9;default->10;};
        if(w.getItem() instanceof SwordItem)return 0;if(w.getItem() instanceof AxeItem)return 1;
        if(w.getItem() instanceof BowItem)return 11;if(w.getItem() instanceof CrossbowItem)return 12;if(w.getItem() instanceof TridentItem)return 13;return -1;
    }
    public static int color(int kind){return switch(kind){case 2,9->0x5AFFA0;case 3,12->0xFFB34B;case 4,8->0xC78AFF;case 6->0xFF5454;case 7->0xFFF19A;case 11,13->0x65F4E4;default->0x86CFFF;};}
}
