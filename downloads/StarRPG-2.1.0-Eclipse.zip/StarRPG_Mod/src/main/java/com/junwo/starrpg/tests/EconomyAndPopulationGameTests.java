package com.junwo.starrpg.tests;

import java.util.*;
import com.junwo.starrpg.*;
import net.minecraft.gametest.framework.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.level.GameType;
import net.neoforged.neoforge.event.entity.living.LivingDropsEvent;
import net.neoforged.neoforge.gametest.*;

@GameTestHolder(StarRPG.MODID)
@PrefixGameTestTemplate(false)
public class EconomyAndPopulationGameTests {
    @GameTest(template="empty") public static void tierFiveKeepsThreeFourFiveAfterReload(GameTestHelper h) {
        var clock=WorldDifficulty.get(h.getLevel().getServer());int original=clock.tier();clock.setTier(5);
        try {
            for(int offset=0;offset<=2;offset++) {
                var mob=EntityType.ZOMBIE.create(h.getLevel());mob.getPersistentData().putInt("starrpg_tier_offset",offset);
                MonsterProgression.tryScale(mob);
                h.assertTrue(MonsterProgression.tier(mob)==5-offset,"Assigned tier outside 3..5");
                mob.setHealth(6);
                CompoundTag tag=new CompoundTag();mob.saveWithoutId(tag);
                var loaded=EntityType.ZOMBIE.create(h.getLevel());loaded.load(tag);MonsterProgression.tryScale(loaded);
                h.assertTrue(MonsterProgression.tier(loaded)==5-offset && loaded.getHealth()==6,"Reload rerolled/healed or forced stage 5");
            }
            h.assertTrue(MonsterProgression.tierFor(0,2)==0 && MonsterProgression.tierFor(1,2)==0,"Negative low-tier enemy");
        } finally {clock.setTier(original);}
        h.succeed();
    }
    @GameTest(template="empty") public static void legacyUniformTierMigratesWithoutHealing(GameTestHelper h) {
        var clock=WorldDifficulty.get(h.getLevel().getServer());int original=clock.tier();clock.setTier(5);
        try {
            var z=EntityType.ZOMBIE.create(h.getLevel());MonsterProgression.applyTier(z,5);z.setHealth(7);
            z.getPersistentData().remove("starrpg_scaling_revision");z.getPersistentData().putInt("starrpg_tier_offset",2);
            MonsterProgression.tryScale(z);
            h.assertTrue(MonsterProgression.tier(z)==3 && z.getHealth()==7,"Legacy tier migration healed/did not lower enemy");
            double health=z.getMaxHealth();MonsterProgression.tryScale(z);
            h.assertTrue(z.getMaxHealth()==health && z.getHealth()==7,"Migration repeated");
        } finally {clock.setTier(original);}
        h.succeed();
    }
    @GameTest(template="empty") public static void armorGapsMigrateAndPreservePickedUpItems(GameTestHelper h) {
        var z=EntityType.ZOMBIE.create(h.getLevel());z.getPersistentData().putInt("starrpg_armor_mask",5);ZombieEquipment.equip(z,5);
        h.assertTrue(!z.getItemBySlot(EquipmentSlot.HEAD).isEmpty() && z.getItemBySlot(EquipmentSlot.CHEST).isEmpty() && !z.getItemBySlot(EquipmentSlot.LEGS).isEmpty() && z.getItemBySlot(EquipmentSlot.FEET).isEmpty(),"Armor gaps not applied");
        z.setItemSlot(EquipmentSlot.CHEST,z.getItemBySlot(EquipmentSlot.HEAD).copy());
        z.setItemSlot(EquipmentSlot.FEET,new ItemStack(Items.NETHERITE_BOOTS));z.getPersistentData().remove("starrpg_equipment_revision");
        ZombieEquipment.equip(z,5);
        h.assertTrue(z.getItemBySlot(EquipmentSlot.CHEST).isEmpty() && z.getItemBySlot(EquipmentSlot.FEET).is(Items.NETHERITE_BOOTS),"Migration removed native gear or kept generated full armor");h.succeed();
    }
    @GameTest(template="empty") public static void walletSavesByUuidAndClampsAmounts(GameTestHelper h) {
        StarWallet bank=new StarWallet();UUID a=UUID.randomUUID(),b=UUID.randomUUID();bank.credit(a,1000);
        h.assertTrue(!bank.debit(a,-1) && !bank.debit(a,1001) && !bank.transfer(a,a,1),"Invalid spend accepted");
        h.assertTrue(bank.transfer(a,b,125) && bank.balance(a)==875 && bank.balance(b)==125,"Transfer lost/created money");
        var loaded=StarWallet.load(bank.save(new CompoundTag(),h.getLevel().registryAccess()),h.getLevel().registryAccess());
        h.assertTrue(loaded.balance(a)==875 && loaded.balance(b)==125,"Saved accounts lost");
        loaded.credit(b,Integer.MAX_VALUE);h.assertTrue(loaded.balance(b)==StarWallet.MAX_BALANCE && !loaded.transfer(a,b,1) && loaded.balance(a)==875,"Overflow or failed transfer charged sender");h.succeed();
    }
    @GameTest(template="empty") public static void huntingLimitSurvivesSaveAndBossIsSeparate(GameTestHelper h) {
        var bank=new StarWallet();UUID a=UUID.randomUUID();
        for(int i=0;i<100;i++)bank.huntingReward(a,14,false,100);
        h.assertTrue(bank.balance(a)==240,"Normal farm cap missing");
        bank=StarWallet.load(bank.save(new CompoundTag(),h.getLevel().registryAccess()),h.getLevel().registryAccess());
        h.assertTrue(bank.huntingReward(a,14,false,101)==0,"Reload resets farm cap");
        h.assertTrue(bank.huntingReward(a,400,true,101)==400 && bank.huntingReward(a,14,false,1300)==14,"Boss reward/window reset wrong");h.succeed();
    }
    private static Player funded(GameTestHelper h) {
        var p=h.makeMockPlayer(GameType.SURVIVAL);var bank=StarWallet.get(h.getLevel().getServer());
        int old=bank.balance(p.getUUID());if(old>0)bank.debit(p.getUUID(),old);bank.credit(p.getUUID(),10000);return p;
    }
    @GameTest(template="empty") public static void purchaseChargesExactlyAndDeliversMaterials(GameTestHelper h) {
        var p=funded(h);var bank=StarWallet.get(p.getServer());
        for(var product:Economy.Product.values()) {
            p.getInventory().clearContent();bank.credit(p.getUUID(),10000);
            int before=bank.balance(p.getUUID());
            h.assertTrue(Economy.buy(p,product,8)==Economy.Purchase.OK,"Valid purchase rejected");
            h.assertTrue(bank.balance(p.getUUID())==before-product.price()*8 && p.getInventory().countItem(product.stack(1).getItem())==8,"Incorrect price/delivery");
        }
        int before=bank.balance(p.getUUID());Economy.buy(p,Economy.Product.DUST,-1);Economy.buy(p,Economy.Product.DUST,65);
        h.assertTrue(bank.balance(p.getUUID())==before,"Invalid count altered wallet");h.succeed();
    }
    @GameTest(template="empty") public static void fullInventoryNeverChargesOrPartiallyDelivers(GameTestHelper h) {
        var p=funded(h);var bank=StarWallet.get(p.getServer());
        for(int i=0;i<p.getInventory().items.size();i++)p.getInventory().items.set(i,new ItemStack(Items.STONE,64));
        p.getInventory().items.set(0,Economy.Product.DUST.stack(63));int before=bank.balance(p.getUUID());
        h.assertTrue(Economy.buy(p,Economy.Product.DUST,8)==Economy.Purchase.NO_SPACE && bank.balance(p.getUUID())==before && p.getInventory().getItem(0).getCount()==63,"Partial purchase lost money/materials");
        h.assertTrue(Economy.buy(p,Economy.Product.DUST,1)==Economy.Purchase.OK && p.getInventory().getItem(0).getCount()==64,"Existing stack room rejected");h.succeed();
    }
    @GameTest(template="empty") public static void insufficientFundsAndForeignMenuClicksRejected(GameTestHelper h) {
        var p=funded(h);var bank=StarWallet.get(p.getServer());bank.debit(p.getUUID(),bank.balance(p.getUUID()));
        h.assertTrue(Economy.buy(p,Economy.Product.FRAGMENT,1)==Economy.Purchase.NO_MONEY && p.getInventory().isEmpty(),"Unfunded purchase delivered item");
        var menu=new MaterialShopMenu(1,p.getInventory());var other=h.makeMockPlayer(GameType.SURVIVAL);
        h.assertTrue(!menu.clickMenuButton(other,0) && !menu.clickMenuButton(p,-1) && !menu.clickMenuButton(p,6),"Invalid shop click accepted");h.succeed();
    }
    @GameTest(template="empty") public static void killsAwardOnceAndExcludeAnimalsAndCreative(GameTestHelper h) {
        var p=funded(h);var bank=StarWallet.get(p.getServer());int before=bank.balance(p.getUUID());
        var z=EntityType.ZOMBIE.create(h.getLevel());MonsterProgression.applyTier(z,3);
        var event=new LivingDropsEvent(z,h.getLevel().damageSources().playerAttack(p),new ArrayList<>(),true);
        Economy.reward(event);Economy.reward(event);
        h.assertTrue(bank.balance(p.getUUID())==before+10,"Kill reward duplicated or wrong tier");
        Economy.reward(new LivingDropsEvent(EntityType.COW.create(h.getLevel()),event.getSource(),new ArrayList<>(),true));
        h.assertTrue(bank.balance(p.getUUID())==before+10,"Cow awarded currency");
        var c=h.makeMockPlayer(GameType.CREATIVE);int cb=bank.balance(c.getUUID());
        Economy.reward(new LivingDropsEvent(EntityType.ZOMBIE.create(h.getLevel()),h.getLevel().damageSources().playerAttack(c),new ArrayList<>(),true));
        h.assertTrue(bank.balance(c.getUUID())==cb,"Creative player farmed currency");h.succeed();
    }
    @GameTest(template="empty") public static void shopSyncPreservesLargeBalance(GameTestHelper h) {
        var p=funded(h);var bank=StarWallet.get(p.getServer());bank.credit(p.getUUID(),1000000);
        var menu=new MaterialShopMenu(1,p.getInventory());menu.broadcastChanges();
        h.assertTrue(menu.balance()==bank.balance(p.getUUID()) && menu.price(2)==Config.RUNE_PRICE.get(),"Shop balance truncated to 16 bits or wrong price");h.succeed();
    }
}
