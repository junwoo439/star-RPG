package com.junwo.starrpg;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.*;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.SimpleMenuProvider;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Only action IDs cross the wire; targets, money, weapon and cooldowns are resolved on the server. */
public record ActionPayload(int action) implements CustomPacketPayload {
    public static final Type<ActionPayload> TYPE=new Type<>(ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,"action"));
    public static final StreamCodec<ByteBuf,ActionPayload> STREAM_CODEC=StreamCodec.composite(ByteBufCodecs.VAR_INT,ActionPayload::action,ActionPayload::new);
    @Override public Type<? extends CustomPacketPayload> type(){return TYPE;}
    public static void handle(ActionPayload message,IPayloadContext context){
        context.enqueueWork(()->{
            if(!(context.player() instanceof ServerPlayer p)||!p.isAlive()||p.isSpectator())return;
            if(message.action==0){
                long now=p.level().getGameTime();if(p.getPersistentData().getLong("starrpg_menu_ready")>now)return;
                p.getPersistentData().putLong("starrpg_menu_ready",now+5);
                p.openMenu(new SimpleMenuProvider((id,inv,player)->new MaterialShopMenu(id,inv),Component.literal("StarRPG")));
            }else if(message.action==1)WeaponAbilities.activate(p);
            else if(message.action==2)Careers.cast(p);
            else if(message.action==3)WeaponAwakening.activate(p);
        });
    }
}
