package com.junwo.starrpg;

import net.minecraft.world.item.ItemStack;

public class RuneItemHelper {

    public static RuneRarity getRarity(ItemStack stack) {
        if (stack.is(StarRPG.COMMON_RUNE.get())) {
            return RuneRarity.COMMON;
        }

        if (stack.is(StarRPG.RARE_RUNE.get())) {
            return RuneRarity.RARE;
        }

        if (stack.is(StarRPG.EPIC_RUNE.get())) {
            return RuneRarity.EPIC;
        }

        if (stack.is(StarRPG.LEGENDARY_RUNE.get())) {
            return RuneRarity.LEGENDARY;
        }

        if (stack.is(StarRPG.MYTHIC_RUNE.get())) {
            return RuneRarity.MYTHIC;
        }

        return null;
    }

    public static boolean isRune(ItemStack stack) {
        return getRarity(stack) != null;
    }
}