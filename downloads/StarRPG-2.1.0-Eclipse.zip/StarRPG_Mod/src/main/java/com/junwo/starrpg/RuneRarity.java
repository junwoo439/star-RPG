package com.junwo.starrpg;

public enum RuneRarity {
    COMMON("일반"),
    RARE("희귀"),
    EPIC("에픽"),
    LEGENDARY("레전더리"),
    MYTHIC("신화");

    private final String koreanName;

    RuneRarity(String koreanName) {
        this.koreanName = koreanName;
    }

    public String getKoreanName() {
        return koreanName;
    }
}