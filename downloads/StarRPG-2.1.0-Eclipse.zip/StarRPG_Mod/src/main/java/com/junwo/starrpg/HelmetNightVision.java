package com.junwo.starrpg;

import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;

public final class HelmetNightVision {
    private static final String OWNED = "starrpg_helmet_night_vision";

    public static void update(Player player, boolean wearing) {
        MobEffectInstance effect = player.getEffect(MobEffects.NIGHT_VISION);
        boolean owned = player.getPersistentData().getBoolean(OWNED);
        // External potions have their own icon/particles or longer duration. Never remove those.
        boolean ours = owned && effect != null && !effect.isInfiniteDuration()
                && effect.getDuration() <= 400 && effect.getAmplifier() == 0
                && !effect.isVisible() && !effect.showIcon();
        if (!wearing) {
            if (ours) player.removeEffect(MobEffects.NIGHT_VISION);
            player.getPersistentData().remove(OWNED);
            return;
        }
        // Vanilla starts pulsing below 200 ticks. Refresh well before that threshold.
        if (effect == null || (!effect.isInfiniteDuration() && effect.getDuration() < 300)) {
            player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0, false, false, false));
            player.getPersistentData().putBoolean(OWNED, true);
        }
    }
}
