package com.junwo.starrpg;

import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.*;

/** Uses the original painted atlas directly; does not lower the block atlas mipmap level. */
public final class ArtisanItemRenderer extends BlockEntityWithoutLevelRenderer {
    public static final ResourceLocation ATLAS=ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,"textures/art/weapons_and_sigils.png");
    public ArtisanItemRenderer(){super(Minecraft.getInstance().getBlockEntityRenderDispatcher(),Minecraft.getInstance().getEntityModels());}
    @Override public void renderByItem(ItemStack stack,ItemDisplayContext context,PoseStack pose,MultiBufferSource buffers,int light,int overlay){
        int kind=WeaponArt.kind(stack);if(kind<0)return;pose.pushPose();pose.translate(0.5,0.5,0.5);
        var player=Minecraft.getInstance().player;
        if(player!=null&&player.isUsingItem()&&ItemStack.isSameItemSameComponents(player.getUseItem(),stack)&&(kind==11||kind==12)){
            float pull=Math.min(1,player.getTicksUsingItem()/(kind==11?18F:25F));pose.scale(1-0.12F*pull,1+0.06F*pull,1);
        }
        // Faces on both sides keep the drawing visible from either hand and on returning daggers.
        var out=buffers.getBuffer(RenderType.entityTranslucent(ATLAS));
        quad(pose,out,kind,0.66F,0xFFFFFF,1,light,0.025F,false);
        quad(pose,out,kind,0.66F,0xFFFFFF,1,light,-0.025F,true);
        if(kind==12&&CrossbowItem.isCharged(stack)){
            pose.pushPose();pose.translate(0,-0.06,0.03);quad(pose,out,14,0.20F,0xFFDE76,0.7F,15728880,0,false);quad(pose,out,14,0.20F,0xFFDE76,0.7F,15728880,-0.07F,true);pose.popPose();
        }pose.popPose();
    }
    public static void quad(PoseStack pose,VertexConsumer out,int cell,float radius,int rgb,float alpha,int light,float z,boolean reverse){
        float u=(cell%4)*0.25F,v=(cell/4)*0.25F;var p=pose.last();
        float[][] vertices=reverse?new float[][]{{-radius,-radius,u,v+.25F},{-radius,radius,u,v},{radius,radius,u+.25F,v},{radius,-radius,u+.25F,v+.25F}}
            :new float[][]{{-radius,-radius,u,v+.25F},{radius,-radius,u+.25F,v+.25F},{radius,radius,u+.25F,v},{-radius,radius,u,v}};
        for(var a:vertices)out.addVertex(p,a[0],a[1],z).setColor((rgb>>16)&255,(rgb>>8)&255,rgb&255,(int)(Math.clamp(alpha,0,1)*255))
            .setUv(a[2],a[3]).setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(p,0,0,reverse?-1:1);
    }
}
