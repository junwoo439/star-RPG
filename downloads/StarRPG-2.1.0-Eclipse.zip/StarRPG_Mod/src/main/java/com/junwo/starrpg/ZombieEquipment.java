package com.junwo.starrpg;

import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.item.*;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.enchantment.Enchantments;

public final class ZombieEquipment {
    private static final String STAGE = "starrpg_equipment_stage";
    private static final String GENERATED = "starrpg_monster_equipment";
    private static final String REVISION = "starrpg_equipment_revision";
    private static final String MASK = "starrpg_armor_mask";
    private static final String ROLE = "starrpg_hook_roll";
    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private static final Item[][] ARMOR = {
        {Items.LEATHER_HELMET, Items.LEATHER_CHESTPLATE, Items.LEATHER_LEGGINGS, Items.LEATHER_BOOTS},
        {Items.CHAINMAIL_HELMET, Items.CHAINMAIL_CHESTPLATE, Items.CHAINMAIL_LEGGINGS, Items.CHAINMAIL_BOOTS},
        {Items.IRON_HELMET, Items.IRON_CHESTPLATE, Items.IRON_LEGGINGS, Items.IRON_BOOTS},
        {Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE, Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS}
    };

    public static boolean supported(Zombie zombie) {
        return zombie.getType() == EntityType.ZOMBIE || zombie.getType() == EntityType.HUSK
                || zombie.getType() == EntityType.ZOMBIE_VILLAGER;
    }
    public static boolean generated(ItemStack stack) {
        return stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getBoolean(GENERATED);
    }
    public static void equip(Zombie zombie, int requested) {
        if (!Config.ZOMBIE_EQUIPMENT.get() || !supported(zombie)) return;
        int tier = Math.clamp(requested, 0, 5);
        var data = zombie.getPersistentData();
        boolean migrate = data.getInt(REVISION) < 2;
        if (!migrate && data.contains(STAGE) && data.getInt(STAGE) >= tier) return;
        data.putInt(REVISION, 2);
        if (!data.contains(MASK)) {
            int mask = 15 & ~(1 << zombie.getRandom().nextInt(4));
            if (zombie.getRandom().nextBoolean()) {
                int second;
                do { second = zombie.getRandom().nextInt(4); } while ((mask & (1 << second)) == 0);
                mask &= ~(1 << second);
            }
            data.putInt(MASK, mask);
        }
        data.putInt(STAGE, tier);
        if (!data.contains(ROLE)) data.putInt(ROLE, zombie.getRandom().nextInt(100));
        int armorSet = tier >= 4 ? 3 : Math.min(tier, 2);
        int chance = Math.min(100, 20 + Math.min(5,tier) * 20);
        int enchantment = tier >= 4 ? 1 : 0;
        for (int i = 0; i < SLOTS.length; i++) {
            ItemStack old = zombie.getItemBySlot(SLOTS[i]);
            if (!old.isEmpty() && !generated(old)) continue;
            if ((data.getInt(MASK) & (1 << i)) == 0) {
                if (generated(old)) zombie.setItemSlot(SLOTS[i], ItemStack.EMPTY);
                continue;
            }
            if (old.isEmpty() && zombie.getRandom().nextInt(100) >= chance) continue;
            String materialKey = "starrpg_armor_material_" + i;
            if (!data.contains(materialKey)) data.putBoolean(materialKey, zombie.getRandom().nextBoolean());
            int material = Math.max(0, armorSet - (data.getBoolean(materialKey) ? 1 : 0));
            give(zombie, SLOTS[i], ARMOR[material][i], enchantment, true);
        }
        ItemStack hand = zombie.getMainHandItem();
        // Preserve native equipment and items picked up from a player.
        if (!hand.isEmpty() && !generated(hand)) return;
        boolean hook = Config.ZOMBIE_HOOKS.get() && tier >= 2 && data.getInt(ROLE) < 15 + (tier - 2) * 10;
        if (hook) give(zombie, EquipmentSlot.MAINHAND, Items.FISHING_ROD, 0, false);
        else if (!hand.isEmpty() || zombie.getRandom().nextInt(100) < 20 + Math.min(5,tier) * 20)
            give(zombie, EquipmentSlot.MAINHAND, tier >= 2 ? Items.IRON_SWORD : Items.STONE_SWORD,
                    enchantment, false);
    }
    private static void give(Zombie zombie, EquipmentSlot slot, Item item, int level, boolean armor) {
        ItemStack stack = new ItemStack(item);
        CustomData.update(DataComponents.CUSTOM_DATA, stack, tag -> tag.putBoolean(GENERATED, true));
        if (level > 0 && !Config.NO_VANILLA_ENCHANTMENTS.get()) stack.enchant(zombie.registryAccess().registryOrThrow(Registries.ENCHANTMENT)
                .getHolderOrThrow(armor ? Enchantments.PROTECTION : Enchantments.SHARPNESS), level);
        zombie.setItemSlot(slot, stack);
        zombie.setDropChance(slot, 0.0F);
    }
}
