package com.junwo.starrpg;

import java.util.List;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.common.NeoForgeMod;
import net.neoforged.neoforge.event.entity.living.*;
import net.neoforged.neoforge.event.entity.player.CriticalHitEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

@EventBusSubscriber(modid = StarRPG.MODID)
public final class ArmorRuneEffects {
    private static ResourceLocation id(String name) { return ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,"rune_"+name); }
    public static RuneEffect effect(Player player, EquipmentSlot slot) {
        var item=player.getItemBySlot(slot);var effect=RuneDataHelper.getRuneEffect(item);
        if (!(item.getItem() instanceof net.minecraft.world.item.ArmorItem armor) || armor.getEquipmentSlot()!=slot
                || effect==null || !effect.getWeaponType().isArmor() || effect.getWeaponType()!=RuneWeaponType.forItem(item)) return null;
        return effect;
    }
    public static int grade(Player player,EquipmentSlot slot) { var e=effect(player,slot);return e==null?0:e.getRarity().ordinal()+1; }
    public static int grade(Player player,EquipmentSlot slot,int variant) {
        var e=effect(player,slot);return e==null || e.getVariant()!=variant?0:e.getRarity().ordinal()+1;
    }
    public static double hookMultiplier(Player player) { int g=grade(player,EquipmentSlot.LEGS,0);return g==0?1:1-(0.1+g*0.1); }
    private static void attribute(AttributeInstance instance,String name,double value,AttributeModifier.Operation op) {
        if(instance==null)return;var key=id(name);
        if(value==0){instance.removeModifier(key);return;}
        var old=instance.getModifier(key);
        if(old==null || Math.abs(old.amount()-value)>0.00001)instance.addOrUpdateTransientModifier(new AttributeModifier(key,value,op));
    }
    public static void update(Player p) {
        long now=p.level().getGameTime();
        int anchor=grade(p,EquipmentSlot.LEGS,0),vitality=grade(p,EquipmentSlot.LEGS,1),bulwark=grade(p,EquipmentSlot.LEGS,2);
        attribute(p.getAttribute(Attributes.KNOCKBACK_RESISTANCE),"anchor",anchor==0?0:0.05+anchor*0.05,AttributeModifier.Operation.ADD_VALUE);
        attribute(p.getAttribute(Attributes.MAX_HEALTH),"vitality",vitality*2,AttributeModifier.Operation.ADD_VALUE);
        attribute(p.getAttribute(Attributes.ARMOR),"bulwark",p.isCrouching()?bulwark:0,AttributeModifier.Operation.ADD_VALUE);
        int stride=grade(p,EquipmentSlot.FEET,0),escape=grade(p,EquipmentSlot.FEET,1);
        double speed=p.isSprinting()?stride*0.03:0;
        if(escape>0 && p.getPersistentData().getLong("starrpg_escape_until")>now)speed=0.10+escape*0.02;
        attribute(p.getAttribute(Attributes.MOVEMENT_SPEED),"stride",speed,AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
        attribute(p.getAttribute(NeoForgeMod.SWIM_SPEED),"aquatic",grade(p,EquipmentSlot.FEET,2)*0.1,AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
        attribute(p.getAttribute(Attributes.STEP_HEIGHT),"pathfinder",grade(p,EquipmentSlot.FEET,3)*0.1,AttributeModifier.Operation.ADD_VALUE);
        if(p.getHealth()>p.getMaxHealth())p.setHealth(p.getMaxHealth());
        if(!p.isAlive())return;
        int head=grade(p,EquipmentSlot.HEAD,0),composure=grade(p,EquipmentSlot.HEAD,3);
        if((head>0 || composure>0) && p.getPersistentData().getLong("starrpg_rune_cleanse_ready")<=now) {
            var effects=head>0?List.of(MobEffects.POISON,MobEffects.BLINDNESS,MobEffects.DARKNESS):List.of(MobEffects.WEAKNESS,MobEffects.MOVEMENT_SLOWDOWN);
            if(effects.stream().anyMatch(p::hasEffect)) {
                effects.forEach(p::removeEffect);
                p.getPersistentData().putLong("starrpg_rune_cleanse_ready",now+(35-Math.max(head,composure)*5)*20L);
            }
        }
        int recovery=grade(p,EquipmentSlot.LEGS,3);
        if(recovery>0 && p.getHealth()<p.getMaxHealth() && p.getFoodData().getFoodLevel()>=6
                && now-p.getPersistentData().getLong("starrpg_armor_last_damage")>=160
                && p.getPersistentData().getLong("starrpg_recovery_ready")<=now) {
            p.heal(recovery*0.5F);p.causeFoodExhaustion(1);
            p.getPersistentData().putLong("starrpg_recovery_ready",now+120);
        }
    }
    @SubscribeEvent public static void tick(PlayerTickEvent.Post e){if(!e.getEntity().level().isClientSide())update(e.getEntity());}
    @SubscribeEvent public static void critical(CriticalHitEvent e) {
        if(e.isCriticalHit())e.setDamageMultiplier(e.getDamageMultiplier()+grade(e.getEntity(),EquipmentSlot.HEAD,2)*0.03F);
    }
    @SubscribeEvent public static void incoming(LivingIncomingDamageEvent e) {
        if(!(e.getEntity() instanceof Player p) || e.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY))return;
        int g=grade(p,EquipmentSlot.CHEST);var rune=effect(p,EquipmentSlot.CHEST);if(rune==null)return;
        float reduction=switch(rune.getVariant()) {
            case 0 -> e.getSource().is(DamageTypeTags.IS_PROJECTILE)?g*0.04F:0;
            case 1 -> e.getSource().getDirectEntity() instanceof LivingEntity && !e.getSource().is(DamageTypeTags.IS_PROJECTILE)?g*0.03F:0;
            case 2 -> e.getSource().is(DamageTypeTags.IS_FIRE)?g*0.06F:0;
            case 3 -> p.getHealth()<=p.getMaxHealth()*0.35F?0.06F+g*0.02F:0;
            default -> 0;
        };
        e.setAmount(e.getAmount()*(1-reduction));
    }
    @SubscribeEvent public static void hurt(LivingDamageEvent.Post e) {
        if(!(e.getEntity() instanceof Player p) || e.getNewDamage()<=0)return;
        long now=p.level().getGameTime();p.getPersistentData().putLong("starrpg_armor_last_damage",now);
        int sentry=grade(p,EquipmentSlot.HEAD,1);
        if(sentry>0 && p.getPersistentData().getLong("starrpg_sentry_ready")<=now
                && e.getSource().getEntity() instanceof LivingEntity attacker && CombatRules.canHarm(p,attacker)) {
            attacker.addEffect(new MobEffectInstance(MobEffects.GLOWING,(2+sentry)*20,0));
            p.getPersistentData().putLong("starrpg_sentry_ready",now+160);
        }
        if(grade(p,EquipmentSlot.FEET,1)>0 && p.getPersistentData().getLong("starrpg_escape_ready")<=now) {
            p.getPersistentData().putLong("starrpg_escape_until",now+40);p.getPersistentData().putLong("starrpg_escape_ready",now+160);
        }
    }
    public static List<String> description(RuneEffect e) {
        int g=e.getRarity().ordinal()+1,v=e.getVariant();
        return switch(e.getWeaponType()) {
            case HELMET -> switch(v) {
                case 0 -> List.of("독·실명·어둠 자동 해제", "재사용 "+(35-g*5)+"초 / 장비 교체로 초기화 불가");
                case 1 -> List.of("나를 공격한 적에게 발광 "+(2+g)+"초", "재사용 8초");
                case 2 -> List.of("근접 치명타 배율 +"+(g*3)+"%p");
                default -> List.of("나약함·둔화 자동 해제", "재사용 "+(35-g*5)+"초 / 정화와 재사용 공유");
            };
            case CHESTPLATE -> switch(v) {
                case 0 -> List.of("투사체 피해 "+g*4+"% 감소");
                case 1 -> List.of("직접 근접 피해 "+g*3+"% 감소");
                case 2 -> List.of("화염 피해 "+g*6+"% 감소");
                default -> List.of("체력 35% 이하일 때 받는 피해 "+(6+g*2)+"% 감소");
            };
            case LEGGINGS -> switch(v) {
                case 0 -> List.of("밀쳐짐 저항 +"+(5+g*5)+"%p", "좀비 갈고리 당김 "+(10+g*10)+"% 감소");
                case 1 -> List.of("최대 체력 +"+g*2);
                case 2 -> List.of("웅크리는 동안 방어력 +"+g);
                default -> List.of("8초간 피해를 받지 않으면 6초마다 체력 "+g*0.5F+" 회복", "허기 6 이상 필요 / 회복 시 허기 소모");
            };
            case BOOTS -> switch(v) {
                case 0 -> List.of("질주 중 이동속도 +"+g*3+"%");
                case 1 -> List.of("피격 후 2초간 이동속도 +"+(10+g*2)+"%", "재사용 8초");
                case 2 -> List.of("수영 속도 +"+g*10+"%");
                default -> List.of("자동으로 오르는 높이 +"+String.format(java.util.Locale.ROOT,"%.1f",g*0.1)+"칸");
            };
            default -> List.of();
        };
    }
}
