package com.junwo.starrpg;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.component.ItemLore;

public class EnhancementLore {
	

	public static void update(ItemStack item) {
	    int level = getEnhancementLevel(item);
	    RuneEffect runeEffect = RuneDataHelper.getRuneEffect(item);

	    if (level <= 0 && runeEffect == null) {
	        item.remove(DataComponents.LORE);
	        return;
	    }

	    List<Component> lore = new ArrayList<>();

	    if (level > 0) {
	        lore.add(
	                Component.literal("강화 단계: +" + level)
	                        .withStyle(ChatFormatting.GOLD)
	        );

	        if (EnhancementData.unlimited(item)) {
                double power=EnhancementData.combatPower(item);
                lore.add(Component.literal("무한 강화 · 실패 시 단계 유지 / 파괴 없음").withStyle(ChatFormatting.AQUA));
                double coefficient=item.getItem() instanceof MagicStaffItem?0.6:item.getItem() instanceof StarDaggerItem?0.6:RuneWeaponType.forItem(item).isRanged()?0.5:1;
                lore.add(Component.literal(String.format(java.util.Locale.ROOT,"강화 피해 +%.1f",power*coefficient)).withStyle(ChatFormatting.RED));
                if(item.getItem() instanceof SwordItem&&level>=6)lore.add(Component.literal(String.format(java.util.Locale.ROOT,"최대 체력 +%.1f",(EnhancementData.power(item)-5)*2)));
                if(item.getItem() instanceof SwordItem&&Careers.weaponJob(item)<0&&level>=10)lore.add(Component.literal("흡혈 "+Math.round(Config.LIFESTEAL.get()*100)+"% / 초당 최대 "+Config.HEAL_CAP.get()));
                if(item.getItem() instanceof AxeItem&&level>=6)lore.add(Component.literal(String.format(java.util.Locale.ROOT,"치명타 배율 +%.0f%%p",Math.min(150,(power-5)*10))));
                if(item.getItem() instanceof AxeItem&&level>=10)lore.add(Component.literal("충전 공격: 출혈 콤보"));
                if(item.getItem() instanceof net.minecraft.world.item.TridentItem)lore.add(Component.literal(String.format(java.util.Locale.ROOT,"근접 강화 피해 +%.1f",power)));
            } else if (item.getItem() instanceof MagicStaffItem) {
                lore.add(Component.literal("마법 강화 피해 +" + level * 0.3F).withStyle(ChatFormatting.LIGHT_PURPLE));
            } else if (item.getItem() instanceof SwordItem) {
                addSwordLore(lore, level);
                if (item.getItem() instanceof StarDaggerItem) lore.set(1, Component.literal("강화 공격력 +" + String.format(java.util.Locale.ROOT, "%.1f", level * 0.6)).withStyle(ChatFormatting.RED));
	        } else if (item.getItem() instanceof AxeItem) {
	            addAxeLore(lore, level);
            } else if (RuneWeaponType.forItem(item) != null && RuneWeaponType.forItem(item).isRanged()) {
                lore.add(Component.literal("투사체 강화 피해 +" + level * 0.5F).withStyle(ChatFormatting.RED));
                if (RuneWeaponType.forItem(item) == RuneWeaponType.TRIDENT) lore.add(Component.literal("근접 강화 피해 +" + level));
                if (RuneWeaponType.forItem(item) == RuneWeaponType.BOW) lore.add(Component.literal("활 충전량에 비례"));
                if (RuneWeaponType.forItem(item) == RuneWeaponType.CROSSBOW) lore.add(Component.literal("화살에 적용 / 폭죽 제외"));
	        } else if (item.getItem() instanceof ArmorItem armor) {
	            addArmorLore(lore, armor.getEquipmentSlot(), level);
	        }
	    }
	    if (runeEffect != null) {
	        lore.add(
	                Component.literal("──────── 별의 룬 ────────")
	                        .withStyle(ChatFormatting.DARK_PURPLE)
	        );

	        lore.add(
	                Component.literal(
	                        runeEffect.getRarity().getKoreanName()
	                                + " · "
	                                + runeEffect.getKoreanName()
	                ).withStyle(ChatFormatting.LIGHT_PURPLE)
	        );

	        for (String line : RuneEffectDescription.getDescriptionLines(runeEffect)) {
	            lore.add(
	                    Component.literal(line)
	                            .withStyle(ChatFormatting.GRAY)
	            );
	        }
	    }

        item.set(DataComponents.LORE, new ItemLore(lore));
    }

    private static void addSwordLore(List<Component> lore, int level) {
        lore.add(
                Component.literal("공격력 +" + level)
                        .withStyle(ChatFormatting.RED)
        );

        if (level >= 6) {
            int healthBonus = (level - 5) * 2;

            lore.add(
                    Component.literal("최대 체력 +" + healthBonus)
                            .withStyle(ChatFormatting.RED)
            );
        }

        if (level >= 10) {
            lore.add(
                    Component.literal("흡혈 " + Math.round(Config.LIFESTEAL.get() * 100) + "% / 초당 최대 " + Config.HEAL_CAP.get())
                            .withStyle(ChatFormatting.DARK_RED)
            );
        }
    }

    private static void addAxeLore(List<Component> lore, int level) {
        lore.add(
                Component.literal("공격력 +" + level)
                        .withStyle(ChatFormatting.RED)
        );

        if (level >= 6) {
            int criticalBonus = (level - 5) * 10;

            lore.add(
                    Component.literal("치명타 배율 +" + criticalBonus + "%p")
                            .withStyle(ChatFormatting.YELLOW)
            );
        }

        if (level >= 10) {
            lore.add(
                    Component.literal("특수: 출혈")
                            .withStyle(ChatFormatting.DARK_RED)
            );

            lore.add(
                    Component.literal("1~2타: 추가 피해 1")
                            .withStyle(ChatFormatting.GRAY)
            );

            lore.add(
                    Component.literal("3~4타: 추가 피해 2")
                            .withStyle(ChatFormatting.GRAY)
            );

            lore.add(
                    Component.literal("5타 이후: 추가 피해 4")
                            .withStyle(ChatFormatting.GRAY)
            );
        }
    }

    private static void addArmorLore(
            List<Component> lore,
            EquipmentSlot slot,
            int level
    ) {
        lore.add(
                Component.literal("최대 체력 +" + level)
                        .withStyle(ChatFormatting.RED)
        );

        switch (slot) {
            case HEAD -> addHelmetLore(lore, level);
            case CHEST -> addChestplateLore(lore, level);
            case LEGS -> addLeggingsLore(lore, level);
            case FEET -> addBootsLore(lore, level);
            default -> {
            }
        }
    }

    private static void addHelmetLore(List<Component> lore, int level) {
        if (level >= 5) {
            lore.add(
                    Component.literal("야간 투시")
                            .withStyle(ChatFormatting.AQUA)
            );
        }

        if (level >= 7) {
            lore.add(
                    Component.literal("수중 호흡")
                            .withStyle(ChatFormatting.AQUA)
            );
        }

        if (level >= 10) {
            lore.add(
                    Component.literal("특수: 화염 저항")
                            .withStyle(ChatFormatting.GOLD)
            );

            lore.add(
                    Component.literal("5초마다 화염 저항 3초")
                            .withStyle(ChatFormatting.GRAY)
            );
        }
    }

    private static void addChestplateLore(List<Component> lore, int level) {
        if (level >= 7) {
            int resistanceLevel = 1;

            lore.add(
                    Component.literal("저항 " + resistanceLevel)
                            .withStyle(ChatFormatting.BLUE)
            );
        }

        if (level >= 10) {
            lore.add(
                    Component.literal("특수: 재생 II, 3초 + 흡수 II, 6초")
                            .withStyle(ChatFormatting.LIGHT_PURPLE)
            );

            lore.add(
                    Component.literal("X키 사용 / 쿨타임 60초")
                            .withStyle(ChatFormatting.GRAY)
            );
        }
    }

    private static void addLeggingsLore(List<Component> lore, int level) {
        if (level >= 5) {
            int speedLevel;

            if (level >= 10) {
                speedLevel = 4;
            } else if (level >= 9) {
                speedLevel = 3;
            } else if (level >= 7) {
                speedLevel = 2;
            } else {
                speedLevel = 1;
            }

            lore.add(
                    Component.literal("신속 " + speedLevel)
                            .withStyle(ChatFormatting.GREEN)
            );
        }

        if (level >= 10) {
            lore.add(
                    Component.literal("돌고래의 은총 II")
                            .withStyle(ChatFormatting.AQUA)
            );

            lore.add(
                    Component.literal("10초마다 출혈 제거")
                            .withStyle(ChatFormatting.GREEN)
            );
        }
    }

    private static void addBootsLore(List<Component> lore, int level) {
        if (level >= 5) {
            int jumpLevel;

            if (level >= 10) {
                jumpLevel = 3;
            } else if (level >= 9) {
                jumpLevel = 2;
            } else {
                jumpLevel = 1;
            }

            lore.add(
                    Component.literal("점프 강화 " + jumpLevel)
                            .withStyle(ChatFormatting.GREEN)
            );
        }

        if (level >= 10) {
            lore.add(
                    Component.literal("낙하 피해 무효")
                            .withStyle(ChatFormatting.BLUE)
            );

            lore.add(
                    Component.literal("적 생명력 흡수 50% 감소")
                            .withStyle(ChatFormatting.DARK_PURPLE)
            );
        }
    }

    private static int getEnhancementLevel(ItemStack item) {
        return EnhancementData.level(item);
    }
}