package com.junwo.starrpg;

import java.util.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.*;
import net.minecraft.world.item.component.*;
import net.minecraft.world.entity.player.Player;

/** Prices use registry IDs/materials, never display names or client-supplied amounts. */
public final class SellPrices {
    private static final Map<String,Integer> SPECIAL=Map.ofEntries(
        Map.entry("diamond",50),Map.entry("diamond_block",450),Map.entry("emerald",10),Map.entry("emerald_block",90),
        Map.entry("netherite_ingot",400),Map.entry("netherite_block",3600),Map.entry("netherite_scrap",80),Map.entry("ancient_debris",80),
        Map.entry("iron_ingot",9),Map.entry("iron_block",81),Map.entry("iron_nugget",1),Map.entry("raw_iron",4),Map.entry("raw_iron_block",36),
        Map.entry("gold_ingot",9),Map.entry("gold_block",81),Map.entry("gold_nugget",1),Map.entry("raw_gold",4),Map.entry("raw_gold_block",36),
        Map.entry("copper_ingot",1),Map.entry("copper_block",9),Map.entry("raw_copper",1),Map.entry("raw_copper_block",9),
        Map.entry("coal",2),Map.entry("charcoal",2),Map.entry("coal_block",18),Map.entry("redstone",1),Map.entry("redstone_block",9),
        Map.entry("lapis_lazuli",2),Map.entry("lapis_block",18),Map.entry("quartz",2),Map.entry("quartz_block",8),
        Map.entry("nether_star",1000),Map.entry("beacon",1100),Map.entry("dragon_egg",3000),Map.entry("elytra",1800),
        Map.entry("totem_of_undying",120),Map.entry("trident",250),Map.entry("mace",500),Map.entry("heavy_core",350),
        Map.entry("breeze_rod",12),Map.entry("blaze_rod",8),Map.entry("ender_pearl",8),Map.entry("ender_eye",12),
        Map.entry("heart_of_the_sea",200),Map.entry("nautilus_shell",15),Map.entry("conduit",280),Map.entry("echo_shard",40),
        Map.entry("enchanted_golden_apple",180),Map.entry("golden_apple",50),Map.entry("golden_carrot",6),
        Map.entry("leather",3),Map.entry("rabbit_hide",1),Map.entry("rabbit_foot",8),Map.entry("scute",8),Map.entry("turtle_scute",8),
        Map.entry("shulker_shell",40),Map.entry("shulker_box",70),Map.entry("saddle",12),Map.entry("name_tag",8),
        Map.entry("experience_bottle",8),Map.entry("end_crystal",25),Map.entry("recovery_compass",250),Map.entry("wither_skeleton_skull",120),
        Map.entry("dragon_head",180),Map.entry("player_head",5),Map.entry("enchanted_book",8),Map.entry("book",3),
        Map.entry("writable_book",4),Map.entry("written_book",4),Map.entry("potion",8),Map.entry("splash_potion",10),Map.entry("lingering_potion",12),
        Map.entry("tipped_arrow",2),Map.entry("spectral_arrow",2),Map.entry("arrow",1),Map.entry("firework_rocket",1),
        Map.entry("trial_key",20),Map.entry("ominous_trial_key",40),Map.entry("ominous_bottle",20),Map.entry("dragon_breath",15),
        Map.entry("bucket",16),Map.entry("water_bucket",16),Map.entry("lava_bucket",17),Map.entry("milk_bucket",17),Map.entry("powder_snow_bucket",17)
    );
    public static int base(Item item){
        var id=BuiltInRegistries.ITEM.getKey(item);String n=id.getPath();
        if(item==Items.AIR)return 0;
        if(id.getNamespace().equals(StarRPG.MODID))return switch(n){
            case "star_dust" -> Math.min(2,Config.DUST_PRICE.get()/2);
            case "star_fragment" -> Math.min(25,Config.FRAGMENT_PRICE.get()/2);
            case "common_rune" -> Math.min(10,Config.RUNE_PRICE.get()/2);
            case "rare_rune" -> Math.min(80,Config.RUNE_PRICE.get()*9/2);
            case "epic_rune" -> Math.min(160,(Config.RUNE_PRICE.get()*36+Config.FRAGMENT_PRICE.get())/2);case "legendary_rune" -> Math.min(300,(Config.RUNE_PRICE.get()*144+Config.FRAGMENT_PRICE.get()*5)/2);case "mythic_rune" -> Math.min(500,(Config.RUNE_PRICE.get()*576+Config.FRAGMENT_PRICE.get()*21)/2);
            case "star_spear","berserker_blade","sun_scepter","soul_scythe","star_gauntlet","aegis_blade" -> 40;case "magic_staff" -> 40;case "star_dagger" -> 35;case "war_hammer" -> 50;case "rune_table_item" -> 30;default -> 1;
        };

        if(SPECIAL.containsKey(n))return SPECIAL.get(n);
        if(n.endsWith("_spawn_egg")||n.contains("command_block")||n.equals("barrier")||n.equals("structure_block")||n.equals("jigsaw")||n.equals("light"))return 1;
        if(n.endsWith("_smithing_template"))return 200;
        if(n.startsWith("music_disc_"))return 40;
        if(n.endsWith("_banner_pattern"))return 12;
        if(n.endsWith("_pottery_sherd"))return 8;
        if(n.endsWith("_shulker_box"))return 70;
        if(item instanceof ArmorItem armor){int units=switch(armor.getEquipmentSlot()){case HEAD->5;case CHEST->8;case LEGS->7;default->4;};return id.getNamespace().equals("minecraft")?gear(n,units):Math.max(gear(n,units),armor.getDefense()*4+12);}
        if(item instanceof TieredItem tool){int units=n.endsWith("_pickaxe")||n.endsWith("_axe")?3:n.endsWith("_shovel")?1:2;return id.getNamespace().equals("minecraft")?gear(n,units):Math.max(gear(n,units),(int)(tool.getTier().getAttackDamageBonus()*8)+12);}
        if(item instanceof BowItem)return 8;if(item instanceof CrossbowItem)return 15;
        if(item instanceof ShieldItem)return 12;if(item instanceof FishingRodItem)return 6;
        if(n.contains("diamond_ore"))return 40;if(n.contains("emerald_ore"))return 8;
        if(n.endsWith("_ore"))return 3;
        if(n.contains("amethyst"))return n.endsWith("_block")?8:2;
        if(n.endsWith("_boat"))return n.contains("chest")?8:4;
        if(n.contains("minecart"))return n.equals("minecart")?30:35;
        if(n.contains("horse_armor"))return n.startsWith("diamond")?100:n.startsWith("iron")?30:20;
        if(n.endsWith("_bucket"))return 20;
        var food=item.getDefaultInstance().get(DataComponents.FOOD);if(food!=null)return Math.max(1,food.nutrition()/2);
        if(n.contains("piston")||n.equals("hopper")||n.equals("observer")||n.equals("dispenser")||n.equals("dropper"))return 6;
        if(n.endsWith("_log")||n.endsWith("_wood")||n.endsWith("_stem")||n.endsWith("_hyphae"))return 3;
        if(n.endsWith("_bed")||n.endsWith("_banner"))return 4;
        if(n.equals("anvil")||n.endsWith("_anvil"))return 100;
        if(n.equals("enchanting_table"))return 80;
        if(n.contains("obsidian"))return 3;
        if(n.contains("prismarine")||n.equals("sea_lantern"))return 3;
        // Renewable plants, ordinary stone/soil/wood parts and decorative blocks are low-value commodities.
        return switch(item.getDefaultInstance().getRarity()){case COMMON->1;case UNCOMMON->4;case RARE->12;case EPIC->40;default->12;};
    }
    private static int gear(String n,int units){
        if(n.startsWith("netherite_"))return (units*50+400)/2;
        int material=n.startsWith("diamond_")?50:n.startsWith("iron_")||n.startsWith("golden_")?9:n.startsWith("chainmail_")?8:n.startsWith("leather_")?3:n.startsWith("turtle_")?8:1;
        return Math.max(1,units*material/2);
    }
    public static boolean hasContents(ItemStack stack){
        if(stack.getOrDefault(DataComponents.CONTAINER,ItemContainerContents.EMPTY).nonEmptyStream().findAny().isPresent())return true;
        if(!stack.getOrDefault(DataComponents.BUNDLE_CONTENTS,BundleContents.EMPTY).isEmpty())return true;
        var tag=stack.get(DataComponents.BLOCK_ENTITY_DATA);
        return tag!=null && (!tag.copyTag().getList("Items",10).isEmpty()||tag.copyTag().contains("RecordItem")||!tag.copyTag().getList("Bees",10).isEmpty());
    }
    public static int unit(ItemStack stack){
        if(stack.isEmpty()||hasContents(stack))return 0;
        int base=base(stack.getItem());if(base<=0)return 0;
        if(stack.isDamageableItem())return Math.max(1,(int)((long)base*Math.max(0,stack.getMaxDamage()-stack.getDamageValue())/stack.getMaxDamage()));
        return base;
    }
    public static boolean sell(Player p,ItemStack stack,int count){
        if(p.level().isClientSide()||p.getServer()==null||!p.isAlive()||p.isCreative()||p.isSpectator()||!Config.ECONOMY_ENABLED.get()||count<1||count>stack.getCount())return false;
        int unit=unit(stack);if(unit<=0){p.sendSystemMessage(Component.literal(hasContents(stack)?"내용물을 먼저 꺼내 주세요.":"이 모드 아이템에는 판매 가격이 없습니다."));return false;}
        long total=(long)unit*count;if(total>StarWallet.MAX_BALANCE)return false;int value=(int)total;var bank=StarWallet.get(p.getServer());
        if((long)bank.balance(p.getUUID())+value>StarWallet.MAX_BALANCE){p.sendSystemMessage(Component.literal("골드 보유 한도를 초과합니다."));return false;}
        if(!bank.canSell(p.getUUID(),value,p.getServer().overworld().getGameTime())){p.sendSystemMessage(Component.literal("상점은 플레이어별 1분에 10,000 G까지 매입합니다."));return false;}
        bank.recordSale(p.getUUID(),value,p.getServer().overworld().getGameTime());stack.shrink(count);bank.credit(p.getUUID(),value);
        p.getInventory().setChanged();p.sendSystemMessage(Component.literal(count+"개 판매: +"+value+" G"));return true;
    }
}
