package com.junwo.starrpg;

import net.minecraft.network.syncher.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.*;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;

/** Purely visual, short lived, server synchronized; no collision, damage, drops or saved entities. */
public final class ArcaneSigil extends Entity {
    private static final EntityDataAccessor<Integer> STYLE=SynchedEntityData.defineId(ArcaneSigil.class,EntityDataSerializers.INT),COLOR=SynchedEntityData.defineId(ArcaneSigil.class,EntityDataSerializers.INT),LIFE=SynchedEntityData.defineId(ArcaneSigil.class,EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> RADIUS=SynchedEntityData.defineId(ArcaneSigil.class,EntityDataSerializers.FLOAT);
    public ArcaneSigil(EntityType<? extends ArcaneSigil> type,Level level){super(type,level);noPhysics=true;setNoGravity(true);}
    @Override protected void defineSynchedData(SynchedEntityData.Builder b){b.define(STYLE,0);b.define(COLOR,0xFFFFFF);b.define(LIFE,30);b.define(RADIUS,2F);}
    public int style(){return entityData.get(STYLE);}public int color(){return entityData.get(COLOR);}public int life(){return entityData.get(LIFE);}public float radius(){return entityData.get(RADIUS);}
    public static void spawn(ServerLevel level,Vec3 position,Vec3 direction,int style,int color,float radius,int life){
        if(level.getEntitiesOfClass(ArcaneSigil.class,new net.minecraft.world.phys.AABB(position,position).inflate(32)).size()>=48)return;
        var e=new ArcaneSigil(ModEntities.ARCANE_SIGIL.get(),level);e.setPos(position);e.entityData.set(STYLE,Math.clamp(style,0,2));e.entityData.set(COLOR,color&0xFFFFFF);e.entityData.set(RADIUS,Math.clamp(radius,0.2F,8));e.entityData.set(LIFE,Math.clamp(life,10,60));
        Vec3 d=direction.normalize();e.setYRot((float)Math.toDegrees(Math.atan2(-d.x,d.z)));e.setXRot((float)-Math.toDegrees(Math.asin(Math.clamp(d.y,-1,1))));level.addFreshEntity(e);
    }
    @Override public void tick(){super.tick();if(tickCount>=life())discard();}
    @Override protected void readAdditionalSaveData(CompoundTag t){}
    @Override protected void addAdditionalSaveData(CompoundTag t){}
    @Override public boolean shouldRenderAtSqrDistance(double distance){return distance<4096;}
}
