package com.junwo.starrpg;

import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.*;
import net.minecraft.world.item.component.CustomData;

/** Authoritative server-owned data. Display names are never trusted. */
public final class EnhancementData {
    private static final String LEVEL = "starrpg_enhancement";
    private static final String FAILURES = "starrpg_enhancement_failures";
    public static boolean supports(ItemStack stack) {
        return stack.getItem() instanceof MagicStaffItem || RuneWeaponType.forItem(stack) != null;
    }
    public static int level(ItemStack stack) {
        return supports(stack) ? Math.clamp(data(stack).getInt(LEVEL), 0, limit(stack)) : 0;
    }
    public static boolean unlimited(ItemStack stack) {
        var item=stack.getItem();
        return item instanceof StarDaggerItem || item instanceof WarHammerItem || item instanceof CareerWeaponItem
            || item instanceof MagicStaffItem || item instanceof BowItem || item instanceof CrossbowItem || item instanceof TridentItem;
    }
    public static int limit(ItemStack stack){return unlimited(stack)?Integer.MAX_VALUE:10;}
    /** Linear tutorial progression, then diminishing but uncapped specialist growth. */
    public static double power(ItemStack stack){int n=level(stack);return n<=10?n:10+3*Math.sqrt(n-10.0);}
    /** Combat-only growth: +25 = 40, with uncapped diminishing growth afterward. */
    public static double combatPower(ItemStack stack){int n=level(stack);return !unlimited(stack)?n:n<=25?n*1.6:40+4*Math.sqrt(n-25.0);}
    public static int failures(ItemStack stack) { return Math.clamp(data(stack).getInt(FAILURES), 0, 100); }
    public static void setLevel(ItemStack stack, int level) {
        if (!supports(stack)) return;
        CompoundTag tag = data(stack);
        tag.putInt(LEVEL, Math.clamp(level, 0, limit(stack)));
        tag.putInt(FAILURES, 0);
        stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
    }
    public static void recordFailure(ItemStack stack) {
        CompoundTag tag = data(stack);
        tag.putInt(FAILURES, failures(stack) + 1);
        stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
    }
    private static CompoundTag data(ItemStack stack) {
        return stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
    }
}
