package com.junwo.starrpg;

import java.util.Optional;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.item.*;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.item.trading.*;
import net.neoforged.bus.api.*;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.village.VillagerTradesEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.tick.EntityTickEvent;

@EventBusSubscriber(modid=StarRPG.MODID)
public final class VillagerRuneTrades {
    public static MerchantOffer sanitize(MerchantOffer offer){
        if(offer==null||!Config.NO_VANILLA_ENCHANTMENTS.get())return offer;
        var result=offer.getResult();boolean vanillaBook=result.is(Items.ENCHANTED_BOOK)&&result.getOrDefault(DataComponents.STORED_ENCHANTMENTS,ItemEnchantments.EMPTY).keySet().stream().anyMatch(h->h.unwrapKey().map(k->k.location().getNamespace().equals("minecraft")).orElse(false));
        if(vanillaBook){
            var copy=result.copy();VanillaEnchantments.strip(copy);
            if(copy.getOrDefault(DataComponents.STORED_ENCHANTMENTS,ItemEnchantments.EMPTY).isEmpty())
                return new MerchantOffer(new ItemCost(Items.EMERALD,8),Optional.empty(),new ItemStack(StarRPG.STAR_DUST.get()),Math.min(4,offer.getUses()),4,offer.getXp(),0.05F,offer.getDemand());
        }
        // Keep the original offer object, stock, demand and pricing for equipment and mod enchantments.
        VanillaEnchantments.strip(result);return offer;
    }
    public static void sanitize(AbstractVillager villager){var offers=villager.getOffers();for(int i=0;i<offers.size();i++){var old=offers.get(i);var updated=sanitize(old);if(old!=updated)offers.set(i,updated);}}
    @SubscribeEvent public static void trades(VillagerTradesEvent e){e.getTrades().values().forEach(list->list.replaceAll(factory->(trader,random)->sanitize(factory.getOffer(trader,random))));}
    @SubscribeEvent(priority=EventPriority.HIGH) public static void interact(PlayerInteractEvent.EntityInteract e){if(!e.getLevel().isClientSide()&&e.getTarget() instanceof AbstractVillager v)sanitize(v);}
    @SubscribeEvent public static void tick(EntityTickEvent.Pre e){if(!e.getEntity().level().isClientSide()&&e.getEntity() instanceof AbstractVillager v&&!v.isTrading()&&v.tickCount%100==0)sanitize(v);}
}
