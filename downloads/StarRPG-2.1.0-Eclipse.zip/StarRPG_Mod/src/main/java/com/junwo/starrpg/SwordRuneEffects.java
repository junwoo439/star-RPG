package com.junwo.starrpg;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;

@EventBusSubscriber(modid = StarRPG.MODID)
public class SwordRuneEffects {

    private record TargetKey(UUID attackerId, UUID targetId) {
    }

    private static final Map<TargetKey, Long> CHASE_COOLDOWN =
            new HashMap<>();

    private static final Map<UUID, Long> GUARD_COOLDOWN =
            new HashMap<>();

    private static final Map<UUID, Long> HEAL_COOLDOWN =
            new HashMap<>();

    private static final Map<TargetKey, Integer> CONTINUOUS_SLASH_COUNT =
            new HashMap<>();

    private static final Map<TargetKey, Long> CONTINUOUS_SLASH_LAST_HIT =
            new HashMap<>();

    private static final Map<UUID, Long> METEOR_FRAGMENT_COOLDOWN =
            new HashMap<>();

    private static final Map<TargetKey, Integer> METEOR_STRIKE_COUNT =
            new HashMap<>();

    private static final Map<TargetKey, Long> METEOR_STRIKE_LAST_HIT =
            new HashMap<>();

    private static final Map<UUID, Long> STAR_BIND_COOLDOWN =
            new HashMap<>();

    private static final Map<UUID, Long> HALF_MOON_COOLDOWN =
            new HashMap<>();

    private static final Map<TargetKey, Integer> CELESTIAL_COLLAPSE_COUNT =
            new HashMap<>();

    private static final Map<TargetKey, Long> CELESTIAL_COLLAPSE_LAST_HIT =
            new HashMap<>();

    private static final Map<UUID, Long> RADIANCE_COOLDOWN =
            new HashMap<>();

    private static final Map<UUID, UUID> STAR_OATH_TARGET =
            new HashMap<>();

    private static final Map<UUID, Integer> STAR_OATH_STACK =
            new HashMap<>();

    private static final Map<UUID, Long> STAR_OATH_LAST_HIT =
            new HashMap<>();

    private static final Map<UUID, Long> ECLIPSE_COOLDOWN =
            new HashMap<>();
    private static final Map<UUID, Long> SUPERNOVA_COOLDOWN =
            new HashMap<>();

    private static final Map<UUID, Integer> CONSTELLATION_STACK =
            new HashMap<>();

    @SubscribeEvent
    public static void onLivingDamage(LivingIncomingDamageEvent event) {
        if (!CombatRules.primary(event.getSource()) || !CombatRules.charged(event.getSource())) return;
        if (!(event.getSource().getEntity() instanceof Player player)) {
            return;
        }

        if (player.level().isClientSide()) {
            return;
        }

        ItemStack weapon = player.getMainHandItem();

        if (!(weapon.getItem() instanceof SwordItem)) {
            return;
        }

        RuneEffect runeEffect = RuneDataHelper.getRuneEffect(weapon);

        if (runeEffect == null) {
            return;
        }

        LivingEntity target = event.getEntity();
        long now = player.level().getGameTime();

        switch (runeEffect) {

            // ===== 일반 검 =====
            case SWORD_STAR_SLASH -> applyStarSlash(player, event);

            case SWORD_CHASE -> applyChase(player, target, now);

            case SWORD_GUARD_RESPONSE -> applyGuardResponse(player, now);

            // ===== 희귀 검 =====
            case SWORD_CONTINUOUS_SLASH ->
                    applyContinuousSlash(player, target, event, now);

            case SWORD_METEOR_FRAGMENT ->
                    applyMeteorFragment(player, target, now);

            case SWORD_DUEL_WILL ->
                    applyDuelWill(player, event);

            // ===== 에픽 검 =====
            case SWORD_METEOR_STRIKE ->
                    applyMeteorStrike(player, target, event, now);

            case SWORD_STAR_BIND ->
                    applyStarBind(player, target, now);

            case SWORD_HALF_MOON ->
                    applyHalfMoon(player, target, now);

            case SWORD_LIFE_TRANSFER ->
                    applyLifeTransfer(player, event);

            // ===== 레전더리 검 =====
            case SWORD_CELESTIAL_COLLAPSE ->
                    applyCelestialCollapse(player, target, now);

            case SWORD_RADIANCE ->
                    applyRadiance(player, now);

            case SWORD_STAR_OATH ->
                    applyStarOath(player, target, event, now);
            
                 // ===== 신화 검 =====
            case SWORD_SUPERNOVA ->
                    applySupernova(player, target, now);

            case SWORD_TIME_SLASH ->
                    applyTimeSlash(player, target, now);

            case SWORD_SKY_JUDGMENT ->
                    applySkyJudgment(target, event);

            default -> {
            }
        }
    }

    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        if (!CombatRules.primary(event.getSource()) || !CombatRules.charged(event.getSource())) return;
        if (!(event.getSource().getEntity() instanceof Player player)) {
            return;
        }

        if (player.level().isClientSide()) {
            return;
        }

        ItemStack weapon = player.getMainHandItem();

        if (!(weapon.getItem() instanceof SwordItem)) {
            return;
        }

        RuneEffect runeEffect = RuneDataHelper.getRuneEffect(weapon);

        if (runeEffect == RuneEffect.SWORD_WEAK_ABSORPTION) {
            applyKillHeal(player, 2.0F, "미약한 흡수", 20);
        }

        if (runeEffect == RuneEffect.SWORD_STAR_HEAL) {
            applyKillHeal(player, 4.0F, "별빛 회복", 20);
        }

        if (runeEffect == RuneEffect.SWORD_ECLIPSE) {
            applyEclipse(player, event.getEntity(), player.level().getGameTime());
        }
        if (runeEffect == RuneEffect.SWORD_CONSTELLATION) {
            applyConstellation(player);
        }
    }

    private static void applyKillHeal(
            Player player,
            float healAmount,
            String effectName,
            long cooldown
    ) {
        long now = player.level().getGameTime();

        long lastUse = HEAL_COOLDOWN.getOrDefault(
                player.getUUID(),
                -cooldown
        );

        if (now - lastUse < cooldown) {
            return;
        }

        HEAL_COOLDOWN.put(player.getUUID(), now);

        player.heal(healAmount);

        player.sendSystemMessage(
                Component.literal(
                        effectName + " 발동! 체력 +" + (int) healAmount
                )
        );
    }

    private static void applyStarSlash(
            Player player,
            LivingIncomingDamageEvent event
    ) {
        if (player.getRandom().nextInt(100) < 15) {
            event.setAmount(event.getAmount() + 1.0F);

            player.sendSystemMessage(
                    Component.literal("별빛 절단 발동!")
            );
        }
    }

    private static void applyChase(
            Player player,
            LivingEntity target,
            long now
    ) {
        TargetKey key = new TargetKey(
                player.getUUID(),
                target.getUUID()
        );

        long lastUse = CHASE_COOLDOWN.getOrDefault(key, -80L);

        if (now - lastUse < 80) {
            return;
        }

        CHASE_COOLDOWN.put(key, now);

        target.addEffect(
                new MobEffectInstance(
                        MobEffects.MOVEMENT_SLOWDOWN,
                        40,
                        0,
                        false,
                        true,
                        true
                )
        );

        player.sendSystemMessage(
                Component.literal("추격 발동!")
        );
    }

    private static void applyGuardResponse(
            Player player,
            long now
    ) {
        long lastUse = GUARD_COOLDOWN.getOrDefault(
                player.getUUID(),
                -160L
        );

        if (now - lastUse < 160) {
            return;
        }

        if (player.getRandom().nextInt(100) >= 10) {
            return;
        }

        GUARD_COOLDOWN.put(player.getUUID(), now);

        player.addEffect(
                new MobEffectInstance(
                        MobEffects.DAMAGE_RESISTANCE,
                        40,
                        0,
                        false,
                        true,
                        true
                )
        );

        player.sendSystemMessage(
                Component.literal("수호 반응 발동!")
        );
    }

    private static void applyContinuousSlash(
            Player player,
            LivingEntity target,
            LivingIncomingDamageEvent event,
            long now
    ) {
        TargetKey key = new TargetKey(
                player.getUUID(),
                target.getUUID()
        );

        long lastHit = CONTINUOUS_SLASH_LAST_HIT.getOrDefault(
                key,
                -80L
        );

        int hitCount;

        if (now - lastHit > 80) {
            hitCount = 1;
        } else {
            hitCount = CONTINUOUS_SLASH_COUNT.getOrDefault(key, 0) + 1;
        }

        CONTINUOUS_SLASH_COUNT.put(key, hitCount);
        CONTINUOUS_SLASH_LAST_HIT.put(key, now);

        if (hitCount >= 3) {
            event.setAmount(event.getAmount() + 3.0F);

            CONTINUOUS_SLASH_COUNT.put(key, 0);

            player.sendSystemMessage(
                    Component.literal("연속 참격 발동! 추가 피해 +3")
            );
        }
    }

    private static void applyMeteorFragment(
            Player player,
            LivingEntity target,
            long now
    ) {
        long lastUse = METEOR_FRAGMENT_COOLDOWN.getOrDefault(
                player.getUUID(),
                -60L
        );

        if (now - lastUse < 60) {
            return;
        }

        if (player.getRandom().nextInt(100) >= 15) {
            return;
        }

        METEOR_FRAGMENT_COOLDOWN.put(player.getUUID(), now);

        List<LivingEntity> nearbyEntities =
                target.level().getEntitiesOfClass(
                        LivingEntity.class,
                        target.getBoundingBox().inflate(2.0D),
                        entity -> entity != target
                                && entity != player
                                && CombatRules.canHarm(player, entity)
                );

        for (LivingEntity nearby : nearbyEntities) {
            CombatRules.runeDamage(player, nearby, 2.0F);
        }

        player.sendSystemMessage(
                Component.literal("유성 파편 발동!")
        );
    }

    private static void applyDuelWill(
            Player player,
            LivingIncomingDamageEvent event
    ) {
        List<Monster> nearbyMonsters =
                player.level().getEntitiesOfClass(
                        Monster.class,
                        player.getBoundingBox().inflate(6.0D),
                        monster -> monster.isAlive()
                );

        if (nearbyMonsters.size() == 1) {
            event.setAmount(event.getAmount() + 2.0F);
        }
    }

    private static void applyMeteorStrike(
            Player player,
            LivingEntity target,
            LivingIncomingDamageEvent event,
            long now
    ) {
        TargetKey key = new TargetKey(
                player.getUUID(),
                target.getUUID()
        );

        long lastHit = METEOR_STRIKE_LAST_HIT.getOrDefault(
                key,
                -80L
        );

        int hitCount;

        if (now - lastHit > 80) {
            hitCount = 1;
        } else {
            hitCount = METEOR_STRIKE_COUNT.getOrDefault(key, 0) + 1;
        }

        METEOR_STRIKE_COUNT.put(key, hitCount);
        METEOR_STRIKE_LAST_HIT.put(key, now);

        if (hitCount >= 4) {
            event.setAmount(event.getAmount() + 5.0F);

            METEOR_STRIKE_COUNT.put(key, 0);

            player.sendSystemMessage(
                    Component.literal("유성 검격 발동! 추가 피해 +5")
            );
        }
    }

    private static void applyStarBind(
            Player player,
            LivingEntity target,
            long now
    ) {
        long lastUse = STAR_BIND_COOLDOWN.getOrDefault(
                player.getUUID(),
                -100L
        );

        if (now - lastUse < 100) {
            return;
        }

        if (player.getRandom().nextInt(100) >= 20) {
            return;
        }

        STAR_BIND_COOLDOWN.put(player.getUUID(), now);

        target.addEffect(
                new MobEffectInstance(
                        MobEffects.MOVEMENT_SLOWDOWN,
                        40,
                        1,
                        false,
                        true,
                        true
                )
        );

        player.sendSystemMessage(
                Component.literal("별의 속박 발동!")
        );
    }

    private static void applyHalfMoon(
            Player player,
            LivingEntity target,
            long now
    ) {
        long lastUse = HALF_MOON_COOLDOWN.getOrDefault(
                player.getUUID(),
                -80L
        );

        if (now - lastUse < 80) {
            return;
        }

        HALF_MOON_COOLDOWN.put(player.getUUID(), now);

        List<LivingEntity> nearbyEntities =
                target.level().getEntitiesOfClass(
                        LivingEntity.class,
                        target.getBoundingBox().inflate(3.0D),
                        entity -> entity != target
                                && entity != player
                                && CombatRules.canHarm(player, entity)
                );

        for (LivingEntity nearby : nearbyEntities) {
            CombatRules.runeDamage(player, nearby, 2.0F);
        }

        if (!nearbyEntities.isEmpty()) {
            player.sendSystemMessage(
                    Component.literal("반월 발동!")
            );
        }
    }

    private static void applyLifeTransfer(
            Player player,
            LivingIncomingDamageEvent event
    ) {
        if (player.getHealth() > player.getMaxHealth() * 0.4F) {
            return;
        }

        event.setAmount(
                event.getAmount() * 1.25F
        );
    }

    private static void applyCelestialCollapse(
            Player player,
            LivingEntity target,
            long now
    ) {
        TargetKey key = new TargetKey(
                player.getUUID(),
                target.getUUID()
        );

        long lastHit = CELESTIAL_COLLAPSE_LAST_HIT.getOrDefault(
                key,
                -80L
        );

        int hitCount;

        if (now - lastHit > 80) {
            hitCount = 1;
        } else {
            hitCount = CELESTIAL_COLLAPSE_COUNT.getOrDefault(key, 0) + 1;
        }

        CELESTIAL_COLLAPSE_COUNT.put(key, hitCount);
        CELESTIAL_COLLAPSE_LAST_HIT.put(key, now);

        if (hitCount < 8) {
            return;
        }

        CELESTIAL_COLLAPSE_COUNT.put(key, 0);

        List<LivingEntity> nearbyEntities =
                target.level().getEntitiesOfClass(
                        LivingEntity.class,
                        target.getBoundingBox().inflate(3.0D),
                        entity -> entity != target
                                && entity != player
                                && CombatRules.canHarm(player, entity)
                );

        for (LivingEntity nearby : nearbyEntities) {
            CombatRules.runeDamage(player, nearby, 6.0F);
        }

        player.sendSystemMessage(
                Component.literal("천체 붕괴 발동!")
        );
    }

    private static void applyRadiance(
            Player player,
            long now
    ) {
        long lastUse = RADIANCE_COOLDOWN.getOrDefault(
                player.getUUID(),
                -200L
        );

        if (now - lastUse < 200) {
            return;
        }

        if (player.getRandom().nextInt(100) >= 20) {
            return;
        }

        RADIANCE_COOLDOWN.put(player.getUUID(), now);

        player.addEffect(
                new MobEffectInstance(
                        MobEffects.DAMAGE_BOOST,
                        80,
                        0,
                        false,
                        true,
                        true
                )
        );

        player.sendSystemMessage(
                Component.literal("광휘 발동! 힘 I")
        );
    }

    private static void applyStarOath(
            Player player,
            LivingEntity target,
            LivingIncomingDamageEvent event,
            long now
    ) {
        UUID playerId = player.getUUID();
        UUID targetId = target.getUUID();

        UUID previousTarget = STAR_OATH_TARGET.get(playerId);

        long lastHit = STAR_OATH_LAST_HIT.getOrDefault(
                playerId,
                -80L
        );

        int stack;

        if (!targetId.equals(previousTarget) || now - lastHit > 80) {
            stack = 1;
        } else {
            stack = Math.min(
                    STAR_OATH_STACK.getOrDefault(playerId, 0) + 1,
                    6
            );
        }

        STAR_OATH_TARGET.put(playerId, targetId);
        STAR_OATH_STACK.put(playerId, stack);
        STAR_OATH_LAST_HIT.put(playerId, now);

        int bonusDamage = Math.min(stack - 1, 5);

        if (bonusDamage > 0) {
            event.setAmount(
                    event.getAmount() + bonusDamage
            );
        }
    }

    private static void applyEclipse(
            Player player,
            LivingEntity deadTarget,
            long now
    ) {
        long lastUse = ECLIPSE_COOLDOWN.getOrDefault(
                player.getUUID(),
                -240L
        );

        if (now - lastUse < 240) {
            return;
        }

        ECLIPSE_COOLDOWN.put(player.getUUID(), now);

        List<LivingEntity> nearbyEntities =
                deadTarget.level().getEntitiesOfClass(
                        LivingEntity.class,
                        deadTarget.getBoundingBox().inflate(4.0D),
                        entity -> entity != player
                                && CombatRules.canHarm(player, entity)
                );

        for (LivingEntity nearby : nearbyEntities) {
            nearby.addEffect(
                    new MobEffectInstance(
                            MobEffects.BLINDNESS,
                            80,
                            0,
                            false,
                            true,
                            true
                    )
            );

            nearby.addEffect(
                    new MobEffectInstance(
                            MobEffects.MOVEMENT_SLOWDOWN,
                            80,
                            0,
                            false,
                            true,
                            true
                    )
            );
        }

        player.sendSystemMessage(
                Component.literal("일식 발동!")
        );
    }
    private static void applySupernova(
            Player player,
            LivingEntity target,
            long now
    ) {
        long lastUse = SUPERNOVA_COOLDOWN.getOrDefault(
                player.getUUID(),
                -400L
        );

        // 20초마다 다음 공격 강화
        if (now - lastUse < 400) {
            return;
        }

        SUPERNOVA_COOLDOWN.put(player.getUUID(), now);

        List<LivingEntity> nearbyEntities =
                target.level().getEntitiesOfClass(
                        LivingEntity.class,
                        target.getBoundingBox().inflate(4.0D),
                        entity -> entity != target
                                && entity != player
                                && CombatRules.canHarm(player, entity)
                );

        for (LivingEntity nearby : nearbyEntities) {
            CombatRules.runeDamage(player, nearby, 8.0F);
        }

        player.sendSystemMessage(
                Component.literal("초신성 발동!")
        );
    }

    private static void applyTimeSlash(
            Player player,
            LivingEntity target,
            long now
    ) {
        long lastUse = STAR_BIND_COOLDOWN.getOrDefault(
                player.getUUID(),
                -160L
        );

        // 쿨타임 8초
        if (now - lastUse < 160) {
            return;
        }

        // 10% 확률
        if (player.getRandom().nextInt(100) >= 10) {
            return;
        }

        STAR_BIND_COOLDOWN.put(player.getUUID(), now);

        target.addEffect(
                new MobEffectInstance(
                        MobEffects.MOVEMENT_SLOWDOWN,
                        60,
                        1,
                        false,
                        true,
                        true
                )
        );

        target.addEffect(
                new MobEffectInstance(
                        MobEffects.WEAKNESS,
                        60,
                        0,
                        false,
                        true,
                        true
                )
        );

        player.sendSystemMessage(
                Component.literal("시간 절단 발동!")
        );
    }

    private static void applyConstellation(Player player) {
        int stack = CONSTELLATION_STACK.getOrDefault(
                player.getUUID(),
                0
        ) + 1;

        if (stack < 5) {
            CONSTELLATION_STACK.put(player.getUUID(), stack);

            player.sendSystemMessage(
                    Component.literal(
                            "별자리 스택: " + stack + " / 5"
                    )
            );

            return;
        }

        CONSTELLATION_STACK.put(player.getUUID(), 0);

        player.addEffect(
                new MobEffectInstance(
                        MobEffects.DAMAGE_BOOST,
                        160,
                        0,
                        false,
                        true,
                        true
                )
        );

        player.addEffect(
                new MobEffectInstance(
                        MobEffects.MOVEMENT_SPEED,
                        160,
                        0,
                        false,
                        true,
                        true
                )
        );

        player.sendSystemMessage(
                Component.literal("별자리의 검 발동!")
        );
    }

    private static void applySkyJudgment(
            LivingEntity target,
            LivingIncomingDamageEvent event
    ) {
        // 공중에 떠 있는 적에게 추가 피해 6
        if (!target.onGround()) {
            event.setAmount(
                    event.getAmount() + 6.0F
            );
        }
    }

    public static void pruneState(long now) {
        CHASE_COOLDOWN.entrySet().removeIf(e -> {
            if (now - e.getValue() < 1200) return false;
            return true;
        });
        GUARD_COOLDOWN.entrySet().removeIf(e -> {
            if (now - e.getValue() < 1200) return false;
            return true;
        });
        HEAL_COOLDOWN.entrySet().removeIf(e -> {
            if (now - e.getValue() < 1200) return false;
            return true;
        });
        CONTINUOUS_SLASH_LAST_HIT.entrySet().removeIf(e -> {
            if (now - e.getValue() < 1200) return false;
            CONTINUOUS_SLASH_COUNT.remove(e.getKey());
            return true;
        });
        METEOR_FRAGMENT_COOLDOWN.entrySet().removeIf(e -> {
            if (now - e.getValue() < 1200) return false;
            return true;
        });
        METEOR_STRIKE_LAST_HIT.entrySet().removeIf(e -> {
            if (now - e.getValue() < 1200) return false;
            METEOR_STRIKE_COUNT.remove(e.getKey());
            return true;
        });
        STAR_BIND_COOLDOWN.entrySet().removeIf(e -> {
            if (now - e.getValue() < 1200) return false;
            return true;
        });
        HALF_MOON_COOLDOWN.entrySet().removeIf(e -> {
            if (now - e.getValue() < 1200) return false;
            return true;
        });
        CELESTIAL_COLLAPSE_LAST_HIT.entrySet().removeIf(e -> {
            if (now - e.getValue() < 1200) return false;
            CELESTIAL_COLLAPSE_COUNT.remove(e.getKey());
            return true;
        });
        RADIANCE_COOLDOWN.entrySet().removeIf(e -> {
            if (now - e.getValue() < 1200) return false;
            return true;
        });
        STAR_OATH_LAST_HIT.entrySet().removeIf(e -> {
            if (now - e.getValue() < 1200) return false;
            STAR_OATH_TARGET.remove(e.getKey());
            STAR_OATH_STACK.remove(e.getKey());
            return true;
        });
        ECLIPSE_COOLDOWN.entrySet().removeIf(e -> {
            if (now - e.getValue() < 1200) return false;
            return true;
        });
        SUPERNOVA_COOLDOWN.entrySet().removeIf(e -> {
            if (now - e.getValue() < 1200) return false;
            return true;
        });
    }
    public static void clearState() {
        CHASE_COOLDOWN.clear();
        GUARD_COOLDOWN.clear();
        HEAL_COOLDOWN.clear();
        CONTINUOUS_SLASH_COUNT.clear();
        CONTINUOUS_SLASH_LAST_HIT.clear();
        METEOR_FRAGMENT_COOLDOWN.clear();
        METEOR_STRIKE_COUNT.clear();
        METEOR_STRIKE_LAST_HIT.clear();
        STAR_BIND_COOLDOWN.clear();
        HALF_MOON_COOLDOWN.clear();
        CELESTIAL_COLLAPSE_COUNT.clear();
        CELESTIAL_COLLAPSE_LAST_HIT.clear();
        RADIANCE_COOLDOWN.clear();
        STAR_OATH_TARGET.clear();
        STAR_OATH_STACK.clear();
        STAR_OATH_LAST_HIT.clear();
        ECLIPSE_COOLDOWN.clear();
        SUPERNOVA_COOLDOWN.clear();
        CONSTELLATION_STACK.clear();
    }
    public static void forgetPlayer(UUID id) { CONSTELLATION_STACK.remove(id); }
}
