package com.junwo.starrpg;

import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.*;

@EventBusSubscriber(modid=StarRPG.MODID,value=Dist.CLIENT)
public final class ControlClientEvents {
    @SubscribeEvent public static void movement(MovementInputUpdateEvent e){
        var p=e.getEntity();var input=e.getInput();
        if(ControlEffects.rooted(p)){input.forwardImpulse=0;input.leftImpulse=0;input.up=input.down=input.left=input.right=input.jumping=false;}
        else if(p.hasEffect(ModEffects.REVERSE_MOVE)){
            input.forwardImpulse=-input.forwardImpulse;input.leftImpulse=-input.leftImpulse;
            boolean up=input.up,left=input.left;input.up=input.down;input.down=up;input.left=input.right;input.right=left;
        }
    }
    @SubscribeEvent public static void mouse(CalculatePlayerTurnEvent e){
        var p=Minecraft.getInstance().player;
        if(p!=null&&p.hasEffect(ModEffects.REVERSE_LOOK)&&Minecraft.getInstance().screen==null){
            // MouseHandler cubes (sensitivity*0.6F+0.2F). Negate that factor without editing user options.
            e.setMouseSensitivity(-e.getMouseSensitivity()-2.0*0.2F/0.6F);e.setCinematicCameraEnabled(false);
        }
    }
    @SubscribeEvent public static void click(InputEvent.InteractionKeyMappingTriggered e){var p=Minecraft.getInstance().player;if(p!=null&&(ControlEffects.stunned(p)||p.hasEffect(ModEffects.BRACED)||(p.hasEffect(ModEffects.COMBO)&&e.isAttack()))){e.setCanceled(true);e.setSwingHand(false);}}
}
