package com.junwo.starrpg;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.resources.ResourceLocation;

public final class GiantArrowRenderer extends ArrowRenderer<GiantArrow> {
    public GiantArrowRenderer(EntityRendererProvider.Context context){super(context);}
    @Override public ResourceLocation getTextureLocation(GiantArrow e){return ResourceLocation.withDefaultNamespace("textures/entity/projectiles/arrow.png");}
    @Override public void render(GiantArrow e,float yaw,float tick,PoseStack pose,MultiBufferSource buffers,int light){pose.pushPose();pose.scale(3,3,3);super.render(e,yaw,tick,pose,buffers,light);pose.popPose();}
}
