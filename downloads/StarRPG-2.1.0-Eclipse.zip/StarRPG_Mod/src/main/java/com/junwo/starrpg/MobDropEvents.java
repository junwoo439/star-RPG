package com.junwo.starrpg;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDropsEvent;

@EventBusSubscriber(modid = StarRPG.MODID)
public class MobDropEvents {
    @SubscribeEvent
    public static void onLivingDrops(LivingDropsEvent event) {
        LivingEntity mob = event.getEntity();
        if (mob.level().isClientSide() || !MonsterProgression.eligible(mob)
                || !(event.getSource().getEntity() instanceof Player player)
                || player.isCreative() || player.isSpectator()) return;
        boolean boss = mob.getType().is(MonsterProgression.BOSSES);
        int tier = MonsterProgression.tier(mob);
        double multiplier = 1 + Math.min(20,tier) * Config.REWARD_SCALE.get();
        if (boss || mob.getRandom().nextInt(100) < Config.DUST_DROP.get()) {
            int base = boss ? 12 + mob.getRandom().nextInt(9) : 1 + mob.getRandom().nextInt(2);
            drop(event, new ItemStack(StarRPG.STAR_DUST.get(), Math.min(64, (int) Math.ceil(base * multiplier))));
        }
        if (boss || mob.getRandom().nextInt(100) < Config.FRAGMENT_DROP.get()) {
            int count = boss ? 2 + mob.getRandom().nextInt(3) + tier / 2 : 1;
            drop(event, new ItemStack(StarRPG.STAR_FRAGMENT.get(), count));
        }
        if (boss || mob.getRandom().nextInt(100) < Config.RUNE_DROP.get()) {
            int roll = mob.getRandom().nextInt(100);
            var rune = boss ? (tier >= 5 && roll < 10 ? StarRPG.MYTHIC_RUNE
                    : tier >= 3 && roll < 30 ? StarRPG.LEGENDARY_RUNE
                    : tier >= 1 && roll < 60 ? StarRPG.EPIC_RUNE : StarRPG.RARE_RUNE)
                    : (tier >= 3 && roll < 20 ? StarRPG.RARE_RUNE : StarRPG.COMMON_RUNE);
            drop(event, new ItemStack(rune.get()));
        }
    }
    private static void drop(LivingDropsEvent event, ItemStack item) {
        LivingEntity mob = event.getEntity();
        event.getDrops().add(new ItemEntity(mob.level(), mob.getX(), mob.getY(), mob.getZ(), item));
    }
}
