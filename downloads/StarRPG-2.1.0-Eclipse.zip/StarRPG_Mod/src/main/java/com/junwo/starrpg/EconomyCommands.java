package com.junwo.starrpg;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.world.SimpleMenuProvider;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

@EventBusSubscriber(modid=StarRPG.MODID)
public final class EconomyCommands {
    @SubscribeEvent public static void register(RegisterCommandsEvent event) {
        var root=Commands.literal("starrpg");
        root.then(Commands.literal("money").executes(ctx -> {
            var p=ctx.getSource().getPlayerOrException();
            ctx.getSource().sendSuccess(()->Component.literal("보유 골드: "+StarWallet.get(p.server).balance(p.getUUID())+" G | 상점: /starrpg shop"),false);return 1;
        }).then(Commands.literal("give").requires(s->s.hasPermission(2))
            .then(Commands.argument("player",EntityArgument.player()).then(Commands.argument("amount",IntegerArgumentType.integer(1,StarWallet.MAX_BALANCE)).executes(ctx->{
                var p=EntityArgument.getPlayer(ctx,"player");int added=StarWallet.get(p.server).credit(p.getUUID(),IntegerArgumentType.getInteger(ctx,"amount"));
                ctx.getSource().sendSuccess(()->Component.literal(p.getScoreboardName()+"에게 "+added+" G 지급"),true);return added>0?1:0;
            })))));
        root.then(Commands.literal("shop").executes(ctx->{
            var p=ctx.getSource().getPlayerOrException();
            p.openMenu(new SimpleMenuProvider((id,inv,player)->new MaterialShopMenu(id,inv),Component.literal("강화 재료 상점")));return 1;
        }));
        var buy=Commands.literal("buy");
        for(var product:Economy.Product.values()) {
            buy.then(Commands.literal(product.name().toLowerCase(java.util.Locale.ROOT))
                .executes(ctx->purchase(ctx.getSource().getPlayerOrException(),product,1))
                .then(Commands.argument("count",IntegerArgumentType.integer(1,64)).executes(ctx->purchase(ctx.getSource().getPlayerOrException(),product,IntegerArgumentType.getInteger(ctx,"count")))));
        }
        root.then(buy);
        root.then(Commands.literal("pay").then(Commands.argument("player",EntityArgument.player()).then(Commands.argument("amount",IntegerArgumentType.integer(1,StarWallet.MAX_BALANCE)).executes(ctx->{
            var from=ctx.getSource().getPlayerOrException();var to=EntityArgument.getPlayer(ctx,"player");int amount=IntegerArgumentType.getInteger(ctx,"amount");
            if (!Config.ECONOMY_ENABLED.get() || !StarWallet.get(from.server).transfer(from.getUUID(),to.getUUID(),amount)) {
                ctx.getSource().sendFailure(Component.literal("송금 실패: 잔액, 상대 잔액 한도, 경제 설정을 확인하세요. 자신에게는 보낼 수 없습니다."));return 0;
            }
            from.sendSystemMessage(Component.literal(to.getScoreboardName()+"에게 "+amount+" G 송금했습니다."));
            to.sendSystemMessage(Component.literal(from.getScoreboardName()+"님에게 "+amount+" G 받았습니다."));return 1;
        }))));
        event.getDispatcher().register(root);
    }
    private static int purchase(net.minecraft.server.level.ServerPlayer p,Economy.Product product,int count) {
        var result=Economy.buy(p,product,count);p.sendSystemMessage(Economy.feedback(result,product,count));return result==Economy.Purchase.OK?1:0;
    }
}
