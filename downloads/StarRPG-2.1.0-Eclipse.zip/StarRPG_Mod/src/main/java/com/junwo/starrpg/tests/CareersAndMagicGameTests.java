package com.junwo.starrpg.tests;

import com.junwo.starrpg.*;
import java.util.*;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.gametest.framework.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.*;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.item.*;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.living.LivingDropsEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.gametest.*;

@GameTestHolder(StarRPG.MODID)
@PrefixGameTestTemplate(false)
public class CareersAndMagicGameTests {
    private static Player player(GameTestHelper h,int job,Item item){
        Player p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(2.5,2,2.5)));p.setYRot(0);p.setXRot(0);
        var v=Careers.profile(p);v.selected=job;v.ranks[job]=1;p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(item));return p;
    }
    @GameTest(template="empty") public static void abilitiesRequireMatchingCareerWeapon(GameTestHelper h){
        Player p=player(h,0,StarRPG.STAR_DAGGER.get());
        h.assertTrue(!WeaponAbilities.activate(p)&&!WeaponAbilities.throwDagger(p,InteractionHand.MAIN_HAND)&&!Careers.cast(p),"Foreign profession granted dagger skills");
        h.assertTrue(p.getMainHandItem().getCount()==1,"Rejected throw consumed weapon");
        p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(Items.IRON_SWORD));h.assertTrue(WeaponAbilities.activate(p),"Warrior sword skill unavailable");WeaponAbilities.cancel(p);h.succeed();
    }
    @GameTest(template="empty") public static void unboundedPromotionConsumesExactResources(GameTestHelper h){
        Player p=player(h,0,Items.IRON_SWORD);var v=Careers.profile(p);v.ranks[0]=3;v.xp[0]=1800;v.mastery[0]=40;
        StarWallet.get(p.getServer()).credit(p.getUUID(),10000);p.getInventory().add(new ItemStack(Items.IRON_INGOT,12));
        h.assertTrue(Careers.advance(p)&&v.rank()==4&&v.xp()==900&&v.mastery()==20,"Fourth promotion blocked or counters wrong");
        h.assertTrue(p.getInventory().countItem(Items.IRON_INGOT)==0&&StarWallet.get(p.getServer()).balance(p.getUUID())==7000,"Promotion double-charged or wrong material");
        h.assertTrue(!Careers.advance(p)&&StarWallet.get(p.getServer()).balance(p.getUUID())==7000,"Unqualified repeat spent currency");
        v.ranks[0]=70000;v.xp[0]=700000;v.mastery[0]=800000;
        var data=CareerData.get(p.getServer());var loaded=CareerData.load(data.save(new CompoundTag(),h.getLevel().registryAccess()),h.getLevel().registryAccess()).profile(p.getUUID());
        var menu=new MaterialShopMenu(1,p.getInventory());
        h.assertTrue(loaded.rank()==70000&&loaded.mastery()==800000&&menu.rank()==70000&&menu.mastery()==800000,"High ranks truncated on save/menu");
        h.assertTrue(Careers.power(Integer.MAX_VALUE)<=6&&Careers.xpCost(Integer.MAX_VALUE)==100000&&Careers.goldCost(Integer.MAX_VALUE)==100000,"Infinite progression overflowed");h.succeed();
    }
    @GameTest(template="empty") public static void professionsDemandDifferentMaterials(GameTestHelper h){
        var types=List.of(Items.IRON_SWORD,StarRPG.STAR_DAGGER.get(),Items.BOW,StarRPG.MAGIC_STAFF.get());var distinct=new HashSet<Item>();
        for(int job=0;job<4;job++){
            Player p=player(h,job,types.get(job));var v=Careers.profile(p);v.xp[job]=300;v.mastery[job]=12;
            StarWallet.get(p.getServer()).credit(p.getUUID(),1000);p.getInventory().add(new ItemStack(Items.DIRT,64));
            h.assertTrue(!Careers.advance(p),"Wrong materials accepted");distinct.add(Careers.material(job));p.getInventory().add(new ItemStack(Careers.material(job),8));
            h.assertTrue(Careers.advance(p)&&v.rank()==2,"Correct profession materials rejected");
        }h.assertTrue(distinct.size()==4,"Shared material for all professions");h.succeed();
    }
    @GameTest(template="hook_arena") public static void masteryTracksAttackStyleAndRejectsFarmPets(GameTestHelper h){
        Player p=player(h,1,StarRPG.STAR_DAGGER.get());var zombie=EntityType.ZOMBIE.create(h.getLevel());zombie.setPos(p.position().add(0,0,2));zombie.setYRot(0);
        var source=h.getLevel().damageSources().playerAttack(p);h.assertTrue(Careers.trialMatches(p,zombie,source),"Backstab mastery not recognized");
        zombie.setYRot(180);h.assertTrue(!Careers.trialMatches(p,zombie,source),"Front hit counted as backstab");
        var thrown=new ThrownDagger(h.getLevel(),p,p.getMainHandItem());var daggerSource=new DamageSource(h.getLevel().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(WeaponAbilities.DAGGER_DAMAGE),thrown,p);
        Careers.death(new LivingDropsEvent(zombie,daggerSource,new ArrayList<>(),true));Careers.death(new LivingDropsEvent(zombie,daggerSource,new ArrayList<>(),true));
        h.assertTrue(Careers.profile(p).mastery()==1,"Mastery missing/duplicated");
        var cow=EntityType.COW.create(h.getLevel());Careers.death(new LivingDropsEvent(cow,daggerSource,new ArrayList<>(),true));h.assertTrue(Careers.profile(p).mastery()==1,"Passive farm counted");
        var v=Careers.profile(p);v.selected=2;v.ranks[2]=1;var arrow=new Arrow(h.getLevel(),p,new ItemStack(Items.ARROW),new ItemStack(Items.BOW));
        h.assertTrue(Careers.trialMatches(p,zombie,h.getLevel().damageSources().arrow(arrow,p)),"Ranged mastery missing");
        v.selected=3;v.ranks[3]=1;var magic=new DamageSource(h.getLevel().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(MagicSystem.MAGIC_DAMAGE),p);
        h.assertTrue(Careers.trialMatches(p,zombie,magic)&&!Careers.trialMatches(p,zombie,source),"Mage mastery accepts melee");h.succeed();
    }
    @GameTest(template="empty") public static void weaponBonusesDoNotHealOrLeakBetweenRoles(GameTestHelper h){
        Player p=player(h,0,StarRPG.STAR_SPEAR.get());p.setHealth(7);Careers.profile(p).ranks[0]=20;Careers.updateAttributes(p);
        h.assertTrue(p.getMaxHealth()>32&&p.getMaxHealth()<50&&p.getHealth()==7,"Prestige health unbounded or heals on equip");
        p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(Items.BOW));Careers.updateAttributes(p);
        h.assertTrue(p.getMaxHealth()==20&&p.getAttributeValue(Attributes.ARMOR)==0,"Warrior bonus leaked into bow");h.succeed();
    }
    @GameTest(template="hook_arena",timeoutTicks=50) public static void returningDaggerReturnsOriginalStackOnce(GameTestHelper h){
        Player p=player(h,1,StarRPG.STAR_DAGGER.get());var item=p.getMainHandItem();EnhancementData.setLevel(item,7);RuneDataHelper.setRuneEffect(item,RuneEffect.SWORD_STAR_SLASH);item.setDamageValue(23);
        h.assertTrue(WeaponAbilities.throwDagger(p,InteractionHand.MAIN_HAND),"Throw failed");var dag=h.getLevel().getEntitiesOfClass(ThrownDagger.class,p.getBoundingBox().inflate(2)).getFirst();
        dag.setPos(p.position().add(0,1,5));dag.beginReturn();
        h.runAfterDelay(20,()->{h.assertTrue(dag.isRemoved()&&p.getInventory().countItem(StarRPG.STAR_DAGGER.get())==1,"Recall lost or duplicated dagger");
            var returned=p.getInventory().items.stream().filter(s->s.is(StarRPG.STAR_DAGGER.get())).findFirst().orElseThrow();
            h.assertTrue(EnhancementData.level(returned)==7&&returned.getDamageValue()==23&&RuneDataHelper.getRuneEffect(returned)==RuneEffect.SWORD_STAR_SLASH,"Recall erased weapon data");
            dag.settle();h.assertTrue(h.getLevel().getEntitiesOfClass(ItemEntity.class,p.getBoundingBox().inflate(4),e->e.getItem().is(StarRPG.STAR_DAGGER.get())).isEmpty(),"Recall also dropped duplicate");h.succeed();});
    }
    @GameTest(template="hook_arena",timeoutTicks=50) public static void fullInventoryRecallDropsExactlyOne(GameTestHelper h){
        Player p=player(h,1,StarRPG.STAR_DAGGER.get());WeaponAbilities.throwDagger(p,InteractionHand.MAIN_HAND);
        var dag=h.getLevel().getEntitiesOfClass(ThrownDagger.class,p.getBoundingBox().inflate(2)).getFirst();for(int i=0;i<36;i++)p.getInventory().items.set(i,new ItemStack(Items.STONE,64));
        dag.setPos(p.position().add(0,1,4));dag.beginReturn();
        h.runAfterDelay(20,()->{h.assertTrue(dag.isRemoved(),"Recall got stuck");var drops=h.getLevel().getEntitiesOfClass(ItemEntity.class,p.getBoundingBox().inflate(4),e->e.getItem().is(StarRPG.STAR_DAGGER.get()));h.assertTrue(drops.size()==1&&drops.getFirst().getItem().getCount()==1,"Full inventory destroyed/duplicated dagger");h.succeed();});
    }
    @GameTest(template="empty") public static void daggerRecallStateSurvivesSave(GameTestHelper h){
        Player p=player(h,1,StarRPG.STAR_DAGGER.get());var dag=new ThrownDagger(h.getLevel(),p,p.getMainHandItem());dag.beginReturn();var nbt=new CompoundTag();dag.saveWithoutId(nbt);
        var loaded=new ThrownDagger(ModEntities.THROWN_DAGGER.get(),h.getLevel());loaded.load(nbt);h.assertTrue(loaded.returning()&&loaded.isNoPhysics(),"Reload lost recall phase");h.succeed();
    }
    @GameTest(template="empty") public static void magicManaCooldownAndProfessionAreAuthoritative(GameTestHelper h){
        Player p=player(h,3,StarRPG.MAGIC_STAFF.get());h.assertTrue(MagicSystem.cast(p),"Mage cannot cast");
        h.assertTrue(MagicSystem.mana(p)==92&&!MagicSystem.cast(p)&&MagicSystem.mana(p)==92,"Spam bypassed cooldown or charged twice");
        h.getLevel().getEntitiesOfClass(MagicBolt.class,p.getBoundingBox().inflate(3),a->a.getOwner()==p).forEach(Entity::discard);
        p.getPersistentData().putLong("starrpg_spell_ready",0);p.getPersistentData().putFloat("starrpg_mana",0);h.assertTrue(!MagicSystem.cast(p),"Cast without mana");
        p.getPersistentData().putFloat("starrpg_mana",80);Careers.profile(p).selected=0;Careers.profile(p).ranks[0]=1;
        h.assertTrue(!MagicSystem.cast(p)&&!MagicSystem.choose(p,1)&&MagicSystem.mana(p)==80,"Warrior cast mage spell");h.succeed();
    }
    @GameTest(template="empty") public static void healingAndFocusCannotBeSpammed(GameTestHelper h){
        Player p=player(h,3,StarRPG.MAGIC_STAFF.get());MagicSystem.choose(p,2);h.assertTrue(!MagicSystem.cast(p)&&MagicSystem.mana(p)==100,"Healing full health spent mana");
        p.setHealth(8);h.assertTrue(MagicSystem.cast(p)&&p.getHealth()>12&&MagicSystem.mana(p)==75,"Healing wrong cost/health");
        h.assertTrue(!MagicSystem.cast(p),"Healing ignored cooldown");h.assertTrue(Careers.cast(p)&&MagicSystem.mana(p)==105&&!Careers.cast(p),"Focus resource/cooldown wrong");
        float mana=MagicSystem.mana(p);Careers.profile(p).switchReady=0;StarWallet.get(p.getServer()).credit(p.getUUID(),1000);Careers.select(p,0);Careers.profile(p).switchReady=0;Careers.select(p,3);
        h.assertTrue(MagicSystem.mana(p)==mana,"Class switch refilled mana");h.succeed();
    }
    @GameTest(template="hook_arena",timeoutTicks=50) public static void magicBoltActuallyHitsAndDoesNotCreateItems(GameTestHelper h){
        Player p=player(h,3,StarRPG.MAGIC_STAFF.get());var cow=h.spawn(EntityType.COW,2,2,6);cow.setNoAi(true);cow.setNoGravity(true);
        var bolt=new MagicBolt(h.getLevel(),p,0,6);bolt.setPos(h.absoluteVec(new Vec3(2.5,2.7,3)));bolt.shoot(0,0,1,1.5F,0);h.getLevel().addFreshEntity(bolt);
        h.runAfterDelay(12,()->{h.assertTrue(cow.getHealth()==4&&bolt.isRemoved(),"Spell projectile missed or wrong damage: "+cow.getHealth());h.assertTrue(h.getLevel().getEntitiesOfClass(ItemEntity.class,cow.getBoundingBox().inflate(3),e->e.getItem().is(Items.AMETHYST_SHARD)).isEmpty(),"Spell minted amethyst");h.succeed();});
    }
    @GameTest(template="hook_arena") public static void fireMagicProtectsPetsAndTerrain(GameTestHelper h){
        Player p=player(h,3,StarRPG.MAGIC_STAFF.get());var cow=h.spawn(EntityType.COW,5,2,5);var pet=h.spawn(EntityType.WOLF,5,2,6);pet.setTame(true,true);float health=pet.getHealth();
        h.setBlock(5,1,5,Blocks.STONE);MagicSystem.explode(p,cow.position(),4,2,p);
        h.assertTrue(cow.getHealth()==6&&pet.getHealth()==health,"Fire magic damaged pet or missed enemy");h.assertBlockPresent(Blocks.STONE,5,1,5);h.succeed();
    }
    @GameTest(template="hook_arena",timeoutTicks=45) public static void meteorHasTelegraphAndCanBeCancelled(GameTestHelper h){
        Player p=player(h,3,StarRPG.MAGIC_STAFF.get());var cow=h.spawn(EntityType.COW,2,2,6);cow.setNoAi(true);cow.setNoGravity(true);cow.getAttribute(Attributes.MAX_HEALTH).setBaseValue(100);cow.setHealth(100);
        var target=WeaponAbilities.target(p,18,0.985);boolean cast=MagicSystem.meteor(p);h.assertTrue(cast&&cow.getHealth()==100&&MagicSystem.mana(p)==60,"Meteor precondition: cast="+cast+" health="+cow.getHealth()+" mana="+MagicSystem.mana(p)+" target="+(target==null?"null":target.getType())+" expectedDot="+p.getLookAngle().dot(cow.getEyePosition().subtract(p.getEyePosition()).normalize()));
        for(int t=0;t<=16;t+=2)h.runAfterDelay(t,()->MagicSystem.tick(new PlayerTickEvent.Post(p)));
        h.runAfterDelay(18,()->{h.assertTrue(cow.getHealth()==88,"Meteor failed actual impact: "+cow.getHealth());
            p.getPersistentData().putLong("starrpg_meteor_ready",0);MagicSystem.restore(p,100);h.assertTrue(MagicSystem.meteor(p),"Second meteor failed");p.setItemInHand(InteractionHand.MAIN_HAND,ItemStack.EMPTY);MagicSystem.tick(new PlayerTickEvent.Post(p));});
        h.runAfterDelay(36,()->{MagicSystem.tick(new PlayerTickEvent.Post(p));h.assertTrue(cow.getHealth()==88,"Unequipped staff still completed meteor");h.succeed();});
    }
    @GameTest(template="empty") public static void staffSupportsEnhancementAndSpellSelectionPreservesData(GameTestHelper h){
        Player p=player(h,3,StarRPG.MAGIC_STAFF.get());EnhancementData.setLevel(p.getMainHandItem(),8);MagicSystem.choose(p,1);
        h.assertTrue(EnhancementData.level(p.getMainHandItem())==8&&MagicSystem.spell(p.getMainHandItem())==1,"Spell selection erased enhancement");
        h.assertTrue(!BowElements.set(p.getMainHandItem(),BowElements.Element.LIGHTNING),"Bow-only control rune leaked to staff");
        h.assertTrue(h.getLevel().getRecipeManager().byKey(net.minecraft.resources.ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,"magic_staff")).isPresent(),"Staff recipe missing");h.succeed();
    }
    @GameTest(template="hook_arena",timeoutTicks=60) public static void thrownDaggerHitsThenReturnsWithoutSecondDamage(GameTestHelper h){
        Player p=player(h,1,StarRPG.STAR_DAGGER.get());var z=h.spawn(EntityType.ZOMBIE,2,2,7);z.setNoAi(true);z.setNoGravity(true);z.setItemSlot(EquipmentSlot.HEAD,new ItemStack(Items.IRON_HELMET));z.getAttribute(Attributes.MAX_HEALTH).setBaseValue(100);z.setHealth(100);
        h.assertTrue(WeaponAbilities.throwDagger(p,InteractionHand.MAIN_HAND),"Live throw failed");
        h.runAfterDelay(14,()->h.assertTrue(z.getHealth()<100,"Outgoing dagger did not hit"));
        h.runAfterDelay(35,()->{h.assertTrue(p.getInventory().countItem(StarRPG.STAR_DAGGER.get())==1,"Hit dagger never returned");h.assertTrue(z.getHealth()>90,"Return flight hit again");h.succeed();});
    }
    @GameTest(template="hook_arena") public static void magicSplashCannotCrossSolidWalls(GameTestHelper h){
        Player p=player(h,3,StarRPG.MAGIC_STAFF.get());var cow=h.spawn(EntityType.COW,5,2,7);cow.setNoAi(true);
        for(int x=4;x<=6;x++)for(int y=1;y<=4;y++)h.setBlock(x,y,6,Blocks.STONE);
        MagicSystem.explode(p,h.absoluteVec(new Vec3(5.5,2,5.5)),8,3,p);
        h.assertTrue(cow.getHealth()==10,"Magic splash passed through wall");h.assertBlockPresent(Blocks.STONE,5,2,6);h.succeed();
    }

}
