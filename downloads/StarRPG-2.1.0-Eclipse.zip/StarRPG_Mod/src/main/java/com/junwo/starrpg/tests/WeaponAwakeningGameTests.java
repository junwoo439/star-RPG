package com.junwo.starrpg.tests;

import com.junwo.starrpg.*;
import java.util.*;
import net.minecraft.gametest.framework.*;
import net.minecraft.world.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.item.*;
import net.minecraft.world.effect.*;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.*;

@GameTestHolder(StarRPG.MODID)
@PrefixGameTestTemplate(false)
public class WeaponAwakeningGameTests {
    private static Item[] weapons(){return new Item[]{StarRPG.STAR_DAGGER.get(),StarRPG.WAR_HAMMER.get(),StarRPG.MAGIC_STAFF.get(),StarRPG.STAR_SPEAR.get(),StarRPG.BERSERKER_BLADE.get(),StarRPG.SUN_SCEPTER.get(),StarRPG.SOUL_SCYTHE.get(),StarRPG.STAR_GAUNTLET.get(),StarRPG.AEGIS_BLADE.get(),Items.BOW,Items.CROSSBOW,Items.TRIDENT};}
    private static Player player(GameTestHelper h,Item item,int level){var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(2.5,2,2.5)));p.setYRot(0);p.setXRot(0);var w=new ItemStack(item);EnhancementData.setLevel(w,level);p.setItemInHand(InteractionHand.MAIN_HAND,w);int job=Careers.weaponJob(w);if(job>=0){var c=Careers.profile(p);c.selected=job;c.ranks[job]=1;}return p;}
    @GameTest(template="empty") public static void thresholdsUseEquipmentNotCareerAndCapAtTwentyFive(GameTestHelper h){
        var p=player(h,StarRPG.STAR_DAGGER.get(),0);Careers.profile(p).ranks[1]=100;
        h.assertTrue(WeaponAwakening.stage(p.getMainHandItem())==0&&!WeaponAwakening.activate(p),"Career rank granted weapon skill");
        for(int n:new int[]{4,5,9,10,14,15,19,20,24,25,100}){EnhancementData.setLevel(p.getMainHandItem(),n);h.assertTrue(WeaponAwakening.stage(p.getMainHandItem())==Math.min(5,n/5),"Wrong stage boundary "+n);}
        for(var item:List.of(Items.IRON_SWORD,Items.IRON_AXE)){var w=new ItemStack(item);EnhancementData.setLevel(w,25);h.assertTrue(WeaponAwakening.stage(w)==2&&EnhancementData.level(w)==10,"Tutorial cap removed");}h.succeed();
    }
    @GameTest(template="empty") public static void statsDoNotStackHealOrLeakOnUnequip(GameTestHelper h){
        var p=player(h,StarRPG.WAR_HAMMER.get(),5);p.setHealth(7);WeaponAwakening.attributes(p);double hp=p.getMaxHealth();WeaponAwakening.attributes(p);h.assertTrue(hp==22&&p.getMaxHealth()==22&&p.getHealth()==7,"Health stacked/healed");p.setItemInHand(InteractionHand.MAIN_HAND,ItemStack.EMPTY);WeaponAwakening.attributes(p);h.assertTrue(p.getMaxHealth()==20,"Held bonus leaked");
        var spear=player(h,StarRPG.STAR_SPEAR.get(),20);double range=spear.getAttributeValue(Attributes.ENTITY_INTERACTION_RANGE);WeaponAwakening.attributes(spear);h.assertTrue(Math.abs(spear.getAttributeValue(Attributes.ENTITY_INTERACTION_RANGE)-range-0.5)<0.001,"Spear reach wrong");Careers.profile(spear).selected=3;WeaponAwakening.attributes(spear);h.assertTrue(spear.getAttributeValue(Attributes.ENTITY_INTERACTION_RANGE)==range,"Other class inherited reach");h.succeed();
    }
    @GameTest(template="empty") public static void staffManaAndEfficiencyUnlockAtFiveAndTwenty(GameTestHelper h){
        var p=player(h,StarRPG.MAGIC_STAFF.get(),0);float base=MagicSystem.maxMana(p);EnhancementData.setLevel(p.getMainHandItem(),5);h.assertTrue(MagicSystem.maxMana(p)==base+10,"Staff +5 mana missing");EnhancementData.setLevel(p.getMainHandItem(),20);h.assertTrue(MagicSystem.manaCost(p,40)==36,"Staff +20 cost reduction wrong");p.setItemInHand(InteractionHand.MAIN_HAND,ItemStack.EMPTY);h.assertTrue(MagicSystem.maxMana(p)==base&&MagicSystem.manaCost(p,40)==40,"Efficiency leaked after unequip");h.succeed();
    }
    @GameTest(template="hook_arena") public static void allTwelveAwakeningsActivateAndRejectSpam(GameTestHelper h){
        for(Item item:weapons()){
            var p=player(h,item,25);p.setHealth(8);p.getInventory().add(new ItemStack(Items.ARROW,64));
            var enemy=EntityType.ZOMBIE.create(h.getLevel());enemy.setPos(p.position().add(0,0,2));enemy.setNoAi(true);enemy.setNoGravity(true);enemy.setOnGround(true);enemy.getAttribute(Attributes.MAX_HEALTH).setBaseValue(200);enemy.setHealth(200);h.getLevel().addFreshEntity(enemy);
            var pet=EntityType.WOLF.create(h.getLevel());pet.setPos(p.position().add(1,0,2));pet.setTame(true,true);h.getLevel().addFreshEntity(pet);float hp=pet.getHealth();
            h.assertTrue(WeaponAwakening.activate(p),"Awakening failed "+item);h.assertTrue(!WeaponAwakening.activate(p),"Spam bypassed timer "+item);h.assertTrue(pet.getHealth()==hp,"Skill hit pet "+item);
            if(!(item instanceof BowItem||item instanceof CrossbowItem))h.assertTrue(enemy.getHealth()<200,"Skill did not damage target "+item);
            enemy.discard();pet.discard();h.getLevel().getEntitiesOfClass(GiantArrow.class,p.getBoundingBox().inflate(4),a->a.getOwner()==p).forEach(Entity::discard);
        }h.succeed();
    }
    @GameTest(template="empty") public static void bowConsumesExactAmmoAndCreativeDoesNotMintAmmo(GameTestHelper h){
        var p=player(h,Items.BOW,15);p.getInventory().add(new ItemStack(Items.ARROW,2));h.assertTrue(!WeaponAwakening.activate(p)&&WeaponAwakening.arrowCount(p)==2&&!p.getPersistentData().contains(WeaponAwakening.READY),"Missing arrows spent resource/timer");
        p.getInventory().add(new ItemStack(Items.ARROW,1));h.assertTrue(WeaponAwakening.activate(p)&&WeaponAwakening.arrowCount(p)==0,"Volley didn't consume 3");
        var arrows=h.getLevel().getEntitiesOfClass(GiantArrow.class,p.getBoundingBox().inflate(3),a->a.getOwner()==p);h.assertTrue(arrows.size()==3&&arrows.stream().allMatch(a->a.getPierceLevel()==0),"Volley count/pierce wrong");arrows.forEach(Entity::discard);
        p.getPersistentData().putLong(WeaponAwakening.READY,0);EnhancementData.setLevel(p.getMainHandItem(),25);p.getInventory().add(new ItemStack(Items.ARROW,5));h.assertTrue(WeaponAwakening.activate(p)&&WeaponAwakening.arrowCount(p)==0,"+25 volley wrong ammo");h.assertTrue(h.getLevel().getEntitiesOfClass(GiantArrow.class,p.getBoundingBox().inflate(3),a->a.getOwner()==p).size()==5,"+25 volley not five");h.succeed();
    }
    @GameTest(template="empty") public static void crossbowPierceKeepsWeaponSnapshot(GameTestHelper h){
        var p=player(h,Items.CROSSBOW,25);p.getInventory().add(new ItemStack(Items.ARROW,1));RuneDataHelper.setRuneEffect(p.getMainHandItem(),RuneEffect.CROSSBOW_IMPACT_COMMON);
        h.assertTrue(WeaponAwakening.activate(p),"Crossbow awakening failed");var arrow=h.getLevel().getEntitiesOfClass(GiantArrow.class,p.getBoundingBox().inflate(3),a->a.getOwner()==p).getFirst();
        h.assertTrue(arrow.getPierceLevel()==4&&EnhancementData.level(arrow.getWeaponItem())==25&&RuneDataHelper.hasRuneEffect(arrow.getWeaponItem()),"Pierce arrow lost weapon data");p.setItemInHand(InteractionHand.MAIN_HAND,ItemStack.EMPTY);h.assertTrue(EnhancementData.level(arrow.getWeaponItem())==25,"Snapshot changed on unequip");h.succeed();
    }
    @GameTest(template="empty") public static void classSwapAndWeaponSwapCannotResetAwakening(GameTestHelper h){
        var p=player(h,StarRPG.STAR_DAGGER.get(),15);h.assertTrue(WeaponAwakening.activate(p),"First skill failed");p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(StarRPG.SOUL_SCYTHE.get()));EnhancementData.setLevel(p.getMainHandItem(),25);var c=Careers.profile(p);c.selected=7;c.ranks[7]=1;h.assertTrue(!WeaponAwakening.activate(p),"Weapon/class swap reset timer");p.getPersistentData().putLong(WeaponAwakening.READY,0);c.selected=3;h.assertTrue(!WeaponAwakening.activate(p),"Wrong career allowed skill");h.succeed();
    }
    @GameTest(template="hook_arena") public static void awakeningCannotDamageThroughWalls(GameTestHelper h){
        var p=player(h,StarRPG.MAGIC_STAFF.get(),25);var cow=h.spawn(EntityType.COW,2,2,6);cow.setNoAi(true);cow.setNoGravity(true);for(int x=1;x<=4;x++)for(int y=1;y<=4;y++)h.setBlock(x,y,4,Blocks.STONE);
        float hp=cow.getHealth();h.assertTrue(WeaponAwakening.activate(p)&&cow.getHealth()==hp&&MagicSystem.mana(p)==75,"Beam passed through wall or wrong mana");h.succeed();
    }
    @GameTest(template="empty") public static void insufficientManaAndCrowdControlPreventCast(GameTestHelper h){
        var p=player(h,StarRPG.MAGIC_STAFF.get(),25);p.getPersistentData().putFloat("starrpg_mana",24);h.assertTrue(!WeaponAwakening.activate(p)&&MagicSystem.mana(p)==24,"Cast with insufficient mana");
        MagicSystem.restore(p,100);p.addEffect(new MobEffectInstance(ModEffects.STUN,20,0));h.assertTrue(!WeaponAwakening.activate(p),"Stunned cast allowed");h.succeed();
    }
    @GameTest(template="hook_arena",timeoutTicks=60) public static void sigilsExpireAndDoNotHurtOrAlterTerrain(GameTestHelper h){
        var p=player(h,StarRPG.SUN_SCEPTER.get(),15);float hp=p.getHealth();ArcaneSigil.spawn(h.getLevel(),p.position(),p.getLookAngle(),1,0xFF9900,2,20);
        var all=h.getLevel().getEntitiesOfClass(ArcaneSigil.class,p.getBoundingBox().inflate(2));h.assertTrue(!all.isEmpty()&&all.stream().allMatch(e->e.noPhysics),"Sigil missing/collidable");
        h.runAfterDelay(25,()->{h.assertTrue(all.stream().allMatch(Entity::isRemoved)&&p.getHealth()==hp,"Visual hurt player or failed cleanup");h.succeed();});
    }
    @GameTest(template="empty") public static void originalAtlasAndAllUnlockDescriptionsPresent(GameTestHelper h)throws Exception{
        try(var in=StarRPG.class.getClassLoader().getResourceAsStream("assets/starrpg/textures/art/weapons_and_sigils.png")){var image=javax.imageio.ImageIO.read(in);h.assertTrue(image.getColorModel().hasAlpha()&&image.getWidth()==image.getHeight(),"Atlas lost transparency/aspect");}
        for(var item:weapons()){int k=WeaponArt.kind(item.getDefaultInstance());h.assertTrue(WeaponAwakening.EFFECTS[k].length==5&&Arrays.stream(WeaponAwakening.EFFECTS[k]).noneMatch(String::isBlank),"Missing unlock description");}
        h.succeed();
    }
    @GameTest(template="empty") public static void staffMagicPassiveIncludesDirectMeteorDamage(GameTestHelper h){
        var p=player(h,StarRPG.MAGIC_STAFF.get(),10);var target=EntityType.COW.create(h.getLevel());target.getAttribute(Attributes.MAX_HEALTH).setBaseValue(40);target.setHealth(40);
        MagicSystem.damage(p,target,10,p);h.assertTrue(Math.abs(target.getHealth()-29)<0.001,"Staff +10 failed for direct meteor magic: "+target.getHealth());h.succeed();
    }

}
