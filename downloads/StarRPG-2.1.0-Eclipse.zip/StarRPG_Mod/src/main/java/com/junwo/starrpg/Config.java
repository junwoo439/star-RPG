package com.junwo.starrpg;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.config.ModConfigEvent;
import net.neoforged.neoforge.common.ModConfigSpec;

// An example config class. This is not required, but it's a good idea to have one to keep your config organized.
// Demonstrates how to use Neo's config APIs
public class Config {
    private static final ModConfigSpec.Builder BUILDER = new ModConfigSpec.Builder();

    public static final ModConfigSpec.BooleanValue LOG_DIRT_BLOCK = BUILDER
            .comment("Whether to log the dirt block on common setup")
            .define("logDirtBlock", true);

    public static final ModConfigSpec.IntValue MAGIC_NUMBER = BUILDER
            .comment("A magic number")
            .defineInRange("magicNumber", 42, 0, Integer.MAX_VALUE);

    public static final ModConfigSpec.ConfigValue<String> MAGIC_NUMBER_INTRODUCTION = BUILDER
            .comment("What you want the introduction message to be for the magic number")
            .define("magicNumberIntroduction", "The magic number is... ");

    // a list of strings that are treated as resource locations for items
    public static final ModConfigSpec.ConfigValue<List<? extends String>> ITEM_STRINGS = BUILDER
            .comment("A list of items to log on common setup.")
            .defineListAllowEmpty("items", List.of("minecraft:iron_ingot"), () -> "", Config::validateItemName);

    public static final ModConfigSpec.ConfigValue<List<? extends Integer>> SUCCESS_CHANCES = BUILDER
            .defineList("enhancement.successChances", List.of(100,95,90,85,80,75,65,55,45,30), v -> v instanceof Integer n && n >= 1 && n <= 100);
    public static final ModConfigSpec.ConfigValue<List<? extends Integer>> DUST_COSTS = BUILDER
            .defineList("enhancement.dustCosts", List.of(1,2,3,4,5,6,8,10,12,15), v -> v instanceof Integer n && n >= 1 && n <= 64);
    public static final ModConfigSpec.ConfigValue<List<? extends Integer>> FRAGMENT_COSTS = BUILDER
            .defineList("enhancement.fragmentCosts", List.of(0,0,0,0,0,1,1,2,3,5), v -> v instanceof Integer n && n >= 0 && n <= 64);
    public static final ModConfigSpec.IntValue PITY_BONUS = BUILDER.defineInRange("enhancement.pityBonusPercent", 10, 1, 100);
    public static final ModConfigSpec.DoubleValue LIFESTEAL = BUILDER.defineInRange("combat.lifestealFraction", 0.12, 0.0, 0.5);
    public static final ModConfigSpec.DoubleValue HEAL_CAP = BUILDER.defineInRange("combat.lifestealPerSecond", 4.0, 0.0, 20.0);
    public static final ModConfigSpec.BooleanValue NO_VANILLA_ENCHANTMENTS = BUILDER.define("combat.disableVanillaEnchantments",true);
    public static final ModConfigSpec.BooleanValue MOB_SCALING = BUILDER.define("monsters.enabled", true);
    public static final ModConfigSpec.IntValue MAX_TIER = BUILDER.comment("Legacy setting retained for old configs; 1.9 world growth is uncapped.").defineInRange("monsters.maxTier", 5, 0, Integer.MAX_VALUE);
    public static final ModConfigSpec.IntValue MINUTES_PER_TIER = BUILDER.comment("Shared active survival/adventure play minutes per world difficulty tier. Sleep and /time do not advance this clock.")
            .defineInRange("monsters.minutesPerTier", 60, 1, 1440);
    public static final ModConfigSpec.BooleanValue ZOMBIE_EQUIPMENT = BUILDER.define("monsters.zombieEquipment", true);
    public static final ModConfigSpec.BooleanValue ZOMBIE_HOOKS = BUILDER.define("monsters.zombieHooks", true);
    public static final ModConfigSpec.BooleanValue MOB_TRAITS = BUILDER.define("monsters.specialTraits", true);
    public static final ModConfigSpec.IntValue HOOK_COOLDOWN = BUILDER.defineInRange("monsters.hookCooldownSeconds", 8, 3, 60);
    public static final ModConfigSpec.DoubleValue MOB_HEALTH = BUILDER.defineInRange("monsters.healthPerTier", 0.30, 0.0, 1.0);
    public static final ModConfigSpec.DoubleValue MOB_DAMAGE = BUILDER.defineInRange("monsters.damagePerTier", 0.12, 0.0, 0.5);
    public static final ModConfigSpec.DoubleValue BOSS_SCALING = BUILDER.defineInRange("monsters.bossScalingMultiplier", 0.5, 0.0, 1.0);
    public static final ModConfigSpec.DoubleValue REWARD_SCALE = BUILDER.defineInRange("rewards.extraPerTier", 0.15, 0.0, 1.0);
    public static final ModConfigSpec.IntValue DUST_DROP = BUILDER.defineInRange("rewards.normalDustPercent", 40, 0, 100);
    public static final ModConfigSpec.IntValue FRAGMENT_DROP = BUILDER.defineInRange("rewards.normalFragmentPercent", 4, 0, 100);
    public static final ModConfigSpec.IntValue RUNE_DROP = BUILDER.defineInRange("rewards.normalRunePercent", 3, 0, 100);

    public static final ModConfigSpec.BooleanValue ECONOMY_ENABLED = BUILDER.define("economy.enabled", true);
    public static final ModConfigSpec.IntValue MATERIAL_PRICE_MULTIPLIER = BUILDER.defineInRange("economy.materialPriceMultiplier",2,1,10);
    public static final ModConfigSpec.IntValue DUST_PRICE = BUILDER.defineInRange("economy.dustPrice",20,1,30000);
    public static final ModConfigSpec.IntValue FRAGMENT_PRICE = BUILDER.defineInRange("economy.fragmentPrice",200,1,30000);
    public static final ModConfigSpec.IntValue RUNE_PRICE = BUILDER.defineInRange("economy.commonRunePrice",120,1,30000);

    static final ModConfigSpec SPEC = BUILDER.build();

    private static boolean validateItemName(final Object obj) {
        return obj instanceof String itemName && BuiltInRegistries.ITEM.containsKey(ResourceLocation.parse(itemName));
    }
}
