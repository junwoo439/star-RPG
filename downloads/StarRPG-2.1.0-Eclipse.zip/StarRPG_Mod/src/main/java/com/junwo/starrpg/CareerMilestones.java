package com.junwo.starrpg;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.effect.*;
import net.neoforged.bus.api.*;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;

@EventBusSubscriber(modid=StarRPG.MODID)
public final class CareerMilestones {
    public static int count(int rank){return Math.max(0,rank-1)/5;}
    public static double stat(int rank){return 2*Math.log1p(count(rank));}
    public static final String[] FIRST={"관통의 상처: 약화","암습의 흔적: 둔화","사냥 표식: 발광","마력 침식: 약화","담금질: 보호막","광폭 추격: 가속","빛의 축복: 자기 치유","영혼 포식: 자기 치유","연환 보법: 가속","철벽: 저항","불꽃 침식: 약화","해류 침식: 약화","서리 침식: 약화","대지 침식: 약화","심연 침식: 약화","성광 침식: 약화"};
    @SubscribeEvent public static void hit(LivingDamageEvent.Post e){
        if(e.getNewDamage()<=0||e.getEntity().level().isClientSide()||!(e.getSource().getEntity() instanceof Player p)||p.getServer()==null
            ||e.getSource().is(CombatRules.RUNE)||!CombatRules.canHarmDead(p,e.getEntity()))return;
        var w=p.getMainHandItem();
        if(e.getSource().getDirectEntity() instanceof net.minecraft.world.entity.projectile.AbstractArrow arrow&&arrow.getWeaponItem()!=null)w=arrow.getWeaponItem();
        if(e.getSource().getDirectEntity() instanceof MagicBolt bolt)w=bolt.staff();
        if(!Careers.qualified(p,w)||count(Careers.profile(p).rank())<1)return;
        long now=p.level().getGameTime();if(p.getPersistentData().getLong("starrpg_milestone_hit")>now)return;
        p.getPersistentData().putLong("starrpg_milestone_hit",now+160);
        switch(Careers.profile(p).selected){
            case 0,3,10,11,12,13,14,15->e.getEntity().addEffect(new MobEffectInstance(MobEffects.WEAKNESS,40,0));
            case 1->e.getEntity().addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,20,0));
            case 2->e.getEntity().addEffect(new MobEffectInstance(MobEffects.GLOWING,80,0));
            case 4->p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,60,0));
            case 5,8->p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED,40,0));
            case 6,7->p.heal(Math.min(1,e.getNewDamage()*0.1F));
            case 9->p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,40,0));
        }
        CombatVisuals.burst(p,ParticleTypes.ENCHANTED_HIT,8);
    }
    public static void onSkill(Player p){
        if(!Careers.qualified(p,p.getMainHandItem()))return;
        int count=count(Careers.profile(p).rank());long now=p.level().getGameTime();
        if(count<2||p.getPersistentData().getLong("starrpg_milestone_ready")>now)return;
        p.getPersistentData().putLong("starrpg_milestone_ready",now+240);
        p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,60,0));
        if(count>=3){
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,60,0));
            if(Careers.mage(Careers.profile(p).selected))MagicSystem.restore(p,8);
            if(Careers.profile(p).selected==2)p.getPersistentData().putLong("starrpg_focus_until",Math.max(p.getPersistentData().getLong("starrpg_focus_until"),now+60));
            CombatVisuals.circle(p,2.5,ParticleTypes.TOTEM_OF_UNDYING);
        }
    }
}
