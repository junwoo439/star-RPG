package com.junwo.starrpg;

import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.inventory.MenuType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModMenus {

    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(
                    net.minecraft.core.registries.Registries.MENU,
                    StarRPG.MODID
            );

    public static final DeferredHolder<MenuType<?>, MenuType<MaterialShopMenu>> MATERIAL_SHOP =
            MENUS.register("material_shop", () -> new MenuType<>(MaterialShopMenu::new, FeatureFlags.DEFAULT_FLAGS));

    public static final DeferredHolder<MenuType<?>, MenuType<EnhancementMenu>> ENHANCEMENT_MENU =
            MENUS.register(
                    "enhancement_menu",
                    () -> new MenuType<>(
                            EnhancementMenu::new,
                            FeatureFlags.DEFAULT_FLAGS
                    )
            );

    public static final DeferredHolder<MenuType<?>, MenuType<RuneEngravingMenu>> RUNE_ENGRAVING_MENU =
            MENUS.register(
                    "rune_engraving_menu",
                    () -> new MenuType<>(
                            RuneEngravingMenu::new,
                            FeatureFlags.DEFAULT_FLAGS
                    )
            );
}