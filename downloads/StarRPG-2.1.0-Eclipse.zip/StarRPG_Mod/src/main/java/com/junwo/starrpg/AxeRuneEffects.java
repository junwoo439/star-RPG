package com.junwo.starrpg;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;

@EventBusSubscriber(modid = StarRPG.MODID)
public class AxeRuneEffects {

    private record TargetKey(UUID attackerId, UUID targetId) {
    }

    private record DamageMark(long endTime, float multiplier) {
    }

    private static final Map<UUID, DamageMark> DAMAGE_MARKS =
            new HashMap<>();

    private static final Map<TargetKey, Long> WEIGHT_COOLDOWN =
            new HashMap<>();

    private static final Map<UUID, Long> SMASH_COOLDOWN =
            new HashMap<>();

    private static final Map<UUID, Long> BATTLE_INSTINCT_COOLDOWN =
            new HashMap<>();

    private static final Map<TargetKey, Integer> EXPLOSION_COUNT =
            new HashMap<>();

    private static final Map<TargetKey, Long> EXPLOSION_LAST_HIT =
            new HashMap<>();

    private static final Map<UUID, UUID> BLOOD_OATH_TARGET =
            new HashMap<>();

    private static final Map<UUID, Integer> BLOOD_OATH_STACK =
            new HashMap<>();

    private static final Map<UUID, Long> BLOOD_OATH_LAST_HIT =
            new HashMap<>();

    private static final Map<UUID, Long> EARTH_SMASH_COOLDOWN =
            new HashMap<>();

    private static final Map<TargetKey, Integer> DEATH_MARK_COUNT =
            new HashMap<>();

    private static final Map<TargetKey, Long> DEATH_MARK_LAST_HIT =
            new HashMap<>();
    private static final Map<TargetKey, Integer> DOOM_MARK_STACK =
            new HashMap<>();

    private static final Map<TargetKey, Long> DOOM_MARK_LAST_HIT =
            new HashMap<>();

    private static final Map<UUID, Long> FINAL_BLOW_COOLDOWN =
            new HashMap<>();

    private static final Map<UUID, Long> BLOOD_STORM_COOLDOWN =
            new HashMap<>();

    private static final Map<UUID, Long> GIANT_STRENGTH_COOLDOWN =
            new HashMap<>();

    @SubscribeEvent
    public static void onLivingDamage(LivingIncomingDamageEvent event) {
        if (!CombatRules.primary(event.getSource()) || !CombatRules.charged(event.getSource())) return;
        LivingEntity target = event.getEntity();

        if (target.level().isClientSide()) {
            return;
        }

        long now = target.level().getGameTime();

        // 균열, 균열의 흔적에 걸린 대상이 받는 추가 피해
        applyDamageMark(target, event, now);

        if (!(event.getSource().getEntity() instanceof Player player)) {
            return;
        }

        ItemStack weapon = player.getMainHandItem();

        if (!(weapon.getItem() instanceof AxeItem)) {
            return;
        }

        RuneEffect runeEffect = RuneDataHelper.getRuneEffect(weapon);

        if (runeEffect == null) {
            return;
        }

        switch (runeEffect) {

            // ===== 일반 도끼 =====
            case AXE_SHOCK -> applyShock(player, target);

            case AXE_CRACK_TRACE -> applyDamageMarkToTarget(
                    target,
                    now,
                    40,
                    1.05F
            );

            case AXE_WEIGHT -> applyWeight(player, target, now);

            case AXE_BREAK -> applyBreak(target, event);

            // ===== 희귀 도끼 =====
            case AXE_CRACK -> applyDamageMarkToTarget(
                    target,
                    now,
                    60,
                    1.08F
            );

            case AXE_HUNTER -> applyHunter(target, event);

            case AXE_SMASH -> applySmash(player, event, now);

            // ===== 에픽 도끼 =====
            case AXE_EXECUTION -> applyExecution(target, event);

            case AXE_SHATTER -> applyShatter(player, target, now);

            case AXE_EXPLOSION ->
                    applyExplosion(player, target, now);

            case AXE_BLOOD_TRACE -> applyBloodTrace(target);

            // ===== 레전더리 도끼 =====
            case AXE_BLOOD_OATH ->
                    applyBloodOath(player, target, event, now);

            case AXE_EARTH_SMASH ->
                    applyEarthSmash(player, target, now);

            case AXE_DEATH_MARK ->
                    applyDeathMark(player, target, event, now);

            case AXE_BERSERKER_RAGE ->
                    applyBerserkerRage(player, event);
            
                 // ===== 신화 도끼 =====
            case AXE_DOOM_MARK ->
                    applyDoomMark(player, target, event, now);

            case AXE_FINAL_BLOW ->
                    applyFinalBlow(player, target, now);

            case AXE_GIANT_STRENGTH ->
                    applyGiantStrength(player, now);

            default -> {
            }
        }
    }

    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        if (!CombatRules.primary(event.getSource()) || !CombatRules.charged(event.getSource())) return;
        if (!(event.getSource().getEntity() instanceof Player player)) {
            return;
        }

        if (player.level().isClientSide()) {
            return;
        }

        ItemStack weapon = player.getMainHandItem();

        if (!(weapon.getItem() instanceof AxeItem)) {
            return;
        }

        RuneEffect runeEffect = RuneDataHelper.getRuneEffect(weapon);

        if (runeEffect == RuneEffect.AXE_BLOOD_STORM) {
            applyBloodStorm(player, event.getEntity(), player.level().getGameTime());
            return;
        }
        if (runeEffect != RuneEffect.AXE_BATTLE_INSTINCT) {
            return;
        }

        long now = player.level().getGameTime();

        long lastUse = BATTLE_INSTINCT_COOLDOWN.getOrDefault(
                player.getUUID(),
                -100L
        );

        if (now - lastUse < 100) {
            return;
        }
        

        BATTLE_INSTINCT_COOLDOWN.put(player.getUUID(), now);

        player.addEffect(
                new MobEffectInstance(
                        MobEffects.DAMAGE_BOOST,
                        60,
                        0,
                        false,
                        true,
                        true
                )
        );

        player.sendSystemMessage(
                Component.literal("전투 본능 발동! 힘 I")
        );
    }

    private static void applyDamageMark(
            LivingEntity target,
            LivingIncomingDamageEvent event,
            long now
    ) {
        DamageMark mark = DAMAGE_MARKS.get(target.getUUID());

        if (mark == null) {
            return;
        }

        if (mark.endTime() <= now) {
            DAMAGE_MARKS.remove(target.getUUID());
            return;
        }

        event.setAmount(
                event.getAmount() * mark.multiplier()
        );
    }

    private static void applyDamageMarkToTarget(
            LivingEntity target,
            long now,
            long duration,
            float multiplier
    ) {
        DAMAGE_MARKS.put(
                target.getUUID(),
                new DamageMark(now + duration, multiplier)
        );
    }

    private static void applyShock(
            Player player,
            LivingEntity target
    ) {
        if (player.getRandom().nextInt(100) >= 15) {
            return;
        }

        target.knockback(
                1.25D,
                player.getX() - target.getX(),
                player.getZ() - target.getZ()
        );

        player.sendSystemMessage(
                Component.literal("충격 발동!")
        );
    }

    private static void applyWeight(
            Player player,
            LivingEntity target,
            long now
    ) {
        TargetKey key = new TargetKey(
                player.getUUID(),
                target.getUUID()
        );

        long lastUse = WEIGHT_COOLDOWN.getOrDefault(
                key,
                -80L
        );

        if (now - lastUse < 80) {
            return;
        }

        WEIGHT_COOLDOWN.put(key, now);

        target.addEffect(
                new MobEffectInstance(
                        MobEffects.MOVEMENT_SLOWDOWN,
                        40,
                        0,
                        false,
                        true,
                        true
                )
        );

        player.sendSystemMessage(
                Component.literal("중압이 발동됨")
        );
    }

    private static void applyBreak(
            LivingEntity target,
            LivingIncomingDamageEvent event
    ) {
        if (!(target instanceof Player targetPlayer)) {
            return;
        }

        if (!targetPlayer.isUsingItem()) {
            return;
        }

        if (!targetPlayer.getUseItem().is(Items.SHIELD)) {
            return;
        }

        event.setAmount(event.getAmount() + 2.0F);
    }

    private static void applyHunter(
            LivingEntity target,
            LivingIncomingDamageEvent event
    ) {
        if (target.getHealth() > target.getMaxHealth() * 0.5F) {
            return;
        }

        event.setAmount(event.getAmount() + 4.0F);
    }

    private static void applySmash(
            Player player,
            LivingIncomingDamageEvent event,
            long now
    ) {
        long lastUse = SMASH_COOLDOWN.getOrDefault(
                player.getUUID(),
                -60L
        );

        if (now - lastUse < 60) {
            return;
        }

        if (player.getRandom().nextInt(100) >= 15) {
            return;
        }

        SMASH_COOLDOWN.put(player.getUUID(), now);

        event.setAmount(event.getAmount() + 3.0F);

        player.sendSystemMessage(
                Component.literal("강타가 발동됨 추가 피해 +3")
        );
    }

    private static void applyExecution(
            LivingEntity target,
            LivingIncomingDamageEvent event
    ) {
        if (target.getHealth() > target.getMaxHealth() * 0.25F) {
            return;
        }

        event.setAmount(event.getAmount() + 7.0F);
    }

    private static void applyShatter(
            Player player,
            LivingEntity target,
            long now
    ) {
        long lastUse = SMASH_COOLDOWN.getOrDefault(
                player.getUUID(),
                -160L
        );

        if (now - lastUse < 160) {
            return;
        }

        if (player.getRandom().nextInt(100) >= 20) {
            return;
        }

        if (!target.hasEffect(MobEffects.DAMAGE_RESISTANCE)) {
            return;
        }

        SMASH_COOLDOWN.put(player.getUUID(), now);

        target.removeEffect(MobEffects.DAMAGE_RESISTANCE);
        target.getPersistentData().putLong("starrpg_resistance_suppressed", now + 60);

        player.sendSystemMessage(
                Component.literal("분쇄가 발동됨 저항 효과 제거")
        );
    }

    private static void applyExplosion(
            Player player,
            LivingEntity target,
            long now
    ) {
        TargetKey key = new TargetKey(
                player.getUUID(),
                target.getUUID()
        );

        long lastHit = EXPLOSION_LAST_HIT.getOrDefault(
                key,
                -100L
        );

        int hitCount;

        if (now - lastHit > 100) {
            hitCount = 1;
        } else {
            hitCount = EXPLOSION_COUNT.getOrDefault(key, 0) + 1;
        }

        EXPLOSION_COUNT.put(key, hitCount);
        EXPLOSION_LAST_HIT.put(key, now);

        if (hitCount < 5) {
            return;
        }

        EXPLOSION_COUNT.put(key, 0);

        List<LivingEntity> nearbyEntities =
                target.level().getEntitiesOfClass(
                        LivingEntity.class,
                        target.getBoundingBox().inflate(3.0D),
                        entity -> entity != target
                                && entity != player
                                && CombatRules.canHarm(player, entity)
                );

        for (LivingEntity nearby : nearbyEntities) {
            CombatRules.runeDamage(player, nearby, 4.0F);
        }

        player.sendSystemMessage(
                Component.literal("폭렬 타격이 발동됨")
        );
    }

    private static void applyBloodTrace(
            LivingEntity target
    ) {
        target.addEffect(
                new MobEffectInstance(
                        MobEffects.GLOWING,
                        120,
                        0,
                        false,
                        true,
                        true
                )
        );
    }

    private static void applyBloodOath(
            Player player,
            LivingEntity target,
            LivingIncomingDamageEvent event,
            long now
    ) {
        UUID playerId = player.getUUID();
        UUID targetId = target.getUUID();

        UUID previousTarget = BLOOD_OATH_TARGET.get(playerId);

        long lastHit = BLOOD_OATH_LAST_HIT.getOrDefault(
                playerId,
                -80L
        );

        int stack;

        if (!targetId.equals(previousTarget) || now - lastHit > 80) {
            stack = 1;
        } else {
            stack = Math.min(
                    BLOOD_OATH_STACK.getOrDefault(playerId, 0) + 1,
                    6
            );
        }

        BLOOD_OATH_TARGET.put(playerId, targetId);
        BLOOD_OATH_STACK.put(playerId, stack);
        BLOOD_OATH_LAST_HIT.put(playerId, now);

        int bonusDamage = Math.min(stack - 1, 5);

        if (bonusDamage > 0) {
            event.setAmount(
                    event.getAmount() + bonusDamage
            );
        }
    }

    private static void applyEarthSmash(
            Player player,
            LivingEntity target,
            long now
    ) {
        if (!player.isCrouching()) {
            return;
        }

        long lastUse = EARTH_SMASH_COOLDOWN.getOrDefault(
                player.getUUID(),
                -200L
        );

        if (now - lastUse < 200) {
            return;
        }

        EARTH_SMASH_COOLDOWN.put(player.getUUID(), now);

        List<LivingEntity> nearbyEntities =
                target.level().getEntitiesOfClass(
                        LivingEntity.class,
                        target.getBoundingBox().inflate(3.0D),
                        entity -> entity != target
                                && entity != player
                                && CombatRules.canHarm(player, entity)
                );

        for (LivingEntity nearby : nearbyEntities) {
            CombatRules.runeDamage(player, nearby, 4.0F);

            nearby.addEffect(
                    new MobEffectInstance(
                            MobEffects.MOVEMENT_SLOWDOWN,
                            40,
                            0,
                            false,
                            true,
                            true
                    )
            );
        }

        player.sendSystemMessage(
                Component.literal("대지 강타가 발동됨")
        );
    }

    private static void applyDeathMark(
            Player player,
            LivingEntity target,
            LivingIncomingDamageEvent event,
            long now
    ) {
        TargetKey key = new TargetKey(
                player.getUUID(),
                target.getUUID()
        );

        long lastHit = DEATH_MARK_LAST_HIT.getOrDefault(
                key,
                -120L
        );

        int hitCount;

        if (now - lastHit > 120) {
            hitCount = 1;
        } else {
            hitCount = DEATH_MARK_COUNT.getOrDefault(key, 0) + 1;
        }

        DEATH_MARK_COUNT.put(key, hitCount);
        DEATH_MARK_LAST_HIT.put(key, now);

        if (hitCount < 5) {
            return;
        }

        DEATH_MARK_COUNT.put(key, 0);

        event.setAmount(event.getAmount() + 8.0F);

        player.sendSystemMessage(
                Component.literal("죽음의 낙인이 발동됨 추가 피해 +8")
        );
    }

    private static void applyBerserkerRage(
            Player player,
            LivingIncomingDamageEvent event
    ) {
        if (player.getHealth() > player.getMaxHealth() * 0.35F) {
            return;
        }

        event.setAmount(
                event.getAmount() * 1.30F
        );
    }
    private static void applyDoomMark(
            Player player,
            LivingEntity target,
            LivingIncomingDamageEvent event,
            long now
    ) {
        TargetKey key = new TargetKey(
                player.getUUID(),
                target.getUUID()
        );

        long lastHit = DOOM_MARK_LAST_HIT.getOrDefault(
                key,
                -160L
        );

        int stack;

        // 8초 동안 공격하지 않으면 중첩 초기화
        if (now - lastHit > 160) {
            stack = 1;
        } else {
            stack = DOOM_MARK_STACK.getOrDefault(key, 0) + 1;
        }

        DOOM_MARK_LAST_HIT.put(key, now);
        DOOM_MARK_STACK.put(key, stack);

        // 6중첩 시 추가 피해 12
        if (stack >= 6) {
            event.setAmount(event.getAmount() + 12.0F);

            DOOM_MARK_STACK.put(key, 0);

            player.sendSystemMessage(
                    Component.literal("멸망의 표식 발동! 추가 피해 +12")
            );
        }
    }

    private static void applyFinalBlow(
            Player player,
            LivingEntity target,
            long now
    ) {
        long lastUse = FINAL_BLOW_COOLDOWN.getOrDefault(
                player.getUUID(),
                -400L
        );

        // 20초마다 다음 공격 강화
        if (now - lastUse < 400) {
            return;
        }

        FINAL_BLOW_COOLDOWN.put(player.getUUID(), now);

        List<LivingEntity> nearbyEntities =
                target.level().getEntitiesOfClass(
                        LivingEntity.class,
                        target.getBoundingBox().inflate(4.0D),
                        entity -> entity != target
                                && entity != player
                                && CombatRules.canHarm(player, entity)
                );

        for (LivingEntity nearby : nearbyEntities) {
            CombatRules.runeDamage(player, nearby, 8.0F);
        }

        player.sendSystemMessage(
                Component.literal("종말의 강타 발동!")
        );
    }

    private static void applyBloodStorm(
            Player player,
            LivingEntity deadTarget,
            long now
    ) {
        long lastUse = BLOOD_STORM_COOLDOWN.getOrDefault(
                player.getUUID(),
                -240L
        );

        // 12초 쿨타임
        if (now - lastUse < 240) {
            return;
        }

        BLOOD_STORM_COOLDOWN.put(player.getUUID(), now);

        List<LivingEntity> nearbyEntities =
                deadTarget.level().getEntitiesOfClass(
                        LivingEntity.class,
                        deadTarget.getBoundingBox().inflate(4.0D),
                        entity -> entity != player
                                && CombatRules.canHarm(player, entity)
                );

        for (LivingEntity nearby : nearbyEntities) {
            EnhancementEffects.applyRuneBleed(nearby, player, 80, 1.0F);
        }

        player.sendSystemMessage(
                Component.literal("피의 폭풍 발동!")
        );
    }

    private static void applyGiantStrength(
            Player player,
            long now
    ) {
        long lastUse = GIANT_STRENGTH_COOLDOWN.getOrDefault(
                player.getUUID(),
                -300L
        );

        // 15초 쿨타임
        if (now - lastUse < 300) {
            return;
        }

        GIANT_STRENGTH_COOLDOWN.put(player.getUUID(), now);

        player.addEffect(
                new MobEffectInstance(
                        MobEffects.DAMAGE_BOOST,
                        80,
                        1,
                        false,
                        true,
                        true
                )
        );

        player.addEffect(
                new MobEffectInstance(
                        MobEffects.DAMAGE_RESISTANCE,
                        80,
                        0,
                        false,
                        true,
                        true
                )
        );

        player.sendSystemMessage(
                Component.literal("거인의 힘 발동!")
        );
    }

    public static void pruneState(long now) {
        WEIGHT_COOLDOWN.entrySet().removeIf(e -> {
            if (now - e.getValue() < 1200) return false;
            return true;
        });
        SMASH_COOLDOWN.entrySet().removeIf(e -> {
            if (now - e.getValue() < 1200) return false;
            return true;
        });
        BATTLE_INSTINCT_COOLDOWN.entrySet().removeIf(e -> {
            if (now - e.getValue() < 1200) return false;
            return true;
        });
        EXPLOSION_LAST_HIT.entrySet().removeIf(e -> {
            if (now - e.getValue() < 1200) return false;
            EXPLOSION_COUNT.remove(e.getKey());
            return true;
        });
        BLOOD_OATH_LAST_HIT.entrySet().removeIf(e -> {
            if (now - e.getValue() < 1200) return false;
            BLOOD_OATH_TARGET.remove(e.getKey());
            BLOOD_OATH_STACK.remove(e.getKey());
            return true;
        });
        EARTH_SMASH_COOLDOWN.entrySet().removeIf(e -> {
            if (now - e.getValue() < 1200) return false;
            return true;
        });
        DEATH_MARK_LAST_HIT.entrySet().removeIf(e -> {
            if (now - e.getValue() < 1200) return false;
            DEATH_MARK_COUNT.remove(e.getKey());
            return true;
        });
        DOOM_MARK_LAST_HIT.entrySet().removeIf(e -> {
            if (now - e.getValue() < 1200) return false;
            DOOM_MARK_STACK.remove(e.getKey());
            return true;
        });
        FINAL_BLOW_COOLDOWN.entrySet().removeIf(e -> {
            if (now - e.getValue() < 1200) return false;
            return true;
        });
        BLOOD_STORM_COOLDOWN.entrySet().removeIf(e -> {
            if (now - e.getValue() < 1200) return false;
            return true;
        });
        GIANT_STRENGTH_COOLDOWN.entrySet().removeIf(e -> {
            if (now - e.getValue() < 1200) return false;
            return true;
        });
        DAMAGE_MARKS.entrySet().removeIf(e -> e.getValue().endTime() <= now);
    }
    public static void clearState() {
        DAMAGE_MARKS.clear();
        WEIGHT_COOLDOWN.clear();
        SMASH_COOLDOWN.clear();
        BATTLE_INSTINCT_COOLDOWN.clear();
        EXPLOSION_COUNT.clear();
        EXPLOSION_LAST_HIT.clear();
        BLOOD_OATH_TARGET.clear();
        BLOOD_OATH_STACK.clear();
        BLOOD_OATH_LAST_HIT.clear();
        EARTH_SMASH_COOLDOWN.clear();
        DEATH_MARK_COUNT.clear();
        DEATH_MARK_LAST_HIT.clear();
        DOOM_MARK_STACK.clear();
        DOOM_MARK_LAST_HIT.clear();
        FINAL_BLOW_COOLDOWN.clear();
        BLOOD_STORM_COOLDOWN.clear();
        GIANT_STRENGTH_COOLDOWN.clear();
    }
}
