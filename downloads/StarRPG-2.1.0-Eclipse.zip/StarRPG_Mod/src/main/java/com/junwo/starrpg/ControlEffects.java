package com.junwo.starrpg;

import net.minecraft.world.entity.*;
import net.neoforged.bus.api.*;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.*;
import net.neoforged.neoforge.event.entity.player.*;
import net.neoforged.neoforge.event.tick.EntityTickEvent;

@EventBusSubscriber(modid=StarRPG.MODID)
public final class ControlEffects {
    public static final net.minecraft.resources.ResourceLocation BOSS_SLOW=net.minecraft.resources.ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,"boss_control_slow");
    public static boolean stunned(LivingEntity e){return e.hasEffect(ModEffects.STUN);}
    public static boolean rooted(LivingEntity e){return e.hasEffect(ModEffects.ROOT)||stunned(e)||e.hasEffect(ModEffects.BRACED);}
    @SubscribeEvent(priority=EventPriority.HIGHEST) public static void attack(AttackEntityEvent e){if(stunned(e.getEntity())||e.getEntity().hasEffect(ModEffects.BRACED)||e.getEntity().hasEffect(ModEffects.COMBO))e.setCanceled(true);}
    @SubscribeEvent(priority=EventPriority.HIGHEST) public static void use(LivingEntityUseItemEvent.Start e){if(stunned(e.getEntity()))e.setCanceled(true);}
    @SubscribeEvent(priority=EventPriority.HIGHEST) public static void interact(PlayerInteractEvent.RightClickItem e){if(stunned(e.getEntity())||e.getEntity().hasEffect(ModEffects.BRACED))e.setCanceled(true);}
    @SubscribeEvent(priority=EventPriority.HIGHEST) public static void interactBlock(PlayerInteractEvent.RightClickBlock e){if(stunned(e.getEntity()))e.setCanceled(true);}
    @SubscribeEvent(priority=EventPriority.HIGHEST) public static void interactEntity(PlayerInteractEvent.EntityInteract e){if(stunned(e.getEntity()))e.setCanceled(true);}
    @SubscribeEvent(priority=EventPriority.HIGHEST) public static void block(PlayerInteractEvent.LeftClickBlock e){if(stunned(e.getEntity()))e.setCanceled(true);}
    @SubscribeEvent public static void jump(LivingEvent.LivingJumpEvent e){if(rooted(e.getEntity())){var v=e.getEntity().getDeltaMovement();e.getEntity().setDeltaMovement(v.x,Math.min(0,v.y),v.z);e.getEntity().hurtMarked=true;}}
    @SubscribeEvent(priority=EventPriority.HIGHEST) public static void damage(LivingIncomingDamageEvent e){if(e.getSource().getEntity() instanceof LivingEntity l && stunned(l) && e.getSource().getDirectEntity()==l)e.setCanceled(true);}
    @SubscribeEvent public static void weakened(LivingIncomingDamageEvent e){
        if(e.getSource().getEntity() instanceof LivingEntity l&&l.getPersistentData().getLong("starrpg_boss_weaken_until")>l.level().getGameTime())e.setAmount(e.getAmount()*0.85F);
    }
    @SubscribeEvent public static void tick(EntityTickEvent.Post e){
        if(!(e.getEntity() instanceof LivingEntity l) || l.level().isClientSide())return;
        if(l.getPersistentData().contains("starrpg_boss_slow_until")&&l.level().getGameTime()>=l.getPersistentData().getLong("starrpg_boss_slow_until")){
            var speed=l.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED);if(speed!=null)speed.removeModifier(BOSS_SLOW);l.getPersistentData().remove("starrpg_boss_slow_until");
        }
        if(stunned(l))l.stopUsingItem();
        if(l instanceof Mob mob){
            if(rooted(l)||l.hasEffect(ModEffects.REVERSE_LOOK)){mob.getNavigation().stop();mob.getMoveControl().strafe(0,0);}
            else if(l.hasEffect(ModEffects.REVERSE_MOVE)){
                mob.getNavigation().stop();var target=mob.getTarget();if(target!=null){var away=mob.position().subtract(target.position()).multiply(1,0,1).normalize().scale(0.08);mob.setDeltaMovement(away.x,mob.getDeltaMovement().y,away.z);}
            }
        }
    }
}
