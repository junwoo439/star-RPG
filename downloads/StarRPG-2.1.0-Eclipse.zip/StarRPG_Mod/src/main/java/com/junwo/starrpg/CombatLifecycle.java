package com.junwo.starrpg;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
@EventBusSubscriber(modid = StarRPG.MODID)
public final class CombatLifecycle {
    @SubscribeEvent public static void tick(ServerTickEvent.Post event) {
        long now = event.getServer().overworld().getGameTime();
        if (now % 100 != 0) return;
        CombatRules.pruneState(now);
        SwordRuneEffects.pruneState(now);
        AxeRuneEffects.pruneState(now);
        EnhancementEffects.pruneState(now);
        ChestAbilityManager.pruneState(now);
    }
    @SubscribeEvent public static void logout(PlayerEvent.PlayerLoggedOutEvent event) {
        SwordRuneEffects.forgetPlayer(event.getEntity().getUUID());
    }
    @SubscribeEvent public static void stop(ServerStoppedEvent event) {
        CombatRules.clearState();
        SwordRuneEffects.clearState(); AxeRuneEffects.clearState();
        EnhancementEffects.clearState(); ChestAbilityManager.clearState();
    }
}
