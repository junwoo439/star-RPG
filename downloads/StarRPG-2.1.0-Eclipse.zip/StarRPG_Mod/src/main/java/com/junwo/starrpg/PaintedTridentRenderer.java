package com.junwo.starrpg;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.projectile.ThrownTrident;
import net.minecraft.world.item.*;

public final class PaintedTridentRenderer extends EntityRenderer<ThrownTrident>{
    private final ItemRenderer items;
    public PaintedTridentRenderer(EntityRendererProvider.Context c){super(c);items=c.getItemRenderer();}
    @Override public ResourceLocation getTextureLocation(ThrownTrident e){return ArtisanItemRenderer.ATLAS;}
    @Override public void render(ThrownTrident e,float yaw,float partial,PoseStack pose,MultiBufferSource buffers,int light){
        pose.pushPose();pose.mulPose(Axis.YP.rotationDegrees(e.getYRot()));pose.mulPose(Axis.XP.rotationDegrees(e.getXRot()+90));pose.scale(1.5F,1.5F,1.5F);
        var stack=e.getWeaponItem();items.renderStatic(stack==null?new ItemStack(Items.TRIDENT):stack,ItemDisplayContext.FIXED,light,OverlayTexture.NO_OVERLAY,pose,buffers,e.level(),e.getId());pose.popPose();
    }
}
