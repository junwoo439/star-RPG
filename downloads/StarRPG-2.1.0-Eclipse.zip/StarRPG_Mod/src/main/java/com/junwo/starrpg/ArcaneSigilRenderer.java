package com.junwo.starrpg;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.resources.ResourceLocation;

public final class ArcaneSigilRenderer extends EntityRenderer<ArcaneSigil> {
    public ArcaneSigilRenderer(EntityRendererProvider.Context c){super(c);}
    @Override public boolean shouldRender(ArcaneSigil e,net.minecraft.client.renderer.culling.Frustum frustum,double x,double y,double z){return e.shouldRenderAtSqrDistance(x*x+y*y+z*z)&&frustum.isVisible(e.getBoundingBox().inflate(e.radius()*3));}
    @Override public ResourceLocation getTextureLocation(ArcaneSigil e){return ArtisanItemRenderer.ATLAS;}
    @Override public void render(ArcaneSigil e,float yaw,float partial,PoseStack p,MultiBufferSource b,int light){
        float age=e.tickCount+partial;draw(p,b,e.style(),e.color(),e.radius(),age,e.life(),e.getYRot(),e.getXRot());
    }
    /** Shared by the real world renderer and the opt-in visual verification screen. */
    public static void draw(PoseStack p,MultiBufferSource b,int style,int color,float radius,float age,int life,float yaw,float pitch){
        p.pushPose();if(style==0)p.mulPose(Axis.XP.rotationDegrees(90));else {p.mulPose(Axis.YP.rotationDegrees(-yaw));p.mulPose(Axis.XP.rotationDegrees(pitch));}
        float alpha=Math.min(1,age/4)*Math.min(1,Math.max(0,(life-age)/10));
        var out=b.getBuffer(RenderType.entityTranslucent(ArtisanItemRenderer.ATLAS));int layers=style==1?3:style==2?2:2;
        for(int i=0;i<layers;i++){p.pushPose();p.translate(0,0,style==1?i*1.8:i*0.035);
            p.mulPose(Axis.ZP.rotationDegrees((i%2==0?1:-1)*age*(style==2?5:1.5F)+i*55));
            float r=radius*(0.85F+Math.min(age/12,1)*0.15F)*(style==1?1-i*0.12F:i==0?1:0.65F);
            ArtisanItemRenderer.quad(p,out,style==2?15:14,r,color,alpha*(i==0?0.8F:0.55F),15728880,0,false);
            ArtisanItemRenderer.quad(p,out,style==2?15:14,r,color,alpha*(i==0?0.8F:0.55F),15728880,0,true);p.popPose();
        }p.popPose();
    }
}
