package com.junwo.starrpg;

import java.util.List;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.*;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.*;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

@EventBusSubscriber(modid=StarRPG.MODID)
public final class ExtendedRuneEffects {
    public static RuneEffect rune(ItemStack item){var r=RuneDataHelper.getRuneEffect(item);return r!=null&&r.getWeaponType()==RuneWeaponType.forItem(item)?r:null;}
    public static int staff(ItemStack item,int variant){var r=rune(item);return r!=null&&r.getWeaponType()==RuneWeaponType.STAFF&&r.getVariant()==variant?r.getRarity().ordinal()+1:0;}
    private record Hit(Player player,RuneEffect rune,boolean charged){}
    private static Hit hit(DamageSource source){
        if(!(source.getEntity() instanceof Player p))return null;
        ItemStack w;boolean charged=true;
        if(source.is(MagicSystem.MAGIC_DAMAGE))w=source.getDirectEntity() instanceof MagicBolt bolt?bolt.staff():p.getMainHandItem();
        else if(source.getDirectEntity() instanceof AbstractArrow arrow){w=arrow.getWeaponItem();charged=arrow.getPersistentData().getFloat("starrpg_shot_power")>=0.9;}
        else if(CombatRules.primary(source)){w=p.getMainHandItem();charged=CombatRules.charged(source);}else return null;
        if(w==null)return null;var r=rune(w);if(r==null||r.getWeaponType().isArmor()||r.getWeaponType()==RuneWeaponType.BOW)return null;
        if(r.getWeaponType()!=RuneWeaponType.STAFF&&r.getVariant()<4)return null;
        return new Hit(p,r,charged);
    }
    private static boolean ready(Player p,String key,int ticks){
        long now=p.level().getGameTime();key="starrpg_extra_"+key;
        if(p.getPersistentData().getLong(key)>now)return false;p.getPersistentData().putLong(key,now+ticks);return true;
    }
    @SubscribeEvent public static void incoming(LivingIncomingDamageEvent e){
        var h=hit(e.getSource());if(h!=null&&h.charged&&CombatRules.canHarm(h.player,e.getEntity())){
            int g=h.rune.getRarity().ordinal()+1,v=h.rune.getVariant();var target=e.getEntity();float extra=0;
            switch(h.rune.getWeaponType()){
                case SWORD->{if(v==4&&h.player.level().getGameTime()-h.player.getPersistentData().getLong("starrpg_armor_last_damage")<60)extra=g*0.4F;if(v==5&&target.getHealth()<=target.getMaxHealth()*0.35F)extra=g*0.5F;}
                case AXE,TRIDENT->{if(v==5&&h.rune.getWeaponType()==RuneWeaponType.TRIDENT||v==4&&h.rune.getWeaponType()==RuneWeaponType.AXE)extra=target.getArmorValue()>0?g*0.4F:0;if(h.rune.getWeaponType()==RuneWeaponType.TRIDENT&&v==7&&target.getHealth()>=target.getMaxHealth()*0.9F)extra=g*0.6F;}
                case CROSSBOW->{if(v==4&&h.player.distanceToSqr(target)>=64)extra=g*0.4F;}
                case STAFF->{if(v==0)extra=g*0.5F;if(v==7&&target.getHealth()<=target.getMaxHealth()*0.3F)extra=g*0.6F;}
                default->{}
            }e.setAmount(e.getAmount()+extra);
        }
        if(!(e.getEntity() instanceof Player p)||e.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY))return;
        float reduction=0;
        if(e.getSource().is(DamageTypeTags.IS_EXPLOSION))reduction+=ArmorRuneEffects.grade(p,EquipmentSlot.CHEST,4)*0.04F;
        if(e.getSource().is(MagicSystem.MAGIC_DAMAGE)||e.getSource().is(CombatRules.RUNE))reduction+=ArmorRuneEffects.grade(p,EquipmentSlot.CHEST,5)*0.04F;
        if(e.getSource().is(DamageTypeTags.IS_FALL))reduction+=ArmorRuneEffects.grade(p,EquipmentSlot.LEGS,5)*0.04F+ArmorRuneEffects.grade(p,EquipmentSlot.FEET,4)*0.08F;
        if(e.getSource().is(DamageTypeTags.IS_PROJECTILE))reduction+=ArmorRuneEffects.grade(p,EquipmentSlot.LEGS,7)*0.025F;
        if(e.getSource().is(DamageTypeTags.IS_FIRE))reduction+=ArmorRuneEffects.grade(p,EquipmentSlot.FEET,6)*0.04F;
        e.setAmount(e.getAmount()*(1-Math.min(0.65F,reduction)));
    }
    @SubscribeEvent public static void before(LivingDamageEvent.Pre e){if(hit(e.getSource())!=null)e.getEntity().getPersistentData().putFloat("starrpg_extra_before",e.getEntity().getHealth());}
    @SubscribeEvent public static void after(LivingDamageEvent.Post e){
        var h=hit(e.getSource());var target=e.getEntity();
        if(h!=null){
            float actual=Math.max(0,Math.min(e.getNewDamage(),target.getPersistentData().getFloat("starrpg_extra_before")-target.getHealth()));target.getPersistentData().remove("starrpg_extra_before");
            if(h.charged&&actual>0&&CombatRules.canHarmDead(h.player,target)){
                var p=h.player;int g=h.rune.getRarity().ordinal()+1,v=h.rune.getVariant();var type=h.rune.getWeaponType();String key=type.name()+v;
                if((type==RuneWeaponType.SWORD&&v==6||type==RuneWeaponType.AXE&&v==7||type==RuneWeaponType.TRIDENT&&v==4)&&ready(p,key,160))p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED,20+g*10,0));
                if((type==RuneWeaponType.SWORD&&v==7||type==RuneWeaponType.CROSSBOW&&v==5||type==RuneWeaponType.STAFF&&v==5)&&ready(p,key,100))p.heal(Math.min(g*0.3F,actual*g*0.03F));
                if(type==RuneWeaponType.AXE&&v==5&&target.isAlive()&&ready(p,key,120))target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS,20+g*8,0));
                if(type==RuneWeaponType.AXE&&v==6&&ready(p,key,120))p.level().getEntitiesOfClass(LivingEntity.class,target.getBoundingBox().inflate(2),a->a!=target&&CombatRules.canHarm(p,a)&&p.hasLineOfSight(a)).stream().limit(4).forEach(a->CombatRules.runeDamage(p,a,g*0.35F));
                if(type==RuneWeaponType.CROSSBOW&&v==6&&target.isAlive()&&ready(p,key,80))target.addEffect(new MobEffectInstance(MobEffects.GLOWING,(2+g)*20,0));
                if((type==RuneWeaponType.CROSSBOW&&v==7||type==RuneWeaponType.TRIDENT&&v==6)&&ready(p,key,400))shield(p,(2+g)*20);
            }
        }
        if(!(target instanceof Player p)||e.getNewDamage()<=0||!p.isAlive())return;
        int thorns=ArmorRuneEffects.grade(p,EquipmentSlot.CHEST,6),wind=ArmorRuneEffects.grade(p,EquipmentSlot.CHEST,7),dodge=ArmorRuneEffects.grade(p,EquipmentSlot.FEET,7);
        if(thorns>0&&!e.getSource().is(CombatRules.RUNE)&&e.getSource().getEntity() instanceof LivingEntity attacker&&CombatRules.canHarm(p,attacker)&&p.distanceToSqr(attacker)<=64&&p.hasLineOfSight(attacker)&&ready(p,"thorns",60))CombatRules.runeDamage(p,attacker,Math.min(thorns*0.5F,e.getNewDamage()*0.1F*thorns));
        if(wind>0&&p.getHealth()<=p.getMaxHealth()*0.35F&&ready(p,"second_wind",600))p.heal(1+wind*0.4F);
        if(dodge>0&&e.getSource().is(DamageTypeTags.IS_PROJECTILE)&&ready(p,"dodge",240))p.getPersistentData().putLong("starrpg_extra_dodge_until",p.level().getGameTime()+40+gTicks(dodge));
    }
    private static int gTicks(int grade){return grade*4;}
    private static void shield(Player p,int ticks){if(!p.hasEffect(MobEffects.ABSORPTION))p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,ticks,0));}
    public static void cast(Player p,ItemStack staff){int g=staff(staff,6);if(g>0&&ready(p,"staff_aegis",400))shield(p,(2+g)*20);}
    private static void attribute(Player p,Holder<Attribute> attribute,String key,double amount,AttributeModifier.Operation op){
        var a=p.getAttribute(attribute);if(a==null)return;var id=ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,"extra_"+key);
        if(amount==0){a.removeModifier(id);return;}var old=a.getModifier(id);if(old==null||old.amount()!=amount)a.addOrUpdateTransientModifier(new AttributeModifier(id,amount,op));
    }
    @SubscribeEvent public static void tick(PlayerTickEvent.Post e){
        Player p=e.getEntity();if(p.level().isClientSide())return;
        attribute(p,Attributes.LUCK,"luck",ArmorRuneEffects.grade(p,EquipmentSlot.HEAD,6)*0.2,AttributeModifier.Operation.ADD_VALUE);
        attribute(p,Attributes.BLOCK_BREAK_SPEED,"mining",ArmorRuneEffects.grade(p,EquipmentSlot.HEAD,7)*0.04,AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
        attribute(p,Attributes.ARMOR_TOUGHNESS,"toughness",ArmorRuneEffects.grade(p,EquipmentSlot.LEGS,4)*0.5,AttributeModifier.Operation.ADD_VALUE);
        attribute(p,Attributes.SAFE_FALL_DISTANCE,"spring",ArmorRuneEffects.grade(p,EquipmentSlot.FEET,5)*0.6,AttributeModifier.Operation.ADD_VALUE);
        int dodge=ArmorRuneEffects.grade(p,EquipmentSlot.FEET,7);
        attribute(p,Attributes.MOVEMENT_SPEED,"dodge",dodge>0&&p.getPersistentData().getLong("starrpg_extra_dodge_until")>p.level().getGameTime()?0.08+dodge*0.02:0,AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
        if(p.isAlive()&&p.tickCount%20==0&&ArmorRuneEffects.grade(p,EquipmentSlot.HEAD,4)>0&&p.isUnderWater())p.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING,60,0,false,false,false));
    }
    public static List<String> description(RuneEffect e){
        int g=e.getRarity().ordinal()+1,v=e.getVariant();String text=switch(e.getWeaponType()){
            case BOW->new String[]{"충전 명중: 1초 속박","충전 명중: 0.5초 기절","충전 명중: 1초 이동 반전","충전 명중: 1초 시점 반전"}[v-4]+" / 재사용 "+(8-(g-1)*0.5F)+"초 · 대상 공통 면역 3초";
            case SWORD->switch(v){case 4->"피격 후 3초간 충전 공격 추가 피해 "+g*0.4F;case 5->"적 체력 35% 이하: 충전 공격 추가 피해 "+g*0.5F;case 6->"충전 명중: 신속 I "+(1+g*0.5F)+"초 / 재사용 8초";default->"충전 실제 피해 "+g*3+"% 회복, 최대 "+g*0.3F+" / 재사용 5초";};
            case AXE->switch(v){case 4->"방어력이 있는 적: 충전 추가 피해 "+g*0.4F;case 5->"충전 명중: 나약함 I "+(1+g*0.4F)+"초 / 재사용 6초";case 6->"충전 명중: 주변 최대 4명 피해 "+g*0.35F+" / 재사용 6초";default->"충전 명중: 신속 I "+(1+g*0.5F)+"초 / 재사용 8초";};
            case CROSSBOW->switch(v){case 4->"8칸 이상 거리: 화살 추가 피해 "+g*0.4F;case 5->"충전 실제 피해 "+g*3+"% 회복, 최대 "+g*0.3F+" / 재사용 5초";case 6->"충전 명중: 발광 "+(2+g)+"초 / 재사용 4초";default->"충전 명중: 흡수 I "+(2+g)+"초 / 재사용 20초";};
            case TRIDENT->switch(v){case 4->"충전 명중: 신속 I "+(1+g*0.5F)+"초 / 재사용 8초";case 5->"방어력이 있는 적: 충전 추가 피해 "+g*0.4F;case 6->"충전 명중: 흡수 I "+(2+g)+"초 / 재사용 20초";default->"체력 90% 이상인 적: 충전 추가 피해 "+g*0.6F;};
            case HELMET->switch(v){case 4->"착용 중 수중 호흡";case 5->"마법사 최대 마나 +"+g*8;case 6->"행운 +"+g*0.2F;default->"블록 채굴 속도 +"+g*4+"%";};
            case CHESTPLATE->switch(v){case 4->"폭발 피해 "+g*4+"% 감소";case 5->"StarRPG 마법·룬 피해 "+g*4+"% 감소";case 6->"8칸 내 공격자에게 받은 피해 "+g*10+"% 반사, 최대 "+g*0.5F+" / 3초";default->"피격 후 체력 35% 이하: 체력 "+(1+g*0.4F)+" 회복 / 30초";};
            case LEGGINGS->switch(v){case 4->"방어 강도 +"+g*0.5F;case 5->"낙하 피해 "+g*4+"% 감소";case 6->"마법사 마나 초당 회복 +"+g*0.3F;default->"투사체 피해 "+g*2.5F+"% 감소";};
            case BOOTS->switch(v){case 4->"낙하 피해 "+g*8+"% 감소";case 5->"안전한 낙하 높이 +"+g*0.6F+"칸";case 6->"화염 피해 "+g*4+"% 감소";default->"투사체 피격: 속도 +"+(8+g*2)+"%, "+(2+g*0.2F)+"초 / 재사용 12초";};
            case STAFF->switch(v){case 0->"마법 추가 피해 "+g*0.5F;case 1->"마나 비용 "+g*4+"% 감소 (올림)";case 2->"주문 재사용 시간 "+g*3+"% 감소";case 3->"지팡이 소지: 마나 초당 회복 +"+g*0.4F;case 4->"화염구·유성 반경 +"+g*0.1F+"칸";case 5->"실제 마법 피해 "+g*3+"% 회복, 최대 "+g*0.3F+" / 5초";case 6->"시전 시 흡수 I "+(2+g)+"초 / 20초";default->"체력 30% 이하 적에게 마법 추가 피해 "+g*0.6F;};
        };return List.of(text);
    }
}
