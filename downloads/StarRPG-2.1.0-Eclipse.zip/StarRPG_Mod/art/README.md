# StarRPG item art

The eight original transparent PNG illustrations in generated/ were created with the image generation tool for StarRPG 1.3.0–1.4.0: the engraving tool, five rune rarities, star dagger and war hammer. Originals are preserved unchanged. Runtime textures are exported at 64 × 64 using nearest-neighbor sampling and transparency for a small, mipmap-compatible Minecraft atlas. No external texture pack is required.
