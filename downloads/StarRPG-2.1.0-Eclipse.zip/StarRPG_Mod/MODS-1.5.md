# 외부 모드 적용 상태 — StarRPG 1.5.0

대상: Minecraft 1.21.1 / NeoForge 21.1.235 / Java 21. 확인일: 2026-10-28.
이 ZIP은 StarRPG 소스와 설치 도구를 포함한다. 외부 모드 JAR을 포함한 완성 모드팩은 아니다.

## Twilight Forest

공식 저장소의 `1.21.1` 브랜치에서 Minecraft 1.21.1 / NeoForge 21.1.209 기반 소스를 확인했다.
https://github.com/TeamTwilight/twilightforest/blob/1.21.1/gradle.properties
보스 ID는 같은 브랜치의 TFEntityNames.java에서 확인했다.

프로젝트의 `install-adventure-mods.bat`을 실행한다. Java 21과 인터넷 연결이 필요하며, Minecraft는 종료한 상태에서 실행한다.
또는 Eclipse의 Gradle Tasks → StarRPG → installAdventureMods, 또는 터미널에서:

```bat
gradlew.bat installAdventureMods
```

이 작업은 공식 Modrinth `twilightforest` 프로젝트에서 **1.21.1 + NeoForge 정식 릴리스**를 선택하고 필수 의존성도 같은 조건으로 해결한다. 파일 크기와 SHA-512를 검사한 뒤 `run-client/mods`에 설치한다. 같은 모드의 이전 JAR은 `run-client/starrpg-mod-backups/<시각>`으로 보관한다. 다른 모드와 월드는 지우지 않는다. 다운로드 실패 시 설치를 시작하지 않는다.
설치한 버전·출처·체크섬은 `adventure-mods-lock.json`에 기록하며 다음 실행은 기록된 Twilight Forest 버전을 사용한다. 명시적으로 갱신할 때만 `gradlew.bat installAdventureMods -PupdateAdventureMods`를 사용한다. 필수 의존성에 고정 버전이 없으면 해당 의존성은 다시 최신 호환 버전을 조회한다.

**현재 검증 제한:** 클라우드에서 Modrinth API 접속이 네트워크 정책으로 403 차단되었다. 따라서 실제 JAR 다운로드/통합 게임 실행은 완료하지 못했다. 공식 소스의 지원 정보, 설치 도구 구성, StarRPG의 선택적 보스 태그만 준비했다. 사용자 PC에서 설치 도구 실행이 성공해야 실제 모드가 추가된다. API에 조건에 맞는 정식 릴리스가 없으면 오류로 중단하며 다른 게임 버전이나 비공식 포트로 대체하지 않는다.

클라우드에서 계속 설치하려면 환경 설정에 저장된 `api.modrinth.com`, `cdn.modrinth.com` 허용 초안을 검토·저장 후 게시해야 한다. 이 초안은 아직 실행 환경에 적용된 것으로 확인되지 않았다.

## Mowzie's Mobs

이미 가지고 있는 아래 두 파일을 프로젝트의 `run-client/mods`에 넣는다. 기존 위치가 `D:\StarRPG_NeoForge\mods`라면 거기에서 복사할 수 있다.

- `mowziesmobs-1.21.1-1.8.2.jar`
- `geckolib-neoforge-1.21.1-4.9.2.jar`

설치 도구는 기존 Mowzie/GeckoLib JAR을 보존한다. 사용자 첨부 Mowzie JAR은 32 MiB 파일 전달 제한을 넘어 클라우드로 가져오지 못했으므로 이 ZIP에 들어 있지 않다. 기존 월드에서 이 모드를 사용했다면, 해당 월드를 열기 전에 반드시 두 파일을 유지한다. 두 모드의 실제 런타임 호환 테스트는 수행하지 못했다.

## Ice and Fire: Dragons

공식 배포 목록과 브랜치에서 현재 프로젝트에 맞는 **Minecraft 1.21.1 / NeoForge 빌드**를 확인하지 못했다. 확인된 공식 배포 목록에는 1.20.1 Forge 계열이 있다.
https://github.com/AlexModGuy/Ice_and_Fire/releases
https://github.com/AlexModGuy/Ice_and_Fire/branches/all

그래서 이번 패키지에는 설치하지 않는다. 1.20.1용 파일이나 Citadel을 현재 프로젝트에 억지로 넣지 않는다. 비공식 포트를 사용자 동의 없이 공식 모드 대신 설치하지 않는다. 향후 호환 정식 버전이 확인되거나 게임 전체 버전 이전을 결정하면 별도로 통합해야 한다.

게임 안에서 `/starrpg mods`를 입력하면 각 모드의 실제 로드 여부와 버전을 확인할 수 있다.

## StarRPG와 연결되는 부분

- Twilight Forest의 나가, 리치, 미노쉬룸, 히드라, 팬텀 나이트, 우르 가스트, 알파 예티, 눈의 여왕을 선택적 보스 태그에 추가했다.
- 태그의 모드가 설치되지 않아도 StarRPG는 정상 실행된다. 보스 태그만 추가하는 것은 외부 모드 설치가 아니다.
- 해당 보스는 설치 시 보스용 완화된 능력치 보정과 골드/기존 보상 경로의 대상이 된다. 특수 AI, 다중 부위, 분신, 보스 무리별 보상은 실제 모드팩에서 추가 검증이 필요하다. 팬텀 나이트는 현재 개체별 보스 보상이다.
- Mowzie의 기존 보스 태그는 유지한다. Ice and Fire의 기존 선택적 태그가 남아 있어도 호환 JAR 없이는 몬스터가 생기지 않는다.
- 새 차원/구조물을 확인할 때는 새 테스트 월드를 권장한다. 기존 월드의 미생성 청크와 차원 생성 여부를 구분한다.
- Eclipse에서는 별도 StarRPG JAR을 `run-client/mods`에 넣지 않는다. 프로젝트 소스에서 자동으로 로드된다.
