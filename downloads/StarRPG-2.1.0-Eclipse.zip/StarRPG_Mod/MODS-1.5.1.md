# 외부 모드 설치 — StarRPG 1.5.1

확인일: 2026-10-28. Minecraft 1.21.1 / NeoForge 21.1.235 / Java 21.

## 이번에는 실제 설치·로드 검증까지 완료

| 모드 | 고정 버전 | 배포처 |
|---|---|---|
| The Twilight Forest | 4.8.3802 (공식 Maven 빌드) | https://maven.tamaized.com/releases/team-twilight/twilightforest/4.8.3802/ |
| Mowzie's Mobs | 1.8.2 | https://modrinth.com/mod/mowzies-mobs/version/xgAXTl17 |
| GeckoLib | 4.9.2 (NeoForge 1.21.1) | https://modrinth.com/mod/geckolib |

기존 1.5.0 설치 도구가 가리켰던 Modrinth `twilightforest` 주소는 존재하지 않았다. 네트워크가 열린 후 이를 확인하고 수정했다. 공식 저장소 README에 명시된 Twilight Forest Maven 배포처를 사용한다.
https://github.com/TeamTwilight/twilightforest/tree/1.21.1#readme

각 JAR의 NeoForge 메타데이터를 확인했다. Twilight Forest는 NeoForge 21.1.209 이상, GeckoLib은 21.1.150 이상, Mowzie는 [21.1.1,21.2)를 요구하므로 현재 21.1.235가 범위에 들어간다. Twilight Forest의 tf-asm은 JAR 안에 포함되며 별도 설치하지 않는다. Mowzie의 GeckoLib 최소 요구 버전은 4.8.3이며 고정한 4.9.2가 충족한다.

## 사용자 PC에서 한 번 실행

1. 기존 프로젝트와 `run-client/saves`를 백업한다. Minecraft를 종료한다.
2. ZIP을 풀고 `build.gradle`이 있는 **안쪽 StarRPG_Mod 폴더**로 들어간다.
3. **setup-adventure-eclipse.bat**을 실행한다. Java 21이 JAVA_HOME 또는 PATH에 등록되어 있어야 한다.
4. 성공 후 Eclipse에서 해당 폴더를 `File > Import > Gradle > Existing Gradle Project`로 가져온다. 기존 프로젝트 갱신이면 `Gradle > Refresh Gradle Project`, F5를 실행한다.
5. `Run Configurations > Java Application > StarRPG Client`를 실행한다.
6. 게임 안에서 `/starrpg mods`를 입력한다. starrpg / twilightforest / mowziesmobs / geckolib이 로드된 것으로 표시되면 된다.

이 파일은 세 모드를 다운로드하고 Eclipse 실행 구성을 준비한다. 별도 게임 서버를 실행하지 않는다. 외부 JAR은 ZIP에 재배포하지 않으며 검증된 공식 URL에서 약 64 MB를 다운로드한다. Minecraft 개발 라이브러리·리소스가 없는 첫 설치는 추가 다운로드가 필요하다.

Eclipse 설정이 이미 되어 있고 모드만 설치하려면 `install-adventure-mods.bat` 또는 `gradlew.bat installAdventureMods`를 사용한다.

## 설치 도구의 동작

- `adventure-mods-lock.json`에 세 파일의 버전, URL, 크기, SHA-512, 모드 ID를 고정했다. 실행할 때 임의의 최신 버전으로 바꾸지 않는다.
- 파일을 모두 내려받고 체크섬·모드 선언을 검증한 뒤 `run-client/mods`에 설치한다. 이미 검증된 다운로드 캐시는 재사용한다.
- 같은 모드 ID의 기존 JAR은 `run-client/starrpg-mod-backups/<시각>`으로 옮긴다. 다른 모드·월드·설정은 보존한다. 기존 다른 버전의 Mowzie/GeckoLib도 검증한 버전으로 교체되며 이전 JAR은 백업된다.
- 다운로드/검증 실패 시 기존 활성 모드를 바꾸지 않는다. 파일 설치 도중 실패하면 이미 이동한 이전 파일을 되돌린다.
- StarRPG 자체는 Eclipse 프로젝트 소스에서 로드된다. 별도 StarRPG JAR을 `run-client/mods`에 넣지 않는다.
- 기존 월드에서 다른 모드도 사용했다면 해당 모드들을 유지한다. 세 모드 설치 도구는 모든 외부 모드팩 조합의 호환성을 보장하지 않는다.

## Ice and Fire

공식 Modrinth 배포 API에서 게임 버전 목록을 확인했으며 1.21.1이 없다. 따라서 이번 설치에서 제외한다.
https://modrinth.com/mod/ice-and-fire-dragons
https://github.com/AlexModGuy/Ice_and_Fire/releases

1.20.1용 파일이나 비공식 포트를 대신 설치하지 않았다. 향후 공식 호환 버전을 확인하거나 별도 버전 이전을 결정할 때 통합해야 한다.

## 검증과 한계

- 공식 배포 파일 세 개 다운로드, 배포처 SHA-512 비교 및 모드 요구 버전 확인 완료.
- Gradle 설치 작업 성공. 실제 GeckoLib 재다운로드와 같은 모드 재설치/이전 파일 백업도 확인.
- 세 모드를 **동시에 로드한 격리 GameTest 환경에서 68개 테스트 통과**.
- Twilight Forest 보스 8종 등록/태그/능력치, Mowzie 보스 4종 등록/태그와 GeckoLib 로드, Twilight Forest 보스 골드·재료 보상을 확인.
- 기존 StarRPG의 단계 분포·좀비·골드·룬·강화 테스트도 함께 통과했다.
- Eclipse 실행 구성 생성 및 클라이언트 실행 준비 통과.
- 실제 Windows Eclipse GUI, 그래픽 렌더링, 보스 전투 AI 전체, Twilight Forest 구조물 생성·장시간 탐험은 직접 플레이 테스트가 필요하다. 테스트 통과가 모든 게임플레이 호환을 의미하지 않는다.
- 테스트는 별도 `run-gametest` 월드에서 했으며 사용자 원본 월드와 첨부 world.zip을 열거나 변경하지 않았다.
