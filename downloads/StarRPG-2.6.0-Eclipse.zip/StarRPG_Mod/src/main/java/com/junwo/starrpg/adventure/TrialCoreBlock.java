package com.junwo.starrpg.adventure;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.phys.BlockHitResult;
public final class TrialCoreBlock extends Block {
    public static final IntegerProperty VARIANT=IntegerProperty.create("variant",0,2);
    public TrialCoreBlock(){super(BlockBehaviour.Properties.of().strength(-1,3600000).lightLevel(s->10));registerDefaultState(stateDefinition.any().setValue(VARIANT,0));}
    @Override protected void createBlockStateDefinition(StateDefinition.Builder<Block,BlockState> b){b.add(VARIANT);}
    @Override protected InteractionResult useWithoutItem(BlockState state,Level l,BlockPos pos,Player p,BlockHitResult hit){if(!l.isClientSide())WorldTrials.startDungeon(p,pos,state.getValue(VARIANT));return InteractionResult.sidedSuccess(l.isClientSide());}
}
