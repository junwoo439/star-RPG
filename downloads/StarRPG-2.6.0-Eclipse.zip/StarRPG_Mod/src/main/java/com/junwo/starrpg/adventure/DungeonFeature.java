package com.junwo.starrpg.adventure;
import net.minecraft.world.level.levelgen.feature.*;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.core.*;
public final class DungeonFeature extends Feature<NoneFeatureConfiguration> {
    public DungeonFeature(){super(NoneFeatureConfiguration.CODEC);}
    @Override public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> c){var l=c.level();var origin=c.origin();int x=(origin.getX()&~15)+8,z=(origin.getZ()&~15)+8,top=l.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.WORLD_SURFACE_WG,x,z);if(top<l.getMinBuildHeight()+30||top>l.getMaxBuildHeight()-26||!l.getFluidState(new BlockPos(x,top-1,z)).isEmpty())return false;int variant=c.random().nextInt(3),base=variant==0?top-19:top-1;BlockState wall=(variant==2?Blocks.POLISHED_BLACKSTONE_BRICKS:variant==1?Blocks.STONE_BRICKS:Blocks.MOSSY_STONE_BRICKS).defaultBlockState();
        for(int dx=-6;dx<=6;dx++)for(int dz=-6;dz<=6;dz++)for(int y=0;y<=18;y++){boolean edge=Math.abs(dx)==6||Math.abs(dz)==6;var block=y%6==0||edge?wall:Blocks.AIR.defaultBlockState();if(edge&&y%6==3&&Math.abs(dx)+Math.abs(dz)==6)block=Blocks.IRON_BARS.defaultBlockState();l.setBlock(new BlockPos(x+dx,base+y,z+dz),block,2);}
        for(int y=1;y<=18;y++){l.setBlock(new BlockPos(x-5,base+y,z-4),Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING,Direction.EAST),2);}
        for(int y=0;y<3;y++)for(int s:new int[]{-1,1})l.setBlock(new BlockPos(x+s*4,base+y*6+4,z+4),Blocks.SEA_LANTERN.defaultBlockState(),2);
        int entrance=variant==0?18:0;for(int y=1;y<=3;y++)l.setBlock(new BlockPos(x,base+entrance+y,z-6),Blocks.AIR.defaultBlockState(),2);
        if(variant==0){l.setBlock(new BlockPos(x-5,top,z-4),Blocks.AIR.defaultBlockState(),2);l.setBlock(new BlockPos(x-4,top,z-4),Blocks.CHISELED_STONE_BRICKS.defaultBlockState(),2);l.setBlock(new BlockPos(x-4,top+1,z-4),Blocks.SOUL_LANTERN.defaultBlockState(),2);}
        l.setBlock(new BlockPos(x,base+1,z),AdventureWorldgen.CORE.get().defaultBlockState().setValue(TrialCoreBlock.VARIANT,variant),2);return true;
    }
}
