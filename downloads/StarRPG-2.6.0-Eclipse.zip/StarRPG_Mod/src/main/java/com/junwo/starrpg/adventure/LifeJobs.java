package com.junwo.starrpg.adventure;

import com.junwo.starrpg.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.*;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.CropBlock;
import net.neoforged.bus.api.*;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.level.BlockEvent;

@EventBusSubscriber(modid=StarRPG.MODID)
public final class LifeJobs {
    public static final String[] NAMES={"광부","생활 대장장이","농부","어부"};
    public static int active(Player p){var t=AdventureData.profile(p);return t.contains("life_active")?t.getInt("life_active"):-1;}
    public static int level(Player p,int job){return Math.min(20,1+AdventureData.value(p,"life_xp_"+job)/100);}
    public static boolean select(Player p,int job){if(p.level().isClientSide()||job<0||job>=4||active(p)==job)return false;AdventureData.set(p,"life_active",job);p.sendSystemMessage(net.minecraft.network.chat.Component.literal("생활 직업: "+NAMES[job]+" · 전투 직업은 별도로 유지됩니다."));return true;}
    private static boolean ore(net.minecraft.world.level.block.state.BlockState s){return s.is(BlockTags.COAL_ORES)||s.is(BlockTags.IRON_ORES)||s.is(BlockTags.COPPER_ORES)||s.is(BlockTags.GOLD_ORES)||s.is(BlockTags.REDSTONE_ORES)||s.is(BlockTags.LAPIS_ORES)||s.is(BlockTags.DIAMOND_ORES)||s.is(BlockTags.EMERALD_ORES);}
    @SubscribeEvent(priority=EventPriority.LOWEST) public static void place(BlockEvent.EntityPlaceEvent e){if(!e.isCanceled()&&e.getLevel() instanceof ServerLevel l&&ore(e.getPlacedBlock()))PlacedOreData.get(l).add(e.getPos());}
    @SubscribeEvent(priority=EventPriority.LOWEST) public static void mine(BlockEvent.BreakEvent e){
        if(e.isCanceled()||!(e.getLevel() instanceof ServerLevel l))return;var p=e.getPlayer();var pos=e.getPos().immutable();var state=e.getState();boolean natural=ore(state)&&!PlacedOreData.get(l).contains(pos);boolean crop=state.getBlock() instanceof CropBlock c&&c.isMaxAge(state);
        l.getServer().execute(()->{if(l.getBlockState(pos).is(state.getBlock()))return;PlacedOreData.get(l).remove(pos);if(p.isCreative()||p.isSpectator()||!p.isAlive())return;
            if(natural){AdventureData.add(p,"ores",1);if(active(p)==0){AdventureData.add(p,"life_xp_0",2);if(p.getRandom().nextInt(100)<5+level(p,0)/2)give(p,new ItemStack(AdventureItems.ORE.get()));}}
            if(crop){AdventureData.add(p,"crops",1);if(active(p)==2){AdventureData.add(p,"life_xp_2",1);if(p.getRandom().nextInt(100)<6+level(p,2)/2)give(p,new ItemStack(AdventureItems.HERB.get()));}}
        });
    }
    @SubscribeEvent(priority=EventPriority.LOWEST) public static void fish(net.neoforged.neoforge.event.entity.player.ItemFishedEvent e){var p=e.getEntity();if(e.isCanceled()||p.level().isClientSide()||p.isCreative()||e.getDrops().isEmpty())return;AdventureData.add(p,"fish",1);if(active(p)==3){AdventureData.add(p,"life_xp_3",4);if(p.getRandom().nextInt(100)<8+level(p,3)/2)e.getDrops().add(new ItemStack(AdventureItems.SCALE.get()));}}
    public static void give(Player p,ItemStack s){if(!p.getInventory().add(s))p.drop(s,false);}
    public static boolean forge(Player p){
        if(p.level().isClientSide()||active(p)!=1)return false;Item[] items={AdventureItems.ORE.get(),Items.IRON_INGOT,Items.COAL};int[] counts={3,2,2};var out=new ItemStack(AdventureItems.ALLOY.get(),p.getRandom().nextInt(100)<level(p,1)-1?2:1);if(!Economy.fits(p,out))return false;
        for(int i=0;i<items.length;i++)if(p.getInventory().countItem(items[i])<counts[i])return false;
        for(int i=0;i<items.length;i++)consume(p,items[i],counts[i]);give(p,out);AdventureData.add(p,"life_xp_1",12);AdventureData.add(p,"alloys",1);return true;
    }
    public static void consume(Player p,Item item,int count){for(var s:p.getInventory().items)if(s.is(item)){int n=Math.min(count,s.getCount());s.shrink(n);count-=n;if(count==0)break;}p.getInventory().setChanged();}
}
