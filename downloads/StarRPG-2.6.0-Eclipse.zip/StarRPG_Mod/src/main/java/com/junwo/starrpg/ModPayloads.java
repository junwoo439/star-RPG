package com.junwo.starrpg;

import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;

@EventBusSubscriber(
        modid = StarRPG.MODID,
        bus = EventBusSubscriber.Bus.MOD
)
public class ModPayloads {

    @SubscribeEvent
    public static void registerPayloads(
            RegisterPayloadHandlersEvent event
    ) {
        event.registrar("13").playToClient(PresentationCuePayload.TYPE,PresentationCuePayload.STREAM_CODEC,PresentationCuePayload::handle);
        event.registrar("13").playToClient(WeaponMotionPayload.TYPE,WeaponMotionPayload.STREAM_CODEC,WeaponMotionPayload::handle);
        event.registrar("13").playToServer(ActionPayload.TYPE,ActionPayload.STREAM_CODEC,ActionPayload::handle);
        event.registrar("13").playToServer(
                UseChestAbilityPayload.TYPE,
                UseChestAbilityPayload.STREAM_CODEC,
                UseChestAbilityPayload::handle
        );
    }
}
