package com.junwo.starrpg.bestiary;

import com.junwo.starrpg.*;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.phys.*;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.*;
import net.neoforged.fml.common.EventBusSubscriber;

/** Health thresholds are one-way. Healing and reloading cannot repeatedly trigger reinforcements. */
@EventBusSubscriber(modid=StarRPG.MODID)
public final class BossPhases {
    private static final ResourceLocation POWER=ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,"boss_phase_power");
    public static int stage(BestiaryMob m){return !m.kind.boss?0:Math.max(m.getPersistentData().getInt("starrpg_boss_phase"),m.getHealth()<=m.getMaxHealth()*.25F?2:m.getHealth()<=m.getMaxHealth()*.5F?1:0);}
    public static boolean flying(BestiaryMob m){return m.getPersistentData().getInt("starrpg_flight_age")>0;}
    public static void tick(BestiaryMob m){
        if(!(m.level() instanceof ServerLevel l)||!m.kind.boss||m.isNoAi())return;
        var tag=m.getPersistentData();int phase=Math.max(stage(m),tag.getInt("starrpg_boss_phase"));
        if(phase>0){var damage=m.getAttribute(Attributes.ATTACK_DAMAGE);var old=damage.getModifier(POWER);if(old==null||old.amount()!=phase*.15)damage.addOrUpdateTransientModifier(new AttributeModifier(POWER,phase*.15,AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));}
        if(phase>tag.getInt("starrpg_boss_phase")&&m.lifeTicks()>40&&BestiaryCombat.valid(m,m.getTarget())){
            tag.putInt("starrpg_boss_phase",phase);m.phase(BestiaryMob.RECOVERY,30);m.nextAttack=l.getGameTime()+35;
            ArcaneSigil.spawn(l,m.position().add(0,.1,0),new Vec3(0,0,1),38,0xFF4545,4,30);
            if((m.kind.body==BestiaryKind.Body.DRAGON||m.kind.body==BestiaryKind.Body.WYVERN)&&l.canSeeSky(m.blockPosition().above())){
                tag.putInt("starrpg_flight_age",1);tag.putDouble("starrpg_flight_ground",m.getY());m.setNoGravity(true);m.getNavigation().stop();
            }else reinforce(m,l,phase);
        }
        if(flying(m))air(m,l);
    }
    private static void reinforce(BestiaryMob m,ServerLevel l,int phase){
        BestiaryKind kind=switch(m.kind.family){case UNDEAD->BestiaryKind.GRAVE_SKELETON;case BEAST->BestiaryKind.DIRE_WOLF;case FIEND->BestiaryKind.INCUBUS;case CELESTIAL->BestiaryKind.AASIMAR;case CONSTRUCT->BestiaryKind.ANIMATED_ARMOR;case GIANT,ELEMENTAL->BestiaryKind.AIR_ELEMENTAL;case DRAGON->BestiaryKind.WYVERN;default->BestiaryKind.GOBLIN;};
        for(int i=0;i<2;i++){var n=BestiaryRegistry.TYPES.get(kind).get().create(l);var pos=m.position().add(i==0?-2:2,0,1);if(!l.getBlockState(net.minecraft.core.BlockPos.containing(pos)).isAir())continue;n.moveTo(pos.x,pos.y,pos.z,0,0);n.setTarget(m.getTarget());n.getPersistentData().putUUID("starrpg_summoner",m.getUUID());n.getPersistentData().putLong("starrpg_summon_expiry",l.getGameTime()+1200);l.addFreshEntity(n);}
    }
    private static void air(BestiaryMob m,ServerLevel l){
        var tag=m.getPersistentData();int age=tag.getInt("starrpg_flight_age");double ground=tag.getDouble("starrpg_flight_ground");
        if(!BestiaryCombat.valid(m,m.getTarget())||ControlEffects.stunned(m)){land(m);return;}
        m.getNavigation().stop();double height=age<40?ground+7:age>105?ground+.3:ground+7;
        var target=m.getTarget();Vec3 horizontal=age<105?target.position().subtract(m.position()).multiply(1,0,1).normalize().scale(.05):Vec3.ZERO;
        m.setDeltaMovement(horizontal.x,Math.clamp((height-m.getY())*.15,-.25,.25),horizontal.z);
        m.getLookControl().setLookAt(target,20,20);
        if(age==40){tag.putDouble("starrpg_bomb_x",target.getX());tag.putDouble("starrpg_bomb_y",target.getY());tag.putDouble("starrpg_bomb_z",target.getZ());ArcaneSigil.spawn(l,target.position().add(0,.08,0),new Vec3(0,0,1),38,0xFF3548,3.5F,36);}
        if(age==76){var at=new Vec3(tag.getDouble("starrpg_bomb_x"),tag.getDouble("starrpg_bomb_y"),tag.getDouble("starrpg_bomb_z"));ArcaneSigil.spawn(l,at,new Vec3(0,0,1),m.kind.move==BestiaryKind.Move.FROST?26:24,m.kind.color,3.5F,40);
            for(var victim:l.getEntitiesOfClass(LivingEntity.class,new AABB(at,at).inflate(3.5),t->(t==target||t instanceof net.minecraft.world.entity.player.Player)&&BestiaryCombat.valid(m,t)&&Math.abs(t.getY()-at.y)<2&&m.hasLineOfSight(t))){float hp=victim.getHealth();m.parryableImpact=false;boolean hit=victim.hurt(m.damageSources().mobAttack(m),(float)m.getAttributeValue(Attributes.ATTACK_DAMAGE)*2);if(hit&&victim.getHealth()<hp&&victim.getPersistentData().getLong("starrpg_heavy_stun_guard")<=l.getGameTime()){victim.addEffect(new MobEffectInstance(ModEffects.STUN,12));victim.getPersistentData().putLong("starrpg_heavy_stun_guard",l.getGameTime()+100);}}
        }
        if(age>=150||age>110&&m.getY()<=ground+.5){land(m);return;}tag.putInt("starrpg_flight_age",age+1);
    }
    public static void land(BestiaryMob m){m.getPersistentData().remove("starrpg_flight_age");m.setNoGravity(false);m.phase(BestiaryMob.RECOVERY,35);m.nextAttack=m.level().getGameTime()+40;}
    @SubscribeEvent(priority=EventPriority.HIGHEST) public static void summonDrops(net.neoforged.neoforge.event.entity.living.LivingDropsEvent e){if(e.getEntity().getPersistentData().hasUUID("starrpg_summoner"))e.setCanceled(true);}
    @SubscribeEvent public static void summonXp(net.neoforged.neoforge.event.entity.living.LivingExperienceDropEvent e){if(e.getEntity().getPersistentData().hasUUID("starrpg_summoner"))e.setDroppedExperience(0);}
    @SubscribeEvent public static void expire(net.neoforged.neoforge.event.tick.EntityTickEvent.Post e){var entity=e.getEntity();if(!(entity.level() instanceof ServerLevel l)||!entity.getPersistentData().hasUUID("starrpg_summoner"))return;var boss=l.getEntity(entity.getPersistentData().getUUID("starrpg_summoner"));if(entity.getPersistentData().getLong("starrpg_summon_expiry")<=l.getGameTime()||!(boss instanceof BestiaryMob b)||!b.isAlive())entity.discard();}
}
