# IceAndFire CE integration attribution

StarRPG uses the installed IceAndFire Community Edition 2.0 renderer and animations through an optional runtime adapter. The CE models and texture assets remain in the upstream mod JAR. No CE Java classes or dragon artwork are bundled in the StarRPG JAR.

IceAndFire CE: https://modrinth.com/mod/iceandfire-ce/version/soR168tk — LGPL-3.0-or-later; source: https://github.com/IAFEnvoy/IceAndFire-CE/tree/1.21.1 . CE authors listed by the artifact: IAFEnvoy, xiaowu, uoay; original Ice and Fire by Alexthe666/AlexModGuy and Raptorfarian.

The JSON recipes under `src/main/resources/data/iceandfire/recipe/delight/` are adapted from CE 2.0 by adding a NeoForge Farmer's Delight load condition. These specific compatibility resources remain under LGPL-3.0-or-later, with their complete modified JSON source included in this project and JAR. The original CE JAR is unchanged. Full LGPL-3.0 and GPL-3.0 texts are included in `src/main/resources/META-INF/licenses/`.

Required external libraries: Jupiter 2.3.7 (https://github.com/IAFEnvoy/Jupiter), Uranus 2.4.1 (https://github.com/IAFEnvoy/Uranus), Architectury API 13.0.11 NeoForge (https://github.com/architectury/architectury). All use LGPL-3.0; see upstream artifacts for notices. Exact CDN URLs, sizes and SHA-512 checksums are pinned in adventure-mods-lock.json and dragon-mods-lock.json. Installation scripts download unmodified artifacts directly from their upstream CDN.

Reference research: official original project https://modrinth.com/mod/ice-and-fire-dragons (no 1.21.1 release listed when checked); original flight behavior source https://github.com/AlexModGuy/Ice_and_Fire/blob/1.20/src/main/java/com/github/alexthe666/iceandfire/entity/IafDragonFlightManager.java . StarRPG's ground combat, beam collision, phase attacks and server movement are independent implementations.
