@echo off
setlocal
cd /d "%~dp0"
echo StarRPG 2.8.0 - IceAndFire CE, adventure mods and Eclipse setup
echo Close Minecraft first. Java 21 and Internet are required.
call gradlew.bat --no-daemon installAdventureMods -Declipse.application=org.eclipse.ui.ide.workbench eclipse neoForgeIdeSync prepareClientRun
if errorlevel 1 (
    echo Setup failed. Read the error above. See UPDATE-2.8.md.
    pause
    exit /b 1
)
echo Setup complete. Import this folder as an Existing Gradle Project in Eclipse.
echo Refresh Gradle Project, press F5, then run StarRPG Client.
pause
