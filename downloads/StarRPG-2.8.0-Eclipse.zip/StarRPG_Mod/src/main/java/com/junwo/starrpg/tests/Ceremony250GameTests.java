package com.junwo.starrpg.tests;

import com.junwo.starrpg.*;
import com.junwo.starrpg.bestiary.*;
import net.minecraft.gametest.framework.*;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.*;
import net.minecraft.world.level.GameType;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.common.damagesource.DamageContainer;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.gametest.*;

@GameTestHolder(StarRPG.MODID)
@PrefixGameTestTemplate(false)
public class Ceremony250GameTests {
    @GameTest(template="empty") public static void enhancementCueFollowsCommittedOutcomeAndNeverMissingMaterials(GameTestHelper h){
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(2,2,2)));var menu=new EnhancementMenu(1,p.getInventory());var w=new ItemStack(StarRPG.STAR_DAGGER.get());menu.getSlot(0).set(w);
        h.assertTrue(!menu.clickMenuButton(p,0)&&!p.getPersistentData().contains("starrpg_ceremony_tick"),"Invalid attempt celebrated");
        menu.getSlot(1).set(new ItemStack(StarRPG.STAR_DUST.get(),64));menu.getSlot(2).set(new ItemStack(StarRPG.STAR_FRAGMENT.get(),64));
        h.assertTrue(menu.clickMenuButton(p,0)&&EnhancementData.level(w)==1&&p.getPersistentData().getInt("starrpg_ceremony_kind")==PresentationCues.UPGRADE&&p.getPersistentData().getInt("starrpg_ceremony_value")==1,"Success cue did not follow committed level");
        EnhancementData.setLevel(w,24);long seed=0;while(true){p.getRandom().setSeed(seed);if(p.getRandom().nextInt(100)>=EnhancementMenu.getSuccessChance(w))break;seed++;}p.getRandom().setSeed(seed);
        int dust=menu.getSlot(1).getItem().getCount(),fragments=menu.getSlot(2).getItem().getCount();
        h.assertTrue(menu.clickMenuButton(p,0)&&EnhancementData.level(w)==24&&EnhancementData.failures(w)==1&&p.getPersistentData().getInt("starrpg_ceremony_kind")==PresentationCues.FAILURE,"Failure animation changed outcome");
        h.assertTrue(menu.getSlot(1).getItem().getCount()==dust-EnhancementMenu.getRequiredDust(24)&&menu.getSlot(2).getItem().getCount()==fragments-EnhancementMenu.getRequiredFragment(24),"Ceremony charged additional materials");h.succeed();
    }
    @GameTest(template="empty") public static void advancementCeremonyRequiresPaymentAndDoesNotAwardAnotherRank(GameTestHelper h){
        var p=h.makeMockPlayer(GameType.SURVIVAL);var c=Careers.profile(p);c.selected=10;c.ranks[10]=1;c.xp[10]=Careers.xpCost(1);c.mastery[10]=Careers.masteryCost(1);
        p.getInventory().add(new ItemStack(Careers.material(10),Careers.materialCount(1)));StarWallet.get(p.getServer()).credit(p.getUUID(),Careers.goldCost(1));
        h.assertTrue(Careers.advance(p)&&c.rank()==2&&p.getPersistentData().getInt("starrpg_ceremony_kind")==PresentationCues.ADVANCE&&p.getPersistentData().getInt("starrpg_ceremony_value")==2,"Missing promotion ceremony");
        h.assertTrue(StarWallet.get(p.getServer()).balance(p.getUUID())==0&&p.getInventory().countItem(Careers.material(10))==0,"Promotion payment changed");
        p.getPersistentData().remove("starrpg_ceremony_tick");h.assertTrue(!Careers.advance(p)&&c.rank()==2&&!p.getPersistentData().contains("starrpg_ceremony_tick"),"Rejected promotion celebrated or awarded rank");h.succeed();
    }
    @GameTest(template="hook_arena") public static void parryPresentationDistinguishesReadyBlockedAndSuccessfulHits(GameTestHelper h){
        var m=BestiaryRegistry.TYPES.get(BestiaryKind.ORC).get().create(h.getLevel());m.setPos(h.absoluteVec(new Vec3(3,2,3)));var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(m.position().add(0,0,1.5));p.setYRot(180);p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(Items.IRON_SWORD));
        long now=h.getLevel().getGameTime();h.assertTrue(ParrySystem.open(p)&&p.getPersistentData().getInt("starrpg_guard_kind")==PresentationCues.GUARD&&p.getPersistentData().getLong(ParrySystem.END)==now+5,"Ready motion changed parry window");
        m.parryableImpact=false;var hit=new LivingIncomingDamageEvent(p,new DamageContainer(m.damageSources().mobAttack(m),10));ParrySystem.defend(hit);h.assertTrue(!hit.isCanceled()&&p.getPersistentData().getInt("starrpg_guard_kind")==PresentationCues.GUARD,"Red attack displayed success");
        m.parryableImpact=true;hit=new LivingIncomingDamageEvent(p,new DamageContainer(m.damageSources().mobAttack(m),10));ParrySystem.defend(hit);h.assertTrue(hit.isCanceled()&&p.getPersistentData().getInt("starrpg_guard_kind")==PresentationCues.PARRY&&m.phase()==BestiaryMob.STAGGER,"Successful parry lacks rebound cue");
        h.assertTrue(!ParrySystem.open(p)&&p.getPersistentData().getLong(ParrySystem.READY)==now+24,"Visual cue reset cooldown");h.succeed();
    }
}
