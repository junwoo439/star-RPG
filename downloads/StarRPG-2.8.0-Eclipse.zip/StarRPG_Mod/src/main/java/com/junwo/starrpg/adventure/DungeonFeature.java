package com.junwo.starrpg.adventure;

import net.minecraft.core.*;
import net.minecraft.tags.BiomeTags;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.*;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/** Ancient, biome-adapted architecture kept inside the generating chunk. */
public final class DungeonFeature extends Feature<NoneFeatureConfiguration> {
    public static final int FLOOR_HEIGHT=8;
    public enum Style {DESERT,SNOW,FOREST,SWAMP,MOUNTAIN,PLAINS}
    public record Palette(Block stone,Block worn,Block pillar,Block trim,Block roof){}
    public DungeonFeature(){super(NoneFeatureConfiguration.CODEC);}
    public static Style style(net.minecraft.core.Holder<net.minecraft.world.level.biome.Biome> b){
        if(b.is(Biomes.DESERT)||b.is(BiomeTags.IS_BADLANDS))return Style.DESERT;
        if(b.is(Biomes.SWAMP)||b.is(Biomes.MANGROVE_SWAMP))return Style.SWAMP;
        if(b.value().getBaseTemperature()<.3F)return Style.SNOW;
        if(b.is(BiomeTags.IS_MOUNTAIN)||b.is(BiomeTags.IS_HILL))return Style.MOUNTAIN;
        if(b.is(BiomeTags.IS_FOREST)||b.is(BiomeTags.IS_TAIGA)||b.is(BiomeTags.IS_JUNGLE))return Style.FOREST;
        return Style.PLAINS;
    }
    public static Palette palette(Style s){return switch(s){
        case DESERT->new Palette(Blocks.SANDSTONE,Blocks.CUT_SANDSTONE,Blocks.CHISELED_SANDSTONE,Blocks.SMOOTH_SANDSTONE,Blocks.RED_SANDSTONE);
        case SNOW->new Palette(Blocks.STONE_BRICKS,Blocks.CRACKED_STONE_BRICKS,Blocks.POLISHED_ANDESITE,Blocks.CHISELED_STONE_BRICKS,Blocks.SPRUCE_PLANKS);
        case SWAMP->new Palette(Blocks.MUD_BRICKS,Blocks.MOSSY_STONE_BRICKS,Blocks.MANGROVE_LOG,Blocks.PACKED_MUD,Blocks.MOSS_BLOCK);
        case FOREST->new Palette(Blocks.STONE_BRICKS,Blocks.MOSSY_STONE_BRICKS,Blocks.DARK_OAK_LOG,Blocks.CHISELED_STONE_BRICKS,Blocks.MOSSY_COBBLESTONE);
        case MOUNTAIN->new Palette(Blocks.DEEPSLATE_BRICKS,Blocks.CRACKED_DEEPSLATE_BRICKS,Blocks.POLISHED_BASALT,Blocks.CHISELED_DEEPSLATE,Blocks.POLISHED_BLACKSTONE);
        case PLAINS->new Palette(Blocks.STONE_BRICKS,Blocks.CRACKED_STONE_BRICKS,Blocks.POLISHED_ANDESITE,Blocks.CHISELED_STONE_BRICKS,Blocks.DARK_OAK_PLANKS);
    };}
    private static void put(WorldGenLevel l,int x,int y,int z,Block b){l.setBlock(new BlockPos(x,y,z),b.defaultBlockState(),2);}
    @Override public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> c){
        var l=c.level();int x=(c.origin().getX()&~15)+8,z=(c.origin().getZ()&~15)+8;
        int top=l.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.WORLD_SURFACE_WG,x,z);
        if(top<l.getMinBuildHeight()+40||top>l.getMaxBuildHeight()-40||!l.getFluidState(new BlockPos(x,top-1,z)).isEmpty())return false;
        var style=style(l.getBiome(new BlockPos(x,top,z)));var p=palette(style);int variant=c.random().nextInt(3),base=variant==0?top-25:top-1;
        for(int dx=-7;dx<=7;dx++)for(int dz=-7;dz<=7;dz++)for(int y=0;y<=24;y++){
            boolean edge=Math.abs(dx)==6&&Math.abs(dz)<=6||Math.abs(dz)==6&&Math.abs(dx)<=6,floor=y%FLOOR_HEIGHT==0;
            Block block=edge||floor?(c.random().nextInt(7)==0?p.worn:p.stone):Blocks.AIR;
            if(edge&&y%8==6)block=p.trim;
            if(edge&&!floor&&y%8>=2&&y%8<=5&&(Math.abs(dx)==6&&Math.abs(dz)<=1||Math.abs(dz)==6&&Math.abs(dx)<=1))block=Blocks.IRON_BARS;
            put(l,x+dx,base+y,z+dz,block);
        }
        for(int sign:new int[]{-1,1})for(int y=1;y<=24;y++){
            Block rib=y%8==0||y%8==1?p.trim:p.pillar;
            put(l,x+sign*6,base+y,z-7,rib);put(l,x+sign*6,base+y,z+7,rib);
            put(l,x-7,base+y,z+sign*6,rib);put(l,x+7,base+y,z+sign*6,rib);
        }
        for(int y:new int[]{8,16,24})for(int d=-7;d<=7;d++){put(l,x+d,base+y,z-7,p.trim);put(l,x+d,base+y,z+7,p.trim);put(l,x-7,base+y,z+d,p.trim);put(l,x+7,base+y,z+d,p.trim);}
        // Continuous piers, cornices and vaulted entrance; no perfectly flat box silhouette.
        for(int sx:new int[]{-1,1})for(int sz:new int[]{-1,1})for(int y=1;y<25;y++)put(l,x+sx*5,base+y,z+sz*5,y%8==7?p.trim:p.pillar);
        if(variant!=0){
            for(int y=1;y<=5;y++)for(int dx=-2;dx<=2;dx++){put(l,x+dx,base+y,z-7,Blocks.AIR);put(l,x+dx,base+y,z-6,Blocks.AIR);}
            for(int sx:new int[]{-1,1})for(int y=1;y<8;y++){put(l,x+sx*3,base+y,z-7,p.pillar);if(y==1||y==7)put(l,x+sx*4,base+y,z-7,p.trim);}
            for(int dx=-3;dx<=3;dx++)put(l,x+dx,base+8-Math.abs(dx)/2,z-7,p.trim);
        }
        if(variant==1){
            for(int sx:new int[]{-1,1})for(int sz:new int[]{-1,1})for(int y=20;y<=31;y++)for(int a=-2;a<=2;a++)for(int b=-2;b<=2;b++)if(Math.max(Math.abs(a),Math.abs(b))==2)put(l,x+sx*5+a,base+y,z+sz*5+b,y==31?p.trim:p.stone);
            for(int dx=-7;dx<=7;dx++)for(int dz=-7;dz<=7;dz++)if((Math.abs(dx)==7||Math.abs(dz)==7)&&(dx+dz)%2==0)put(l,x+dx,base+25,z+dz,p.trim);
        }else if(variant==2){
            if(style==Style.DESERT){for(int tier=0;tier<5;tier++){int r=7-tier;for(int dx=-r;dx<=r;dx++)for(int dz=-r;dz<=r;dz++)put(l,x+dx,base+25+tier,z+dz,tier%2==0?p.trim:p.roof);}}
            else{for(int y=25;y<=35;y++){int radius=Math.max(0,6-(y-25)/2);for(int dx=-radius;dx<=radius;dx++)for(int dz=-radius;dz<=radius;dz++)if(Math.abs(dx)==radius||Math.abs(dz)==radius)put(l,x+dx,base+y,z+dz,p.roof);}put(l,x,base+36,z,Blocks.LIGHTNING_ROD);}
        }
        if(variant==1)for(int sx:new int[]{-1,1})for(int sz:new int[]{-1,1}){
            // Cold-region turrets shed snow; weathered lowland towers keep broken crowns.
            if(style==Style.SNOW){for(int tier=0;tier<4;tier++){int radius=Math.max(0,2-tier);for(int a=-radius;a<=radius;a++)for(int b=-radius;b<=radius;b++)put(l,x+sx*5+a,base+32+tier,z+sz*5+b,p.roof);}put(l,x+sx*5,base+36,z+sz*5,Blocks.SNOW_BLOCK);}
            else for(int a=-2;a<=2;a++)for(int b=-2;b<=2;b++)if(Math.max(Math.abs(a),Math.abs(b))==2&&(a+b)%2==0)put(l,x+sx*5+a,base+32,z+sz*5+b,(style==Style.SWAMP||style==Style.FOREST)&&(a-b)%3==0?Blocks.MOSS_BLOCK:p.trim);
        }
        if(variant==2&&style==Style.MOUNTAIN)for(int y=25;y<=34;y++){
            int radius=Math.min(7,7-(y-25)/2);for(int sign:new int[]{-1,1}){put(l,x+sign*radius,base+y,z,p.pillar);put(l,x,base+y,z+sign*radius,p.pillar);}
        }
        // Climbable service shaft and well-lit halls are deliberately preserved after ornamentation.
        for(int y=1;y<=(variant==0?25:24);y++){put(l,x-6,base+y,z-4,p.pillar);l.setBlock(new BlockPos(x-5,base+y,z-4),Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING,Direction.EAST),2);}
        for(int floor=0;floor<3;floor++)for(int sign:new int[]{-1,1}){
            put(l,x+sign*4,base+floor*8+7,z+4,Blocks.CHAIN);
            l.setBlock(new BlockPos(x+sign*4,base+floor*8+6,z+4),Blocks.LANTERN.defaultBlockState().setValue(LanternBlock.HANGING,true),2);
            put(l,x+sign*6,base+floor*8+1,z+5,p.trim);
        }
        // Exterior age and climate details stay inside the same chunk and away from traversal.
        if(variant!=0&&(style==Style.FOREST||style==Style.SWAMP))for(int i=0;i<9;i++){int dx=i%3*2-2;put(l,x+dx,base+25,z+5,Blocks.MOSS_BLOCK);l.setBlock(new BlockPos(x+5,base+2+i,z+4),Blocks.VINE.defaultBlockState().setValue(VineBlock.EAST,true),2);}
        if(variant!=0&&style==Style.SNOW)for(int dx=-6;dx<=6;dx+=2){put(l,x+dx,base+25,z-6,Blocks.SNOW_BLOCK);put(l,x+dx,base+25,z+6,Blocks.SNOW_BLOCK);}
        if(variant==0){
            put(l,x-5,top,z-4,Blocks.AIR);for(int sx:new int[]{-1,1})for(int y=0;y<5;y++)put(l,x-5+sx*2,top+y,z-4,p.pillar);
            for(int dx=-2;dx<=2;dx++)put(l,x-5+dx,top+5-Math.abs(dx)/2,z-4,p.trim);
            put(l,x-4,top+1,z-4,Blocks.SOUL_LANTERN);
        }
        if(variant!=0)for(int dx:new int[]{-6,6})for(int dz:new int[]{-6,6})for(int depth=1;depth<=16&&base-depth>l.getMinBuildHeight();depth++){
            var footing=new BlockPos(x+dx,base-depth,z+dz);
            if(l.getBlockState(footing).isFaceSturdy(l,footing,Direction.UP))break;
            put(l,footing.getX(),footing.getY(),footing.getZ(),depth%4==0?p.worn:p.stone);
        }
        l.setBlock(new BlockPos(x,base+1,z),AdventureWorldgen.CORE.get().defaultBlockState().setValue(TrialCoreBlock.VARIANT,variant).setValue(TrialCoreBlock.GRAND,true),2);
        return true;
    }
}
