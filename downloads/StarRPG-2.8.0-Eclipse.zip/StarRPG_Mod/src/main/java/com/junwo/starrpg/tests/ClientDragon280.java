package com.junwo.starrpg.tests;

import com.junwo.starrpg.*;
import com.junwo.starrpg.bestiary.*;
import net.minecraft.client.*;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.core.BlockPos;
import net.minecraft.world.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.*;
import net.minecraft.world.level.levelgen.presets.WorldPresets;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;

/** A new disposable world only; all combat and flight runs on the actual integrated server. */
@EventBusSubscriber(modid=StarRPG.MODID,value=Dist.CLIENT)
public final class ClientDragon280 {
    private static boolean started,configured;private static int tick;private static BestiaryMob boss;private static LivingEntity target;
    @SubscribeEvent public static void tick(net.neoforged.neoforge.client.event.ClientTickEvent.Post event){
        if(!Boolean.getBoolean("starrpg.dragon280"))return;var mc=Minecraft.getInstance();
        if(!started&&mc.screen instanceof TitleScreen&&mc.getOverlay()==null){started=true;mc.options.hideGui=true;mc.options.cloudStatus().set(CloudStatus.OFF);mc.options.guiScale().set(2);mc.options.renderDistance().set(4);mc.options.simulationDistance().set(5);mc.getWindow().setWindowed(1280,800);mc.resizeDisplay();mc.createWorldOpenFlows().createFreshLevel("starrpg-dragon-280-"+System.currentTimeMillis(),new LevelSettings("StarRPG IceAndFire CE integration verification",GameType.CREATIVE,false,Difficulty.NORMAL,true,new GameRules(),WorldDataConfiguration.DEFAULT),new WorldOptions(280,false,false),WorldPresets::createNormalWorldDimensions,mc.screen);return;}
        if(mc.player==null||mc.level==null||mc.getSingleplayerServer()==null)return;var server=mc.getSingleplayerServer();var id=mc.player.getUUID();
        if(!configured){configured=true;mc.setScreen(null);server.execute(()->{var p=server.getPlayerList().getPlayer(id);var l=p.serverLevel();l.setDayTime(6000);l.getGameRules().getRule(GameRules.RULE_DAYLIGHT).set(false,server);l.getGameRules().getRule(GameRules.RULE_DOMOBSPAWNING).set(false,server);l.getGameRules().getRule(GameRules.RULE_DOBLOCKDROPS).set(false,server);WorldDifficulty.get(server).setTier(0);for(int x=-30;x<=30;x++)for(int z=-26;z<=35;z++)l.setBlock(new BlockPos(x,180,z),(x/4+z/4)%2==0?Blocks.SMOOTH_STONE.defaultBlockState():Blocks.POLISHED_ANDESITE.defaultBlockState(),2);p.setNoGravity(true);p.getAbilities().flying=true;p.onUpdateAbilities();p.teleportTo(l,15,186,-10,45,10);});return;}
        if(tick==0&&mc.player.getY()<185)return;tick++;if(tick==20){if(!IceAndFireDragonVisual.available())throw new IllegalStateException("CE dependency not installed");StarRPG.LOGGER.info("DRAGON280_READY");tick=Math.max(20,Integer.getInteger("starrpg.dragon280.start",0)*240+1);}
        int stage=(tick-1)/240,step=tick%240;
        if(step==25&&stage<=10)server.execute(()->{
            var p=server.getPlayerList().getPlayer(id);var l=p.serverLevel();l.getEntitiesOfClass(BestiaryMob.class,p.getBoundingBox().inflate(100)).forEach(Entity::discard);l.getEntitiesOfClass(net.minecraft.world.entity.animal.Cow.class,p.getBoundingBox().inflate(100)).forEach(Entity::discard);l.getEntitiesOfClass(ArcaneSigil.class,p.getBoundingBox().inflate(100)).forEach(Entity::discard);
            BestiaryKind kind=switch(stage){case 1,5->BestiaryKind.WHITE_DRAGON;case 2,6->BestiaryKind.BLUE_DRAGON;case 3->BestiaryKind.GOLD_DRAGON;default->BestiaryKind.RED_DRAGON;};boss=BestiaryRegistry.TYPES.get(kind).get().create(l);boss.moveTo(0,181,6,180,0);boss.yBodyRot=boss.yBodyRotO=boss.yHeadRot=boss.yHeadRotO=180;boss.nextAttack=l.getGameTime()+10000;boss.setNoAi(stage<4);l.addFreshEntity(boss);
            p.teleportTo(l,stage<4?12:16,stage<4?185:186,stage<4?-6:-12,stage<4?45:40,stage<4?8:7);
            if(stage>=4){target=EntityType.COW.create(l);target.setPos(0,181,stage==7?10:-2);target.setNoGravity(true);((Mob)target).setNoAi(true);target.getAttribute(Attributes.MAX_HEALTH).setBaseValue(1000);target.setHealth(1000);l.addFreshEntity(target);boss.setTarget(target);
                if(stage==8||stage==9){boss.setHealth(boss.getMaxHealth()*(stage==8?.49F:.24F));boss.getPersistentData().putInt("starrpg_boss_phase",stage==8?1:2);DragonBattle.beginFlight(boss);}
                else{boss.getPersistentData().putInt("starrpg_dragon_combo",stage==7?1:stage==10?2:0);boss.startAttack(target,true);}
            }
            StarRPG.LOGGER.info("DRAGON280_SCENE {} {}",stage,kind);
        });
        if(step==95&&stage>=8&&stage<=9)server.execute(()->{if(!BossPhases.flying(boss)||boss.getY()<184)throw new IllegalStateException("Dragon failed to fly");StarRPG.LOGGER.info("DRAGON280_FLIGHT_OK {}",stage);});
        if(step==230&&stage>=8&&stage<=9)server.execute(()->{if(BossPhases.flying(boss)||boss.isNoGravity())throw new IllegalStateException("Dragon failed to land");StarRPG.LOGGER.info("DRAGON280_LANDING_OK {}",stage);});
        if(step==(stage<4?150:stage<8||stage==10?80:120)&&stage<=10){if(!IceAndFireDragonVisual.available())throw new IllegalStateException("CE rendering failed");Screenshot.grab(mc.gameDirectory,"starrpg-2.8-dragon-"+stage+".png",mc.getMainRenderTarget(),message->StarRPG.LOGGER.info("DRAGON280_SCREENSHOT {}",stage));}
        if(tick>=2640){mc.options.hideGui=false;StarRPG.LOGGER.info("DRAGON280_COMPLETE");mc.stop();}
    }
}
