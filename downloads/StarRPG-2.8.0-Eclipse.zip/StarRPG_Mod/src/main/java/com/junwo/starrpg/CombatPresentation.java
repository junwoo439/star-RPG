package com.junwo.starrpg;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.*;
import net.minecraft.world.item.*;

/** Bounded client poses driven by confirmed server cues. No input lock or camera motion. */
public final class CombatPresentation {
    public static float age(LivingEntity e,String key,float partial){return e.getPersistentData().contains(key)?e.level().getGameTime()-e.getPersistentData().getLong(key)+partial:10000;}
    public static float guard(LivingEntity e,float partial){
        float t=age(e,"starrpg_guard_tick",partial);boolean success=e.getPersistentData().getInt("starrpg_guard_kind")==PresentationCues.PARRY;
        if(t<0||t>=(success?14:10))return 0;
        return success?(float)Math.sin(Math.PI*(t+3)/17):t<5?1:1-(t-5)/5;
    }
    public static float strike(LivingEntity e,float partial,int kind){
        float t=age(e,"starrpg_motion_tick",partial),duration=kind==3||kind==6?15:kind==2?8:11;
        return t<0||t>=duration?0:(float)Math.sin(Math.PI*Math.min(1,t/duration));
    }
    public static boolean guardPose(HumanoidModel<?> m,LivingEntity e,float partial){
        float block=guard(e,partial);if(block<=0)return false;boolean right=e.getMainArm()==HumanoidArm.RIGHT;
        var main=right?m.rightArm:m.leftArm;var off=right?m.leftArm:m.rightArm;
        main.xRot=-1.25F*block;main.yRot=(right?-.75F:.75F)*block;main.zRot=(right?-.45F:.45F)*block;
        off.xRot=-1.35F*block;off.yRot=(right?.6F:-.6F)*block;off.zRot=(right?.2F:-.2F)*block;
        m.body.yRot=(right?-.12F:.12F)*block;return true;
    }
    public static void weaponPose(HumanoidModel<?> m,LivingEntity e,float partial){
        if(e.isUsingItem())return;int kind=WeaponArt.kind(e.getMainHandItem());if(kind<0||kind==11||kind==12)return;
        float hit=strike(e,partial,kind);if(hit<=0)return;boolean right=e.getMainArm()==HumanoidArm.RIGHT;float sign=right?1:-1;
        var arm=right?m.rightArm:m.leftArm;var off=right?m.leftArm:m.rightArm;int side=e.getPersistentData().getInt("starrpg_motion_side")==1?-1:1;
        if(kind==3||kind==6){arm.xRot=-.35F-hit*2.2F;arm.yRot=-sign*.25F*hit;off.xRot=-hit*.95F;off.yRot=sign*.35F*hit;m.body.yRot=sign*hit*.3F;}
        else if(kind==13){arm.xRot=-1.3F-hit*.35F;arm.yRot=-sign*.2F;}
        else{arm.xRot=-.6F-hit*1.3F;arm.yRot=sign*side*(.4F-hit*1.2F);arm.zRot=sign*side*hit*.45F;m.body.yRot=sign*side*hit*.35F;off.xRot=-.3F-hit*.3F;}
    }
    public static void firstPerson(PoseStack p,LivingEntity e,InteractionHand hand,float partial,ItemStack stack){
        float sign=(hand==InteractionHand.MAIN_HAND)==(e.getMainArm()==HumanoidArm.RIGHT)?1:-1,block=guard(e,partial);
        if(block>0){p.translate(-sign*.12*block,.1*block,-.05*block);p.mulPose(Axis.ZP.rotationDegrees(sign*-20*block));p.mulPose(Axis.XP.rotationDegrees(-10*block));return;}
        if(hand!=InteractionHand.MAIN_HAND||e.isUsingItem()||e.isSwimming()||e.isFallFlying())return;
        int kind=WeaponArt.kind(stack);if(kind<0||kind==4||kind==11||kind==12)return;
        float hit=strike(e,partial,kind),side=e.getPersistentData().getInt("starrpg_motion_side")==1?-1:1;
        if(kind==3||kind==6){p.translate(sign*hit*.08,hit*.18,-hit*.10);p.mulPose(Axis.XP.rotationDegrees(-hit*38));p.mulPose(Axis.ZP.rotationDegrees(sign*hit*-24));}
        else if(kind==13){p.translate(0,0,-hit*.4);p.mulPose(Axis.XP.rotationDegrees(-hit*15));}
        else{p.translate(-sign*side*hit*.18,-hit*.04,-hit*.12);p.mulPose(Axis.ZP.rotationDegrees(sign*side*hit*30));p.mulPose(Axis.YP.rotationDegrees(-sign*side*hit*14));}
    }
}
