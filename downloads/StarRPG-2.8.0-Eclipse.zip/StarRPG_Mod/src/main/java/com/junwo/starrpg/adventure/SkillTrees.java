package com.junwo.starrpg.adventure;
import com.junwo.starrpg.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
@EventBusSubscriber(modid=StarRPG.MODID)
public final class SkillTrees {
    public static final String[][] NAMES={{"관통의 길","철벽의 길"},{"암살의 길","척후의 길"},{"저격의 길","기동의 길"},{"비전의 길","보호의 길"},{"파쇄의 길","담금질의 길"},{"격노의 길","불굴의 길"},{"심판의 길","축복의 길"},{"영혼 수확","영혼 순환"},{"연격의 길","호흡의 길"},{"파괴의 길","수호의 길"},{"폭발 화염","지속 화염"},{"거센 해일","회복의 샘"},{"빙결 관통","서리 방벽"},{"지각 파쇄","대지 갑옷"},{"심연 폭발","영혼 흡수"},{"빛의 심판","빛의 가호"}};
    public static int branch(Player p,int job){return AdventureData.value(p,"branch_"+job);}
    public static int nodes(Player p,int job){return AdventureData.value(p,"nodes_"+job);}
    public static boolean learn(Player p,int choice){int job=Careers.profile(p).selected;if(p.level().isClientSide()||job<0||choice<1||choice>2)return false;int old=branch(p,job),n=nodes(p,job),available=Math.min(3,1+(Careers.profile(p).rank()-1)/3);if(old!=0&&old!=choice||n>=available)return false;AdventureData.set(p,"branch_"+job,choice);AdventureData.set(p,"nodes_"+job,n+1);update(p);return true;}
    public static boolean reset(Player p){int job=Careers.profile(p).selected;if(job<0||nodes(p,job)==0||!StarWallet.get(p.getServer()).debit(p.getUUID(),500))return false;AdventureData.set(p,"branch_"+job,0);AdventureData.set(p,"nodes_"+job,0);update(p);return true;}
    private static void attr(Player p,net.minecraft.core.Holder<Attribute> type,String name,double value,AttributeModifier.Operation operation){var a=p.getAttribute(type);if(a==null)return;var id=ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,name);if(value==0)a.removeModifier(id);else a.addOrUpdateTransientModifier(new AttributeModifier(id,value,operation));}
    public static void update(Player p){int job=Careers.profile(p).selected,n=job<0?0:nodes(p,job);boolean support=job>=0&&branch(p,job)==2&&Careers.qualified(p,p.getMainHandItem());attr(p,Attributes.ARMOR,"tree_armor",support?n:0,AttributeModifier.Operation.ADD_VALUE);attr(p,Attributes.MOVEMENT_SPEED,"tree_speed",support&&(job==1||job==2||job==8)?n*.025:0,AttributeModifier.Operation.ADD_MULTIPLIED_BASE);attr(p,Attributes.KNOCKBACK_RESISTANCE,"tree_poise",support&&(job==0||job==4||job==13)?n*.05:0,AttributeModifier.Operation.ADD_VALUE);attr(p,Attributes.ATTACK_SPEED,"tree_composure",support&&job==8?n*.03:0,AttributeModifier.Operation.ADD_MULTIPLIED_BASE);}
    @SubscribeEvent public static void tick(net.neoforged.neoforge.event.tick.PlayerTickEvent.Post e){var p=e.getEntity();if(!p.level().isClientSide()&&p.tickCount%20==0)update(p);}
    public static float skillBonus(Player p,net.minecraft.world.item.ItemStack weapon){int job=Careers.profile(p).selected;return job>=0&&branch(p,job)==1&&Careers.qualified(p,weapon)?1+nodes(p,job)*.08F:1;}
    public static boolean attack(net.minecraft.world.damagesource.DamageSource s){return CombatRules.primary(s)||s.is(MagicSystem.MAGIC_DAMAGE)||s.is(WeaponAbilities.DAGGER_DAMAGE)||s.getDirectEntity() instanceof net.minecraft.world.entity.projectile.AbstractArrow;}
    @SubscribeEvent public static void damage(net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent e){if(e.isCanceled()||e.getEntity().level().isClientSide())return;if(e.getEntity() instanceof Player defender&&Careers.profile(defender).selected==5&&branch(defender,5)==2&&Careers.qualified(defender,defender.getMainHandItem())&&defender.getHealth()<=defender.getMaxHealth()*.5F)e.setAmount(e.getAmount()*(1-nodes(defender,5)*.05F));if(!(e.getSource().getEntity() instanceof Player p)||!attack(e.getSource())||!Careers.qualified(p,p.getMainHandItem()))return;int job=Careers.profile(p).selected,n=nodes(p,job);if(branch(p,job)==1)e.setAmount(e.getAmount()*(1+n*.08F+(job==1&&SpecialWeaponEffects.behind(p,e.getEntity())?n*.02F:0)));}
    @SubscribeEvent public static void hit(net.neoforged.neoforge.event.entity.living.LivingDamageEvent.Post e){if(e.getEntity().level().isClientSide()||e.getNewDamage()<=0||!(e.getSource().getEntity() instanceof Player p)||!attack(e.getSource())||!Careers.qualified(p,p.getMainHandItem()))return;int job=Careers.profile(p).selected,n=nodes(p,job);if(n==0)return;
        if(branch(p,job)==1&&job==10&&n>=2&&e.getSource().is(MagicSystem.MAGIC_DAMAGE)&&p.getPersistentData().getLong("tree_explosion")<=p.level().getGameTime()){
            p.getPersistentData().putLong("tree_explosion",p.level().getGameTime()+160);var center=e.getEntity();
            for(var other:p.level().getEntitiesOfClass(net.minecraft.world.entity.LivingEntity.class,center.getBoundingBox().inflate(2),t->t!=center&&CombatRules.canHarm(p,t)&&p.hasLineOfSight(t)).stream().limit(3).toList())CombatRules.runeDamage(p,other,1+n);
            ArcaneSigil.spawn((net.minecraft.server.level.ServerLevel)p.level(),center.position(),new net.minecraft.world.phys.Vec3(0,0,1),7,0xFF7544,1.5F,20);
        }
        if(branch(p,job)!=2)return;if(job==10)e.getEntity().igniteForSeconds(2+n);else if(job==12)e.getEntity().addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN,40+n*10,1));else if(job==7||job==14)p.heal(Math.min(2,e.getNewDamage()*n*.015F));else if(job==11||job==15){long t=p.level().getGameTime();if(p.getPersistentData().getLong("tree_heal")<=t){p.heal(n);p.getPersistentData().putLong("tree_heal",t+100);}}}
}
