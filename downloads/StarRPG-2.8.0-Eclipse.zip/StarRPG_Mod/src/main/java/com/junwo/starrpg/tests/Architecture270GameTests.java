package com.junwo.starrpg.tests;
import com.junwo.starrpg.*;
import com.junwo.starrpg.adventure.*;
import net.minecraft.gametest.framework.*;
import net.minecraft.nbt.*;
import net.minecraft.core.registries.Registries;
import net.neoforged.neoforge.gametest.*;
@GameTestHolder(StarRPG.MODID)
@PrefixGameTestTemplate(false)
public class Architecture270GameTests {
    @GameTest(template="empty") public static void legacyCoreBlockStateLoadsWithoutChangingItsLayout(GameTestHelper h){
        var tag=new CompoundTag();tag.putString("Name","starrpg:trial_core");var properties=new CompoundTag();properties.putString("variant","2");tag.put("Properties",properties);
        var old=NbtUtils.readBlockState(h.getLevel().registryAccess().lookupOrThrow(Registries.BLOCK),tag);
        h.assertTrue(old.is(AdventureWorldgen.CORE.get())&&old.getValue(TrialCoreBlock.VARIANT)==2&&!old.getValue(TrialCoreBlock.GRAND),"Old core changed its stored floor layout");
        var next=old.setValue(TrialCoreBlock.GRAND,true);var round=NbtUtils.readBlockState(h.getLevel().registryAccess().lookupOrThrow(Registries.BLOCK),NbtUtils.writeBlockState(next));
        h.assertTrue(round.getValue(TrialCoreBlock.GRAND)&&round.getValue(TrialCoreBlock.VARIANT)==2,"New core lost its layout marker on reload");h.succeed();
    }
}
