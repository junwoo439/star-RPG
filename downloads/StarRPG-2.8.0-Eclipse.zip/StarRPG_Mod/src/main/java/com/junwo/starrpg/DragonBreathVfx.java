package com.junwo.starrpg;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.phys.Vec3;

/** True three-dimensional, mouth-anchored streams; length and pitch match server ray collision. */
public final class DragonBreathVfx {
    public static void draw(PoseStack p,MultiBufferSource b,int style,int color,float range,float age,int life,float yaw,float pitch){
        float fade=Math.min(1,age/2)*Math.min(1,(life-age)/3),length=range*Math.min(1,age/2);
        if(fade<=0)return;
        p.pushPose();p.mulPose(Axis.YP.rotationDegrees(-yaw));p.mulPose(Axis.XP.rotationDegrees(pitch));
        int segments=10+VisualOptions.quality()*5,rays=style==55?3:2+VisualOptions.quality();
        for(int ray=0;ray<rays;ray++){
            Vec3 previous=Vec3.ZERO;
            for(int i=1;i<=segments;i++){
                float f=i/(float)segments,phase=age*.27F-f*8+ray*2.399F,width=.08F+f*.28F;
                Vec3 at=new Vec3(Math.sin(phase)*width,Math.cos(phase*1.3)*width,f*length);
                if(style==55)at=at.add(Math.sin(i*4.17+age*.5+ray)*.2,Math.cos(i*3.7+age*.3)*.2,0);
                CinematicVfx.line(p,b,previous,at,style==55?.025F:style==56?.045F:.065F,color,fade*(style==54?.28F:.72F));
                if(i%2==0){
                    p.pushPose();p.translate(at.x,at.y,at.z);p.mulPose(Axis.ZP.rotation(phase));
                    int cell=style==52?2:style==53?12:style==54?6:style==55?3:7;
                    for(int plane=0;plane<2;plane++){p.pushPose();p.mulPose(Axis.YP.rotationDegrees(plane*90));CinematicVfx.sprite(p,b,cell,width*1.5F,width*(style==52?2.7F:1.5F),color,fade*(style==54?.32F:.6F));p.popPose();}
                    if(style==53)CinematicVfx.crystal(p,b,width*.35F,width,0xCEFAFF,fade*.75F);
                    p.popPose();
                }
                if(style==55&&i%4==0)CinematicVfx.line(p,b,at,at.add(Math.sin(i)*.7,Math.cos(i)*.6,.4),.015F,0xDBF8FF,fade*.6F);
                previous=at;
            }
        }
        if(style!=54)CinematicVfx.line(p,b,Vec3.ZERO,new Vec3(0,0,length),style==55?.02F:.04F,style==52?0xFFF3BF:0xEEFFFF,fade*.8F);
        p.popPose();
    }
}
