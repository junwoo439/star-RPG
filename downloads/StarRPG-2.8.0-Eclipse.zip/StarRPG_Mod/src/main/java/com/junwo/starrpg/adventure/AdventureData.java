package com.junwo.starrpg.adventure;

import java.util.*;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.saveddata.SavedData;

/** Adventure progress is keyed by UUID and survives death, dimension changes and server restarts. */
public final class AdventureData extends SavedData {
    private final Map<UUID,CompoundTag> players=new HashMap<>();
    public static AdventureData get(MinecraftServer s){return s.overworld().getDataStorage().computeIfAbsent(new Factory<>(AdventureData::new,AdventureData::load),"starrpg_adventure");}
    public static CompoundTag profile(Player p){return get(p.getServer()).players.computeIfAbsent(p.getUUID(),id->new CompoundTag());}
    public static int value(Player p,String key){return profile(p).getInt(key);}
    public static void set(Player p,String key,int value){profile(p).putInt(key,Math.max(0,value));get(p.getServer()).setDirty();}
    public static void add(Player p,String key,int amount){set(p,key,(int)Math.min(Integer.MAX_VALUE,(long)value(p,key)+amount));}
    public static AdventureData load(CompoundTag t,HolderLookup.Provider lookup){var d=new AdventureData();for(Tag raw:t.getList("players",Tag.TAG_COMPOUND)){var row=(CompoundTag)raw;if(row.hasUUID("id"))d.players.put(row.getUUID("id"),row.getCompound("progress").copy());}return d;}
    @Override public CompoundTag save(CompoundTag t,HolderLookup.Provider lookup){var rows=new ListTag();players.forEach((id,data)->{var row=new CompoundTag();row.putUUID("id",id);row.put("progress",data.copy());rows.add(row);});t.put("players",rows);return t;}
}
