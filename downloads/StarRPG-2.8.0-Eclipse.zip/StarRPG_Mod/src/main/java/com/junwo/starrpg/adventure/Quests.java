package com.junwo.starrpg.adventure;
import com.junwo.starrpg.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerLevel;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
@EventBusSubscriber(modid=StarRPG.MODID)
public final class Quests {
    public static final String[] TITLES={"별의 흔적","잃어버린 성좌","찢어진 하늘","별을 삼킨 왕","별을 벼리는 손","별의 연대기 완결"};
    public static final String[] STORY={"별빛을 먹은 몬스터의 흔적을 수집하라.","지하 유적과 폐성에 남은 별의 기록을 찾아라.","하늘의 균열을 봉인하고 침공을 막아라.","별을 삼킨 강대한 보스를 쓰러뜨려라.","모두의 재료를 모아 전설 장비를 완성하라.","아린이 당신의 이름을 새로운 별자리에 새겼다."};
    public static final String[] KEYS={"kills","dungeons","rifts","bosses","legendary_crafted"};
    public static final String[] DAILY={"kills","ores","crops","fish"};
    public static final String[] DAILY_NAMES={"몬스터 10마리 토벌","자연 광석 12개 채굴","성숙 작물 16개 수확","물고기 4회 낚기"};
    public static final int[] GOALS={10,12,16,4};
    public static boolean near(Player p){return !p.level().getEntitiesOfClass(QuestEnvoy.class,p.getBoundingBox().inflate(6)).isEmpty();}
    public static boolean act(Player p,int action){if(p.level().isClientSide()||!near(p))return false;int chapter=AdventureData.value(p,"story_chapter");var data=AdventureData.profile(p);int day=(int)Math.min(Integer.MAX_VALUE-1,p.getServer().overworld().getGameTime()/24000),daily=day%4;
        if(action==0){if(chapter>=5||AdventureData.value(p,"story_active")>0)return false;AdventureData.set(p,"story_active",1);return true;}
        if(action==1){if(chapter>=5||AdventureData.value(p,"story_active")==0||AdventureData.value(p,KEYS[chapter])<(chapter==0?5:1))return false;AdventureData.set(p,"story_chapter",chapter+1);AdventureData.set(p,"story_active",0);StarWallet.get(p.getServer()).credit(p.getUUID(),500+chapter*250);LifeJobs.give(p,new net.minecraft.world.item.ItemStack(chapter==4?StarRPG.LEGENDARY_RUNE.get():StarRPG.STAR_FRAGMENT.get(),chapter==4?1:2));return true;}
        if(action==2){if(data.getInt("daily_claim_day")==day+1||data.getInt("daily_accept_day")==day+1)return false;AdventureData.set(p,"daily_accept_day",day+1);AdventureData.set(p,"daily_base",AdventureData.value(p,DAILY[daily]));return true;}
        if(action==3){if(data.getInt("daily_claim_day")==day+1||data.getInt("daily_accept_day")!=day+1||AdventureData.value(p,DAILY[daily])-data.getInt("daily_base")<GOALS[daily])return false;AdventureData.set(p,"daily_claim_day",day+1);StarWallet.get(p.getServer()).credit(p.getUUID(),250);LifeJobs.give(p,new net.minecraft.world.item.ItemStack(StarRPG.STAR_DUST.get(),5));return true;}return false;
    }
    @SubscribeEvent public static void village(net.neoforged.neoforge.event.tick.PlayerTickEvent.Post e){var p=e.getEntity();if(!(p.level() instanceof ServerLevel l)||p.tickCount%1200!=0||!l.isVillage(p.blockPosition())||!p.isAlive())return;if(!l.getEntitiesOfClass(QuestEnvoy.class,p.getBoundingBox().inflate(96)).isEmpty())return;String cell="envoy_"+l.dimension().location()+":"+(p.getBlockX()>>7)+":"+(p.getBlockZ()>>7);for(int dx:new int[]{2,-2,0})for(int dz:new int[]{2,-2,0}){var n=AdventureEntities.ENVOY.get().create(l);n.moveTo(p.getX()+dx,p.getY(),p.getZ()+dz,0,0);if(l.noCollision(n)&&l.getBlockState(n.blockPosition().below()).isSolidRender(l,n.blockPosition().below())){if(WorldTrials.markVillage(l,cell))l.addFreshEntity(n);return;}}}
}
