package com.junwo.starrpg;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.*;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.*;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.*;

/** The projectile owns one real stack. Recall transfers it once; failures drop that same stack. */
public final class ThrownDagger extends AbstractArrow implements ItemSupplier {
    private static final EntityDataAccessor<Boolean> RETURNING=SynchedEntityData.defineId(ThrownDagger.class,EntityDataSerializers.BOOLEAN);
    private double travelled;private int returnTicks;private boolean settled;
    public ThrownDagger(EntityType<? extends ThrownDagger> type,Level level){super(type,level);}
    public ThrownDagger(Level level,Player p,ItemStack stack){super(ModEntities.THROWN_DAGGER.get(),p,level,stack,stack);pickup=p.hasInfiniteMaterials()?Pickup.CREATIVE_ONLY:Pickup.ALLOWED;setNoGravity(true);}
    @Override protected void defineSynchedData(SynchedEntityData.Builder builder){super.defineSynchedData(builder);builder.define(RETURNING,false);}
    public boolean returning(){return entityData.get(RETURNING);}
    @Override protected ItemStack getDefaultPickupItem(){return new ItemStack(StarRPG.STAR_DAGGER.get());}
    @Override public ItemStack getItem(){return getPickupItem();}
    @Override public void playerTouch(Player p){} // Recall is the only inventory transfer while airborne.
    @Override protected boolean canHitEntity(Entity entity){return !returning()&&super.canHitEntity(entity)&&(!(getOwner() instanceof Player p)||!(entity instanceof LivingEntity living)||CombatRules.canHarm(p,living));}
    @Override protected void onHitEntity(EntityHitResult hit){
        Entity struck=hit.getEntity();if(struck instanceof net.neoforged.neoforge.entity.PartEntity<?> part)struck=part.getParent();
        if(!level().isClientSide()&&!returning()&&getOwner() instanceof Player p&&struck instanceof LivingEntity target&&CombatRules.canHarm(p,target)){
            float damage=5+(float)EnhancementData.combatPower(getPickupItem())*0.6F;
            if(Careers.profile(p).selected==1)damage*=1+Careers.power(p)*0.06F+CareerMilestones.stat(Careers.profile(p).rank())*0.02F;
            if(SpecialWeaponEffects.behind(p,target))damage*=1.2F;
            target.hurt(new net.minecraft.world.damagesource.DamageSource(level().registryAccess().registryOrThrow(net.minecraft.core.registries.Registries.DAMAGE_TYPE).getHolderOrThrow(WeaponAbilities.DAGGER_DAMAGE),this,p),damage);
            ArcaneSigil.spawn((ServerLevel)level(),target.position().add(0,1,0),getDeltaMovement().normalize(),2,0x65FFD0,1.2F,16);CombatVisuals.burst(target,ParticleTypes.ENCHANTED_HIT,12);CombatVisuals.sound(this,SoundEvents.TRIDENT_HIT,0.6F,1.4F);
        }
        beginReturn();
    }
    @Override protected void onHitBlock(BlockHitResult hit){if(!level().isClientSide()){setPos(hit.getLocation());CombatVisuals.burst(this,ParticleTypes.CRIT,7);}beginReturn();}
    public void beginReturn(){
        if(level().isClientSide()||settled||isRemoved())return;
        if(!(getOwner() instanceof Player p)||!p.isAlive()||p.level()!=level()){settle();return;}
        entityData.set(RETURNING,true);setNoPhysics(true);setNoGravity(true);inGround=false;
    }
    private void receive(Player p){
        if(settled||isRemoved())return;settled=true;
        if(pickup==Pickup.ALLOWED){var stack=getPickupItem();p.getInventory().add(stack);if(!stack.isEmpty()){setPos(p.position());var drop=spawnAtLocation(stack,0.1F);if(drop!=null)drop.setDefaultPickUpDelay();}p.getInventory().setChanged();}
        CombatVisuals.sound(p,SoundEvents.ITEM_PICKUP,0.4F,1.4F);discard();
    }
    public void settle(){
        if(level().isClientSide()||settled||isRemoved())return;settled=true;
        if(pickup==Pickup.ALLOWED){var drop=spawnAtLocation(getPickupItem(),0.1F);if(drop!=null)drop.setDefaultPickUpDelay();}discard();
    }
    @Override public void tick(){
        if(!level().isClientSide()){
            if(returning()){
                if(!(getOwner() instanceof Player p)||!p.isAlive()||p.isSpectator()||p.level()!=level()||++returnTicks>80){settle();return;}
                var delta=p.position().add(0,1,0).subtract(position());
                if(delta.lengthSqr()<1.4){receive(p);return;}
                var direction=delta.normalize();double speed=Math.min(1.7,delta.length());
                // A small decaying curve makes the return visible without orbiting the owner's hand.
                double curve=Math.min(0.18,delta.length()*0.03)*Math.sin(returnTicks*0.5);
                setDeltaMovement(direction.scale(speed).add(direction.z*curve,0,-direction.x*curve));
            }else{
                travelled+=getDeltaMovement().length();if(travelled>=14||tickCount>=40)beginReturn();
            }
            if(tickCount%2==0)CombatVisuals.at((ServerLevel)level(),position(),returning()?ParticleTypes.END_ROD:ParticleTypes.CRIT,2,0.035);
        }super.tick();
    }
    @Override public void addAdditionalSaveData(CompoundTag tag){super.addAdditionalSaveData(tag);tag.putDouble("starrpg_travel",travelled);tag.putBoolean("starrpg_returning",returning());tag.putInt("starrpg_return_ticks",returnTicks);}
    @Override public void readAdditionalSaveData(CompoundTag tag){super.readAdditionalSaveData(tag);travelled=Math.max(0,tag.getDouble("starrpg_travel"));returnTicks=Math.max(0,tag.getInt("starrpg_return_ticks"));entityData.set(RETURNING,tag.getBoolean("starrpg_returning"));setNoPhysics(returning());setNoGravity(true);}
}
