package com.junwo.starrpg;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

@EventBusSubscriber(
        modid = StarRPG.MODID,
        value = Dist.CLIENT
)
public class StarRPGClientEvents {

    @SubscribeEvent public static void air(net.neoforged.neoforge.event.entity.player.PlayerInteractEvent.LeftClickEmpty e){PacketDistributor.sendToServer(new ActionPayload(4));}
    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        if(net.minecraft.client.Minecraft.getInstance().player==null)return;
        while(StarRPGKeyMappings.VISUALS.consumeClick()){int q=(VisualOptions.quality()+1)%3;VisualOptions.QUALITY.set(q);VisualOptions.SPEC.save();net.minecraft.client.Minecraft.getInstance().player.displayClientMessage(net.minecraft.network.chat.Component.literal("이펙트: "+new String[]{"가벼움","균형","화려함"}[q]),true);}
        while(StarRPGKeyMappings.PARRY.consumeClick())PacketDistributor.sendToServer(new ActionPayload(5));
        while(StarRPGKeyMappings.HUB.consumeClick())PacketDistributor.sendToServer(new ActionPayload(0));
        while(StarRPGKeyMappings.AWAKEN.consumeClick())PacketDistributor.sendToServer(new ActionPayload(3));
        while(StarRPGKeyMappings.WEAPON.consumeClick())if(!net.minecraft.client.gui.screens.Screen.hasShiftDown())PacketDistributor.sendToServer(new ActionPayload(1));
        while(StarRPGKeyMappings.CAREER.consumeClick())PacketDistributor.sendToServer(new ActionPayload(2));
        while (StarRPGKeyMappings.CHEST_ABILITY.consumeClick()) {
            PacketDistributor.sendToServer(
                    UseChestAbilityPayload.INSTANCE
            );
        }
    }
}