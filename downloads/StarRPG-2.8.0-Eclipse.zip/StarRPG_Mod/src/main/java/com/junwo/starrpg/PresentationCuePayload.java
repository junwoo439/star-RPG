package com.junwo.starrpg;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.*;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record PresentationCuePayload(int entity,int cue,int value,int color) implements CustomPacketPayload {
    public static final Type<PresentationCuePayload> TYPE=new Type<>(ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,"presentation_cue"));
    public static final StreamCodec<ByteBuf,PresentationCuePayload> STREAM_CODEC=StreamCodec.composite(ByteBufCodecs.VAR_INT,PresentationCuePayload::entity,ByteBufCodecs.VAR_INT,PresentationCuePayload::cue,ByteBufCodecs.VAR_INT,PresentationCuePayload::value,ByteBufCodecs.INT,PresentationCuePayload::color,PresentationCuePayload::new);
    @Override public Type<? extends CustomPacketPayload> type(){return TYPE;}
    public static void handle(PresentationCuePayload m,IPayloadContext c){c.enqueueWork(()->{
        if(m.cue<PresentationCues.GUARD||m.cue>PresentationCues.CRAFT)return;
        if(c.player().level().getEntity(m.entity) instanceof LivingEntity e)PresentationCues.mark(e,m.cue,m.value,m.color);
    });}
}
