package com.junwo.starrpg.adventure;
import com.junwo.starrpg.bestiary.*;
public final class JournalText {
    private static final java.util.Map<String,String[]> LOOT=new java.util.HashMap<>();
    static {
        LOOT.put("aasimar",new String[]{"minecraft:glowstone_dust"});
        LOOT.put("air_elemental",new String[]{"minecraft:redstone"});
        LOOT.put("ancient_golem",new String[]{"minecraft:iron_nugget","starrpg:star_fragment"});
        LOOT.put("animated_armor",new String[]{"minecraft:iron_nugget"});
        LOOT.put("banshee",new String[]{"minecraft:bone"});
        LOOT.put("basilisk",new String[]{"minecraft:amethyst_shard"});
        LOOT.put("beelzebub",new String[]{"minecraft:quartz","starrpg:star_fragment"});
        LOOT.put("black_dragon",new String[]{"minecraft:amethyst_shard","starrpg:star_fragment"});
        LOOT.put("blue_dragon",new String[]{"minecraft:amethyst_shard","starrpg:star_fragment"});
        LOOT.put("brass_dragon",new String[]{"minecraft:amethyst_shard","starrpg:star_fragment"});
        LOOT.put("bronze_dragon",new String[]{"minecraft:amethyst_shard","starrpg:star_fragment"});
        LOOT.put("cloud_giant",new String[]{"minecraft:iron_ingot"});
        LOOT.put("cockatrice",new String[]{"minecraft:amethyst_shard"});
        LOOT.put("copper_dragon",new String[]{"minecraft:amethyst_shard","starrpg:star_fragment"});
        LOOT.put("corrupt_guard",new String[]{"minecraft:iron_nugget"});
        LOOT.put("demogorgon",new String[]{"minecraft:quartz","starrpg:star_fragment"});
        LOOT.put("dire_bear",new String[]{"minecraft:leather"});
        LOOT.put("dire_wolf",new String[]{"minecraft:leather"});
        LOOT.put("earth_elemental",new String[]{"minecraft:redstone"});
        LOOT.put("elder_bear",new String[]{"minecraft:leather","starrpg:star_fragment"});
        LOOT.put("fire_elemental",new String[]{"minecraft:redstone"});
        LOOT.put("fire_giant",new String[]{"minecraft:iron_ingot"});
        LOOT.put("frost_giant",new String[]{"minecraft:iron_ingot"});
        LOOT.put("gargoyle",new String[]{"minecraft:iron_nugget"});
        LOOT.put("geist",new String[]{"minecraft:bone"});
        LOOT.put("giant_ant",new String[]{"minecraft:leather"});
        LOOT.put("giant_spider",new String[]{"minecraft:leather"});
        LOOT.put("goblin",new String[]{"minecraft:iron_nugget"});
        LOOT.put("gold_dragon",new String[]{"minecraft:amethyst_shard","starrpg:star_fragment"});
        LOOT.put("grave_skeleton",new String[]{"minecraft:bone"});
        LOOT.put("green_dragon",new String[]{"minecraft:amethyst_shard","starrpg:star_fragment"});
        LOOT.put("hydra",new String[]{"minecraft:amethyst_shard","starrpg:star_fragment"});
        LOOT.put("hyena",new String[]{"minecraft:leather"});
        LOOT.put("incubus",new String[]{"minecraft:quartz"});
        LOOT.put("kobold",new String[]{"minecraft:iron_nugget"});
        LOOT.put("lich",new String[]{"minecraft:bone","starrpg:star_fragment"});
        LOOT.put("ogre",new String[]{"minecraft:iron_nugget"});
        LOOT.put("ogre_warlord",new String[]{"minecraft:iron_nugget","starrpg:star_fragment"});
        LOOT.put("orc",new String[]{"minecraft:iron_nugget"});
        LOOT.put("red_dragon",new String[]{"minecraft:amethyst_shard","starrpg:star_fragment"});
        LOOT.put("reef_shark",new String[]{"minecraft:leather"});
        LOOT.put("rotting_zombie",new String[]{"minecraft:bone"});
        LOOT.put("silver_dragon",new String[]{"minecraft:amethyst_shard","starrpg:star_fragment"});
        LOOT.put("solar",new String[]{"minecraft:glowstone_dust","starrpg:star_fragment"});
        LOOT.put("stone_golem",new String[]{"minecraft:iron_nugget"});
        LOOT.put("storm_giant",new String[]{"minecraft:iron_ingot","starrpg:star_fragment"});
        LOOT.put("succubus",new String[]{"minecraft:quartz"});
        LOOT.put("troll",new String[]{"minecraft:iron_nugget"});
        LOOT.put("vampire",new String[]{"minecraft:bone"});
        LOOT.put("water_elemental",new String[]{"minecraft:redstone"});
        LOOT.put("white_dragon",new String[]{"minecraft:amethyst_shard","starrpg:star_fragment"});
        LOOT.put("wild_boar",new String[]{"minecraft:leather"});
        LOOT.put("wyvern",new String[]{"minecraft:amethyst_shard"});
    }
    public static String region(BestiaryKind k){return switch(k.habitat){case FOREST->"숲";case PLAINS->"평원";case DESERT->"사막";case OCEAN->"바다";case SAVANNA->"사바나";case MOUNTAIN->"산악";case SWAMP->"늪";case DARK->"어두운 지역";case BADLANDS->"악지";case SNOW->"설원";case COAST->"해안";case NETHER->"네더";};}
    public static String attack(BestiaryKind k){return switch(k.move){case SWEEP->"넓은 전방 베기";case LUNGE->"전방 돌진·관통";case BITE->"근거리 물어뜯기";case WEB->"원형 거미줄·독 공격";case SLAM->"원형 지면 강타·밀치기";case DRAIN->"흡혈 타격";case HEX->"저주 마법·둔화";case SCREAM->"주변 비명 공격";case FIRE->"화염과 화상";case LIGHTNING->"번개 공격";case POISON->"독 공격";case FROST->"서리 공격·둔화";case LIGHT->"성광 공격·발광";case TIDE->"해일·밀치기";case WIND->"바람 공격·밀치기";};}
    public static String drops(BestiaryKind k){var names=new java.util.ArrayList<String>();for(String id:LOOT.getOrDefault(k.id,new String[0]))names.add(net.minecraft.core.registries.BuiltInRegistries.ITEM.get(net.minecraft.resources.ResourceLocation.parse(id)).getDescription().getString());if(k.boss){if(k.family==BestiaryKind.Family.DRAGON)names.add("용의 심장 파편");else if(k==BestiaryKind.LICH)names.add("리치의 영혼");else if(k==BestiaryKind.ANCIENT_GOLEM)names.add("고대 골렘 핵");}return String.join(" · ",names);}
}
