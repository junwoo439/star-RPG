package com.junwo.starrpg.mixin;

import com.junwo.starrpg.CombatPresentation;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.*;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemInHandRenderer.class)
public abstract class FirstPersonMotionMixin {
    // Runs within vanilla's push/pop pair, so main-hand transforms never leak into the offhand.
    @Inject(method="renderArmWithItem",at=@At(value="INVOKE",target="Lcom/mojang/blaze3d/vertex/PoseStack;pushPose()V",shift=At.Shift.AFTER,ordinal=0))
    private void starrpg$motion(AbstractClientPlayer player,float partial,float pitch,InteractionHand hand,float swing,ItemStack stack,float equip,PoseStack pose,MultiBufferSource buffer,int light,CallbackInfo ci){
        CombatPresentation.firstPerson(pose,player,hand,partial,stack);
    }
}
