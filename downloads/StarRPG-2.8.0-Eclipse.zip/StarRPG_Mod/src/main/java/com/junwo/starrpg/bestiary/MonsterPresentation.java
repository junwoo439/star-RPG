package com.junwo.starrpg.bestiary;

/** Shared visual protocol IDs, without any client class references. */
public final class MonsterPresentation {
    public static int breath(BestiaryKind k){
        if(k.family!=BestiaryKind.Family.DRAGON||!k.boss)return -1;
        return switch(k.move){case FIRE->40;case FROST->41;case POISON->42;case LIGHTNING->43;case LIGHT->44;default->-1;};
    }
}
