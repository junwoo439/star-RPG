package com.junwo.starrpg;

import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ArmorItem;

public class EnhancementMenu extends AbstractContainerMenu {

	private final Player owner;
    private final net.minecraft.world.inventory.ContainerLevelAccess access;
    private final SimpleContainer enhancementInventory = new SimpleContainer(3);

    public EnhancementMenu(int containerId, Inventory playerInventory) {this(containerId,playerInventory,net.minecraft.world.inventory.ContainerLevelAccess.NULL);}
    public EnhancementMenu(int containerId, Inventory playerInventory,net.minecraft.world.inventory.ContainerLevelAccess access) {
        super(ModMenus.ENHANCEMENT_MENU.get(), containerId);
        this.owner=playerInventory.player;this.access=access;

        // 0번: 강화할 장비 칸
        this.addSlot(new Slot(enhancementInventory, 0, 35, 35) {
        	@Override
        	public boolean mayPlace(ItemStack stack) {
            return EnhancementData.supports(stack);
        	}

            @Override
            public int getMaxStackSize() {
                return 1;
            }
        });

        // 1번: 별가루 칸
        this.addSlot(new Slot(enhancementInventory, 1, 89, 35) {
            @Override
            public boolean mayPlace(ItemStack stack) {
                return stack.is(StarRPG.STAR_DUST.get());
            }
        });
        
        // 2번: 별조각 칸
        this.addSlot(new Slot(enhancementInventory, 2, 143, 35) {
            @Override
            public boolean mayPlace(ItemStack stack) {
                return stack.is(StarRPG.STAR_FRAGMENT.get());
            }
        });
        
        
        // 플레이어 인벤토리
        for (int row = 0; row < 3; row++) {
            for (int column = 0; column < 9; column++) {
                this.addSlot(new Slot(
                        playerInventory,
                        column + row * 9 + 9,
                        8 + column * 18,
                        135 + row * 18
                ));
            }
        }

        // 핫바
        for (int column = 0; column < 9; column++) {
            this.addSlot(new Slot(
                    playerInventory,
                    column,
                    8 + column * 18,
                    193
            ));
        }
    }

    @Override
    public boolean stillValid(Player player) {
        return player==owner && player.isAlive() && stillValid(access,player,net.minecraft.world.level.block.Blocks.ENCHANTING_TABLE);
    }

    @Override
    public void removed(Player player) {
        super.removed(player);
        this.clearContainer(player, enhancementInventory);
    }

    @Override
    public boolean clickMenuButton(Player player, int buttonId) {
        if (player.level().isClientSide() || buttonId != 0 || !stillValid(player) || player.isSpectator() || ControlEffects.stunned(player)) return false;
        ItemStack weapon = enhancementInventory.getItem(0);
        ItemStack dust = enhancementInventory.getItem(1);
        ItemStack fragment = enhancementInventory.getItem(2);
        if (!EnhancementData.supports(weapon)) return false;
        int level = EnhancementData.level(weapon);
        if (level >= EnhancementData.limit(weapon)) return false;
        int dustCost = getRequiredDust(level), fragmentCost = getRequiredFragment(level);
        if (!dust.is(StarRPG.STAR_DUST.get()) || dust.getCount() < dustCost
                || (fragmentCost > 0 && (!fragment.is(StarRPG.STAR_FRAGMENT.get())
                || fragment.getCount() < fragmentCost))) {
            player.sendSystemMessage(Component.literal("강화 재료가 부족합니다."));
            return false;
        }
        dust.shrink(dustCost);
        fragment.shrink(fragmentCost);
        boolean success = player.getRandom().nextInt(100) < getSuccessChance(weapon);
        if (success) {
            EnhancementData.setLevel(weapon, level + 1);
            player.sendSystemMessage(Component.literal("강화 성공! +" + (level + 1)));
        } else {
            EnhancementData.recordFailure(weapon);
            player.sendSystemMessage(Component.literal("강화 실패: 단계 유지, 다음 성공 확률 상승"));
        }
        EnhancementLore.update(weapon);
        PresentationCues.play(player,success?PresentationCues.UPGRADE:PresentationCues.FAILURE,EnhancementData.level(weapon),success?PresentationCues.enhancementColor(EnhancementData.level(weapon)):0xA8A8BA);
        player.level().playSound(null, player.blockPosition(), success ? SoundEvents.PLAYER_LEVELUP
                : SoundEvents.ITEM_BREAK, SoundSource.PLAYERS, 0.7F, 1.0F);
        broadcastChanges();
        return true;
    }
    private static int cost(java.util.List<? extends Integer> values, int level, int[] fallback) {
        return values.size() == 10 ? values.get(level) : fallback[level];
    }
    public static int getRequiredDust(int level) {
        return level >= 0 && level < 10 ? cost(Config.DUST_COSTS.get(), level, new int[]{1,2,3,4,5,6,8,10,12,15}) : level>=10?(int)Math.min(64L,18L+(level-10L)/2):0;
    }
    public static int getRequiredFragment(int level) {
        return level >= 0 && level < 10 ? cost(Config.FRAGMENT_COSTS.get(), level, new int[]{0,0,0,0,0,1,1,2,3,5}) : level>=10?(int)Math.min(64L,6L+(level-10L)/3):0;
    }
    public static int getSuccessChance(int level) {
        return level >= 0 && level < 10 ? cost(Config.SUCCESS_CHANCES.get(), level, new int[]{100,95,90,85,80,75,65,55,45,30}) : level>=10?Math.max(5,(int)Math.round(30/(1+(level-9)/12.0))):0;
    }
    public static int getSuccessChance(ItemStack stack) {
        int level = EnhancementData.level(stack);
        return level >= EnhancementData.limit(stack) ? 0 : Math.min(100, getSuccessChance(level)
                + EnhancementData.failures(stack) * Config.PITY_BONUS.get());
    }
    public static int getDestroyChance(int level) { return 0; }

    @Override
    public ItemStack quickMoveStack(Player player, int slotIndex) {
        if(player!=owner||slotIndex<0||slotIndex>=slots.size())return ItemStack.EMPTY;
        var slot=slots.get(slotIndex);if(!slot.hasItem())return ItemStack.EMPTY;var stack=slot.getItem();var copy=stack.copy();
        if(slotIndex<3){if(!moveItemStackTo(stack,3,slots.size(),true))return ItemStack.EMPTY;}
        else if(EnhancementData.supports(stack)){if(!moveItemStackTo(stack,0,1,false))return ItemStack.EMPTY;}
        else if(stack.is(StarRPG.STAR_DUST.get())){if(!moveItemStackTo(stack,1,2,false))return ItemStack.EMPTY;}
        else if(stack.is(StarRPG.STAR_FRAGMENT.get())){if(!moveItemStackTo(stack,2,3,false))return ItemStack.EMPTY;}
        else return ItemStack.EMPTY;
        if(stack.isEmpty())slot.setByPlayer(ItemStack.EMPTY);else slot.setChanged();slot.onTake(player,stack);return copy;
    }
}
