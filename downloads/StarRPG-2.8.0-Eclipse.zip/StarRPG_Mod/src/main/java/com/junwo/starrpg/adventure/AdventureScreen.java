package com.junwo.starrpg.adventure;
import com.junwo.starrpg.*;
import com.junwo.starrpg.bestiary.*;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
public final class AdventureScreen extends AbstractContainerScreen<AdventureMenu> {
    private int tab,page,lastJob=-1,entry=-1;
    public AdventureScreen(AdventureMenu m,Inventory inv,Component title){super(m,inv,title);imageWidth=360;imageHeight=250;inventoryLabelY=10000;tab=title.getString().contains("의뢰")?4:0;}
    @Override protected void init(){super.init();build();}
    @Override protected void containerTick(){super.containerTick();if(lastJob!=menu.value(10)){lastJob=menu.value(10);build();}}
    private void button(String title,int x,int y,int w,Runnable action){addRenderableWidget(Button.builder(Component.literal(title),b->action.run()).bounds(leftPos+x,topPos+y,w,18).build());}
    private void action(String title,int id,int x,int y,int w){button(title,x,y,w,()->minecraft.gameMode.handleInventoryButtonClick(menu.containerId,id));}
    private void build(){clearWidgets();String[] tabs={"생활 직업","스킬 트리","몬스터 도감","전설 제작","의뢰"};for(int i=0;i<5;i++){final int n=i;button(tabs[i],8+i*69,26,66,()->{tab=n;page=0;entry=-1;build();});}
        if(tab==0){for(int i=0;i<4;i++)action(LifeJobs.NAMES[i]+" 선택",i,205,55+i*28,145);action("합금 제작",10,205,175,145);}
        if(tab==1){int job=menu.value(10)-1;if(job>=0){action(SkillTrees.NAMES[job][0],20,12,90,163);action(SkillTrees.NAMES[job][1],21,185,90,163);action("경로 초기화 · 500G",22,100,205,165);}}
        if(tab==2&&entry>=0){button("목록으로",12,210,90,()->{entry=-1;build();});}
        if(tab==2&&entry<0){for(int i=0;i<6;i++){int n=page*6+i;if(n<53){final int row=n;button("정보",198,53+i*25,64,()->{entry=row;build();});action("10회 보상",100+n,270,53+i*25,78);}}button("◀",10,213,40,()->{page=Math.max(0,page-1);build();});button("▶",55,213,40,()->{page=Math.min(8,page+1);build();});action("53종 수집 완료 보상",200,154,213,195);}
        if(tab==4){action("메인 의뢰 수락",400,12,120,160);action("메인 보상 받기",401,185,120,160);action("오늘의 의뢰 수락",402,12,182,160);action("일일 보상 받기",403,185,182,160);}
        if(tab==3){for(int i=0;i<4;i++)action("제작",300+page*4+i,280,57+i*36,65);button("◀",10,215,40,()->{page=Math.max(0,page-1);build();});button("▶",55,215,40,()->{page=Math.min(2,page+1);build();});}
    }
    @Override protected void renderBg(GuiGraphics g,float partial,int x,int y){g.fillGradient(leftPos,topPos,leftPos+imageWidth,topPos+imageHeight,0xFF24364B,0xFF0B1420);}
    private void text(GuiGraphics g,String s,int x,int y,int color){g.drawString(font,s,x,y,color,false);}
    @Override protected void renderLabels(GuiGraphics g,int x,int y){text(g,"별빛 모험 기록",10,8,0xF6D98C);
        if(tab==0){int job=menu.value(0)-1;for(int i=0;i<4;i++)text(g,(job==i?"▶ ":"")+LifeJobs.NAMES[i]+" Lv."+menu.value(1+i)+"  XP "+menu.value(5+i)+"/100",12,60+i*28,job==i?0xFFD46A:0xD9E6F4);text(g,"희귀 광석 "+menu.value(14)+" / 별철 합금 "+menu.value(15),12,175,0x83D6F8);text(g,"합금: 광석 3 + 철 2 + 석탄 2 / 생활 대장장이",12,201,0xBACADD);text(g,"광부 → 희귀 광석 → 대장장이 → 전설 장비",12,224,0xC7DDCC);}
        if(tab==1){int job=menu.value(10)-1;if(job<0){text(g,"전투 직업을 먼저 선택하세요.",14,65,0xE5D5AA);return;}text(g,Careers.NAMES[job]+" · 선택 경로 "+menu.value(11)+" · 습득 "+menu.value(12)+"/"+menu.value(13),12,59,0xDCE7F4);text(g,"1·4·7차에서 1개씩, 한 경로의 3단계 성장",12,124,0xC1CFDD);text(g,"공격 경로: 단계마다 직접 피해 +8%",12,145,0xFFB18A);text(g,"보조 경로: 단계마다 방어 +1, 직업별 특성",12,164,0x9CCFEA);text(g,"암살자·궁수·격투가 기동 / 원소·사신 특수 효과",12,182,0xB4D3BD);}
        if(tab==2&&entry>=0){var k=BestiaryKind.values()[entry];if(menu.value(30+entry)==0){text(g,"미발견 · 몬스터를 가까이에서 관찰하세요",12,70,0xAABACD);}else{text(g,k.name+(k.boss?" · 보스":""),12,55,0xF1D490);text(g,"출현: "+JournalText.region(k)+" · 월드 "+k.minTier+"단계 이상",12,77,0xC3D4E5);text(g,"공격: "+JournalText.attack(k),12,99,0xD9BBAB);text(g,k.parryable()?"강공격: 금색 예고 · V 패링 가능":"강공격: 빨간 예고 · 회피 필요",12,121,0xDBBDA7);text(g,"전리품: "+JournalText.drops(k),12,143,0xB6D8BA);text(g,"처치 "+menu.value(90+entry)+"회 / 수집 보상 "+(menu.value(150+entry)>0?"수령":"10회 필요"),12,165,0xA9C7DE);if(k.boss)text(g,"체력 50%·25%에서 새 전투 단계",12,187,0xDEB2AB);}}
        if(tab==2&&entry<0){for(int i=0;i<6;i++){int n=page*6+i;if(n>=53)break;var k=BestiaryKind.values()[n];boolean seen=menu.value(30+n)>0;text(g,seen?k.name:"미발견 몬스터",12,56+i*25,seen?0xF2D99B:0x7A8798);text(g,seen?JournalText.region(k)+" · "+menu.value(90+n)+"회":"탐험하여 정보를 해금하세요",12,66+i*25,0xB0C1D3);}text(g,"지역·속성/공격 정보는 발견 시, 보상은 10회 처치",12,238,0x98B2C7);}
        if(tab==4){int c=Math.min(5,menu.value(210)),d=menu.value(214);text(g,Quests.TITLES[c],12,55,0xF2D48D);text(g,Quests.STORY[c],12,76,0xBFCFE3);text(g,"메인 진행: "+menu.value(212)+"/"+menu.value(213)+(menu.value(211)>0?" · 수락 중":" · 수락 필요"),12,98,0x8DC9C5);text(g,Quests.DAILY_NAMES[d]+(menu.value(218)>0?" · 오늘 완료":menu.value(217)>0?" · "+Math.max(0,menu.value(215))+"/"+menu.value(216):" · 수락 후 시작"),12,154,0xE2D5AD);text(g,menu.value(219)>0?"기록관 아린과 대화 중":"마을 기록관 근처에서 수락·보상받기",12,211,0xA9C4DE);text(g,"던전 "+menu.value(220)+"회 / 균열 봉인 "+menu.value(221)+"회",12,232,0xC4C4D9);}
        if(tab==3){String[] titles={"적룡의 유산","리치의 영혼","고대 골렘"};text(g,titles[page]+" 세트 · 2/4부위 효과",12,51,0xF1CD85);for(int i=0;i<4;i++){var stack=new net.minecraft.world.item.ItemStack(LegendarySets.PIECES.get(page*4+i).get());g.renderItem(stack,12,71+i*36);text(g,stack.getHoverName().getString(),34,75+i*36,0xCCD9EB);}text(g,"합금4·보스재료2·다이아2·약초1·비늘1",12,193,0xAFCCBB);text(g,"유적의 잔영1 · 균열 파편1",110,222,0xAFCCBB);}
    }
    @Override public void render(GuiGraphics g,int x,int y,float partial){super.render(g,x,y,partial);renderTooltip(g,x,y);}
}
