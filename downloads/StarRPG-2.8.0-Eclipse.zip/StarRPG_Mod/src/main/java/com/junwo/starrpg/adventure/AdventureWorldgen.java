package com.junwo.starrpg.adventure;
import com.junwo.starrpg.StarRPG;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.neoforged.neoforge.registries.*;
public final class AdventureWorldgen {
    public static final DeferredHolder<net.minecraft.world.level.block.Block,TrialCoreBlock> CORE=StarRPG.BLOCKS.register("trial_core",TrialCoreBlock::new);
    public static final DeferredItem<net.minecraft.world.item.BlockItem> CORE_ITEM=StarRPG.ITEMS.register("trial_core",()->new net.minecraft.world.item.BlockItem(CORE.get(),new net.minecraft.world.item.Item.Properties()));
    public static final DeferredRegister<Feature<?>> FEATURES=DeferredRegister.create(Registries.FEATURE,StarRPG.MODID);
    public static final DeferredHolder<Feature<?>,DungeonFeature> DUNGEON=FEATURES.register("star_dungeon",DungeonFeature::new);
    public static void init(net.neoforged.bus.api.IEventBus bus){FEATURES.register(bus);}
}
