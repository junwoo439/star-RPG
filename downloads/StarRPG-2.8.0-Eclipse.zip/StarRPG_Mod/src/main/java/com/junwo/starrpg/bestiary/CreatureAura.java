package com.junwo.starrpg.bestiary;

import com.junwo.starrpg.*;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;

/** Small local creature accents; no new entities, collisions, damage or status effects. */
public final class CreatureAura {
    public static void render(BestiaryMob m,float partial,PoseStack p,MultiBufferSource b){
        if(!VisualOptions.AURAS.get()||!m.isAlive()||m.isInvisible())return;
        float age=m.tickCount+partial,scale=m.kind.scale(),r=Math.max(.4F,m.getBbWidth()*.45F);int color=m.kind.color;
        boolean charging=m.phase()==BestiaryMob.HEAVY;
        if(m.kind.family==BestiaryKind.Family.ELEMENTAL||m.kind==BestiaryKind.LICH||m.kind==BestiaryKind.SOLAR||m.kind==BestiaryKind.ANCIENT_GOLEM){
            p.pushPose();CinematicVfx.seal(p,b,r,age,color,charging?.65F:.22F);
            if(VisualOptions.quality()>0){p.translate(0,m.getBbHeight()*.6,0);for(int i=0;i<3;i++){p.pushPose();p.mulPose(Axis.YP.rotation(age*.012F+i*2.094F));p.translate(r*.7,Math.sin(age*.04+i)*.15,0);p.mulPose(Axis.ZP.rotation(age*.02F));CinematicVfx.crystal(p,b,.08F*scale,.22F*scale,color,.6F);p.popPose();}}p.popPose();
        }
        if(charging&&m.kind.family==BestiaryKind.Family.DRAGON){
            p.pushPose();p.mulPose(Axis.YP.rotationDegrees(-m.yBodyRot));p.translate(0,m.getBbHeight()*.72,m.getBbWidth()*.55);p.mulPose(Axis.ZP.rotation(age*.06F));CinematicVfx.sprite(p,b,0,.5F*scale,.5F*scale,color,.5F);CinematicVfx.sprite(p,b,7,.25F*scale,.25F*scale,color,.75F);p.popPose();
        }
        if(m.kind.body==BestiaryKind.Body.GHOST&&VisualOptions.quality()>0){p.pushPose();p.translate(0,.5,0);p.mulPose(Axis.YP.rotation(age*.015F));CinematicVfx.sprite(p,b,9,.5F,.7F,color,.2F);p.popPose();}
    }
}
