package com.junwo.starrpg.bestiary;

import com.junwo.starrpg.*;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.*;

/** Server-authoritative dragon choreography. Visual proxies never decide hits or spawn projectiles. */
public final class DragonBattle {
    public static final int NONE=0,BITE=1,BREATH=2,TAIL=3,WING=4,DIVE=5;
    public static boolean dragon(BestiaryMob m){return m.kind.body==BestiaryKind.Body.DRAGON;}
    public static Vec3 forward(float yaw){return new Vec3(-Math.sin(Math.toRadians(yaw)),0,Math.cos(Math.toRadians(yaw)));}
    public static Vec3 mouth(BestiaryMob m,Vec3 direction){return m.position().add(direction.multiply(1,0,1).normalize().scale(net.neoforged.fml.ModList.get().isLoaded("iceandfire")?4.5:2.6)).add(0,net.neoforged.fml.ModList.get().isLoaded("iceandfire")?2.8:2.2,0);}
    public static int element(BestiaryMob m){return switch(m.kind.move){case FROST->53;case POISON->54;case LIGHTNING->55;case LIGHT->56;default->52;};}
    public static boolean start(BestiaryMob m,LivingEntity target,boolean heavy){
        if(!dragon(m))return false;
        if(!heavy){m.dragonAction(BITE);return false;}
        int sequence=m.getPersistentData().getInt("starrpg_dragon_combo");m.getPersistentData().putInt("starrpg_dragon_combo",sequence+1);
        int action=switch(Math.floorMod(sequence,3)){case 1->TAIL;case 2->WING;default->BREATH;};
        if(target.position().subtract(m.position()).multiply(1,0,1).normalize().dot(forward(m.yBodyRot))<-.3)action=TAIL;
        m.dragonAction(action);m.heavyAttack=true;m.attackOrigin=m.position();m.attackPoint=target.position();
        m.attackDirection=(action==TAIL?forward(m.yBodyRot):target.position().subtract(m.position()).multiply(1,0,1).normalize());
        int windup=action==BREATH?40:action==TAIL?30:32;m.phase(BestiaryMob.HEAVY,windup);m.getNavigation().stop();
        if(action!=TAIL){m.setYRot((float)Math.toDegrees(Math.atan2(-m.attackDirection.x,m.attackDirection.z)));m.yBodyRot=m.getYRot();}
        if(m.level() instanceof ServerLevel l)ArcaneSigil.spawn(l,m.attackOrigin.add(0,.08,0),m.attackDirection,action==BREATH?37:38,action==BREATH?0xFF453A:0xFFC84D,action==BREATH?10:5.5F,windup);
        m.playSound(SoundEvents.ENDER_DRAGON_GROWL,.8F,action==BREATH?.8F:.65F);return true;
    }
    public static boolean groundTick(BestiaryMob m){
        int action=m.dragonAction();if(!dragon(m)||action<BREATH||action>DIVE||m.phase()==BestiaryMob.IDLE||m.phase()==BestiaryMob.STAGGER)return false;
        if(!m.isAlive()||ControlEffects.stunned(m)||ControlEffects.rooted(m)||!BestiaryCombat.valid(m,m.getTarget())){
            m.dragonAction(NONE);m.phase(BestiaryMob.RECOVERY,20);m.nextAttack=m.level().getGameTime()+30;return true;
        }
        m.getNavigation().stop();m.setDeltaMovement(0,m.getDeltaMovement().y,0);
        int left=m.remaining()-1;m.countdown(left);
        if(m.phase()==BestiaryMob.HEAVY){if(action==BREATH&&left%8==0){Vec3 mouth=mouth(m,m.attackDirection);beam(m,mouth,mouth.add(m.attackDirection.scale(.4)),10);}if(left<=0){m.phase(BestiaryMob.ACTIVE,action==BREATH?48:4);if(action!=BREATH)melee(m,action);}return true;}
        if(m.phase()==BestiaryMob.ACTIVE&&action==BREATH){
            int elapsed=m.duration()-m.remaining();double angle=Math.toRadians(-30+60*elapsed/(double)m.duration());Vec3 direction=m.attackDirection.yRot((float)angle);Vec3 from=mouth(m,direction);double distance=Math.max(3,m.attackPoint.subtract(m.attackOrigin).horizontalDistance()),offset=from.subtract(m.position()).horizontalDistance();double slope=(m.attackPoint.y+m.getTarget().getBbHeight()*.55-from.y)/Math.max(1,distance-offset);Vec3 end=m.attackOrigin.add(direction.scale(10));end=new Vec3(end.x,from.y+slope*(10-offset),end.z);m.getLookControl().setLookAt(end.x,end.y,end.z,15,15);
            if(elapsed%4==0)beam(m,from,end,12);
            if(elapsed%12==0)breathHit(m,from,end,.48F);
        }
        if(left<=0){if(m.phase()==BestiaryMob.ACTIVE){m.phase(BestiaryMob.RECOVERY,action==BREATH?38:32);m.nextAttack=m.level().getGameTime()+m.duration()+15;}else{m.dragonAction(NONE);m.phase(BestiaryMob.IDLE,0);}}return true;
    }
    private static void melee(BestiaryMob m,int action){
        if(!(m.level() instanceof ServerLevel l))return;
        int count=0;for(var target:l.getEntitiesOfClass(LivingEntity.class,m.getBoundingBox().inflate(5.5),t->(t instanceof Player||t==m.getTarget())&&BestiaryCombat.valid(m,t))){
            var delta=target.position().subtract(m.attackOrigin);if(delta.lengthSqr()>30.25||Math.abs(delta.y)>3||!m.hasLineOfSight(target))continue;
            if(action==TAIL&&delta.multiply(1,0,1).normalize().dot(m.attackDirection)>.4)continue;
            if(++count>6)break;impact(m,target,action==TAIL?1.7F:1.05F,true,true);
            if(m.phase()==BestiaryMob.STAGGER)break;
            target.knockback(action==WING?1.1:.65,m.getX()-target.getX(),m.getZ()-target.getZ());target.hurtMarked=true;
        }
        if(m.phase()!=BestiaryMob.STAGGER)ArcaneSigil.spawn(l,m.position().add(0,.15,0),m.attackDirection,action==TAIL?18:21,m.kind.color,5.5F,24);
        m.playSound(action==TAIL?SoundEvents.PLAYER_ATTACK_SWEEP:SoundEvents.ENDER_DRAGON_FLAP,1,.7F);
    }
    public static Vec3 clipped(BestiaryMob m,Vec3 from,Vec3 to){
        var hit=m.level().clip(new ClipContext(from,to,ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,m));return hit.getType()==HitResult.Type.MISS?to:hit.getLocation();
    }
    public static void beam(BestiaryMob m,Vec3 from,Vec3 to,int life){
        if(!(m.level() instanceof ServerLevel l))return;var end=clipped(m,from,to);var delta=end.subtract(from);double length=delta.length();
        if(length>.2)ArcaneSigil.spawn(l,from,delta.normalize(),element(m),m.kind.color,(float)Math.min(10,length),life);
    }
    public static void breathHit(BestiaryMob m,Vec3 from,Vec3 to,float multiplier){
        if(!(m.level() instanceof ServerLevel l))return;Vec3 end=clipped(m,from,to);
        int count=0;for(var target:l.getEntitiesOfClass(LivingEntity.class,new AABB(from,end).inflate(1),t->(t instanceof Player||t==m.getTarget())&&BestiaryCombat.valid(m,t))){
            if(target.getBoundingBox().inflate(.6).clip(from,end).isEmpty()&&!target.getBoundingBox().inflate(.6).contains(from))continue;
            if(!m.hasLineOfSight(target)||++count>6)continue;
            if(impact(m,target,multiplier,false,false))switch(m.kind.move){case FIRE->target.igniteForSeconds(2);case FROST->target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,30,1));case POISON->target.addEffect(new MobEffectInstance(MobEffects.POISON,40));case LIGHT->target.addEffect(new MobEffectInstance(MobEffects.GLOWING,50));default->{}}
        }
    }
    private static boolean impact(BestiaryMob m,LivingEntity target,float multiplier,boolean parry,boolean stun){
        float before=target.getHealth();boolean hit;m.parryableImpact=parry;
        try{hit=target.hurt(m.damageSources().mobAttack(m),(float)m.getAttributeValue(Attributes.ATTACK_DAMAGE)*multiplier);}finally{m.parryableImpact=false;}
        if(hit&&target.getHealth()<before&&stun&&target.getPersistentData().getLong("starrpg_heavy_stun_guard")<=m.level().getGameTime()){
            target.addEffect(new MobEffectInstance(ModEffects.STUN,12));target.getPersistentData().putLong("starrpg_heavy_stun_guard",m.level().getGameTime()+100);
        }return hit&&target.getHealth()<before;
    }
    public static void beginFlight(BestiaryMob m){
        var t=m.getPersistentData();t.putInt("starrpg_flight_age",1);t.putDouble("starrpg_flight_ground",m.getY());t.putDouble("starrpg_flight_x",m.getX());t.putDouble("starrpg_flight_z",m.getZ());
        var target=m.getTarget();t.putDouble("starrpg_flight_center_x",target.getX());t.putDouble("starrpg_flight_center_z",target.getZ());
        t.putInt("starrpg_flight_mode",BossPhases.stage(m)>=2?DIVE:BREATH);m.setNoGravity(true);m.getNavigation().stop();m.dragonAction(NONE);
        m.phase(BestiaryMob.RECOVERY,30);m.playSound(SoundEvents.ENDER_DRAGON_FLAP,1.2F,.7F);
    }
    private static double smooth(double n){n=Math.clamp(n,0,1);return n*n*(3-2*n);}
    public static void air(BestiaryMob m,ServerLevel l){
        var t=m.getPersistentData();int age=t.getInt("starrpg_flight_age");double ground=t.getDouble("starrpg_flight_ground");
        if(!BestiaryCombat.valid(m,m.getTarget())||ControlEffects.stunned(m)||ControlEffects.rooted(m)){BossPhases.land(m);return;}
        if(!t.contains("starrpg_flight_x")){BossPhases.land(m);return;}m.getNavigation().stop();m.setNoGravity(true);
        var target=m.getTarget();double sx=t.getDouble("starrpg_flight_x"),sz=t.getDouble("starrpg_flight_z"),cx=t.getDouble("starrpg_flight_center_x"),cz=t.getDouble("starrpg_flight_center_z");
        double radius=Math.max(4,Math.hypot(sx-cx,sz-cz)),angle=Math.atan2(sz-cz,sx-cx)+Math.max(0,Math.min(age,105)-36)*.012;
        double orbit=smooth((age-30)/30.0)*(1-smooth((age-105)/55.0));double x=sx+(cx+Math.cos(angle)*radius-sx)*orbit,z=sz+(cz+Math.sin(angle)*radius-sz)*orbit;
        double height=ground+7*smooth(age/36.0)*(1-smooth((age-105)/60.0));boolean dive=t.getInt("starrpg_flight_mode")==DIVE;
        if(age==40){t.putDouble("starrpg_bomb_x",target.getX());t.putDouble("starrpg_bomb_y",target.getY());t.putDouble("starrpg_bomb_z",target.getZ());if(!dive)ArcaneSigil.spawn(l,target.position().add(0,.08,0),new Vec3(0,0,1),38,0xFF3548,3.5F,36);}
        var locked=new Vec3(t.getDouble("starrpg_bomb_x"),t.getDouble("starrpg_bomb_y"),t.getDouble("starrpg_bomb_z"));
        if(!dive&&age>=68&&age<=88){m.dragonAction(BREATH);if(age%4==0)beam(m,mouth(m,locked.subtract(m.position())),locked,12);}
        if(!dive&&age==76)blast(m,locked,3.5,2);
        if(dive&&age==100){t.putDouble("starrpg_dive_x",target.getX());t.putDouble("starrpg_dive_y",target.getY());t.putDouble("starrpg_dive_z",target.getZ());ArcaneSigil.spawn(l,target.position().add(0,.08,0),new Vec3(0,0,1),38,0xFF3548,4,58);m.playSound(SoundEvents.ENDER_DRAGON_GROWL,1,.65F);}
        if(dive&&age>=112){m.dragonAction(DIVE);double blend=smooth((age-112)/42.0);x=x*(1-blend)+t.getDouble("starrpg_dive_x")*blend;z=z*(1-blend)+t.getDouble("starrpg_dive_z")*blend;height=height*(1-blend)+t.getDouble("starrpg_dive_y")*blend;}
        if(!dive&&age>90)m.dragonAction(NONE);
        var velocity=m.getDeltaMovement();var desired=new Vec3(x-m.getX(),0,z-m.getZ()).scale(.12);if(desired.length()>.45)desired=desired.normalize().scale(.45);
        m.setDeltaMovement(velocity.x*.65+desired.x*.35,Math.clamp(velocity.y*.55+(height-m.getY())*.1,-.4,.35),velocity.z*.65+desired.z*.35);
        float facing=(float)Math.toDegrees(Math.atan2(m.getX()-target.getX(),target.getZ()-m.getZ()));m.setYRot(Mth.rotLerp(.06F,m.getYRot(),facing));m.yBodyRot=Mth.rotLerp(.1F,m.yBodyRot,m.getYRot());m.getLookControl().setLookAt(target,12,12);
        if(dive&&age==158){var at=new Vec3(t.getDouble("starrpg_dive_x"),t.getDouble("starrpg_dive_y"),t.getDouble("starrpg_dive_z"));if(m.position().distanceToSqr(at)<25)blast(m,at,4,1.8F);}
        if(age>=205||age>(dive?159:150)&&(m.onGround()||m.getY()<=Math.min(ground,height)+.35)){BossPhases.land(m);return;}t.putInt("starrpg_flight_age",age+1);
    }
    private static void blast(BestiaryMob m,Vec3 at,double radius,float multiplier){
        if(!(m.level() instanceof ServerLevel l))return;ArcaneSigil.spawn(l,at,new Vec3(0,0,1),m.kind.move==BestiaryKind.Move.FROST?26:24,m.kind.color,(float)radius,32);
        int count=0;for(var victim:l.getEntitiesOfClass(LivingEntity.class,new AABB(at,at).inflate(radius),t->(t instanceof Player||t==m.getTarget())&&BestiaryCombat.valid(m,t))){if(Math.abs(victim.getY()-at.y)>2||victim.distanceToSqr(at)>radius*radius||!m.hasLineOfSight(victim)||++count>6)continue;impact(m,victim,multiplier,false,true);}
        m.playSound(SoundEvents.GENERIC_EXPLODE.value(),.8F,.7F);
    }
}
