package com.junwo.starrpg.bestiary;

import com.junwo.starrpg.*;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.phys.*;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.*;
import net.neoforged.fml.common.EventBusSubscriber;

/** Health thresholds are one-way. Healing and reloading cannot repeatedly trigger reinforcements. */
@EventBusSubscriber(modid=StarRPG.MODID)
public final class BossPhases {
    private static final ResourceLocation POWER=ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,"boss_phase_power");
    public static int stage(BestiaryMob m){return !m.kind.boss?0:Math.max(m.getPersistentData().getInt("starrpg_boss_phase"),m.getHealth()<=m.getMaxHealth()*.25F?2:m.getHealth()<=m.getMaxHealth()*.5F?1:0);}
    public static boolean flying(BestiaryMob m){return m.getPersistentData().getInt("starrpg_flight_age")>0;}
    public static void tick(BestiaryMob m){
        if(!(m.level() instanceof ServerLevel l)||!m.kind.boss||m.isNoAi())return;
        var tag=m.getPersistentData();int phase=Math.max(stage(m),tag.getInt("starrpg_boss_phase"));
        if(phase>0){var damage=m.getAttribute(Attributes.ATTACK_DAMAGE);var old=damage.getModifier(POWER);if(old==null||old.amount()!=phase*.15)damage.addOrUpdateTransientModifier(new AttributeModifier(POWER,phase*.15,AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));}
        if(phase>tag.getInt("starrpg_boss_phase")&&m.lifeTicks()>40&&BestiaryCombat.valid(m,m.getTarget())){
            tag.putInt("starrpg_boss_phase",phase);m.phase(BestiaryMob.RECOVERY,30);m.nextAttack=l.getGameTime()+35;
            ArcaneSigil.spawn(l,m.position().add(0,.1,0),new Vec3(0,0,1),38,0xFF4545,4,30);
            if((m.kind.body==BestiaryKind.Body.DRAGON||m.kind.body==BestiaryKind.Body.WYVERN)&&l.canSeeSky(m.blockPosition().above())){
                if(!flying(m))DragonBattle.beginFlight(m);
            }else reinforce(m,l,phase);
        }
        if(DragonBattle.dragon(m)&&phase>0&&!flying(m)&&m.lifeTicks()>100&&BestiaryCombat.valid(m,m.getTarget())&&m.distanceToSqr(m.getTarget())>64&&tag.getLong("starrpg_flight_ready")<=l.getGameTime()&&l.canSeeSky(m.blockPosition().above()))DragonBattle.beginFlight(m);
        if(flying(m))air(m,l);
    }
    private static void reinforce(BestiaryMob m,ServerLevel l,int phase){
        BestiaryKind kind=switch(m.kind.family){case UNDEAD->BestiaryKind.GRAVE_SKELETON;case BEAST->BestiaryKind.DIRE_WOLF;case FIEND->BestiaryKind.INCUBUS;case CELESTIAL->BestiaryKind.AASIMAR;case CONSTRUCT->BestiaryKind.ANIMATED_ARMOR;case GIANT,ELEMENTAL->BestiaryKind.AIR_ELEMENTAL;case DRAGON->BestiaryKind.WYVERN;default->BestiaryKind.GOBLIN;};
        for(int i=0;i<2;i++){var n=BestiaryRegistry.TYPES.get(kind).get().create(l);var pos=m.position().add(i==0?-2:2,0,1);if(!l.getBlockState(net.minecraft.core.BlockPos.containing(pos)).isAir())continue;n.moveTo(pos.x,pos.y,pos.z,0,0);n.setTarget(m.getTarget());n.getPersistentData().putUUID("starrpg_summoner",m.getUUID());n.getPersistentData().putLong("starrpg_summon_expiry",l.getGameTime()+1200);l.addFreshEntity(n);}
    }
    private static void air(BestiaryMob m,ServerLevel l){DragonBattle.air(m,l);}
    public static void land(BestiaryMob m){m.getPersistentData().remove("starrpg_flight_age");m.getPersistentData().putLong("starrpg_flight_ready",m.level().getGameTime()+(stage(m)>=2?420:550));m.dragonAction(DragonBattle.NONE);m.setNoGravity(false);m.phase(BestiaryMob.RECOVERY,35);m.nextAttack=m.level().getGameTime()+40;}
    @SubscribeEvent(priority=EventPriority.HIGHEST) public static void summonDrops(net.neoforged.neoforge.event.entity.living.LivingDropsEvent e){if(e.getEntity().getPersistentData().hasUUID("starrpg_summoner"))e.setCanceled(true);}
    @SubscribeEvent public static void summonXp(net.neoforged.neoforge.event.entity.living.LivingExperienceDropEvent e){if(e.getEntity().getPersistentData().hasUUID("starrpg_summoner"))e.setDroppedExperience(0);}
    @SubscribeEvent public static void expire(net.neoforged.neoforge.event.tick.EntityTickEvent.Post e){var entity=e.getEntity();if(!(entity.level() instanceof ServerLevel l)||!entity.getPersistentData().hasUUID("starrpg_summoner"))return;var boss=l.getEntity(entity.getPersistentData().getUUID("starrpg_summoner"));if(entity.getPersistentData().getLong("starrpg_summon_expiry")<=l.getGameTime()||!(boss instanceof BestiaryMob b)||!b.isAlive())entity.discard();}
}
