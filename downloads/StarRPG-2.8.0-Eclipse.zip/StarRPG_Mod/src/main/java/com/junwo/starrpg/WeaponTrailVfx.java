package com.junwo.starrpg;

import com.mojang.blaze3d.vertex.*;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.*;

/** Animated 3-D ribbons: colored halo, narrow white core, tapered head and sparks. */
public final class WeaponTrailVfx {
    private static void vertex(PoseStack p,VertexConsumer out,float x,float y,float z,int color,float alpha){out.addVertex(p.last(),x,y,z).setColor((color>>16)&255,(color>>8)&255,color&255,(int)(Math.clamp(alpha,0,1)*255));}
    private static void segment(PoseStack p,VertexConsumer out,float a,float b,float radius,float width,int color,float alpha,float height){
        float[][] pts={{(float)Math.sin(a)*(radius-width),height,(float)Math.cos(a)*(radius-width)},
            {(float)Math.sin(a)*(radius+width),height,(float)Math.cos(a)*(radius+width)},
            {(float)Math.sin(b)*(radius+width),height,(float)Math.cos(b)*(radius+width)},
            {(float)Math.sin(b)*(radius-width),height,(float)Math.cos(b)*(radius-width)}};
        for(int side=0;side<2;side++)for(int i=0;i<4;i++){var v=pts[side==0?i:3-i];vertex(p,out,v[0],v[1],v[2],color,alpha);}
    }
    public static void arc(PoseStack p,MultiBufferSource b,float radius,float from,float length,int color,float alpha){
        var out=b.getBuffer(RenderType.lightning());
        for(int layer=0;layer<3;layer++)for(int i=0;i<40;i++){
            float t=i/40F,taper=(float)Math.sin((t+0.0125F)*Math.PI),width=radius*(layer==0?0.22F:layer==1?0.09F:0.025F)*taper;
            segment(p,out,from+length*t,from+length*(t+0.025F),radius,width,layer==2?0xFFF4FF:color,alpha*(layer==0?0.18F:layer==1?0.48F:0.95F)*taper,layer*0.003F);
        }
    }
    private static void beam(PoseStack p,MultiBufferSource b,float length,float width,int color,float alpha){
        var out=b.getBuffer(RenderType.lightning());
        for(int plane=0;plane<2;plane++){
            p.pushPose();p.mulPose(Axis.ZP.rotationDegrees(plane*90));
            for(int layer=0;layer<3;layer++){
                float w=width*(layer==0?1:layer==1?0.4F:0.08F);int c=layer==2?0xFFFFFF:color;float a=alpha*(layer==0?0.12F:layer==1?0.4F:0.95F);
                float[][] pts={{-w,0,-length*0.5F},{w,0,-length*0.5F},{0,0,length*0.5F},{0,0,length*0.5F}};
                for(int side=0;side<2;side++)for(int i=0;i<4;i++){var v=pts[side==0?i:3-i];vertex(p,out,v[0],v[1],v[2],c,a);}
            }p.popPose();
        }
    }
    public static void draw(PoseStack p,MultiBufferSource b,int style,int color,float radius,float age,int life,float yaw,float pitch){
        if(style!=37&&style!=38){CinematicVfx.draw(p,b,style,color,radius,age,life,yaw,pitch);return;}
        float t=Math.clamp(age/life,0,1),alpha=(float)Math.sin(Math.PI*t);if(alpha<=0)return;
        p.pushPose();
        if(style==37||style==38){telegraph(p,b,style,color,radius,t,yaw);p.popPose();return;}
        if(style>=24){ultimate(p,b,style,color,radius,age,life,alpha);p.popPose();return;}
        p.mulPose(Axis.YP.rotationDegrees(-yaw));p.mulPose(Axis.XP.rotationDegrees(pitch));
        switch(style){
            case 17,18->{p.mulPose(Axis.ZP.rotationDegrees(style==17?-12:65));arc(p,b,radius,-2.3F+t*2.7F,2.8F,color,alpha);
                p.translate(0,0.04,0);arc(p,b,radius*0.86F,-2.5F+t*2.7F,2.2F,color,alpha*0.5F);
                for(int i=0;i<4;i++){float a=-2.3F+t*2.7F+2.8F*(.65F+i*.08F);p.pushPose();p.translate(Math.sin(a)*radius,.06+i*.02,Math.cos(a)*radius);p.mulPose(Axis.YP.rotation(a));p.mulPose(Axis.XP.rotationDegrees(-25));beam(p,b,radius*.28F,radius*.035F,color,alpha*.8F);p.popPose();}}
            case 19->{p.translate(0,0,(t-0.3)*radius);beam(p,b,radius*2.8F,radius*0.25F,color,alpha);
                for(int i=0;i<2;i++){p.pushPose();p.translate(0,0,i*radius*0.9);p.mulPose(Axis.XP.rotationDegrees(90));arc(p,b,radius*0.35F,age*0.3F+i,5.8F,color,alpha*0.75F);p.popPose();}}
            case 20->{p.translate(0,0,t*radius);beam(p,b,radius*1.7F,radius*0.45F,color,alpha);
                p.mulPose(Axis.XP.rotationDegrees(90));arc(p,b,radius*(0.3F+t*0.7F),0,6.28F,color,alpha);}
            case 21->{for(int i=0;i<3;i++){p.pushPose();p.translate(0,i*0.08,0);arc(p,b,radius*(0.25F+t)*(1-i*0.2F),i,6.28F,color,alpha*(1-i*0.2F));p.popPose();}}
            case 22->{beam(p,b,radius*3.5F,radius*0.14F,color,alpha);for(int i=0;i<3;i++){p.pushPose();p.translate(0,0,i*0.6);p.mulPose(Axis.XP.rotationDegrees(90));arc(p,b,radius*0.25F,i+age*0.2F,5.8F,color,alpha);p.popPose();}}
            case 23->{for(int i=0;i<3;i++){p.pushPose();p.mulPose(Axis.ZP.rotationDegrees(i*30));arc(p,b,radius*(0.8F+i*0.1F),age*0.2F+i*2,4.8F,color,alpha);p.popPose();}}
        }p.popPose();
    }
    private static void telegraph(PoseStack p,MultiBufferSource b,int style,int color,float r,float t,float yaw){
        p.mulPose(Axis.YP.rotationDegrees(-yaw));
        float half=style==38?(float)Math.PI:.9273F,from=-half,length=half*2;
        var out=b.getBuffer(RenderType.lightning());
        for(int i=0;i<48;i++){float a=from+length*i/48,beta=from+length*(i+1)/48;
            segment(p,out,a,beta,r,.045F,color,.85F,.02F);
            segment(p,out,a,beta,r*t,.02F,color,.5F,.025F);
        }
        if(style==37)for(int sign:new int[]{-1,1}){p.pushPose();p.mulPose(Axis.YP.rotation(sign*half));p.translate(0,.025,r/2);beam(p,b,r,.05F,color,.9F);p.popPose();}
    }
    private static void ultimate(PoseStack p,MultiBufferSource b,int style,int color,float r,float age,int life,float alpha){
        int school=style>=31?style-30:style-23;
        if(style>=31){
            // Preparation: ascending rotating circles and a contracting target ring.
            SpellVfx.draw(p,b,0,color,r,age,life,0,0);
            for(int i=0;i<3;i++){p.pushPose();p.translate(0,1+i*1.3,0);arc(p,b,r*(0.65F-i*0.1F),age*0.12F+i,5.9F,color,alpha*0.8F);p.popPose();}
            return;
        }
        SpellVfx.draw(p,b,MagicSchools.impactStyle(school),color,r,age,life,0,0);
        float progress=Math.min(1,age/18);
        arc(p,b,r*(0.4F+progress*1.1F),age*0.08F,6.28F,color,alpha);
        if(school==1||school==6){p.pushPose();p.translate(0,3.5,0);p.mulPose(Axis.XP.rotationDegrees(90));beam(p,b,9,r*0.65F,color,alpha);p.popPose();}
        if(school==2||school==5){for(int i=0;i<6;i++){p.pushPose();p.translate(0,i*0.55,0);arc(p,b,r*(0.95F-i*0.08F),age*0.2F+i*0.7F,4.2F,color,alpha*0.7F);p.popPose();}}
        if(school==3||school==4){for(int i=0;i<6;i++){p.pushPose();p.mulPose(Axis.YP.rotationDegrees(i*60));p.translate(0,0,r*0.65);p.mulPose(Axis.XP.rotationDegrees(-65));beam(p,b,r*(1.1F+progress),r*0.17F,color,alpha);p.popPose();}}
    }
}
