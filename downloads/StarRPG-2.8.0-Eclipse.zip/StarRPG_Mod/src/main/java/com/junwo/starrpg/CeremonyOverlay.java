package com.junwo.starrpg;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.*;

/** Visible above enhancement/career screens too; never closes a screen or consumes input. */
@EventBusSubscriber(modid=StarRPG.MODID,value=Dist.CLIENT)
public final class CeremonyOverlay {
    @SubscribeEvent public static void hud(RenderGuiEvent.Post e){if(Minecraft.getInstance().screen==null)draw(e.getGuiGraphics(),e.getPartialTick().getGameTimeDeltaPartialTick(false));}
    @SubscribeEvent public static void screen(ScreenEvent.Render.Post e){draw(e.getGuiGraphics(),e.getPartialTick());}
    public static void sprite(GuiGraphics g,int cell,float x,float y,int size,float rotation,int color,float alpha){
        g.pose().pushPose();g.pose().translate(x,y,1100);g.pose().mulPose(Axis.ZP.rotation(rotation));
        RenderSystem.enableBlend();RenderSystem.defaultBlendFunc();RenderSystem.setShaderColor((color>>16&255)/255F,(color>>8&255)/255F,(color&255)/255F,Math.clamp(alpha,0,1));
        g.blit(CinematicVfx.ATLAS,-size/2,-size/2,size,size,cell%4*313.5F+3,cell/4*313.5F+3,307,307,1254,1254);
        RenderSystem.setShaderColor(1,1,1,1);RenderSystem.disableBlend();g.pose().popPose();
    }
    private static void draw(GuiGraphics g,float partial){
        var mc=Minecraft.getInstance();var p=mc.player;if(p==null||mc.options.hideGui||mc.screen instanceof StarRevealScreen)return;
        float cx=g.guiWidth()/2F,cy=g.guiHeight()*.24F;
        float guard=CombatPresentation.age(p,"starrpg_guard_tick",partial);int mode=p.getPersistentData().getInt("starrpg_guard_kind");
        if(guard>=0&&guard<(mode==PresentationCues.PARRY?16:5)){
            boolean hit=mode==PresentationCues.PARRY;float a=hit?Math.min(1,(16-guard)/6):1;
            sprite(g,hit?7:14,cx,g.guiHeight()/2F+26,hit?60:36,hit?guard*.04F:0,0xFFE193,a*.8F);
            if(hit){g.pose().pushPose();g.pose().translate(0,0,1101);g.drawCenteredString(mc.font,"패링 성공",(int)cx,g.guiHeight()/2+53,0xFFFFDC83);g.pose().popPose();}
        }
        float age=CombatPresentation.age(p,"starrpg_ceremony_tick",partial);if(age<0||age>=60)return;
        var tag=p.getPersistentData();int cue=tag.getInt("starrpg_ceremony_kind"),color=tag.getInt("starrpg_ceremony_color"),value=tag.getInt("starrpg_ceremony_value");
        float fall=Math.clamp(age/23,0,1),fade=Math.min(1,(60-age)/14),y=-35+(cy+35)*(1-(float)Math.pow(1-fall,2));
        int size=cue==PresentationCues.ADVANCE?74:56;
        for(int i=4;i>=1;i--)sprite(g,7,cx+i*6,y-i*13,size/(i+1),age*.035F,color,fade*.12F);
        sprite(g,7,cx,y,size,age*.025F,color,fade);
        if(age>20){float bloom=Math.min(1,(age-20)/10);sprite(g,0,cx,cy,Math.round(size*(1+bloom*.5F)),age*.015F,color,fade*.65F);
            int n=VisualOptions.quality()==0?4:8;for(int i=0;i<n;i++){double a=i*Math.PI*2/n+age*.01;float r=(age-20)*2;float sy=(float)(cy+Math.sin(a)*r*.4)+(cue==PresentationCues.FAILURE?(age-20)*.7F:0);sprite(g,7,(float)(cx+Math.cos(a)*r),sy,12,0,color,fade*.7F);}
            String title=switch(cue){case PresentationCues.UPGRADE->"강화 성공  +"+value;case PresentationCues.FAILURE->"강화 실패 · 단계 유지";case PresentationCues.ADVANCE->value+"차 전직 완료";default->"새로운 직업 선택";};
            int alpha=(int)(fade*255);if(alpha>8){g.pose().pushPose();g.pose().translate(0,0,1101);g.drawCenteredString(mc.font,title,(int)cx,(int)cy+48,(alpha<<24)|color);g.pose().popPose();}
        }
    }
}
