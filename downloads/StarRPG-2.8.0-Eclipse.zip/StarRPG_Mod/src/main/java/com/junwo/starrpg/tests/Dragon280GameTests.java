package com.junwo.starrpg.tests;

import com.junwo.starrpg.*;
import com.junwo.starrpg.bestiary.*;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.*;
import net.minecraft.world.*;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.*;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.*;

@GameTestHolder(StarRPG.MODID)
@PrefixGameTestTemplate(false)
public final class Dragon280GameTests {
    private static BestiaryMob dragon(GameTestHelper h){var m=BestiaryRegistry.TYPES.get(BestiaryKind.RED_DRAGON).get().create(h.getLevel());m.setPos(h.absoluteVec(new Vec3(4,1,1)));m.setNoGravity(true);m.setYRot(0);m.yBodyRot=0;return m;}
    private static LivingEntity target(GameTestHelper h,BestiaryMob m){var c=EntityType.COW.create(h.getLevel());c.setPos(m.position().add(0,0,6));c.setNoAi(true);c.setNoGravity(true);c.getAttribute(Attributes.MAX_HEALTH).setBaseValue(200);c.setHealth(200);h.getLevel().addFreshEntity(c);m.setTarget(c);return c;}
    @GameTest(template="hook_arena") public static void breathHasWindupAndChannelRecovery(GameTestHelper h){
        var m=dragon(h);var c=target(h,m);m.startAttack(c,true);h.assertTrue(m.dragonAction()==DragonBattle.BREATH&&m.duration()==40,"Wrong breath tell");
        for(int i=0;i<40;i++)m.combatTick();h.assertTrue(c.getHealth()==200&&m.phase()==BestiaryMob.ACTIVE,"Breath dealt early damage");
        // The broad body of a cow intersects the central sweep near its midpoint.
        for(int i=0;i<48;i++)m.combatTick();h.assertTrue(c.getHealth()<200&&m.phase()==BestiaryMob.RECOVERY&&m.duration()==38,"No channel hit or punish window: health="+c.getHealth()+" phase="+m.phase()+" action="+m.dragonAction()+" direction="+m.attackDirection+" los="+m.hasLineOfSight(c)+" mouth="+DragonBattle.mouth(m,new Vec3(0,0,1))+" clipped="+DragonBattle.clipped(m,DragonBattle.mouth(m,new Vec3(0,0,1)),c.getEyePosition())+" target="+c.getBoundingBox());c.discard();h.succeed();
    }
    @GameTest(template="hook_arena") public static void dragonBreathStopsAtSolidWalls(GameTestHelper h){
        var m=dragon(h);var c=target(h,m);var from=DragonBattle.mouth(m,new Vec3(0,0,1));var end=c.getEyePosition();
        for(int x=3;x<=5;x++)for(int y=1;y<=6;y++)h.setBlock(new BlockPos(x,y,6),Blocks.STONE);
        var clipped=DragonBattle.clipped(m,from,end);h.assertTrue(clipped.distanceToSqr(from)<end.distanceToSqr(from),"Beam ignored wall");DragonBattle.breathHit(m,from,end,1);
        h.assertTrue(c.getHealth()==200,"Breath damaged through wall");c.discard();h.succeed();
    }
    @GameTest(template="hook_arena") public static void breathDoesNotHitBehindItsMouth(GameTestHelper h){
        var m=dragon(h);var c=target(h,m);c.setPos(m.position().add(0,0,-2));DragonBattle.breathHit(m,DragonBattle.mouth(m,new Vec3(0,0,1)),m.position().add(0,2,10),1);
        h.assertTrue(c.getHealth()==200,"Rear target hit by forward beam");c.discard();h.succeed();
    }
    @GameTest(template="hook_arena") public static void stunInterruptsDragonChannel(GameTestHelper h){
        var m=dragon(h);var c=target(h,m);m.startAttack(c,true);m.addEffect(new MobEffectInstance(ModEffects.STUN,20));m.combatTick();
        h.assertTrue(c.getHealth()==200&&m.phase()==BestiaryMob.RECOVERY&&m.dragonAction()==DragonBattle.NONE,"Stunned dragon kept channeling");c.discard();h.succeed();
    }
    @GameTest(template="hook_arena") public static void tailCanBeParriedAndCreatesOpening(GameTestHelper h){
        var m=dragon(h);m.setPos(h.absoluteVec(new Vec3(4,2,4)));var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(m.position().add(0,0,-3));p.setYRot(0);p.setXRot(0);p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(Items.IRON_SWORD));h.getLevel().addFreshEntity(p);m.setTarget(p);m.getPersistentData().putInt("starrpg_dragon_combo",1);m.startAttack(p,true);
        h.assertTrue(m.dragonAction()==DragonBattle.TAIL&&ParrySystem.open(p),"Tail or guard unavailable");float hp=p.getHealth();for(int i=0;i<30;i++)m.combatTick();
        h.assertTrue(m.phase()==BestiaryMob.STAGGER&&p.getHealth()==hp,"Tail parry failed to stop damage");p.discard();h.succeed();
    }
    @GameTest(template="hook_arena") public static void lostTargetRestoresGravityAndCooldown(GameTestHelper h){
        var m=dragon(h);var c=target(h,m);DragonBattle.beginFlight(m);m.setTarget(null);DragonBattle.air(m,h.getLevel());
        h.assertTrue(!BossPhases.flying(m)&&!m.isNoGravity()&&m.dragonAction()==DragonBattle.NONE&&m.getPersistentData().getLong("starrpg_flight_ready")>h.getLevel().getGameTime(),"Flight did not safely end");c.discard();h.succeed();
    }
    @GameTest(template="hook_arena") public static void legacyFlightDoesNotLeavePermanentNoGravity(GameTestHelper h){
        var m=dragon(h);var c=target(h,m);m.getPersistentData().putInt("starrpg_flight_age",70);m.getPersistentData().putDouble("starrpg_flight_ground",m.getY());DragonBattle.air(m,h.getLevel());
        h.assertTrue(!BossPhases.flying(m)&&!m.isNoGravity(),"Legacy flight remained suspended");c.discard();h.succeed();
    }
    @GameTest(template="hook_arena") public static void headDamageUsesTheSameBossHealthAndPartsAreNotSaved(GameTestHelper h){
        var m=dragon(h);m.updateDragonParts();var head=m.getParts()[0];float before=m.getHealth();
        h.assertTrue(head.getParent()==m&&!head.shouldBeSaved()&&head.position().distanceToSqr(m.position())>9,"Invalid head extension");
        h.assertTrue(head.hurt(m.damageSources().generic(),10)&&m.getHealth()<before,"Head did not forward damage to boss");h.succeed();
    }
    @GameTest(template="empty") public static void multipartIdsAreStableAndOrdinaryMonstersHaveNoExtraParts(GameTestHelper h){
        var m=dragon(h);m.setId(m.getId());h.assertTrue(m.isMultipartEntity()&&m.getParts().length==3,"Dragon parts missing");
        for(int i=0;i<3;i++)h.assertTrue(m.getParts()[i].getId()==m.getId()+i+1,"Invalid network part ID");
        var goblin=BestiaryRegistry.TYPES.get(BestiaryKind.GOBLIN).get().create(h.getLevel());h.assertTrue(!goblin.isMultipartEntity()&&goblin.getParts()==null,"Unrelated creature changed");h.succeed();
    }
}
