package com.junwo.starrpg;

import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.renderer.*;

/** Alpha-weighted additive emission: transparent PNG pixels contribute no rectangular background. */
public abstract class SpellRenderType extends RenderType {
    private SpellRenderType(){super("starrpg_emission",DefaultVertexFormat.NEW_ENTITY,VertexFormat.Mode.QUADS,1536,false,true,()->{},()->{});}
    public static final RenderType EMISSION=create("starrpg_emission",DefaultVertexFormat.NEW_ENTITY,VertexFormat.Mode.QUADS,786432,false,true,
        CompositeState.builder().setShaderState(RENDERTYPE_ENTITY_TRANSLUCENT_EMISSIVE_SHADER)
        .setTextureState(new TextureStateShard(CinematicVfx.ATLAS,true,false))
        .setTransparencyState(LIGHTNING_TRANSPARENCY).setCullState(NO_CULL).setLightmapState(LIGHTMAP).setOverlayState(OVERLAY)
        .setWriteMaskState(COLOR_WRITE).createCompositeState(false));
    public static final RenderType GEOMETRY=create("starrpg_luminous_geometry",DefaultVertexFormat.POSITION_COLOR,VertexFormat.Mode.QUADS,786432,false,true,
        CompositeState.builder().setShaderState(RENDERTYPE_LIGHTNING_SHADER)
        .setTransparencyState(LIGHTNING_TRANSPARENCY).setCullState(NO_CULL)
        .setWriteMaskState(COLOR_WRITE).createCompositeState(false));
}
