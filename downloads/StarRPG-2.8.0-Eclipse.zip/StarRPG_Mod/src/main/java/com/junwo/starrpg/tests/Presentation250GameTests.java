package com.junwo.starrpg.tests;

import com.junwo.starrpg.*;
import com.junwo.starrpg.bestiary.*;
import net.minecraft.gametest.framework.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.phys.*;
import net.neoforged.neoforge.gametest.*;

@GameTestHolder(StarRPG.MODID)
@PrefixGameTestTemplate(false)
public class Presentation250GameTests {
    @GameTest(template="hook_arena",timeoutTicks=80) public static void animatedFrostBreathDoesNotRepeatCombatDamage(GameTestHelper h){
        var l=h.getLevel();var m=BestiaryRegistry.TYPES.get(BestiaryKind.WHITE_DRAGON).get().create(l);m.setPos(h.absoluteVec(new Vec3(3,1,1)));m.setNoGravity(true);
        var t=EntityType.COW.create(l);t.setNoAi(true);t.setNoGravity(true);t.setPos(m.position().add(0,0,6));t.getAttribute(Attributes.MAX_HEALTH).setBaseValue(200);t.setHealth(200);l.addFreshEntity(t);m.setTarget(t);
        m.startAttack(t,true);for(int i=0;i<88;i++)m.combatTick();float hp=t.getHealth();
        h.assertTrue(hp<200&&l.getEntitiesOfClass(ArcaneSigil.class,m.getBoundingBox().inflate(12)).stream().anyMatch(e->e.style()==53),"Missing actual breath or damage: hp="+hp+" action="+m.dragonAction()+" phase="+m.phase()+" los="+m.hasLineOfSight(t)+" beam53="+l.getEntitiesOfClass(ArcaneSigil.class,m.getBoundingBox().inflate(12)).stream().filter(e->e.style()==53).count());
        h.runAfterDelay(30,()->{h.assertTrue(t.getHealth()==hp,"Decorative breath caused repeated damage");t.discard();h.succeed();});
    }
    @GameTest(template="empty") public static void attackWarningsHavePriorityOverBreathAndSpellDecoration(GameTestHelper h){
        // Isolate vertically inside this test's active chunk. A distant generated chunk need
        // not be entity-ticking, so its lookup cannot verify a live presentation budget.
        var l=h.getLevel();var pos=h.absoluteVec(new Vec3(2,100,2));
        var box=new AABB(pos,pos).inflate(32);l.getEntitiesOfClass(ArcaneSigil.class,box).forEach(Entity::discard);
        for(int i=0;i<48;i++)ArcaneSigil.spawn(l,pos,new Vec3(0,0,1),24,0xFFFFFF,2,30);
        ArcaneSigil.spawn(l,pos,new Vec3(0,0,1),40,0xFF7722,9,24);
        h.assertTrue(l.getEntitiesOfClass(ArcaneSigil.class,box).size()==48&&l.getEntitiesOfClass(ArcaneSigil.class,box).stream().noneMatch(e->e.style()==40),"Breath bypassed decoration budget: "+l.getEntitiesOfClass(ArcaneSigil.class,box).size());
        ArcaneSigil.spawn(l,pos,new Vec3(0,0,1),38,0xFF3322,5,36);
        h.assertTrue(l.getEntitiesOfClass(ArcaneSigil.class,box).size()==48&&l.getEntitiesOfClass(ArcaneSigil.class,box).stream().anyMatch(e->e.style()==38&&e.radius()==5&&e.life()==36),"Warning lost or timing/range changed");
        l.getEntitiesOfClass(ArcaneSigil.class,box).forEach(Entity::discard);h.succeed();
    }
}
