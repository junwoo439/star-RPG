package com.junwo.starrpg.bestiary;

import java.util.EnumSet;
import net.minecraft.world.entity.ai.goal.Goal;

public final class BestiaryCombatGoal extends Goal {
    private final BestiaryMob mob;
    public BestiaryCombatGoal(BestiaryMob mob){this.mob=mob;setFlags(EnumSet.of(Flag.MOVE,Flag.LOOK));}
    @Override public boolean canUse(){return mob.phase()!=BestiaryMob.IDLE||BestiaryCombat.valid(mob,mob.getTarget());}
    @Override public boolean requiresUpdateEveryTick(){return true;}
    @Override public void tick(){
        if(BossPhases.flying(mob))return;
        if(mob.phase()!=BestiaryMob.IDLE){mob.combatTick();return;}
        var t=mob.getTarget();if(!BestiaryCombat.valid(mob,t))return;
        mob.getLookControl().setLookAt(t,25,25);
        double range=mob.kind.move.ordinal()>=BestiaryKind.Move.HEX.ordinal()?mob.kind.reach()*.8:Math.max(2.1,mob.getBbWidth()+.8);
        if(mob.distanceToSqr(t)>range*range||!mob.hasLineOfSight(t)){mob.getNavigation().moveTo(t,1);return;}
        mob.getNavigation().stop();
        if(mob.level().getGameTime()>=mob.nextAttack&&mob.lifeTicks()>40)mob.startAttack(t,mob.distanceToSqr(t)>16||mob.nextHeavy());
    }
}
