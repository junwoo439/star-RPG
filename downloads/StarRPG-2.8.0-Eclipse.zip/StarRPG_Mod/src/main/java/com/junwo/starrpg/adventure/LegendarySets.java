package com.junwo.starrpg.adventure;
import com.junwo.starrpg.*;
import com.junwo.starrpg.bestiary.*;
import net.minecraft.world.item.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
@EventBusSubscriber(modid=StarRPG.MODID)
public final class LegendarySets {
    public static final String[] IDS={"dragon","lich","golem"};
    public static final java.util.List<DeferredItem<Item>> PIECES=new java.util.ArrayList<>();
    static{for(String set:IDS)for(var slot:ArmorItem.Type.values())if(slot!=ArmorItem.Type.BODY)PIECES.add(StarRPG.ITEMS.register(set+"_"+slot.getName(),()->new ArmorItem(ArmorMaterials.DIAMOND,slot,new Item.Properties().rarity(Rarity.EPIC))));}
    public static void init(){}
    public static int count(Player p,int set){int n=0;for(var s:p.getArmorSlots())for(int i=set*4;i<set*4+4;i++)if(s.is(PIECES.get(i).get())){n++;break;}return n;}
    private static Item material(int set){return switch(set){case 0->AdventureItems.DRAGON.get();case 1->AdventureItems.LICH.get();default->AdventureItems.GOLEM.get();};}
    public static boolean craft(Player p,int piece){if(piece<0||piece>=12||LifeJobs.active(p)!=1)return false;var out=new ItemStack(PIECES.get(piece).get());if(!Economy.fits(p,out)||p.getInventory().countItem(AdventureItems.ALLOY.get())<4||p.getInventory().countItem(material(piece/4))<2||p.getInventory().countItem(Items.DIAMOND)<2||p.getInventory().countItem(AdventureItems.HERB.get())<1||p.getInventory().countItem(AdventureItems.SCALE.get())<1||p.getInventory().countItem(AdventureItems.RELIC.get())<1||p.getInventory().countItem(AdventureItems.RIFT.get())<1)return false;LifeJobs.consume(p,AdventureItems.ALLOY.get(),4);LifeJobs.consume(p,material(piece/4),2);LifeJobs.consume(p,Items.DIAMOND,2);LifeJobs.consume(p,AdventureItems.HERB.get(),1);LifeJobs.consume(p,AdventureItems.SCALE.get(),1);LifeJobs.consume(p,AdventureItems.RELIC.get(),1);LifeJobs.consume(p,AdventureItems.RIFT.get(),1);LifeJobs.give(p,out);AdventureData.add(p,"legendary_crafted",1);AdventureData.add(p,"life_xp_1",40);PresentationCues.play(p,PresentationCues.CRAFT,piece,0xFFD86A);return true;}
    @SubscribeEvent public static void drop(net.neoforged.neoforge.event.entity.living.LivingDropsEvent e){if(e.getEntity().level().isClientSide()||!(e.getEntity() instanceof BestiaryMob b)||!b.kind.boss||!(e.getSource().getEntity() instanceof Player)||b.getPersistentData().hasUUID("starrpg_summoner"))return;int set=b.kind.family==BestiaryKind.Family.DRAGON?0:b.kind==BestiaryKind.LICH?1:b.kind==BestiaryKind.ANCIENT_GOLEM?2:-1;if(set>=0)e.getDrops().add(new net.minecraft.world.entity.item.ItemEntity(b.level(),b.getX(),b.getY(),b.getZ(),new ItemStack(material(set),1+b.getRandom().nextInt(2))));}
    private static void stat(Player p,net.minecraft.core.Holder<Attribute> attr,String id,double amount){var a=p.getAttribute(attr);if(a==null)return;var key=ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,id);if(amount==0)a.removeModifier(key);else a.addOrUpdateTransientModifier(new AttributeModifier(key,amount,AttributeModifier.Operation.ADD_VALUE));}
    @SubscribeEvent public static void tick(net.neoforged.neoforge.event.tick.PlayerTickEvent.Post e){var p=e.getEntity();if(p.level().isClientSide()||p.tickCount%20!=0)return;int dragon=count(p,0),golem=count(p,2);stat(p,Attributes.ARMOR,"legend_golem_armor",golem>=2?3:0);stat(p,Attributes.KNOCKBACK_RESISTANCE,"legend_golem_poise",golem==4?.3:0);if(dragon>=2)p.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.FIRE_RESISTANCE,300,0,false,false));}
    @SubscribeEvent public static void damage(net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent e){if(e.getEntity().level().isClientSide())return;if(e.getSource().getEntity() instanceof Player p&&SkillTrees.attack(e.getSource())&&count(p,0)==4&&e.getEntity().isOnFire())e.setAmount(e.getAmount()*1.15F);if(e.getEntity() instanceof Player p&&count(p,1)>=2&&(e.getSource().is(net.minecraft.world.damagesource.DamageTypes.MAGIC)||e.getSource().is(MagicSystem.MAGIC_DAMAGE)))e.setAmount(e.getAmount()*.85F);}
    @SubscribeEvent public static void heal(net.neoforged.neoforge.event.entity.living.LivingDamageEvent.Post e){if(e.getEntity().level().isClientSide()||e.getNewDamage()<=0)return;if(e.getSource().getEntity() instanceof Player p&&count(p,1)==4&&SkillTrees.attack(e.getSource()))p.heal(Math.min(2,e.getNewDamage()*.05F));if(e.getEntity() instanceof Player p&&count(p,2)==4&&p.getPersistentData().getLong("golem_set_ready")<=p.level().getGameTime()){p.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.ABSORPTION,160,0));p.getPersistentData().putLong("golem_set_ready",p.level().getGameTime()+400);}}
}
