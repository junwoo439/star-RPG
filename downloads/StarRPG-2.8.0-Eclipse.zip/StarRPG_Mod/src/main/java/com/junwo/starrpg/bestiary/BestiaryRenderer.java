package com.junwo.starrpg.bestiary;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.resources.ResourceLocation;

public final class BestiaryRenderer extends MobRenderer<BestiaryMob,BestiaryModel> {
    public BestiaryRenderer(EntityRendererProvider.Context c,BestiaryKind k){super(c,new BestiaryModel(k),k.width()*.5F);}
    @Override public boolean shouldRender(BestiaryMob m,net.minecraft.client.renderer.culling.Frustum f,double x,double y,double z){return m.shouldRenderAtSqrDistance(m.distanceToSqr(x,y,z))&&f.isVisible(m.getBoundingBox().inflate(m.kind.family==BestiaryKind.Family.DRAGON?8:2));}
    @Override public void render(BestiaryMob m,float yaw,float partial,PoseStack p,net.minecraft.client.renderer.MultiBufferSource b,int light){if(!IceAndFireDragonVisual.render(m,yaw,partial,p,b,light))super.render(m,yaw,partial,p,b,light);if(m.distanceToSqr(net.minecraft.client.Minecraft.getInstance().gameRenderer.getMainCamera().getPosition())<1024)CreatureAura.render(m,partial,p,b);}
    @Override protected void scale(BestiaryMob m,PoseStack p,float partial){float s=m.kind.scale();p.scale(s,s,s);}
    @Override public ResourceLocation getTextureLocation(BestiaryMob m){return ResourceLocation.fromNamespaceAndPath("starrpg","textures/entity/bestiary_materials.png");}
}
