package com.junwo.starrpg.adventure;
import com.junwo.starrpg.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.npc.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.*;
import net.minecraft.network.chat.Component;
public final class QuestEnvoy extends Villager {
    public QuestEnvoy(EntityType<? extends Villager> type,Level level){super(type,level);setCustomName(Component.literal("별빛 기록관 아린"));setCustomNameVisible(true);setNoAi(true);setInvulnerable(true);setPersistenceRequired();setVillagerData(getVillagerData().setProfession(VillagerProfession.CLERIC));}
    @Override public InteractionResult mobInteract(Player p,InteractionHand hand){if(!level().isClientSide()&&hand==InteractionHand.MAIN_HAND)p.openMenu(new SimpleMenuProvider((id,inv,who)->new AdventureMenu(id,inv),Component.literal("별의 연대기 · 의뢰")));return InteractionResult.sidedSuccess(level().isClientSide());}
}
