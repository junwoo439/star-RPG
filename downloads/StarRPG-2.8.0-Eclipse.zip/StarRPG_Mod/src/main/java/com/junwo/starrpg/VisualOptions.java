package com.junwo.starrpg;

import net.neoforged.neoforge.common.ModConfigSpec;

/** Local presentation settings; combat timings/ranges and enemy tells never depend on quality. */
public final class VisualOptions {
    private static final ModConfigSpec.Builder B=new ModConfigSpec.Builder();
    public static final ModConfigSpec.IntValue QUALITY=B.comment("0 reduced, 1 balanced, 2 cinematic. F8 cycles locally; enemy attack outlines remain.").defineInRange("effects.quality",2,0,2);
    public static final ModConfigSpec.BooleanValue AURAS=B.define("effects.creatureAuras",true);
    public static final ModConfigSpec SPEC=B.build();
    public static int quality(){return Math.clamp(QUALITY.get(),0,2);}
}
