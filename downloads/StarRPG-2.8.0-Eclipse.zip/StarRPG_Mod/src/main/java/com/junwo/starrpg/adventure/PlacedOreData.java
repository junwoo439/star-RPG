package com.junwo.starrpg.adventure;
import java.util.*;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.*;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.saveddata.SavedData;
public final class PlacedOreData extends SavedData {
    private final Set<Long> placed=new HashSet<>();
    public static PlacedOreData get(ServerLevel l){return l.getDataStorage().computeIfAbsent(new Factory<>(PlacedOreData::new,PlacedOreData::load),"starrpg_placed_ores");}
    public boolean contains(BlockPos p){return placed.contains(p.asLong());}
    public void add(BlockPos p){if(placed.add(p.asLong()))setDirty();}
    public void remove(BlockPos p){if(placed.remove(p.asLong()))setDirty();}
    public static PlacedOreData load(CompoundTag t,HolderLookup.Provider lookup){var d=new PlacedOreData();for(long p:t.getLongArray("placed"))d.placed.add(p);return d;}
    @Override public CompoundTag save(CompoundTag t,HolderLookup.Provider lookup){t.putLongArray("placed",placed.stream().mapToLong(Long::longValue).toArray());return t;}
}
