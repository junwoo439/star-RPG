package com.junwo.starrpg;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.resources.ResourceLocation;

public final class ArcaneSigilRenderer extends EntityRenderer<ArcaneSigil> {
    public ArcaneSigilRenderer(EntityRendererProvider.Context c){super(c);}
    @Override public boolean shouldRender(ArcaneSigil e,net.minecraft.client.renderer.culling.Frustum frustum,double x,double y,double z){return e.withinView(x,y,z)&&frustum.isVisible(e.getBoundingBox().inflate(e.radius()*4+1));}
    @Override public ResourceLocation getTextureLocation(ArcaneSigil e){return CinematicVfx.ATLAS;}
    @Override public void render(ArcaneSigil e,float yaw,float partial,PoseStack p,MultiBufferSource b,int light){
        float age=e.tickCount+partial;draw(p,b,e.style(),e.color(),e.radius(),age,e.life(),e.getYRot(),e.getXRot());
    }
    /** Shared by the real world renderer and the opt-in visual verification screen. */
    public static void draw(PoseStack p,MultiBufferSource b,int style,int color,float radius,float age,int life,float yaw,float pitch){
        SpellVfx.draw(p,b,style,color,radius,age,life,yaw,pitch);
    }
}
