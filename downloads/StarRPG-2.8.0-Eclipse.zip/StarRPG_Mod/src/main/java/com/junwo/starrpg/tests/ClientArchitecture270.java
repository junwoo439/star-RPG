package com.junwo.starrpg.tests;
import com.junwo.starrpg.*;
import com.junwo.starrpg.adventure.*;
import net.minecraft.client.*;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.*;
import net.minecraft.world.Difficulty;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.*;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraft.world.level.levelgen.presets.WorldPresets;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
/** Changes terrain only in a new disposable showcase world. Never opens an existing save. */
@EventBusSubscriber(modid=StarRPG.MODID,value=Dist.CLIENT)
public final class ClientArchitecture270 {
    private static boolean started,configured;private static int tick;
    private static final String[] BIOMES={"desert","snowy_plains","forest","swamp","stony_peaks","plains"};
    private static final DungeonFeature.Style[] STYLES={DungeonFeature.Style.DESERT,DungeonFeature.Style.SNOW,DungeonFeature.Style.FOREST,DungeonFeature.Style.SWAMP,DungeonFeature.Style.MOUNTAIN,DungeonFeature.Style.PLAINS};
    @SubscribeEvent public static void tick(net.neoforged.neoforge.client.event.ClientTickEvent.Post e){
        if(!Boolean.getBoolean("starrpg.architecture270"))return;var mc=Minecraft.getInstance();
        if(!started&&mc.screen instanceof TitleScreen&&mc.getOverlay()==null){started=true;mc.options.hideGui=true;mc.options.cloudStatus().set(CloudStatus.OFF);mc.options.guiScale().set(2);mc.options.renderDistance().set(4);mc.options.simulationDistance().set(5);mc.getWindow().setWindowed(1280,800);mc.resizeDisplay();mc.createWorldOpenFlows().createFreshLevel("starrpg-architecture-270-"+System.currentTimeMillis(),new LevelSettings("StarRPG terrain architecture verification",GameType.CREATIVE,false,Difficulty.NORMAL,true,new GameRules(),WorldDataConfiguration.DEFAULT),new WorldOptions(270,false,false),WorldPresets::createNormalWorldDimensions,mc.screen);return;}
        if(mc.player==null||mc.level==null||mc.getSingleplayerServer()==null)return;var server=mc.getSingleplayerServer();var id=mc.player.getUUID();
        if(!configured){configured=true;mc.setScreen(null);server.execute(()->{var p=server.getPlayerList().getPlayer(id);var l=p.serverLevel();l.setDayTime(6000);l.getGameRules().getRule(GameRules.RULE_DOBLOCKDROPS).set(false,server);l.getGameRules().getRule(GameRules.RULE_DAYLIGHT).set(false,server);l.getGameRules().getRule(GameRules.RULE_DOMOBSPAWNING).set(false,server);p.setNoGravity(true);p.getAbilities().flying=true;p.onUpdateAbilities();p.teleportTo(l,27,195,-20,34,-7);});return;}
        if(tick==0&&mc.player.getY()<190)return;tick++;if(tick==20)StarRPG.LOGGER.info("ARCH270_READY");int stage=(tick-1)/240,step=tick%240;
        if(stage<6&&step==30)server.execute(()->{var p=server.getPlayerList().getPlayer(id);var l=p.serverLevel();for(int x=-16;x<=32;x++)for(int z=-24;z<=32;z++)l.setBlock(new BlockPos(x,180,z),(stage==0?Blocks.SANDSTONE:stage==1?Blocks.SNOW_BLOCK:stage==2?Blocks.MOSS_BLOCK:stage==3?Blocks.MUD:stage==4?Blocks.STONE:Blocks.GRASS_BLOCK).defaultBlockState(),3);
            for(int x=0;x<16;x++)for(int z=0;z<16;z++)for(int y=150;y<=220;y++)l.setBlock(new BlockPos(x,y,z),(y<=179?Blocks.STONE:Blocks.AIR).defaultBlockState(),2);
            for(int x=0;x<16;x++)for(int z=0;z<16;z++)l.setBlock(new BlockPos(x,180,z),(stage==0?Blocks.SANDSTONE:stage==1?Blocks.SNOW_BLOCK:stage==2?Blocks.MOSS_BLOCK:stage==3?Blocks.MUD:stage==4?Blocks.STONE:Blocks.GRASS_BLOCK).defaultBlockState(),2);
            server.getCommands().performPrefixedCommand(p.createCommandSourceStack(),"fillbiome 0 148 0 15 224 15 minecraft:"+BIOMES[stage]);
            var actual=DungeonFeature.style(l.getBiome(new BlockPos(8,181,8)));if(actual!=STYLES[stage])throw new IllegalStateException("Biome style mismatch "+actual+" / "+STYLES[stage]);
            int variant=stage==0||stage==4?2:stage==2?0:1;long seed=0;while(net.minecraft.util.RandomSource.create(seed).nextInt(3)!=variant)seed++;
            if(!AdventureWorldgen.DUNGEON.get().place(NoneFeatureConfiguration.INSTANCE,l,l.getChunkSource().getGenerator(),net.minecraft.util.RandomSource.create(seed),new BlockPos(8,181,8)))throw new IllegalStateException("Dungeon rejected gallery");
            if(stage==2)p.teleportTo(l,15,185,-3,50,20);else p.teleportTo(l,27,195,-20,34,-7);
            StarRPG.LOGGER.info("ARCH270_THEME_OK {}",actual);
        });
        if(step==210&&stage<6)Screenshot.grab(mc.gameDirectory,"starrpg-2.7-architecture-"+BIOMES[stage]+".png",mc.getMainRenderTarget(),message->StarRPG.LOGGER.info("ARCH270_SCREENSHOT {}",stage));
        if(tick>=1440){mc.options.hideGui=false;StarRPG.LOGGER.info("ARCH270_COMPLETE");mc.stop();}
    }
}
