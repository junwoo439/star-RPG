package com.junwo.starrpg.tests;

import com.junwo.starrpg.*;
import com.junwo.starrpg.bestiary.*;
import net.minecraft.client.*;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.core.BlockPos;
import net.minecraft.world.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.*;
import net.minecraft.world.level.levelgen.presets.WorldPresets;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;

/** Creates only a new disposable showcase world; never reads or opens an existing player's save. */
@EventBusSubscriber(modid=StarRPG.MODID,value=Dist.CLIENT)
public final class ClientVisual250 {
    private static boolean started,configured;private static int tick;
    private static final BestiaryKind[][] GROUPS={
        {BestiaryKind.RED_DRAGON,BestiaryKind.GOLD_DRAGON,BestiaryKind.BLACK_DRAGON},
        {BestiaryKind.BLUE_DRAGON,BestiaryKind.WHITE_DRAGON,BestiaryKind.GREEN_DRAGON},
        {BestiaryKind.GOBLIN,BestiaryKind.OGRE_WARLORD,BestiaryKind.LICH},
        {BestiaryKind.DIRE_BEAR,BestiaryKind.GIANT_SPIDER,BestiaryKind.REEF_SHARK},
        {BestiaryKind.BANSHEE,BestiaryKind.VAMPIRE,BestiaryKind.ANCIENT_GOLEM},
        {BestiaryKind.SOLAR,BestiaryKind.DEMOGORGON,BestiaryKind.FIRE_ELEMENTAL}};
    @SubscribeEvent public static void tick(net.neoforged.neoforge.client.event.ClientTickEvent.Post e){
        if(!Boolean.getBoolean("starrpg.visual250"))return;var mc=Minecraft.getInstance();
        if(!started&&mc.screen instanceof TitleScreen&&mc.getOverlay()==null){
            started=true;mc.options.hideGui=true;mc.options.guiScale().set(2);mc.options.renderDistance().set(4);mc.options.simulationDistance().set(5);mc.getWindow().setWindowed(1280,800);mc.resizeDisplay();
            mc.createWorldOpenFlows().createFreshLevel("starrpg-showcase-250-"+System.currentTimeMillis(),new LevelSettings("StarRPG 2.5 visual verification",GameType.CREATIVE,false,Difficulty.NORMAL,true,new GameRules(),WorldDataConfiguration.DEFAULT),new WorldOptions(250,false,false),WorldPresets::createNormalWorldDimensions,mc.screen);return;
        }
        if(mc.player==null||mc.level==null||mc.getSingleplayerServer()==null)return;
        var server=mc.getSingleplayerServer();var id=mc.player.getUUID();
        if(!configured){configured=true;mc.setScreen(null);server.execute(()->{
            var p=server.getPlayerList().getPlayer(id);var l=p.serverLevel();
            for(int x=-22;x<=22;x++)for(int z=-14;z<=26;z++){var block=(x%6==0||z%6==0)?Blocks.POLISHED_BLACKSTONE_BRICKS:Blocks.DEEPSLATE_TILES;l.setBlock(new BlockPos(x,180,z),block.defaultBlockState(),3);}
            for(int x=-20;x<=20;x+=5)for(int y=181;y<=190;y++){l.setBlock(new BlockPos(x,y,22),Blocks.DEEPSLATE_BRICKS.defaultBlockState(),3);if(y==189)l.setBlock(new BlockPos(x,y,21),Blocks.SEA_LANTERN.defaultBlockState(),3);}
            for(int x=-20;x<=20;x++)for(int y=181;y<=184;y++)l.setBlock(new BlockPos(x,y,23),Blocks.DEEPSLATE_BRICKS.defaultBlockState(),3);
            l.setDayTime(6000);l.getGameRules().getRule(GameRules.RULE_DAYLIGHT).set(false,server);l.getGameRules().getRule(GameRules.RULE_DOMOBSPAWNING).set(false,server);WorldDifficulty.get(server).setTier(0);
            p.teleportTo(l,0,184,-8,0,10);p.getInventory().clearContent();p.setNoGravity(true);p.getAbilities().flying=true;p.onUpdateAbilities();
        });return;}
        if(tick==0&&(mc.player.getY()<183||Math.abs(mc.player.getZ()+8)>2))return;
        tick++;
        if(tick==20){for(var k:BestiaryKind.values()){var m=BestiaryRegistry.TYPES.get(k).get().create(mc.level);if(!(mc.getEntityRenderDispatcher().getRenderer(m) instanceof BestiaryRenderer))throw new IllegalStateException("Missing renderer "+k.id);}StarRPG.LOGGER.info("VISUAL250_ALL_53_RENDERERS_OK");tick+=Math.clamp(Integer.getInteger("starrpg.visual250.start",0),0,22)*100;}
        int stage=(tick-1)/100,step=tick%100;
        if(step==30&&stage<GROUPS.length){server.execute(()->{
            var p=server.getPlayerList().getPlayer(id);var l=p.serverLevel();l.getEntitiesOfClass(BestiaryMob.class,p.getBoundingBox().inflate(60)).forEach(Entity::discard);
            for(int i=0;i<3;i++){var k=GROUPS[stage][i];var m=BestiaryRegistry.TYPES.get(k).get().create(l);m.moveTo((i-1)*9,181,6,155,0);m.yBodyRot=m.yBodyRotO=m.yHeadRot=m.yHeadRotO=155;m.setNoAi(true);m.setInvulnerable(true);m.setNoGravity(true);m.setCustomName(net.minecraft.network.chat.Component.literal(k.name));m.setCustomNameVisible(true);l.addFreshEntity(m);}
        });}
        if(stage>=6&&stage<=11&&step==30){server.execute(()->{var p=server.getPlayerList().getPlayer(id);var l=p.serverLevel();l.getEntitiesOfClass(BestiaryMob.class,p.getBoundingBox().inflate(60)).forEach(Entity::discard);l.setDayTime(15000);p.teleportTo(l,0,184,-4,0,-3);});}
        if(stage>=6&&stage<=11&&step==55){int school=stage-5;server.execute(()->{var p=server.getPlayerList().getPlayer(id);ArcaneSigil.spawn(p.serverLevel(),new Vec3(0,181.1,7),new Vec3(0,0,-1),school+23,MagicSchools.color(school),2.4F,44);});}
        if(stage==12&&step==30){VisualOptions.QUALITY.set(0);StarRPG.LOGGER.info("VISUAL250_QUALITY_LOW");server.execute(()->{var p=server.getPlayerList().getPlayer(id);ArcaneSigil.spawn(p.serverLevel(),new Vec3(0,181.1,7),new Vec3(0,0,-1),26,0x92EEFF,2.4F,60);ArcaneSigil.spawn(p.serverLevel(),new Vec3(0,181.15,7),new Vec3(0,0,-1),38,0xFF3344,5,60);});}
        if(stage==13&&step==30){VisualOptions.QUALITY.set(1);StarRPG.LOGGER.info("VISUAL250_QUALITY_BALANCED");server.execute(()->{var p=server.getPlayerList().getPlayer(id);ArcaneSigil.spawn(p.serverLevel(),new Vec3(0,181.1,7),new Vec3(0,0,-1),28,0xAF68FF,2.4F,60);});}
        if(stage==14&&step==30){VisualOptions.QUALITY.set(2);server.execute(()->{
            var p=server.getPlayerList().getPlayer(id);var l=p.serverLevel();l.setDayTime(6000);p.teleportTo(l,7,183,-4,35,5);
            var m=BestiaryRegistry.TYPES.get(BestiaryKind.RED_DRAGON).get().create(l);m.moveTo(0,181,7,180,0);m.setNoGravity(true);l.addFreshEntity(m);
            var target=EntityType.COW.create(l);target.setPos(0,181,3);target.setNoAi(true);target.setNoGravity(true);target.setInvisible(true);target.setInvulnerable(true);l.addFreshEntity(target);m.setTarget(target);m.startAttack(target,true);
        });}
        if(stage==15&&step==30)server.execute(()->{var p=server.getPlayerList().getPlayer(id);var l=p.serverLevel();l.getEntitiesOfClass(LivingEntity.class,p.getBoundingBox().inflate(60),e2->e2!=p).forEach(Entity::discard);l.setDayTime(15000);p.teleportTo(l,0,184,-4,0,8);});
        if(stage>=15&&stage<=21&&(step==40||step==60||step==80)){int style=stage+2;server.execute(()->{var p=server.getPlayerList().getPlayer(id);ArcaneSigil.spawn(p.serverLevel(),new Vec3(0,182,6),new Vec3(.3,0,-1),style,style==23?0xB46DFF:style==21?0xFFB145:0x88DFFF,1.8F,18);});}
        if(stage==22&&step==45)server.execute(()->{var p=server.getPlayerList().getPlayer(id);int original=Careers.profile(p).selected;try{for(int i=1;i<=6;i++){Careers.profile(p).selected=i+9;var bolt=new MagicBolt(p.serverLevel(),p,0,0);bolt.setPos((i-3.5)*1.6,183,12);bolt.shoot(0,0,-1,.18F,0);p.serverLevel().addFreshEntity(bolt);}}finally{Careers.profile(p).selected=original;}});
        if(step==73&&stage<23)Screenshot.grab(mc.gameDirectory,"starrpg-2.5-scene-"+stage+".png",mc.getMainRenderTarget(),message->StarRPG.LOGGER.info("VISUAL250_SCREENSHOT {}",stage));
        if(tick>=Math.clamp(Integer.getInteger("starrpg.visual250.stages",23),1,23)*100){VisualOptions.QUALITY.set(2);mc.options.hideGui=false;StarRPG.LOGGER.info("VISUAL250_COMPLETE");mc.stop();}
    }
}
