package com.junwo.starrpg.bestiary;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.neoforged.neoforge.entity.PartEntity;

/** Head/neck/tail hits forward to the one real boss. Parts have no save, loot or independent health. */
public final class DragonHitPart extends PartEntity<BestiaryMob> {
    private final EntityDimensions size;
    public DragonHitPart(BestiaryMob parent,float width,float height){super(parent);size=EntityDimensions.scalable(width,height);refreshDimensions();}
    @Override protected void defineSynchedData(SynchedEntityData.Builder b){}
    @Override protected void readAdditionalSaveData(CompoundTag t){}
    @Override protected void addAdditionalSaveData(CompoundTag t){}
    @Override public EntityDimensions getDimensions(Pose pose){return size==null?EntityDimensions.scalable(1,1):size;}
    @Override public boolean isPickable(){return getParent().isAlive();}
    @Override public boolean hurt(DamageSource source,float amount){return getParent().isAlive()&&getParent().hurt(source,amount);}
    @Override public boolean is(Entity other){return this==other||getParent()==other;}
    @Override public boolean shouldBeSaved(){return false;}
}
