package com.junwo.starrpg;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.resources.ResourceLocation;

/** A moving spell has its own faceted core, rotating seals and element-specific glow. */
public final class MagicBoltRenderer extends EntityRenderer<MagicBolt> {
    public MagicBoltRenderer(EntityRendererProvider.Context context){super(context);}
    @Override public ResourceLocation getTextureLocation(MagicBolt e){return CinematicVfx.ATLAS;}
    @Override public void render(MagicBolt bolt,float yaw,float partial,PoseStack p,MultiBufferSource b,int light){
        float age=bolt.tickCount+partial;int color=MagicSchools.color(bolt.school());
        CinematicVfx.draw(p,b,22,color,bolt.spellId()==1?.7F:.4F,5,12,-bolt.getYRot(),-bolt.getXRot());
        p.pushPose();p.mulPose(Axis.YP.rotationDegrees(age*8));p.mulPose(Axis.ZP.rotationDegrees(age*5));CinematicVfx.crystal(p,b,.18F,.45F,color,1);p.popPose();
        p.pushPose();p.mulPose(entityRenderDispatcher.cameraOrientation());drawHalo(p,b,bolt.school(),age);p.popPose();
    }
    public static void drawHalo(PoseStack p,MultiBufferSource b,int school,float age){
        p.pushPose();p.mulPose(Axis.ZP.rotation(age*.06F));CinematicVfx.sprite(p,b,0,.45F,.45F,MagicSchools.color(school),.7F);p.mulPose(Axis.ZP.rotation(-age*.1F));CinematicVfx.sprite(p,b,school==1?2:school==3?4:school==5?9:7,.26F,.3F,MagicSchools.color(school),.85F);p.popPose();
    }
}
