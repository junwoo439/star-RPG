package com.junwo.starrpg.adventure;
import com.junwo.starrpg.*;
import net.minecraft.world.entity.*;
import net.neoforged.neoforge.registries.*;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
@EventBusSubscriber(modid=StarRPG.MODID,bus=EventBusSubscriber.Bus.MOD)
public final class AdventureEntities {
    public static final DeferredHolder<EntityType<?>,EntityType<QuestEnvoy>> ENVOY=ModEntities.ENTITIES.register("star_envoy",()->EntityType.Builder.<QuestEnvoy>of(QuestEnvoy::new,MobCategory.MISC).sized(.6F,1.95F).clientTrackingRange(8).build("starrpg:star_envoy"));
    public static final DeferredItem<net.neoforged.neoforge.common.DeferredSpawnEggItem> EGG=StarRPG.ITEMS.register("star_envoy_spawn_egg",()->new net.neoforged.neoforge.common.DeferredSpawnEggItem(ENVOY,0x33396D,0xF3D791,new net.minecraft.world.item.Item.Properties()));
    public static void init(){}
    @SubscribeEvent public static void attributes(net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent e){e.put(ENVOY.get(),net.minecraft.world.entity.npc.Villager.createAttributes().build());}
}
