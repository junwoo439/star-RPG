package com.junwo.starrpg;

import java.util.*;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

public final class MaterialShopScreen extends AbstractContainerScreen<MaterialShopMenu> {
    private final Map<Button,Integer> actions=new HashMap<>();
    private int preview=-1,page,careerPage;
    public MaterialShopScreen(MaterialShopMenu m,Inventory i,Component t){super(m,i,t);imageWidth=360;imageHeight=250;}
    @Override protected void init(){super.init();build();}
    private Button button(String label,int x,int y,int width,Runnable action){return addRenderableWidget(Button.builder(Component.literal(label),b->action.run()).bounds(leftPos+x,topPos+y,width,18).build());}
    private void action(String label,int id,int x,int y,int width){var b=button(label,x,y,width,()->{if(minecraft!=null&&minecraft.gameMode!=null)minecraft.gameMode.handleInventoryButtonClick(menu.containerId,id);});actions.put(b,id);}
    private void build(){
        clearWidgets();actions.clear();String[] names={"상점","판매","직업·전직","마법","모험"};
        for(int i=0;i<5;i++){final int tab=i;button(names[i],8+i*69,27,66,()->{if(tab==4)net.neoforged.neoforge.network.PacketDistributor.sendToServer(new ActionPayload(6));else{menu.clientTab=tab;build();}}).active=i!=menu.clientTab;}
        switch(menu.clientTab){
            case 0->{for(int i=0;i<3;i++){int product=page*3+i;if(product>=Economy.Product.values().length)break;action("1개",100+product*2,238,53+i*23,48);action("8개",101+product*2,292,53+i*23,48);}
                button("◀",8,120,36,()->{page=Math.max(0,page-1);build();});button("▶",306,120,36,()->{page=Math.min((Economy.Product.values().length-1)/3,page+1);build();});}
            case 1->{action("1개 판매",20,158,79,68);action("전량 판매",21,233,79,72);}
            case 2->{for(int i=0;i<8;i++){int index=careerPage*8+i;if(index>=Careers.ACTIVE.length)break;final int id=Careers.ACTIVE[index];button(Careers.NAMES[id],8,49+i*19,86,()->{preview=id;build();});}
                button("◀",8,210,40,()->{careerPage=Math.max(0,careerPage-1);build();});button("▶",54,210,40,()->{careerPage=Math.min((Careers.ACTIVE.length-1)/8,careerPage+1);build();});
                if(preview>=0){action(menu.job()==preview?"현재 직업":menu.job()<0?"무료로 확정":"500 G · 초기화",200+preview,105,224,115);action("다음 전직",50,228,224,118);}}
            case 3->{for(int i=0;i<3;i++)action(MagicSchools.spellName(menu.job(),i),70+i,8+i*114,72,108);}
        }updateButtons();
    }
    private void updateButtons(){actions.forEach((b,id)->{
        if(id>=200&&id<200+Careers.COUNT){
            b.active=menu.job()!=id-200;
            b.setMessage(Component.literal(menu.job()==id-200?"현재 직업":menu.job()<0?"무료로 확정":"500 G · 초기화"));
            b.setTooltip(net.minecraft.client.gui.components.Tooltip.create(Component.literal(menu.job()<0?"첫 직업 선택은 무기 강화를 유지합니다.":"직업 변경 확정: 인벤토리·보조 손·메뉴에 든 이전 직업 무기 전부 +0. 룬·내구도 유지. 같은 직업 전직은 초기화하지 않습니다.")));
        }
        else if(id>=100){int index=(id-100)/2;b.active=menu.enabled()&&menu.balance()>=(long)menu.price(index)*(id%2==0?1:8);}
        else if(id==20||id==21)b.active=menu.enabled()&&menu.canSell()&&menu.sellPrice()>0&&!menu.saleItem().isEmpty();
        else if(id>=40&&id<50)b.active=menu.job()!=id-40;
        else if(id==50)b.active=menu.job()==preview&&menu.rank()>0&&menu.rank()<Integer.MAX_VALUE;
        else if(id>=70&&id<=72){b.active=Careers.mage(menu.job())&&menu.spell()>=0&&menu.spell()!=id-70;b.setMessage(Component.literal(MagicSchools.spellName(menu.job(),id-70)));}
    });}
    @Override protected void containerTick(){super.containerTick();updateButtons();}
    @Override protected void renderBg(GuiGraphics g,float t,int x,int y){
        g.fillGradient(leftPos,topPos,leftPos+imageWidth,topPos+imageHeight,0xFF283B50,0xFF101823);
        if(menu.clientTab==2)g.fill(leftPos+100,topPos+49,leftPos+352,topPos+220,0xFF101923);
        for(var slot:menu.slots)if(slot.isActive())g.fill(leftPos+slot.x-1,topPos+slot.y-1,leftPos+slot.x+17,topPos+slot.y+17,0xFF101820);
        if(menu.clientTab==0)for(int i=0;i<3;i++){int n=page*3+i;if(n<Economy.Product.values().length)g.renderItem(Economy.Product.values()[n].stack(1),leftPos+12,topPos+54+i*23);}
    }
    private void text(GuiGraphics g,String s,int x,int y,int color){g.drawString(font,s,x,y,color,false);}
    private void fit(GuiGraphics g,String s,int x,int y,int color){g.pose().pushPose();g.pose().translate(x,y,0);float scale=Math.min(1,238f/Math.max(1,font.width(s)));g.pose().scale(scale,scale,1);text(g,s,0,0,color);g.pose().popPose();}
    @Override protected void renderLabels(GuiGraphics g,int x,int y){
        text(g,"StarRPG",8,10,0xFFFFFF);text(g,String.format(java.util.Locale.ROOT,"%,d G",menu.balance()),220,10,0xFFD978);
        switch(menu.clientTab){
            case 0->{for(int i=0;i<3;i++){int n=page*3+i;if(n<Economy.Product.values().length)text(g,Economy.Product.values()[n].label+"  "+menu.price(n)+" G",35,58+i*23,0xFFFFFF);}text(g,"생존 물자  "+(page+1)+" / "+((Economy.Product.values().length+2)/3),110,123,0xBCD0E0);}
            case 1->{text(g,"판매할 아이템을 왼쪽 칸에 넣으세요.",8,55,0xFFFFFF);text(g,"개당 "+menu.sellPrice()+" G",54,80,0xFFD978);text(g,"전량 "+menu.sellPrice()*menu.saleItem().getCount()+" G",54,93,0xFFD978);text(g,"내구도 반영 · 내용물이 있는 보관함 판매 불가",8,116,0xBCD0E0);}
            case 2->{
                if(preview<0){text(g,"직업 이름을 눌러 살펴보세요.",110,66,0xF2DCA8);text(g,"클릭만으로 직업이 바뀌지 않습니다.",110,87,0xBDCADD);text(g,"설명을 읽고 아래에서 확정하세요.",110,108,0xBDCADD);text(g,"첫 선택 무료 · 교체 500 G / 30초",110,139,0xBDCADD);text(g,"검·도끼는 누구나 사용하는 입문 무기",110,161,0xBDCADD);}
                else{
                    int rank=menu.previewRank(preview);fit(g,Careers.NAMES[preview]+" · "+rank+"차"+(preview==menu.job()?" (현재 직업)":" (미리보기)"),108,56,0xFFD978);
                    fit(g,"전용 무기: "+Careers.WEAPONS[preview],108,74,0xFFFFFF);
                    fit(g,Careers.mage(preview)?Careers.PASSIVES[preview]:JobWeaponTraits.description(preview),108,90,0xBDCADD);fit(g,Careers.ABILITIES[preview],108,106,0xA9D9FF);
                    fit(g,"G: 6초 동안 강화 타격 3회",108,122,0xB6EDBD);
                    fit(g,CareerTechniques.promotionText(preview),108,137,0xB6EDBD);
                    fit(g,"매 5회 전직: 체력·무기 능력치 계속 성장",108,152,0xB6EDBD);
                    int next=Math.max(1,rank);fit(g,"XP "+menu.previewXp(preview)+"/"+Careers.xpCost(next)+" · 실적 "+menu.previewMastery(preview)+"/"+Careers.masteryCost(next),108,172,0xBDCADD);
                    fit(g,Careers.materialName(preview)+" "+menu.previewMaterials(preview)+"/"+Careers.materialCount(next)+" · "+Careers.goldCost(next)+" G",108,187,0xF2DCA8);
                    fit(g,menu.job()>=0&&menu.job()!=preview?"변경 확정 시 소지한 이전 직업 무기 전부 +0":"실적: "+Careers.TRIALS[preview],108,203,menu.job()>=0&&menu.job()!=preview?0xFFAC82:0x9DB4C9);
                }
            }
            case 3->{text(g,"마나 "+menu.mana()+" / "+menu.maxMana(),8,54,0xC2A8FF);
                text(g,"주문 "+menu.cooldown(0)+" / 보조 "+menu.cooldown(1),8,96,0xFFFFFF);
                text(g,"R "+MagicSchools.ultimateName(menu.job())+" "+menu.cooldown(2)+" / G "+menu.cooldown(3),8,110,0xFFD978);
                text(g,"우클릭: 주문 / Shift+우클릭: 변경",8,124,0xBCD0E0);}
        }
    }
    @Override public void render(GuiGraphics g,int x,int y,float t){super.render(g,x,y,t);renderTooltip(g,x,y);}
}
