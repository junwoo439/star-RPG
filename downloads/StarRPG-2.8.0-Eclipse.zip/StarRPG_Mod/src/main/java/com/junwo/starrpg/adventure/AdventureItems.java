package com.junwo.starrpg.adventure;

import com.junwo.starrpg.*;
import net.minecraft.world.item.*;
import net.neoforged.neoforge.registries.DeferredItem;

public final class AdventureItems {
    public static final DeferredItem<Item> ORE=material("astral_ore"),ALLOY=material("astral_alloy"),HERB=material("star_herb"),SCALE=material("moon_scale"),DRAGON=material("dragon_heart"),LICH=material("lich_soul"),GOLEM=material("golem_core"),RELIC=material("dungeon_relic"),RIFT=material("rift_shard");
    public static final DeferredItem<CareerWeaponItem> RELIC_SPEAR=StarRPG.ITEMS.register("relic_spear",()->new CareerWeaponItem(new Item.Properties().rarity(Rarity.RARE),0,6,-2.7F)),RELIC_BLADE=StarRPG.ITEMS.register("relic_greatsword",()->new CareerWeaponItem(new Item.Properties().rarity(Rarity.RARE),5,8,-3F)),RELIC_SCYTHE=StarRPG.ITEMS.register("relic_scythe",()->new CareerWeaponItem(new Item.Properties().rarity(Rarity.RARE),7,6,-2.8F));
    private static DeferredItem<Item> material(String id){return StarRPG.ITEMS.register(id,()->new Item(new Item.Properties()));}
    public static void init(){}
}
