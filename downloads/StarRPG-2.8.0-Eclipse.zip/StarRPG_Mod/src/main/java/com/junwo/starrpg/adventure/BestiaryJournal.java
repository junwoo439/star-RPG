package com.junwo.starrpg.adventure;

import com.junwo.starrpg.*;
import com.junwo.starrpg.bestiary.*;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;

@EventBusSubscriber(modid=StarRPG.MODID)
public final class BestiaryJournal {
    public static boolean seen(Player p,BestiaryKind k){return AdventureData.value(p,"seen_"+k.id)>0;}
    public static int kills(Player p,BestiaryKind k){return AdventureData.value(p,"kills_"+k.id);}
    @SubscribeEvent public static void look(net.neoforged.neoforge.event.tick.PlayerTickEvent.Post e){var p=e.getEntity();if(p.level().isClientSide()||p.tickCount%40!=0||p.isSpectator())return;for(var m:p.level().getEntitiesOfClass(BestiaryMob.class,p.getBoundingBox().inflate(24),m->m.isAlive()&&p.hasLineOfSight(m)))if(!seen(p,m.kind)){AdventureData.set(p,"seen_"+m.kind.id,1);p.displayClientMessage(net.minecraft.network.chat.Component.literal("도감 발견: "+m.kind.name),true);}}
    @SubscribeEvent public static void kill(net.neoforged.neoforge.event.entity.living.LivingDeathEvent e){if(e.getEntity().level().isClientSide()||!(e.getSource().getEntity() instanceof Player p)||!(e.getEntity() instanceof BestiaryMob m)||m.getPersistentData().hasUUID("starrpg_summoner"))return;AdventureData.set(p,"seen_"+m.kind.id,1);AdventureData.add(p,"kills_"+m.kind.id,1);AdventureData.add(p,"kills",1);if(m.kind.boss)AdventureData.add(p,"bosses",1);}
    public static boolean claim(Player p,BestiaryKind k){if(p.level().isClientSide()||kills(p,k)<10||AdventureData.value(p,"journal_paid_"+k.id)>0)return false;AdventureData.set(p,"journal_paid_"+k.id,1);StarWallet.get(p.getServer()).credit(p.getUUID(),k.boss?1500:150);LifeJobs.give(p,new net.minecraft.world.item.ItemStack(StarRPG.STAR_FRAGMENT.get(),k.boss?3:1));return true;}
    public static boolean complete(Player p){for(var k:BestiaryKind.values())if(AdventureData.value(p,"journal_paid_"+k.id)==0)return false;if(AdventureData.value(p,"journal_complete")>0)return false;AdventureData.set(p,"journal_complete",1);StarWallet.get(p.getServer()).credit(p.getUUID(),10000);LifeJobs.give(p,new net.minecraft.world.item.ItemStack(StarRPG.LEGENDARY_RUNE.get()));return true;}
}
