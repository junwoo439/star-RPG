@echo off
chcp 65001 >nul
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-dragon-mods.ps1"
if errorlevel 1 (
  echo Installation failed. Existing files were preserved or restored.
  pause
  exit /b 1
)
echo Copy every JAR in this folder's mods directory to BOTH server and client mods directories.
pause
