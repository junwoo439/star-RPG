package com.junwo.starrpg;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

@EventBusSubscriber(modid = StarRPG.MODID)
public final class StarRPGCommands {
    @SubscribeEvent
    public static void register(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("starrpg")
            .then(Commands.literal("setlevel").requires(s -> s.hasPermission(2))
                .then(Commands.argument("level", IntegerArgumentType.integer(0,10)).executes(ctx -> {
                    var player = ctx.getSource().getPlayerOrException();
                    var item = player.getMainHandItem();
                    if (!EnhancementData.supports(item)) { ctx.getSource().sendFailure(Component.literal("장비를 손에 들어 주세요.")); return 0; }
                    EnhancementData.setLevel(item, IntegerArgumentType.getInteger(ctx,"level"));
                    EnhancementLore.update(item);
                    ctx.getSource().sendSuccess(() -> Component.literal("장비 강화 데이터 적용 완료"), true);
                    return 1;
                })))
            .then(Commands.literal("difficulty").executes(ctx -> {
                var player = ctx.getSource().getPlayerOrException();
                int current = MonsterProgression.gearTier(player);
                int peak = Math.max(current, player.getPersistentData().getInt("starrpg_equipment_peak"));
                ctx.getSource().sendSuccess(() -> Component.literal("현재 장비 단계: " + current + " / 몬스터 기준 단계: " + peak), false);
                return 1;
            })));
    }
}
