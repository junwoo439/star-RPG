package com.junwo.starrpg;

import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;

public class RuneEngravingMenu extends AbstractContainerMenu {

    private final SimpleContainer engravingInventory = new SimpleContainer(2);

    public RuneEngravingMenu(int containerId, Inventory playerInventory) {
        super(ModMenus.RUNE_ENGRAVING_MENU.get(), containerId);

        // 0번: 룬을 부여할 검 또는 도끼
        this.addSlot(new Slot(engravingInventory, 0, 53, 35) {
            @Override
            public boolean mayPlace(ItemStack stack) {
                return stack.getItem() instanceof SwordItem
                        || stack.getItem() instanceof AxeItem;
            }

            @Override
            public int getMaxStackSize() {
                return 1;
            }
        });

        // 1번: 별의 룬
        this.addSlot(new Slot(engravingInventory, 1, 107, 35) {
            @Override
            public boolean mayPlace(ItemStack stack) {
                return RuneItemHelper.isRune(stack);
            }

            @Override
            public int getMaxStackSize() {
                return 1;
            }
        });

        // 플레이어 인벤토리
        for (int row = 0; row < 3; row++) {
            for (int column = 0; column < 9; column++) {
                this.addSlot(new Slot(
                        playerInventory,
                        column + row * 9 + 9,
                        8 + column * 18,
                        118 + row * 18
                ));
            }
        }

        // 핫바
        for (int column = 0; column < 9; column++) {
            this.addSlot(new Slot(
                    playerInventory,
                    column,
                    8 + column * 18,
                    176
            ));
        }
    }

    @Override
    public boolean stillValid(Player player) {
        return true;
    }

    @Override
    public void removed(Player player) {
        super.removed(player);
        this.clearContainer(player, engravingInventory);
    }
    @Override
    public boolean clickMenuButton(Player player, int buttonId) {
        if (player.level().isClientSide() || buttonId != 0) {
            return false;
        }

        ItemStack weapon = engravingInventory.getItem(0);
        ItemStack rune = engravingInventory.getItem(1);

        if (weapon.isEmpty()) {
            player.sendSystemMessage(
                    net.minecraft.network.chat.Component.literal(
                            "각인할 검 또는 도끼를 넣어 주세요."
                    )
            );
            return false;
        }

        if (rune.isEmpty()) {
            player.sendSystemMessage(
                    net.minecraft.network.chat.Component.literal(
                            "별의 룬을 넣어 주세요."
                    )
            );
            return false;
        }

        RuneWeaponType weaponType;

        if (weapon.getItem() instanceof SwordItem) {
            weaponType = RuneWeaponType.SWORD;
        } else if (weapon.getItem() instanceof AxeItem) {
            weaponType = RuneWeaponType.AXE;
        } else {
            player.sendSystemMessage(
                    net.minecraft.network.chat.Component.literal(
                            "검 또는 도끼만 룬 각인이 가능합니다."
                    )
            );
            return false;
        }

        RuneRarity rarity = RuneItemHelper.getRarity(rune);

        if (rarity == null) {
            player.sendSystemMessage(
                    net.minecraft.network.chat.Component.literal(
                            "올바른 별의 룬을 넣어 주세요."
                    )
            );
            return false;
        }

        RuneEffect oldEffect = RuneDataHelper.getRuneEffect(weapon);
        if (oldEffect != null && rarity.ordinal() < oldEffect.getRarity().ordinal()) {
            player.sendSystemMessage(net.minecraft.network.chat.Component.literal("기존 룬과 같거나 높은 등급이 필요합니다."));
            return false;
        }
        RuneEffect effect = RuneEffectManager.getRandomEffect(
                rarity,
                weaponType,
                player.getRandom()
        );

        if (effect == null) {
            player.sendSystemMessage(
                    net.minecraft.network.chat.Component.literal(
                            "룬 효과를 찾지 못했습니다."
                    )
            );
            return false;
        }

        RuneDataHelper.setRuneEffect(weapon, effect);
        EnhancementLore.update(weapon);
        rune.shrink(1);

        player.sendSystemMessage(
                net.minecraft.network.chat.Component.literal(
                        rarity.getKoreanName()
                                + " 룬 각인 성공: "
                                + effect.getKoreanName()
                )
        );

        this.broadcastChanges();
        return true;
    }

    @Override
    public ItemStack quickMoveStack(Player player, int slotIndex) {
        return ItemStack.EMPTY;
    }
}