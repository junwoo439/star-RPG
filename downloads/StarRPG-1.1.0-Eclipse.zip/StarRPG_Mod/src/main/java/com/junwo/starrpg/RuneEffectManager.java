package com.junwo.starrpg;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.util.RandomSource;

public class RuneEffectManager {

    public static RuneEffect getRandomEffect(
            RuneRarity rarity,
            RuneWeaponType weaponType,
            RandomSource random
    ) {
        List<RuneEffect> possibleEffects = new ArrayList<>();

        for (RuneEffect effect : RuneEffect.values()) {
            if (effect.getRarity() == rarity
                    && effect.getWeaponType() == weaponType) {

                possibleEffects.add(effect);
            }
        }

        if (possibleEffects.isEmpty()) {
            return null;
        }

        return possibleEffects.get(
                random.nextInt(possibleEffects.size())
        );
    }
}