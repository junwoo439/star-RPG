package com.junwo.starrpg;

public enum RuneWeaponType {
    SWORD,
    AXE
}