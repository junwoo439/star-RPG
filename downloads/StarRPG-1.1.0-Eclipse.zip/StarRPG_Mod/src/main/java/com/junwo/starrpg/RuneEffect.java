package com.junwo.starrpg;

public enum RuneEffect {

    // ===== 검: 일반 =====
    SWORD_WEAK_ABSORPTION(
            "미약한 흡수",
            RuneRarity.COMMON,
            RuneWeaponType.SWORD
    ),
    SWORD_STAR_SLASH(
            "별빛 절단",
            RuneRarity.COMMON,
            RuneWeaponType.SWORD
    ),
    SWORD_CHASE(
            "추격",
            RuneRarity.COMMON,
            RuneWeaponType.SWORD
    ),
    SWORD_GUARD_RESPONSE(
            "수호 반응",
            RuneRarity.COMMON,
            RuneWeaponType.SWORD
    ),

    // ===== 검: 희귀 =====
    SWORD_STAR_HEAL(
            "별빛 회복",
            RuneRarity.RARE,
            RuneWeaponType.SWORD
    ),
    SWORD_CONTINUOUS_SLASH(
            "연속 참격",
            RuneRarity.RARE,
            RuneWeaponType.SWORD
    ),
    SWORD_METEOR_FRAGMENT(
            "유성 파편",
            RuneRarity.RARE,
            RuneWeaponType.SWORD
    ),
    SWORD_DUEL_WILL(
            "결투의 의지",
            RuneRarity.RARE,
            RuneWeaponType.SWORD
    ),

    // ===== 검: 에픽 =====
    SWORD_METEOR_STRIKE(
            "유성 검격",
            RuneRarity.EPIC,
            RuneWeaponType.SWORD
    ),
    SWORD_STAR_BIND(
            "별의 속박",
            RuneRarity.EPIC,
            RuneWeaponType.SWORD
    ),
    SWORD_HALF_MOON(
            "반월",
            RuneRarity.EPIC,
            RuneWeaponType.SWORD
    ),
    SWORD_LIFE_TRANSFER(
            "생명 전환",
            RuneRarity.EPIC,
            RuneWeaponType.SWORD
    ),

    // ===== 검: 레전더리 =====
    SWORD_CELESTIAL_COLLAPSE(
            "천체 붕괴",
            RuneRarity.LEGENDARY,
            RuneWeaponType.SWORD
    ),
    SWORD_RADIANCE(
            "광휘",
            RuneRarity.LEGENDARY,
            RuneWeaponType.SWORD
    ),
    SWORD_STAR_OATH(
            "별의 맹세",
            RuneRarity.LEGENDARY,
            RuneWeaponType.SWORD
    ),
    SWORD_ECLIPSE(
            "일식",
            RuneRarity.LEGENDARY,
            RuneWeaponType.SWORD
    ),

    // ===== 검: 신화 =====
    SWORD_SUPERNOVA(
            "초신성",
            RuneRarity.MYTHIC,
            RuneWeaponType.SWORD
    ),
    SWORD_TIME_SLASH(
            "시간 절단",
            RuneRarity.MYTHIC,
            RuneWeaponType.SWORD
    ),
    SWORD_CONSTELLATION(
            "별자리의 검",
            RuneRarity.MYTHIC,
            RuneWeaponType.SWORD
    ),
    SWORD_SKY_JUDGMENT(
            "천공의 심판",
            RuneRarity.MYTHIC,
            RuneWeaponType.SWORD
    ),

    // ===== 도끼: 일반 =====
    AXE_SHOCK(
            "충격",
            RuneRarity.COMMON,
            RuneWeaponType.AXE
    ),
    AXE_CRACK_TRACE(
            "균열의 흔적",
            RuneRarity.COMMON,
            RuneWeaponType.AXE
    ),
    AXE_WEIGHT(
            "중압",
            RuneRarity.COMMON,
            RuneWeaponType.AXE
    ),
    AXE_BREAK(
            "파쇄",
            RuneRarity.COMMON,
            RuneWeaponType.AXE
    ),

    // ===== 도끼: 희귀 =====
    AXE_CRACK(
            "균열",
            RuneRarity.RARE,
            RuneWeaponType.AXE
    ),
    AXE_HUNTER(
            "사냥꾼",
            RuneRarity.RARE,
            RuneWeaponType.AXE
    ),
    AXE_SMASH(
            "강타",
            RuneRarity.RARE,
            RuneWeaponType.AXE
    ),
    AXE_BATTLE_INSTINCT(
            "전투 본능",
            RuneRarity.RARE,
            RuneWeaponType.AXE
    ),

    // ===== 도끼: 에픽 =====
    AXE_EXECUTION(
            "처형",
            RuneRarity.EPIC,
            RuneWeaponType.AXE
    ),
    AXE_SHATTER(
            "분쇄",
            RuneRarity.EPIC,
            RuneWeaponType.AXE
    ),
    AXE_EXPLOSION(
            "폭렬 타격",
            RuneRarity.EPIC,
            RuneWeaponType.AXE
    ),
    AXE_BLOOD_TRACE(
            "피의 추적",
            RuneRarity.EPIC,
            RuneWeaponType.AXE
    ),

    // ===== 도끼: 레전더리 =====
    AXE_BLOOD_OATH(
            "피의 맹세",
            RuneRarity.LEGENDARY,
            RuneWeaponType.AXE
    ),
    AXE_EARTH_SMASH(
            "대지 강타",
            RuneRarity.LEGENDARY,
            RuneWeaponType.AXE
    ),
    AXE_DEATH_MARK(
            "죽음의 낙인",
            RuneRarity.LEGENDARY,
            RuneWeaponType.AXE
    ),
    AXE_BERSERKER_RAGE(
            "광전사의 분노",
            RuneRarity.LEGENDARY,
            RuneWeaponType.AXE
    ),

    // ===== 도끼: 신화 =====
    AXE_DOOM_MARK(
            "멸망의 표식",
            RuneRarity.MYTHIC,
            RuneWeaponType.AXE
    ),
    AXE_FINAL_BLOW(
            "종말의 강타",
            RuneRarity.MYTHIC,
            RuneWeaponType.AXE
    ),
    AXE_BLOOD_STORM(
            "피의 폭풍",
            RuneRarity.MYTHIC,
            RuneWeaponType.AXE
    ),
    AXE_GIANT_STRENGTH(
            "거인의 힘",
            RuneRarity.MYTHIC,
            RuneWeaponType.AXE
    );

    private final String koreanName;
    private final RuneRarity rarity;
    private final RuneWeaponType weaponType;

    RuneEffect(
            String koreanName,
            RuneRarity rarity,
            RuneWeaponType weaponType
    ) {
        this.koreanName = koreanName;
        this.rarity = rarity;
        this.weaponType = weaponType;
    }

    public String getKoreanName() {
        return koreanName;
    }

    public RuneRarity getRarity() {
        return rarity;
    }

    public RuneWeaponType getWeaponType() {
        return weaponType;
    }
}