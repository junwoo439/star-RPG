package com.junwo.starrpg;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingFallEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.CriticalHitEvent;
import net.neoforged.neoforge.event.tick.EntityTickEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

@EventBusSubscriber(modid = StarRPG.MODID)
public class EnhancementEffects {
    private record HealWindow(long start, float healed) {}
    private static final Map<UUID, Float> HEALTH_BEFORE = new HashMap<>();
    private static final Map<UUID, HealWindow> HEAL_WINDOWS = new HashMap<>();

    @SubscribeEvent
    public static void beforeDamage(net.neoforged.neoforge.event.entity.living.LivingDamageEvent.Pre event) {
        if (CombatRules.primary(event.getSource())) HEALTH_BEFORE.put(event.getEntity().getUUID(), event.getEntity().getHealth());
    }

    @SubscribeEvent
    public static void afterDamage(net.neoforged.neoforge.event.entity.living.LivingDamageEvent.Post event) {
        if (!CombatRules.primary(event.getSource())) return;
        Float before = HEALTH_BEFORE.remove(event.getEntity().getUUID());
        if (before == null || !(event.getSource().getEntity() instanceof Player player)) return;
        ItemStack weapon = player.getMainHandItem();
        if (!(weapon.getItem() instanceof SwordItem) || EnhancementData.level(weapon) < 10) return;
        float actual = Math.max(0, Math.min(event.getNewDamage(), before - event.getEntity().getHealth()));
        long now = player.level().getGameTime();
        HealWindow window = HEAL_WINDOWS.get(player.getUUID());
        if (window == null || now - window.start() >= 20) window = new HealWindow(now, 0);
        float healing = actual * Config.LIFESTEAL.get().floatValue();
        if (event.getEntity() instanceof Player victim && hasPlusTenBoots(victim)) healing *= 0.5F;
        healing = Math.max(0, Math.min(healing, Config.HEAL_CAP.get().floatValue() - window.healed()));
        player.heal(healing);
        HEAL_WINDOWS.put(player.getUUID(), new HealWindow(window.start(), window.healed() + healing));
    }


    private static final ResourceLocation ARMOR_HEALTH_ID =
            ResourceLocation.fromNamespaceAndPath(
                    StarRPG.MODID,
                    "armor_enhancement_health"
            );

    private static final ResourceLocation SWORD_HEALTH_ID =
            ResourceLocation.fromNamespaceAndPath(
                    StarRPG.MODID,
                    "sword_enhancement_health"
            );

    private record TargetKey(UUID attackerId, UUID targetId) {}

    private static final Map<TargetKey, Integer> AXE_COMBO_COUNT =
            new HashMap<>();

    private static final Map<TargetKey, Long> AXE_LAST_HIT_TIME =
            new HashMap<>();

    private static final Map<UUID, BleedData> BLEED_DATA =
            new HashMap<>();

    private record BleedData(long endTime, float damage, UUID attackerId) {
    }

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        Player player = event.getEntity();

        if (player.level().isClientSide()) {
            return;
        }

        updateArmorHealth(player);
        updateSwordHealth(player);
        applyArmorEffects(player);
        if (player instanceof net.minecraft.server.level.ServerPlayer serverPlayer
                && player.level().getGameTime() % 10 == 0) {

            ChestAbilityManager.showCooldown(serverPlayer);
        }
    }

    @SubscribeEvent
    public static void onLivingHurt(LivingIncomingDamageEvent event) {
        if (!CombatRules.primary(event.getSource())) return;
        if (!(event.getSource().getEntity() instanceof Player player)) {
            return;
        }

        ItemStack weapon = player.getMainHandItem();
        int level = getEnhancementLevel(weapon);

        if (level <= 0) {
            return;
        }

        // 검·도끼: 강화 단계당 피해 +1
        if (weapon.getItem() instanceof SwordItem
                || weapon.getItem() instanceof AxeItem) {

        	event.setAmount(event.getAmount() + level * CombatRules.attackScale(event.getSource()));
        }

        // +10 도끼: 출혈 콤보
        if (weapon.getItem() instanceof AxeItem && level >= 10 && CombatRules.charged(event.getSource())) {
            LivingEntity target = event.getEntity();

            if (target != player) {
                applyAxeBleedCombo(player, target, event);
            }
        }

    }

    @SubscribeEvent
    public static void onCriticalHit(CriticalHitEvent event) {
        Player player = event.getEntity();

        if (player.level().isClientSide()) {
            return;
        }

        ItemStack weapon = player.getMainHandItem();

        if (!(weapon.getItem() instanceof AxeItem)) {
            return;
        }

        int level = getEnhancementLevel(weapon);

        if (level < 6 || !event.isCriticalHit()) {
            return;
        }

        float extraCriticalDamage = (level - 5) * 0.10F;

        event.setDamageMultiplier(
                event.getDamageMultiplier() + extraCriticalDamage
        );
    }

        // +6부터 강

    @SubscribeEvent
    public static void onLivingFall(LivingFallEvent event) {
        if (!(event.getEntity() instanceof Player player)) {
            return;
        }

        if (player.level().isClientSide()) {
            return;
        }

        // +10 부츠: 낙하 피해 무효
        if (hasPlusTenBoots(player)) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onEntityTick(EntityTickEvent.Post event) {
        if (!(event.getEntity() instanceof LivingEntity target)) {
            return;
        }

        if (target.level().isClientSide()) {
            return;
        }

        BleedData bleed = BLEED_DATA.get(target.getUUID());

        if (bleed == null) {
            return;
        }

        long now = target.level().getGameTime();

        if (now >= bleed.endTime()) {
            BLEED_DATA.remove(target.getUUID());
            return;
        }

        // 1초마다 출혈 피해
        if (target.tickCount % 20 == 0) {
            Player attacker = target.level().getPlayerByUUID(bleed.attackerId());
            if (attacker != null) CombatRules.runeDamage(attacker, target, bleed.damage());
        }
    }

    private static void applyAxeBleedCombo(
            Player player,
            LivingEntity target,
            LivingIncomingDamageEvent event
    ) {
        TargetKey targetId = new TargetKey(player.getUUID(), target.getUUID());
        long now = player.level().getGameTime();

        long lastHitTime = AXE_LAST_HIT_TIME.getOrDefault(
                targetId,
                -200L
        );

        int comboCount;

        // 5초 동안 공격하지 않으면 콤보 초기화
        if (now - lastHitTime > 100) {
            comboCount = 1;
        } else {
            comboCount = AXE_COMBO_COUNT.getOrDefault(targetId, 0) + 1;
        }

        AXE_COMBO_COUNT.put(targetId, comboCount);
        AXE_LAST_HIT_TIME.put(targetId, now);

        float bleedDamage;

        if (comboCount <= 2) {
            bleedDamage = 1.0F;
        } else if (comboCount <= 4) {
            bleedDamage = 2.0F;
        } else {
            bleedDamage = 4.0F;
        }

        applyRuneBleed(target, player, 100, bleedDamage);
        event.setAmount(event.getAmount() + bleedDamage);

        player.sendSystemMessage(
                Component.literal(
                        "출혈 " + comboCount
                        + "타: 추가 피해 "
                        + (int) bleedDamage
                )
        );
    }

    public static boolean hasBleed(LivingEntity target) { return BLEED_DATA.containsKey(target.getUUID()); }

    public static void applyRuneBleed(LivingEntity target, Player attacker, int duration, float damage) {
        if (!CombatRules.canHarm(attacker, target)) return;
        BLEED_DATA.put(target.getUUID(), new BleedData(target.level().getGameTime() + duration, damage, attacker.getUUID()));
    }

    private static void updateArmorHealth(Player player) {
        int totalArmorLevel = 0;

        totalArmorLevel += getEnhancementLevel(
                player.getItemBySlot(EquipmentSlot.HEAD)
        );
        totalArmorLevel += getEnhancementLevel(
                player.getItemBySlot(EquipmentSlot.CHEST)
        );
        totalArmorLevel += getEnhancementLevel(
                player.getItemBySlot(EquipmentSlot.LEGS)
        );
        totalArmorLevel += getEnhancementLevel(
                player.getItemBySlot(EquipmentSlot.FEET)
        );

        AttributeInstance maxHealth =
                player.getAttribute(Attributes.MAX_HEALTH);

        if (maxHealth == null) {
            return;
        }

        if (totalArmorLevel <= 0) {
            maxHealth.removeModifier(ARMOR_HEALTH_ID);
            return;
        }

        maxHealth.addOrUpdateTransientModifier(
                new AttributeModifier(
                        ARMOR_HEALTH_ID,
                        totalArmorLevel,
                        AttributeModifier.Operation.ADD_VALUE
                )
        );
    }

    private static void updateSwordHealth(Player player) {
        ItemStack sword = player.getMainHandItem();

        AttributeInstance maxHealth =
                player.getAttribute(Attributes.MAX_HEALTH);

        if (maxHealth == null) {
            return;
        }

        if (!(sword.getItem() instanceof SwordItem)) {
            maxHealth.removeModifier(SWORD_HEALTH_ID);
            return;
        }

        int level = getEnhancementLevel(sword);

        if (level < 6) {
            maxHealth.removeModifier(SWORD_HEALTH_ID);
            return;
        }

        // +6부터 한 단계당 최대 체력 +2
        int healthBonus = (level - 5) * 2;

        maxHealth.addOrUpdateTransientModifier(
                new AttributeModifier(
                        SWORD_HEALTH_ID,
                        healthBonus,
                        AttributeModifier.Operation.ADD_VALUE
                )
        );
    }

    private static void applyArmorEffects(Player player) {
        ItemStack helmet = player.getItemBySlot(EquipmentSlot.HEAD);
        int helmetLevel = getEnhancementLevel(helmet);

        if (helmetLevel >= 5) {
            addEffect(player, MobEffects.NIGHT_VISION, 0);
        }

        if (helmetLevel >= 7) {
            addEffect(player, MobEffects.WATER_BREATHING, 0);
        }

        // +10 투구: 5초마다 화염 저항 3초
        if (helmetLevel >= 10
                && player.level().getGameTime() % 100 == 0) {

            addEffectForTime(
                    player,
                    MobEffects.FIRE_RESISTANCE,
                    0,
                    60
            );
        }

        ItemStack chestplate = player.getItemBySlot(EquipmentSlot.CHEST);
        int chestplateLevel = getEnhancementLevel(chestplate);

        if (chestplateLevel >= 7) {
            if (player.getPersistentData().getLong("starrpg_resistance_suppressed") <= player.level().getGameTime()) {
                addEffect(player, MobEffects.DAMAGE_RESISTANCE, 0);
            }
        }

        ItemStack leggings = player.getItemBySlot(EquipmentSlot.LEGS);
        int leggingsLevel = getEnhancementLevel(leggings);

        if (leggingsLevel >= 5) {
            int amplifier;

            if (leggingsLevel >= 10) {
                amplifier = 3;
            } else if (leggingsLevel >= 9) {
                amplifier = 2;
            } else if (leggingsLevel >= 7) {
                amplifier = 1;
            } else {
                amplifier = 0;
            }

            addEffect(player, MobEffects.MOVEMENT_SPEED, amplifier);
        }

        if (leggingsLevel >= 10) {
            addEffect(player, MobEffects.DOLPHINS_GRACE, 1);

            if (player.level().getGameTime() % 200 == 0) {
                if (BLEED_DATA.remove(player.getUUID()) != null) {
                    player.sendSystemMessage(
                            Component.literal(
                                    "돌고래의 호흡이 출혈을 제거했습니다."
                            )
                    );
                }
            }
        }

        ItemStack boots = player.getItemBySlot(EquipmentSlot.FEET);
        int bootsLevel = getEnhancementLevel(boots);

        if (bootsLevel >= 5) {
            int amplifier;

            if (bootsLevel >= 10) {
                amplifier = 2;
            } else if (bootsLevel >= 9) {
                amplifier = 1;
            } else {
                amplifier = 0;
            }

            addEffect(player, MobEffects.JUMP, amplifier);
        }
    }

    private static boolean hasPlusTenBoots(Player player) {
        ItemStack boots = player.getItemBySlot(EquipmentSlot.FEET);

        return getEnhancementLevel(boots) >= 10;
    }

    private static void addEffect(
            Player player,
            net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> effect,
            int amplifier
    ) {
        addEffectForTime(player, effect, amplifier, 60);
    }

    private static void addEffectForTime(
            Player player,
            net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> effect,
            int amplifier,
            int duration
    ) {
        player.addEffect(
                new MobEffectInstance(
                        effect,
                        duration,
                        amplifier,
                        false,
                        false,
                        true
                )
        );
    }

    private static int getEnhancementLevel(ItemStack item) {
        return EnhancementData.level(item);
    }

    public static void pruneState(long now) {
        AXE_LAST_HIT_TIME.entrySet().removeIf(e -> {
            if (now - e.getValue() < 1200) return false;
            AXE_COMBO_COUNT.remove(e.getKey());
            return true;
        });
        BLEED_DATA.entrySet().removeIf(e -> e.getValue().endTime() <= now);
        HEALTH_BEFORE.clear();
        HEAL_WINDOWS.entrySet().removeIf(e -> now - e.getValue().start() >= 20);
    }
    public static void clearState() {
        HEALTH_BEFORE.clear();
        HEAL_WINDOWS.clear();
        AXE_COMBO_COUNT.clear();
        AXE_LAST_HIT_TIME.clear();
        BLEED_DATA.clear();
    }
}
