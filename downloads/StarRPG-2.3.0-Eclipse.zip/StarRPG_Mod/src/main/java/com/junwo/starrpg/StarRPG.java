package com.junwo.starrpg;

import org.slf4j.Logger;

import com.mojang.logging.LogUtils;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.event.server.ServerStartingEvent;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

// The value here should match an entry in the META-INF/neoforge.mods.toml file
@Mod(StarRPG.MODID)
public class StarRPG {
    // Define mod id in a common place for everything to reference
    public static final String MODID = "starrpg";
    // Directly reference a slf4j logger
    public static final Logger LOGGER = LogUtils.getLogger();
    // Create a Deferred Register to hold Blocks which will all be registered under the "examplemod" namespace
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MODID);
    // Create a Deferred Register to hold Items which will all be registered under the "examplemod" namespace
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MODID);
    // Create a Deferred Register to hold CreativeModeTabs which will all be registered under the "examplemod" namespace
    public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    // Creates a new Block with the id "examplemod:example_block", combining the namespace and path
    public static final DeferredBlock<Block> EXAMPLE_BLOCK = BLOCKS.registerSimpleBlock("example_block", BlockBehaviour.Properties.of().mapColor(MapColor.STONE));
    // Creates a new BlockItem with the id "examplemod:example_block", combining the namespace and path
    public static final DeferredItem<BlockItem> EXAMPLE_BLOCK_ITEM =
            ITEMS.registerSimpleBlockItem("example_block", EXAMPLE_BLOCK);

    // Creates a new food item with the id "examplemod:example_id", nutrition 1 and saturation 2
    public static final DeferredItem<Item> EXAMPLE_ITEM = ITEMS.registerSimpleItem("example_item", new Item.Properties().food(new FoodProperties.Builder()
            .alwaysEdible().nutrition(1).saturationModifier(2f).build()));
    
    public static final DeferredItem<StarFragmentItem> STAR_FRAGMENT =
            ITEMS.registerItem("star_fragment", StarFragmentItem::new, new Item.Properties());

    public static final DeferredItem<Item> STAR_DUST =
            ITEMS.registerSimpleItem("star_dust", new Item.Properties());
    public static final DeferredItem<RuneTableItem> RUNE_TABLE_ITEM =
            ITEMS.registerItem(
                    "rune_table_item",
                    RuneTableItem::new,
                    new Item.Properties()
            );
    public static final DeferredItem<Item> COMMON_RUNE =
            ITEMS.registerSimpleItem("common_rune", new Item.Properties());

    public static final DeferredItem<Item> RARE_RUNE =
            ITEMS.registerSimpleItem("rare_rune", new Item.Properties());

    public static final DeferredItem<Item> EPIC_RUNE =
            ITEMS.registerSimpleItem("epic_rune", new Item.Properties());

    public static final DeferredItem<Item> LEGENDARY_RUNE =
            ITEMS.registerSimpleItem("legendary_rune", new Item.Properties());

    public static final DeferredItem<Item> MYTHIC_RUNE =
            ITEMS.registerSimpleItem("mythic_rune", new Item.Properties());
    public static final DeferredItem<StarDaggerItem> STAR_DAGGER =
            ITEMS.registerItem("star_dagger", StarDaggerItem::new, new Item.Properties());
    public static final DeferredItem<WarHammerItem> WAR_HAMMER =
            ITEMS.registerItem("war_hammer", WarHammerItem::new, new Item.Properties());
    public static final DeferredItem<MagicStaffItem> MAGIC_STAFF = ITEMS.registerItem("magic_staff", MagicStaffItem::new, new Item.Properties());
    public static final DeferredItem<MagicStaffItem> FIRE_STAFF=ITEMS.registerItem("fire_staff",p->new MagicStaffItem(p,1),new Item.Properties());
    public static final DeferredItem<MagicStaffItem> WATER_STAFF=ITEMS.registerItem("water_staff",p->new MagicStaffItem(p,2),new Item.Properties());
    public static final DeferredItem<MagicStaffItem> ICE_STAFF=ITEMS.registerItem("ice_staff",p->new MagicStaffItem(p,3),new Item.Properties());
    public static final DeferredItem<MagicStaffItem> EARTH_STAFF=ITEMS.registerItem("earth_staff",p->new MagicStaffItem(p,4),new Item.Properties());
    public static final DeferredItem<MagicStaffItem> DARK_STAFF=ITEMS.registerItem("dark_staff",p->new MagicStaffItem(p,5),new Item.Properties());
    public static final DeferredItem<MagicStaffItem> LIGHT_STAFF=ITEMS.registerItem("light_staff",p->new MagicStaffItem(p,6),new Item.Properties());
    public static final DeferredItem<CareerWeaponItem> STAR_SPEAR = ITEMS.registerItem("star_spear", p -> new CareerWeaponItem(p,0,4,-2.7F),new Item.Properties());
    public static final DeferredItem<CareerWeaponItem> BERSERKER_BLADE = ITEMS.registerItem("berserker_blade", p -> new CareerWeaponItem(p,5,6,-3.0F),new Item.Properties());
    public static final DeferredItem<CareerWeaponItem> SUN_SCEPTER = ITEMS.registerItem("sun_scepter", p -> new CareerWeaponItem(p,6,2,-2.4F),new Item.Properties());
    public static final DeferredItem<CareerWeaponItem> SOUL_SCYTHE = ITEMS.registerItem("soul_scythe", p -> new CareerWeaponItem(p,7,4,-2.8F),new Item.Properties());
    public static final DeferredItem<CareerWeaponItem> STAR_GAUNTLET = ITEMS.registerItem("star_gauntlet", p -> new CareerWeaponItem(p,8,1,-1.6F),new Item.Properties());
    public static final DeferredItem<CareerWeaponItem> AEGIS_BLADE = ITEMS.registerItem("aegis_blade", p -> new CareerWeaponItem(p,9,3,-2.8F),new Item.Properties());
    // Creates a creative tab with the id "examplemod:example_tab" for the example item, that is placed after the combat tab
    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> EXAMPLE_TAB = CREATIVE_MODE_TABS.register("example_tab", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.starrpg")) //The language key for the title of your CreativeModeTab
            .withTabsBefore(CreativeModeTabs.COMBAT)
            .icon(() -> STAR_FRAGMENT.get().getDefaultInstance())
            .displayItems((parameters, output) -> {
                output.accept(EXAMPLE_ITEM.get());
                output.accept(STAR_FRAGMENT.get());
                output.accept(STAR_DUST.get());
                output.accept(RUNE_TABLE_ITEM.get());
                output.accept(COMMON_RUNE.get());
                output.accept(RARE_RUNE.get());
                output.accept(EPIC_RUNE.get());
                output.accept(LEGENDARY_RUNE.get());
                output.accept(MYTHIC_RUNE.get());
                output.accept(STAR_DAGGER.get());
                output.accept(WAR_HAMMER.get());
                for(int school=1;school<=6;school++)output.accept(CareerConsolidation.staff(school));
                output.accept(STAR_SPEAR.get());
                output.accept(BERSERKER_BLADE.get());
                output.accept(SOUL_SCYTHE.get());
                output.accept(STAR_GAUNTLET.get());

            }).build());

    // The constructor for the mod class is the first code that is run when your mod is loaded.
    // FML will recognize some parameter types like IEventBus or ModContainer and pass them in automatically.
    public StarRPG(IEventBus modEventBus, ModContainer modContainer) {
        // Register the commonSetup method for modloading
        modEventBus.addListener(this::commonSetup);

        // Register the Deferred Register to the mod event bus so blocks get registered
        BLOCKS.register(modEventBus);
        // Register the Deferred Register to the mod event bus so items get registered
        ITEMS.register(modEventBus);
        // Register the Deferred Register to the mod event bus so tabs get registered
        CREATIVE_MODE_TABS.register(modEventBus);
        ModMenus.MENUS.register(modEventBus);
        ModEntities.ENTITIES.register(modEventBus);
        ModEffects.EFFECTS.register(modEventBus);

        // Register ourselves for server and other game events we are interested in.
        // Note that this is necessary if and only if we want *this* class (ExampleMod) to respond directly to events.
        // Do not add this line if there are no @SubscribeEvent-annotated functions in this class, like onServerStarting() below.
        NeoForge.EVENT_BUS.register(this);

        // Register the item to a creative tab
        modEventBus.addListener(this::addCreative);

        // Register our mod's ModConfigSpec so that FML can create and load the config file for us
        modContainer.registerConfig(ModConfig.Type.SERVER, Config.SPEC);
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        LOGGER.info("StarRPG combat and progression registered");
    }

    // Add the example block item to the building blocks tab
    private void addCreative(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
            event.accept(EXAMPLE_BLOCK_ITEM);
        }
    }

    // You can use SubscribeEvent and let the Event Bus discover methods to call
    @SubscribeEvent
    public void onServerStarting(ServerStartingEvent event) {
        // Do something when the server starts
        LOGGER.info("HELLO from server starting");
    }
}
