# StarRPG 2.9.0 verification

Verified on Java21.0.13, Minecraft1.21.1, NeoForge21.1.235 in the Linux development environment. Native clients render through Mesa llvmpipe.

- **245/245 required GameTests passed with CE2.0 and all seven pinned external JARs.** Final build also completed `build`, `installAdventureMods`, Eclipse generation, NeoForge IDE sync and normal client preparation.
- **245/245 passed without CE/Jupiter/Uranus/Architectury**, retaining Mowzie's Mobs, GeckoLib and Twilight Forest. This checks the optional integration and independent fallback path.
- The previous222 tests remain included. The23 new cases cover separate saved data/career/enhancement preservation; all three persistent accessory slots; quick-move/close conservation; no-payment overflow rejection; multi-stack raid loot capacity and once-only claims; independent variant codex; locked/failed constellation growth; boss tell/interruption/recovery/wall checks; Hydra head loss/regrowth/shared health/reload; Golem weak parts; bounded ward absorption; immediate freeze/shatter; bounded lightning chain/self-protection; unchanged armor defense; legacy dungeon core protection; village ledger/daily cap/reload; failed legendary recipes; party size/friendly fire; encounter size locking; room puzzles/remix/clue/floor conservation; actual generated crypt/fortress/tower furniture placement; new economy anti-arbitrage.

## Actual singleplayer

New disposable native-client worlds rendered every one of the53 species, the7 new menu tabs,4 legendary equipment configurations and9 representative unique boss casts. Screenshots include authored armor, two-handed spear presentation, species anatomy, ward/element effects and inventory synchronization. CE's adult articulated dragons remained enabled.

Native dungeon checks exercised actual feature placement on dry terrain, the awakened core, entry, generated rooms and the real indexed rune blocks/puzzle. A final isolated flat-world pass waited for chunk-generation/save futures before exiting and completed normal world saving and shutdown. The earlier rapid-exit capture used for the72-second video verified its scenes before shutdown; the final save check is a separate successful run.

Two integration defects found during validation were corrected: generated corner piers overlapped prospective rune furniture, and puzzle helpers previously accepted positions not containing the indexed rune block. Generated-structure regression tests now cover all three dungeon variants and all six puzzle rooms. Legacy cores remain unchanged.

## Actual multiplayer

Two separate Minecraft JVMs connected over TCP to a new, isolated LAN world. No production server or user world was opened. The development fixture uses offline authentication only for this local test; it is excluded from the distributed JAR.

Both clients completed normal shutdown. Checked behavior:

- invite/accept, server snapshots and party health HUD; a real client melee packet could not hurt its party member; element reactions could not bypass that protection;
- party kill quest and personal once-only claims; crafting through the server menu payload, then a real inventory quick-move packet to equip the resulting ring without duplication;
- ordinary two-person boss scaling and two-person raid scaling; attempts to leave an active raid were rejected;
- actual ally healing counted toward raid contribution and earned the healer a separate reward; both individual rewards were claimable once;
- village-specific per-player discounts, faction acceptance/completion, guard development, merchant, defense event, mutation kill/codex and star growth;
- both players completed a three-wave dungeon; both could separately claim the secret-room reward once after solving the real rune blocks;
- the crafting reveal displayed the actual new key, rather than an unrelated legacy armor piece;
- TCP disconnection/reconnection retained party, equipped ring, star unlock and star level; the reopened menu synchronized the equipment stack again;
- serialized UUID-specific accessory/star state was also inspected before reconnect.

## Installer and release

The full installer was exercised with all **eight actual JARs**. It verified hashes/mod IDs, backed up2.8, preserved an unrelated mod, repeated successfully, and restored the exact prior target files after a conflicting-file failure. A fresh upstream Uranus download with an intentionally wrong SHA-512 was rejected before changing the target. Packaged archive contents and public artifact hashes are checked separately during release.

No test/dev classes, test arenas, user worlds, build directories or external mod binaries are included in the distributed StarRPG JAR. External JARs remain original upstream artifacts. Source ZIP contains opt-in test source for reproduction; the normal Eclipse client launch has no automated test flags.

The two-client run verifies functionality and synchronization, **not a16-client performance benchmark**. Windows Eclipse GUI interaction and long-running large-server load remain separate environment checks. F8 quality controls, distance-limited aura rendering, local variant limits and projectile/sigil budgets are retained.
