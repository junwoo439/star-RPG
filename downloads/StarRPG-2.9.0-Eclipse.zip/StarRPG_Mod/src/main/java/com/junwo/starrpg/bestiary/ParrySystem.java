package com.junwo.starrpg.bestiary;

import com.junwo.starrpg.*;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.neoforged.bus.api.*;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

@EventBusSubscriber(modid=StarRPG.MODID)
public final class ParrySystem {
    public static final String END="starrpg_parry_end",READY="starrpg_parry_ready";
    public static boolean equipment(Player p){var w=p.getMainHandItem().getItem();return w instanceof SwordItem||w instanceof AxeItem||w instanceof WarHammerItem||w instanceof TridentItem||w instanceof ShieldItem||p.getOffhandItem().getItem() instanceof ShieldItem;}
    public static boolean open(Player p){
        if(!(p.level() instanceof ServerLevel l)||!p.isAlive()||p.isSpectator()||ControlEffects.stunned(p)||p.hasEffect(ModEffects.COMBO)||p.hasEffect(ModEffects.BRACED)||p.containerMenu!=p.inventoryMenu||!equipment(p))return false;
        long now=l.getGameTime();if(p.getPersistentData().getLong(READY)>now){p.displayClientMessage(Component.literal("패링 대기 "+MagicSystem.cooldown(p,READY)),true);return false;}
        p.getPersistentData().putLong(END,now+5+com.junwo.starrpg.awakening.Accessories.parryTicks(p));p.getPersistentData().putLong(READY,now+24);
        p.displayClientMessage(Component.literal("패링 준비 · 정면 근접 공격"),true);
        PresentationCues.play(p,PresentationCues.GUARD,0,0xFFD76A);return true;
    }
    public static boolean facing(Player p,LivingEntity m){var delta=m.getEyePosition().subtract(p.getEyePosition()).normalize();return p.getLookAngle().dot(delta)>.35;}
    @SubscribeEvent(priority=EventPriority.HIGHEST) public static void defend(LivingIncomingDamageEvent e){
        if(e.isCanceled()||!(e.getEntity() instanceof Player p)||p.level().isClientSide()||!e.getSource().is(DamageTypes.MOB_ATTACK)||!(e.getSource().getDirectEntity() instanceof Mob m))return;
        if(ControlEffects.stunned(m)||ControlEffects.stunned(p)||!p.isAlive()||p.isSpectator()||!equipment(p)||p.getPersistentData().getLong(END)<=p.level().getGameTime()||!facing(p,m)||m.distanceToSqr(p)>Math.pow(m.getBbWidth()+7,2))return;
        if(m instanceof BestiaryMob b&&!b.parryableImpact)return;
        e.setCanceled(true);p.getPersistentData().remove(END);
        if(m instanceof BestiaryMob b){b.stagger(b.kind.boss?24:36);com.junwo.starrpg.awakening.Raids.parry(p,b);}else m.addEffect(new MobEffectInstance(ModEffects.STUN,m.getType().is(MonsterProgression.BOSSES)?12:24,0));
        m.getPersistentData().putUUID("starrpg_riposte_owner",p.getUUID());m.getPersistentData().putLong("starrpg_riposte_until",p.level().getGameTime()+40);
        p.displayClientMessage(Component.literal("패링 성공! 2초 안에 충전 공격으로 반격 +25%"),true);
        CombatVisuals.sound(p,net.minecraft.sounds.SoundEvents.SHIELD_BLOCK,.9F,1.3F);
        PresentationCues.play(p,PresentationCues.PARRY,0,0xFFC65B);
    }
    @SubscribeEvent public static void logout(net.neoforged.neoforge.event.entity.player.PlayerEvent.PlayerLoggedOutEvent e){e.getEntity().getPersistentData().remove(END);}
    @SubscribeEvent public static void dimension(net.neoforged.neoforge.event.entity.player.PlayerEvent.PlayerChangedDimensionEvent e){e.getEntity().getPersistentData().remove(END);}
    @SubscribeEvent public static void death(net.neoforged.neoforge.event.entity.living.LivingDeathEvent e){if(e.getEntity() instanceof Player p)p.getPersistentData().remove(END);}
    @SubscribeEvent public static void riposte(LivingIncomingDamageEvent e){
        if(e.getEntity().level().isClientSide()||!CombatRules.primary(e.getSource())||!CombatRules.charged(e.getSource())||!(e.getSource().getEntity() instanceof Player p))return;
        var tag=e.getEntity().getPersistentData();
        if(tag.getLong("starrpg_riposte_until")>p.level().getGameTime()&&tag.hasUUID("starrpg_riposte_owner")&&tag.getUUID("starrpg_riposte_owner").equals(p.getUUID())){e.setAmount(e.getAmount()*1.25F);tag.remove("starrpg_riposte_until");tag.remove("starrpg_riposte_owner");}
    }
}
