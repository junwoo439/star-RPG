package com.junwo.starrpg.awakening;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.*;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.world.entity.LivingEntity;

/** Articulated armor plates follow the player's original head, arms and legs. */
public final class LegendaryArmorModel extends HumanoidModel<LivingEntity> {
    private static final LegendaryArmorModel[][] CACHE=new LegendaryArmorModel[4][2];
    private LegendaryArmorModel(ModelPart root){super(root);}
    public static LegendaryArmorModel get(int set,boolean leggings){int i=leggings?1:0;if(CACHE[set][i]==null)CACHE[set][i]=build(set,leggings);return CACHE[set][i];}
    private static void part(PartDefinition parent,String name,float x,float y,float z,float w,float h,float d,float rx,float ry,float rz,int uv){parent.addOrReplaceChild(name,CubeListBuilder.create().texOffs(uv,40).addBox(-w/2,-h/2,-d/2,w,h,d),PartPose.offsetAndRotation(x,y,z,rx,ry,rz));}
    private static LegendaryArmorModel build(int set,boolean leggings){var mesh=HumanoidModel.createMesh(new CubeDeformation(leggings?.5F:1),0);var root=mesh.getRoot();var head=root.getChild("head");var body=root.getChild("body");
        if(set==0){for(int side:new int[]{-1,1}){part(head,"dragonHorn"+side,side*4,-10,2,2,7,2,-.45F,0,side*.32F,0);part(head,"dragonHornTip"+side,side*5,-14,3,1,4,1,-.75F,0,side*.45F,0);}for(int n=0;n<4;n++)part(body,"scale"+n,0,2+n*2.3F,-3.3F,7-n*.4F,2,1,0,0,0,16);}
        if(set==1){for(int i=-2;i<=2;i++)part(head,"lichCrown"+i,i*1.9F,-9-Math.abs(i)*.6F,0,1.2F,4+Math.abs(i),1.2F,0,0,i*.12F,0);part(body,"soulGem",0,4,-3.8F,3,3,1,0,0,.78F,32);part(body,"mantle",0,5,3.5F,11,10,1,.12F,0,0,16);}
        if(set==2){part(head,"golemBrow",0,-6,-5,10,2,2,0,0,0,16);part(body,"core",0,5,-4.2F,4,4,2,0,0,.78F,32);part(body,"waistGuard",0,11,-3.8F,10,3,2,0,0,0,16);}
        if(set==3){for(int i=0;i<5;i++)part(head,"starProng"+i,(i-2)*2,-9-(i%2),0,1,4,1,0,0,(i-2)*.15F,32);part(body,"eclipseCore",0,4,-4,4,4,1,0,0,.78F,32);}
        for(String arm:new String[]{"right_arm","left_arm"}){int side=arm.startsWith("right")?-1:1;var a=root.getChild(arm);part(a,"pauldron",side,-1,0,set==2?8:6,set==2?5:4,7,0,0,side*.15F,16);if(set==0)for(int i=0;i<3;i++)part(a,"pauldronSpike"+i,side*2,-4,(-1+i)*2,1,4,1,-.2F,0,side*.25F,0);if(set==1)part(a,"soulShoulder",side,-3,0,2,3,2,0,.78F,0,32);part(a,"bracer",0,7,-.2F,5,4,5,0,0,0,16);}
        for(String leg:new String[]{"right_leg","left_leg"}){var a=root.getChild(leg);part(a,"knee",0,6,-3,4,3,2,0,0,0,16);if(!leggings)part(a,"greave",0,10,-1,5,3,7,0,0,0,16);}
        return new LegendaryArmorModel(LayerDefinition.create(mesh,64,64).bakeRoot());
    }
}
