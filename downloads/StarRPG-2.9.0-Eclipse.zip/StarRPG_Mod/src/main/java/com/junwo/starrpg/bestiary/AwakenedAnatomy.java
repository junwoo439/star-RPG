package com.junwo.starrpg.bestiary;

import java.util.*;
import static com.junwo.starrpg.bestiary.CreatureMesh.*;

/** Species-specific silhouettes and anatomy; the rig remains shared where anatomy really is shared. */
public final class AwakenedAnatomy {
    private static Node node(Map<String,Node> bones,String name){return bones.get(name);}
    private static void crown(Node parent,String name,int teeth,int color,float width){if(parent==null)return;for(int i=0;i<teeth;i++){float x=(i-(teeth-1)*.5F)*width;parent.node(name+i,x,-6,2,0,0,r(x*3)).taper(4+Math.abs(x)*.4F,.65F,.04F,HORN,color);}}
    private static void plates(Node parent,String name,int count,int color,float width){if(parent==null)return;for(int i=0;i<count;i++)parent.node(name+i,0,-2+i*2,-4.2F).chamfer(-width/2,-1,-.4F,width,1.5F,.8F,.3F,METAL,color);}
    private static void horns(Node parent,String name,float length,float spread,int color){if(parent==null)return;for(int side:new int[]{-1,1}){var horn=parent.node(name+side,side*spread,-6,2,r(-30),0,r(side*25));horn.taper(length,1.1F,.3F,HORN,color);horn.node(name+"tip"+side,0,-length,0,r(-30),0,r(side*20)).taper(length*.55F,.5F,.01F,HORN,0xEEE2BD);}}
    public static void decorate(BestiaryKind kind,Node root){
        Map<String,Node> bones=new HashMap<>();root.collect(bones);Node head=node(bones,"head"),body=node(bones,"body"),left=node(bones,"armL"),right=node(bones,"armR");
        int pale=mix(kind.color,0xF2E8D3,.65F),shade=mix(kind.color,0x252B35,.35F);
        switch(kind){
            case DIRE_BEAR->{if(body!=null)body.proportions(1.08F,1.12F,1);crown(head,"bearScar",2,pale,2);}
            case ELDER_BEAR->{root.proportions(1.13F,1.05F,1);horns(head,"elderAntler",8,3,pale);plates(body,"oldTotem",4,0xA9A189,9);}
            case DIRE_WOLF->{if(head!=null)head.proportions(.88F,1,1.15F);for(int i=0;i<4;i++)root.node("wolfBackRuff"+i,0,7,i*3-5,r(-28),0,0).taper(4,1.4F,.05F,SHAG,shade);}
            case HYENA->{root.proportions(1.1F,.92F,.93F);if(head!=null)head.proportions(1.12F,.9F,.85F);plates(body,"hyenaStripe",6,shade,6);}
            case WILD_BOAR->{if(head!=null)head.proportions(1.2F,.95F,1);for(int i=0;i<5;i++)root.node("boarBristle"+i,0,6,i*3-4,r(-30),0,0).taper(3,1,.03F,SHAG,shade);}
            case GIANT_ANT->{if(body!=null)body.proportions(.85F,1.15F,1.25F);for(int i=0;i<3;i++)root.node("antAbdomen"+i,0,14,9+i*3).chamfer(-4+i*.5F,-3,-1,8-i,6,3,.9F,CHITIN,shade);}
            case GIANT_SPIDER->{if(body!=null)body.proportions(1.15F,1.1F,.9F);for(int side:new int[]{-1,1})root.node("spiderPedipalp"+side,side*2,18,-11,r(-20),r(side*25),0).taper(-5,.9F,.1F,CHITIN,pale);}
            case REEF_SHARK->{if(head!=null)head.proportions(1.05F,.88F,1.15F);for(int side:new int[]{-1,1})root.node("sharkGillRidge"+side,side*5,14,-5).box(-.2F,-2,-1,.4F,4,6,HIDE,pale);}
            case GOBLIN->{root.proportions(1.03F,.9F,1);crown(head,"scrapHood",3,0x78634B,2);if(left!=null)left.proportions(1,1.15F,1);}
            case ORC->{if(body!=null)body.proportions(1.2F,1.05F,1.1F);horns(head,"orcJawFang",2,2,pale);plates(right,"warBracer",3,0x626D68,5);}
            case KOBOLD->{root.proportions(.82F,1.07F,1.12F);horns(head,"koboldHorn",4,2,pale);}
            case TROLL->{root.proportions(.92F,1.14F,1);if(left!=null)left.proportions(1,1.25F,1);if(right!=null)right.proportions(1,1.22F,1);crown(head,"trollMossCrest",5,0x6C8646,1.5F);}
            case OGRE->{if(body!=null)body.proportions(1.3F,1.05F,1.35F);crown(head,"ogreBrow",1,shade,1);plates(left,"ogreShackle",2,0x776E61,7);}
            case OGRE_WARLORD->{root.proportions(1.12F,1.08F,1);horns(head,"warlordCrown",6,3,0xA69261);plates(body,"warlordPlate",5,0x74694E,12);for(int side:new int[]{-1,1})root.node("warlordBanner"+side,side*6,0,5,r(10),r(side*15),0).box(-2,0,0,4,22,.6F,CLOTH,0x842E30);}
            case CORRUPT_GUARD->{plates(body,"guardRibArmor",4,0x6E817C,9);crown(head,"guardHelmetRidge",3,0x7B8C79,1.7F);}
            case GRAVE_SKELETON->{if(head!=null)head.proportions(.95F,1.1F,1);plates(left,"boneArmGuard",3,pale,3);}
            case ROTTING_ZOMBIE->{root.proportions(1.08F,.95F,1);if(head!=null)head.offset(.7F,.5F,0);plates(body,"exposedRibs",4,0xB3AD87,6);}
            case VAMPIRE->{root.proportions(.9F,1.08F,1);crown(head,"vampireHair",5,0x28252D,1.3F);}
            case LICH->{root.proportions(.92F,1.12F,1);horns(head,"lichCrown",7,3,0xA9A58A);for(int i=0;i<3;i++){var book=root.node("lichTome"+i,0,8,0,0,r(i*120),r(12));book.node("lichBook"+i,9,0,0).box(-2,-3,-.7F,4,6,1.4F,CLOTH,0x567B79);}}
            case BANSHEE->{root.proportions(1.03F,1.14F,.8F);for(int i=0;i<7;i++)root.node("bansheeHair"+i,(i-3)*1.4F,-5,2,r(i*4),0,0).taper(-18,1,.04F,CLOTH,0xC3E1DC);}
            case GEIST->{root.proportions(.83F,1,.75F);horns(head,"geistShackles",3,4,0x72859D);for(int i=0;i<4;i++)root.node("geistChain"+i,i<2?-5:5,6+i%2*5,1).box(-.5F,0,-.5F,1,6,1,METAL,0x74838C);}
            case RED_DRAGON->horns(head,"redRoyalHorn",7,4,0xD8B17A);
            case BLUE_DRAGON->crown(head,"stormFork",3,0xAADBF4,2);
            case GREEN_DRAGON->crown(head,"venomCrest",5,0xB9CB78,1.6F);
            case BLACK_DRAGON->horns(head,"blackCrown",9,4,0x797283);
            case WHITE_DRAGON->crown(head,"frostBlade",7,0xD9F6FF,1.2F);
            case GOLD_DRAGON->horns(head,"goldRoyalAntler",10,4,0xE7CD73);
            case SILVER_DRAGON->crown(head,"silverFan",5,0xE5EFF4,2);
            case BRONZE_DRAGON->crown(head,"bronzeFin",3,0xA5C3A3,2.5F);
            case BRASS_DRAGON->crown(head,"brassSail",7,0xD0AA5B,1.5F);
            case COPPER_DRAGON->horns(head,"copperFork",6,5,0xB97C5E);
            case WYVERN->{root.proportions(.86F,.93F,1.12F);horns(head,"wyvernTusks",4,3,pale);}
            case BASILISK->{root.proportions(1.08F,.87F,1.1F);crown(head,"basiliskEyeHood",5,0xB9C76C,1.7F);for(int side:new int[]{-1,1})root.node("leg"+(side<0?4:5),side*4,17,0,r(side*12),0,r(side*-15)).box(-1.5F,0,-2,3,7,4,SCALES,shade);}
            case COCKATRICE->{crown(head,"cockatriceComb",5,0xC55344,1.1F);if(head!=null)head.box(-1.2F,-3,-8,2.4F,2,4,HORN,0xD0AD66);}
            case HYDRA->{root.proportions(1.1F,.92F,1.08F);for(int i=0;i<3;i++)horns(node(bones,i==0?"head":"head"+(i+1)),"hydraHorn"+i,4+i,3,0xC6C58B);}
            case SUCCUBUS->{root.proportions(.87F,1.05F,.9F);horns(head,"succubusCurl",5,2,0xB47FA1);}
            case INCUBUS->{root.proportions(1.12F,1.06F,1);horns(head,"incubusCrest",7,3,0xB5A3CD);plates(body,"incubusCuirass",4,0x58445F,9);}
            case BEELZEBUB->{if(body!=null)body.proportions(1.3F,1.15F,1.3F);crown(head,"flyKingRidge",7,0xA5B45F,1.4F);for(int i=0;i<5;i++)root.node("beelzebubSac"+i,(i%2==0?-1:1)*5,14+i,8+i).chamfer(-2,-2,-2,4,4,4,.8F,CHITIN,0xA3BA4B);}
            case DEMOGORGON->{root.proportions(1.1F,1.12F,1);horns(head,"demonKingHorn",9,3,0xCBA47C);horns(node(bones,"head2"),"demonTwinHorn",7,3,0xBCA4BB);plates(left,"demonArmChains",5,0x635B62,7);}
            case AASIMAR->{root.proportions(.94F,1.08F,1);crown(head,"aasimarDiadem",3,0xE7D69A,2);}
            case SOLAR->{root.proportions(1.08F,1.12F,1);crown(head,"solarCorona",9,0xF1D48B,1.3F);plates(body,"solarRays",5,0xE2CD8B,10);}
            case FIRE_ELEMENTAL->{root.proportions(.95F,1.15F,.9F);crown(head,"fireCorona",5,0xFBC66E,1.4F);}
            case EARTH_ELEMENTAL->{root.proportions(1.2F,.88F,1.25F);plates(body,"earthSlabs",3,0xA99570,12);}
            case WATER_ELEMENTAL->{root.proportions(.87F,1.12F,.9F);crown(head,"waterCrest",3,0xA5E2E9,2);}
            case AIR_ELEMENTAL->{root.proportions(.75F,1.18F,.75F);horns(head,"airRibbon",6,2,0xD1F1EC);}
            case CLOUD_GIANT->{root.proportions(.95F,1.18F,1);crown(head,"cloudDiadem",3,0xD7DDEA,2);}
            case FIRE_GIANT->{root.proportions(1.12F,1.02F,1);plates(body,"fireGiantCracks",5,0xDD8951,12);}
            case FROST_GIANT->{root.proportions(1.04F,1.12F,1);horns(head,"frostGiantCrown",6,4,0xC1E4EB);}
            case STORM_GIANT->{root.proportions(1.13F,1.17F,1);horns(head,"stormTitanHorn",9,4,0xC9D3ED);plates(body,"stormTitanRings",5,0x9DABCB,13);}
            case STONE_GOLEM->{root.proportions(1.15F,.92F,1.1F);plates(body,"golemSlabArmor",4,0xA7AB9D,13);}
            case GARGOYLE->{root.proportions(.95F,.92F,1.1F);horns(head,"gargoyleEars",6,3,0xB0AABD);}
            case ANIMATED_ARMOR->{root.proportions(1.02F,1.04F,1.05F);plates(body,"emptyCuirass",5,0xA1B2BD,10);crown(head,"armorPlume",3,0x717885,1.6F);}
            case ANCIENT_GOLEM->{root.proportions(1.16F,1.08F,1.1F);plates(body,"ancientRunicPlates",6,0x8BB3A9,15);horns(head,"ancientPillars",5,4,0x8C9C86);for(int side:new int[]{-1,1})root.node("golemShoulder"+side,side*10,-1,0,0,0,r(side*12)).chamfer(-4,-3,-4,8,8,8,1.5F,STONE,shade);}
        }
        var rare=root.node("awakenedRareCrown",0,-9,0);for(int i=0;i<5;i++)rare.node("rareShard"+i,(i-2)*2,0,0,0,0,r((i-2)*12)).taper(3+(i%2),.65F,.02F,HORN,0xFFE2A0);
        var mutant=root.node("awakenedMutation",0,2,5);for(int i=0;i<4;i++)mutant.node("mutationShard"+i,(i%2==0?-1:1)*4,i*3,0,0,0,r(i%2==0?-35:35)).taper(5,1,.05F,HORN,0xBC8DFA);
    }
    public static void pose(BestiaryMob m,Node root,Map<String,Node> bones,float swing,float amount,float age){
        float partial=age-m.tickCount,travel=(float)Math.min(1,m.getDeltaMovement().horizontalDistance()*5);if(m.kind.body!=BestiaryKind.Body.DRAGON){root.xRot+=travel*(float)Math.sin(swing*.7)*.025F;root.dy-=Math.abs((float)Math.sin(swing*.7))*amount*.35F;}
        var rare=bones.get("awakenedRareCrown");if(rare!=null){rare.visible=m.awakenedVariant()>0;rare.dy+=(float)Math.sin(age*.06)*.8F;rare.yRot+=age*.018F;}
        var mutant=bones.get("awakenedMutation");if(mutant!=null)mutant.visible=m.awakenedVariant()>=2;
        if(m.kind==BestiaryKind.HYDRA)for(int i=0;i<3;i++){var head=bones.get(i==0?"head":"head"+(i+1));if(head!=null){head.visible=(m.headMask()&(1<<i))!=0;head.yRot+=(float)Math.sin(age*.035+i*2)*.08F;}}
        if(m.kind==BestiaryKind.LICH)for(int i=0;i<3;i++){var book=bones.get("lichTome"+i);if(book!=null){book.yRot+=age*.02F;book.dy+=(float)Math.sin(age*.07+i)*1.5F;}}
        float progress=m.progress(age-m.tickCount),wind=m.phase()==BestiaryMob.HEAVY?progress*progress*(3-2*progress):m.phase()==BestiaryMob.ACTIVE?1-progress:m.phase()==BestiaryMob.RECOVERY?.15F*(1-progress):0;
        int skill=m.bossSkill();if(skill>0){var l=bones.get("armL");var rr=bones.get("armR");var body=bones.get("body");if(skill<=3||skill==19||skill==20){if(l!=null){l.xRot=-1.5F*wind;l.zRot-=.5F*wind;}if(rr!=null){rr.xRot=-1.5F*wind;rr.zRot+=.5F*wind;}}else if(skill==9||skill==10||skill==12||skill==14||skill==23||skill==24){if(l!=null)l.xRot=-2.7F*wind;if(rr!=null)rr.xRot=-2.7F*wind;if(body!=null)body.xRot-=.2F*wind;}if(skill==7||skill==13||skill==81)root.xRot+=wind*.25F;}
        if(m.kind==BestiaryKind.HYDRA)for(int i=0;i<3;i++){var neck=bones.get((i==0?"head":"head"+(i+1))+"Neck");if(neck!=null)neck.visible=(m.headMask()&(1<<i))!=0;}
        if(m.deathTime>0&&m.kind.body!=BestiaryKind.Body.DRAGON){float collapse=Math.min(1,(m.deathTime+partial)/18);collapse=collapse*collapse*(3-2*collapse);root.zRot+=collapse*.9F;root.dy+=collapse*5;root.alpha*=1-collapse*.6F;}
    }
}
