package com.junwo.starrpg.tests;
import com.junwo.starrpg.*;
import com.junwo.starrpg.bestiary.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.TitleScreen;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
@EventBusSubscriber(modid=StarRPG.MODID,value=Dist.CLIENT)
public final class ArtBake290 {
    private static boolean done;
    @SubscribeEvent public static void tick(net.neoforged.neoforge.client.event.ClientTickEvent.Post e)throws java.io.IOException{
        var mc=Minecraft.getInstance();if(done||!Boolean.getBoolean("starrpg.art290")||!(mc.screen instanceof TitleScreen)||mc.getOverlay()!=null)return;done=true;
        AwakenedTextures.exportAll(mc.gameDirectory.toPath().resolve("../src/main/resources/assets/starrpg/textures/entity/awakening").normalize());
        com.junwo.starrpg.awakening.AwakeningArt.export(mc.gameDirectory.toPath().resolve("../src/main/resources/assets/starrpg").normalize());
        StarRPG.LOGGER.info("ART290_BAKED_53_SPECIES");mc.stop();
    }
}
