package com.junwo.starrpg.awakening;
import com.junwo.starrpg.*;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.item.ItemStack;
public final class LegendaryWeaponModels {
    public static int kind(ItemStack s){if(s.is(AwakeningItems.DRAGON_WEAPON.get()))return 0;if(s.is(AwakeningItems.LICH_WEAPON.get()))return 1;if(s.is(AwakeningItems.GOLEM_WEAPON.get()))return 2;if(s.is(AwakeningItems.RAID_WEAPON.get()))return 3;return -1;}
    public static boolean draw(ItemStack s,PoseStack p,MultiBufferSource b,int light,boolean held){int type=kind(s);if(type<0)return false;if(!held)p.scale(.44F,.44F,.44F);int metal=new int[]{0x963E32,0x4D6878,0x6D8174,0x665286}[type],trim=new int[]{0xDCAE67,0xC4D8D5,0xC3BD8D,0xD7C0FF}[type],glow=new int[]{0xFF8A35,0x63F5E7,0x64EED2,0xC596FF}[type];
        WeaponModels.box(p,b,-.045F,-.7F,-.045F,.09F,1.95F,.09F,metal,light);for(int i=0;i<6;i++)WeaponModels.box(p,b,-.052F,-.22F+i*.1F,-.052F,.104F,.045F,.104F,trim,light);
        if(type==0||type==3){WeaponModels.box(p,b,-.18F,1.13F,-.08F,.36F,.09F,.16F,trim,light);for(int side:new int[]{-1,1}){p.pushPose();p.translate(side*.12,1.24,0);p.mulPose(Axis.ZP.rotationDegrees(side*-23));WeaponModels.box(p,b,-.035F,-.03F,-.045F,.07F,.38F,.09F,metal,light);p.popPose();}p.pushPose();p.translate(0,1.47,0);p.scale(.45F,1,.28F);p.mulPose(Axis.ZP.rotationDegrees(45));WeaponModels.box(p,b,-.25F,-.25F,-.10F,.5F,.5F,.2F,trim,light);p.popPose();WeaponModels.box(p,b,-.02F,1.17F,-.082F,.04F,.48F,.04F,glow,15728880);}
        if(type==1){for(int i=0;i<6;i++){p.pushPose();p.translate(-.15-i*.13,1.15-i*i*.018,0);p.mulPose(Axis.ZP.rotationDegrees(-i*9));WeaponModels.box(p,b,-.1F,-.05F,-.065F,.23F,.16F,.13F,trim,light);WeaponModels.box(p,b,-.1F,-.065F,-.073F,.23F,.025F,.146F,glow,15728880);p.popPose();}WeaponModels.box(p,b,-.11F,1.1F,-.11F,.22F,.26F,.22F,metal,light);}
        if(type==2){WeaponModels.box(p,b,-.48F,.86F,-.23F,.96F,.48F,.46F,metal,light);for(int side:new int[]{-1,1})WeaponModels.box(p,b,side<0?-.55F:.40F,.80F,-.28F,.15F,.60F,.56F,trim,light);WeaponModels.box(p,b,-.16F,.97F,-.245F,.32F,.23F,.035F,glow,15728880);for(int side:new int[]{-1,1})WeaponModels.box(p,b,side*.24F-.025F,.83F,-.255F,.05F,.5F,.025F,glow,15728880);}
        return true;
    }
}
