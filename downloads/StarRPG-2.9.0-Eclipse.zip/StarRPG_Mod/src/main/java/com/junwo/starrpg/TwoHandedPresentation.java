package com.junwo.starrpg;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.*;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.*;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderHandEvent;

@EventBusSubscriber(modid=StarRPG.MODID,value=Dist.CLIENT)
public final class TwoHandedPresentation {
    private static boolean pairedSpearRender;
    public static boolean hideHeldSpear(){return pairedSpearRender;}
    @SubscribeEvent public static void playerPre(net.neoforged.neoforge.client.event.RenderPlayerEvent.Pre e){pairedSpearRender=paired(e.getEntity())&&WeaponArt.kind(e.getEntity().getMainHandItem())==5;}
    @SubscribeEvent public static void playerPost(net.neoforged.neoforge.client.event.RenderPlayerEvent.Post e){pairedSpearRender=false;}
    public static boolean paired(LivingEntity p){int k=WeaponArt.kind(p.getMainHandItem());return (k==5||k==9)&&p.getOffhandItem().isEmpty()&&!p.isUsingItem()&&!p.isSwimming()&&!p.isFallFlying();}
    public static float punch(LivingEntity e,float partial){
        if(!e.getPersistentData().contains("starrpg_motion_tick"))return 0;
        float age=e.level().getGameTime()-e.getPersistentData().getLong("starrpg_motion_tick")+partial;
        return age>=0&&age<9?(float)Math.sin(Math.PI*age/9):0;
    }
    public static void pose(HumanoidModel<?> m,LivingEntity e,float age){
        if(!(e instanceof AbstractClientPlayer)||e.isSwimming()||e.isFallFlying())return;
        if(CombatPresentation.guardPose(m,e,age-e.tickCount))return;
        if(!paired(e)){CombatPresentation.weaponPose(m,e,age-e.tickCount);return;}
        float hit=punch(e,age-e.tickCount);boolean right=e.getMainArm()==HumanoidArm.RIGHT;
        var main=right?m.rightArm:m.leftArm;var off=right?m.leftArm:m.rightArm;int kind=WeaponArt.kind(e.getMainHandItem());
        if(kind==9){boolean left=e.getPersistentData().getInt("starrpg_motion_side")==1;
            m.rightArm.xRot=-1.0F-(left?0:hit*.7F);m.leftArm.xRot=-1.0F-(left?hit*.7F:0);
            m.rightArm.yRot=-.22F;m.leftArm.yRot=.22F;m.rightArm.zRot=.1F;m.leftArm.zRot=-.1F;
            m.body.yRot=(left?-1:1)*hit*.3F;
            m.rightArm.z=left?0:-hit*3;m.leftArm.z=left?-hit*3:0;
        }else{
            m.body.yRot=0;m.rightArm.x=-5;m.leftArm.x=5;m.rightArm.z=m.leftArm.z=-hit*5;
            main.xRot=-.7F;main.yRot=right?-.18F:.18F;main.zRot=0;
            off.xRot=-1.15F;off.yRot=right?.72F:-.72F;off.zRot=right?-.15F:.15F;
        }
    }
    @SubscribeEvent public static void hand(RenderHandEvent e){
        var mc=Minecraft.getInstance();var player=mc.player;if(player==null||!paired(player)||player.isScoping())return;
        // Render both hands in one pass. No dummy stack is placed in the offhand inventory.
        e.setCanceled(true);if(e.getHand()!=InteractionHand.MAIN_HAND)return;
        renderHands(e.getPoseStack(),e.getMultiBufferSource(),e.getPackedLight(),player,e.getPartialTick(),e.getEquipProgress());
    }
    public static void renderHands(PoseStack p,MultiBufferSource b,int light,AbstractClientPlayer player,float partial,float equip){
        p.pushPose();float guard=CombatPresentation.guard(player,partial);
        if(guard>0){p.translate(0,guard*.2,-guard*.1);p.mulPose(Axis.XP.rotationDegrees(guard*-25));}
        int kind=WeaponArt.kind(player.getMainHandItem());float hit=punch(player,partial);int side=player.getPersistentData().getInt("starrpg_motion_side")==1?-1:1;
        float dominant=player.getMainArm()==HumanoidArm.RIGHT?1:-1;
        for(int sign:new int[]{1,-1}){
            float reach=kind==9?(sign==side?hit*.52F:0):hit*.48F;
            p.pushPose();if(kind==9)p.translate(sign*.38,-.38-equip*.6,-.65-reach);
            else p.translate(sign==dominant?.28*dominant:.046*dominant,(sign==dominant?-.38:-.302)-equip*.6,(sign==dominant?-.65:-1.152)-reach);
            if(!player.isInvisible())arm(p,b,light,player,sign);
            if(kind==9){p.mulPose(Axis.XP.rotationDegrees(-75));p.mulPose(Axis.ZP.rotationDegrees(sign*(-10+hit*18)));WeaponModels.glove(p,b,light);}
            p.popPose();
        }
        if(kind==5){p.pushPose();p.translate(.28*dominant,-.38-equip*.6,-.65-hit*.48);p.mulPose(Axis.YP.rotationDegrees(25*dominant));p.mulPose(Axis.XP.rotationDegrees(-82));if(!com.junwo.starrpg.awakening.LegendaryWeaponModels.draw(player.getMainHandItem(),p,b,light,true))WeaponModels.spear(p,b,light);p.popPose();}
        p.popPose();
    }
    private static void arm(PoseStack p,MultiBufferSource b,int light,AbstractClientPlayer player,int sign){
        var renderer=(PlayerRenderer)Minecraft.getInstance().getEntityRenderDispatcher().getRenderer(player);var model=renderer.getModel();
        var arm=sign==1?model.rightArm:model.leftArm;var sleeve=sign==1?model.rightSleeve:model.leftSleeve;
        var old=arm.storePose();var oldSleeve=sleeve.storePose();
        p.pushPose();p.mulPose(Axis.XP.rotationDegrees(80));p.scale(1,-1,1);p.translate(-arm.x/16.0,-arm.y/16.0-.68,-arm.z/16.0);
        arm.xRot=arm.yRot=arm.zRot=0;sleeve.copyFrom(arm);
        arm.render(p,b.getBuffer(RenderType.entitySolid(player.getSkin().texture())),light,OverlayTexture.NO_OVERLAY);
        sleeve.render(p,b.getBuffer(RenderType.entityTranslucent(player.getSkin().texture())),light,OverlayTexture.NO_OVERLAY);
        p.popPose();arm.loadPose(old);sleeve.loadPose(oldSleeve);
    }
    public static final class OtherGlove extends RenderLayer<AbstractClientPlayer,PlayerModel<AbstractClientPlayer>> {
        public OtherGlove(PlayerRenderer renderer){super(renderer);}
        private org.joml.Vector3f grip(HumanoidArm arm){var p=new PoseStack();getParentModel().translateToHand(arm,p);return p.last().pose().transformPosition(new org.joml.Vector3f(arm==HumanoidArm.RIGHT?-.0625F:.0625F,.625F,-.125F));}
        @Override public void render(PoseStack p,MultiBufferSource b,int light,AbstractClientPlayer e,float walk,float amount,float partial,float age,float yaw,float pitch){
            if(!paired(e)||e.isInvisible())return;
            if(WeaponArt.kind(e.getMainHandItem())==5){
                var a=grip(e.getMainArm());var z=grip(e.getMainArm().getOpposite());var d=z.sub(a,new org.joml.Vector3f()).normalize();
                p.pushPose();p.translate(a.x,a.y,a.z);p.mulPose(new org.joml.Quaternionf().rotationTo(new org.joml.Vector3f(0,1,0),d));if(!com.junwo.starrpg.awakening.LegendaryWeaponModels.draw(e.getMainHandItem(),p,b,light,true))WeaponModels.spear(p,b,light);p.popPose();return;
            }
            var arm=e.getMainArm().getOpposite();p.pushPose();getParentModel().translateToHand(arm,p);
            p.mulPose(Axis.XP.rotationDegrees(-90));p.mulPose(Axis.YP.rotationDegrees(180));p.translate(arm==HumanoidArm.LEFT?-.0625:.0625,.125,-.625);WeaponModels.glove(p,b,light);p.popPose();
        }
    }
}
