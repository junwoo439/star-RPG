package com.junwo.starrpg.awakening;
import com.junwo.starrpg.bestiary.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.neoforged.neoforge.entity.PartEntity;
public final class BossHitPart extends PartEntity<BestiaryMob> {
    private final int index;private final EntityDimensions dimensions;
    public BossHitPart(BestiaryMob parent,int index,float width,float height){super(parent);this.index=index;dimensions=EntityDimensions.scalable(width,height);refreshDimensions();}
    @Override protected void defineSynchedData(SynchedEntityData.Builder builder){}
    @Override protected void readAdditionalSaveData(CompoundTag tag){}
    @Override protected void addAdditionalSaveData(CompoundTag tag){}
    @Override public EntityDimensions getDimensions(Pose pose){return dimensions==null?EntityDimensions.scalable(1,1):dimensions;}
    @Override public boolean shouldBeSaved(){return false;}
    @Override public boolean isPickable(){return getParent().isAlive()&&(getParent().kind!=BestiaryKind.HYDRA||(getParent().headMask()&(1<<index))!=0);}
    @Override public boolean is(Entity other){return this==other||getParent()==other;}
    @Override public boolean hurt(DamageSource source,float amount){if(!isPickable())return false;var parent=getParent();var data=parent.getPersistentData();boolean previous=data.contains("aw_hit_part");int value=data.getInt("aw_hit_part");float before=parent.getHealth();boolean hurt;try{data.putInt("aw_hit_part",index);hurt=parent.hurt(source,amount);}finally{if(previous)data.putInt("aw_hit_part",value);else data.remove("aw_hit_part");}if(hurt&&before>parent.getHealth())UniqueBossCombat.headHit(parent,index,before-parent.getHealth());return hurt;}
}
