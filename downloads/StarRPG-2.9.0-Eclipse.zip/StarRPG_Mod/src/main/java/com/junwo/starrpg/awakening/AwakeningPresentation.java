package com.junwo.starrpg.awakening;
import com.junwo.starrpg.*;
import com.junwo.starrpg.adventure.LegendarySets;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
public final class AwakeningPresentation extends RenderLayer<AbstractClientPlayer,PlayerModel<AbstractClientPlayer>> {
    public AwakeningPresentation(PlayerRenderer parent){super(parent);}
    @Override public void render(PoseStack p,MultiBufferSource b,int light,AbstractClientPlayer player,float walk,float amount,float partial,float age,float yaw,float pitch){if(!VisualOptions.AURAS.get()||player.isInvisible()||player.distanceToSqr(net.minecraft.client.Minecraft.getInstance().gameRenderer.getMainCamera().getPosition())>1024)return;int set=-1;for(int i=0;i<3;i++)if(LegendarySets.count(player,i)>=2){set=i;break;}int constellation=player.getPersistentData().getLong("aw_aura_until")>player.level().getGameTime()?player.getPersistentData().getInt("aw_aura"):-1;if(set<0&&constellation<0)return;p.pushPose();p.translate(0,1.5,0);p.scale(1,-1,1);if(set>=0){int color=new int[]{0xFF975E,0x67D8D8,0xA2D9B5}[set];CinematicVfx.seal(p,b,.62F,age,color,.17F);if(LegendarySets.count(player,set)==4&&VisualOptions.quality()>0)for(int i=0;i<3;i++){p.pushPose();p.mulPose(Axis.YP.rotation(age*.018F+i*2.094F));p.translate(.6,.6+Math.sin(age*.05+i)*.12,0);CinematicVfx.crystal(p,b,.045F,.13F,color,.55F);p.popPose();}}if(constellation>=0){int color=new int[]{0xFF8B72,0x80C5FF,0xBD9CFF}[Math.clamp(constellation,0,2)];p.translate(0,2.1,0);p.mulPose(Axis.YP.rotation(age*.008F));CinematicVfx.seal(p,b,.32F,age,color,.35F);}p.popPose();}
}
