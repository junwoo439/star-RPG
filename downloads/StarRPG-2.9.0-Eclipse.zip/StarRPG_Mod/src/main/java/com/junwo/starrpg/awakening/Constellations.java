package com.junwo.starrpg.awakening;

import com.junwo.starrpg.*;
import com.junwo.starrpg.adventure.*;
import com.junwo.starrpg.bestiary.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;

@EventBusSubscriber(modid=StarRPG.MODID)
public final class Constellations {
    public static final String[] NAMES={"붉은 사냥꾼","푸른 수호성","보랏빛 현자"};
    public static int level(Player p,int id){return Math.clamp(AwakeningData.number(p,"constellation_level_"+id),0,5);}
    public static int active(Player p){return AwakeningData.number(p,"constellation_active")-1;}
    public static boolean select(Player p,int id){if(id<0||id>2||(AwakeningData.number(p,"constellation_unlocked")&(1<<id))==0)return false;AwakeningData.set(p,"constellation_active",id+1);return true;}
    public static boolean grow(Player p,int id){if(id<0||id>2||(AwakeningData.number(p,"constellation_unlocked")&(1<<id))==0)return false;int rank=level(p,id);if(rank>=5||p.getInventory().countItem(AwakeningItems.STAR_CORE.get())<rank+1||p.getInventory().countItem(AwakeningItems.ESSENCE.get())<5*(rank+1)||StarWallet.get(p.getServer()).balance(p.getUUID())<1000*(rank+1))return false;LifeJobs.consume(p,AwakeningItems.STAR_CORE.get(),rank+1);LifeJobs.consume(p,AwakeningItems.ESSENCE.get(),5*(rank+1));StarWallet.get(p.getServer()).debit(p.getUUID(),1000*(rank+1));AwakeningData.set(p,"constellation_level_"+id,rank+1);return true;}
    public static int mana(Player p){return p.level().isClientSide()?0:active(p)==2?level(p,2)*6:0;}
    private static void attribute(Player p,net.minecraft.core.Holder<Attribute> attr,String name,double amount,AttributeModifier.Operation op){var a=p.getAttribute(attr);if(a==null)return;var id=ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,name);if(amount==0)a.removeModifier(id);else a.addOrUpdateTransientModifier(new AttributeModifier(id,amount,op));}
    private static boolean linked(Player p){int job=Careers.profile(p).selected;return job>=0&&SkillTrees.nodes(p,job)==3;}
    @SubscribeEvent public static void tick(net.neoforged.neoforge.event.tick.PlayerTickEvent.Post e){var p=e.getEntity();if(p.level().isClientSide()||p.tickCount%20!=0)return;int active=active(p);attribute(p,Attributes.ATTACK_DAMAGE,"constellation_attack",active==0?level(p,0)*.015+(linked(p)?.02:0):0,AttributeModifier.Operation.ADD_MULTIPLIED_BASE);attribute(p,Attributes.ARMOR,"constellation_guard",active==1?level(p,1)+(linked(p)?1:0):0,AttributeModifier.Operation.ADD_VALUE);}
    @SubscribeEvent public static void spell(net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent e){if(e.getEntity().level().isClientSide()||!(e.getSource().getEntity() instanceof Player p)||!e.getSource().is(MagicSystem.MAGIC_DAMAGE)||active(p)!=2)return;int job=Careers.profile(p).selected;float link=job>=0&&SkillTrees.nodes(p,job)==3?.02F:0;e.setAmount(e.getAmount()*(1+level(p,2)*.015F+link));}
    @SubscribeEvent public static void unlock(net.neoforged.neoforge.event.entity.living.LivingDeathEvent e){if(e.getEntity().level().isClientSide()||!(e.getEntity() instanceof BestiaryMob mob)||!(e.getSource().getEntity() instanceof Player p)||p.isCreative()||p.isSpectator()||mob.getPersistentData().hasUUID("starrpg_summoner")||!mob.kind.boss||mob.awakenedVariant()==3||mob.kind.minTier<10)return;AwakeningData.set(p,"constellation_unlocked",7);if(!mob.getPersistentData().getBoolean("constellation_paid")){mob.getPersistentData().putBoolean("constellation_paid",true);LifeJobs.give(p,new ItemStack(AwakeningItems.STAR_CORE.get()));}p.sendSystemMessage(net.minecraft.network.chat.Component.literal("성좌가 깨어났습니다. Shift+H → 각성 → 성좌"));}
}
