package com.junwo.starrpg.awakening;
import com.junwo.starrpg.*;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.resources.ResourceLocation;
public final class BossSpellRenderer extends EntityRenderer<BossSpell> {
    public BossSpellRenderer(EntityRendererProvider.Context context){super(context);}
    @Override public ResourceLocation getTextureLocation(BossSpell entity){return CinematicVfx.ATLAS;}
    @Override public boolean shouldRender(BossSpell e,net.minecraft.client.renderer.culling.Frustum f,double x,double y,double z){return e.distanceToSqr(x,y,z)<4096&&f.isVisible(e.getBoundingBox().inflate(e.radius()+2));}
    @Override public void render(BossSpell e,float yaw,float partial,PoseStack pose,MultiBufferSource buffers,int light){AwakeningVfx.draw(pose,buffers,e.style(),e.color(),e.radius(),e.tickCount+partial,e.life(),e.getYRot(),e.getXRot());}
}
