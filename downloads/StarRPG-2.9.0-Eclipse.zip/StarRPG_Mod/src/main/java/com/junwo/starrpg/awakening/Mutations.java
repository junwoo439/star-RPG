package com.junwo.starrpg.awakening;

import com.junwo.starrpg.*;
import com.junwo.starrpg.adventure.*;
import com.junwo.starrpg.bestiary.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.*;
import net.neoforged.fml.common.EventBusSubscriber;

@EventBusSubscriber(modid=StarRPG.MODID)
public final class Mutations {
    public static double rareChance(int tier){return .02+Math.min(20,Math.max(0,tier))*.002;}
    public static double mutationChance(int tier){return tier<3?0:.005+Math.min(30,tier)*.00075;}
    @SubscribeEvent public static void spawn(net.neoforged.neoforge.event.entity.living.FinalizeSpawnEvent e){if(!(e.getEntity() instanceof BestiaryMob m)||e.getSpawnType()!=MobSpawnType.NATURAL&&e.getSpawnType()!=MobSpawnType.CHUNK_GENERATION)return;var level=e.getLevel().getLevel();if(level.getEntitiesOfClass(BestiaryMob.class,m.getBoundingBox().inflate(24),b->b.awakenedVariant()>0).size()>=6)return;int tier=WorldDifficulty.get(level.getServer()).tier();double roll=m.getRandom().nextDouble(),factor=m.kind.boss?.25:1;if(roll<mutationChance(tier)*factor)m.awakenedVariant(2);else if(roll<(mutationChance(tier)+rareChance(tier))*factor)m.awakenedVariant(1);}
    @SubscribeEvent(priority=EventPriority.LOW) public static void joined(net.neoforged.neoforge.event.entity.EntityJoinLevelEvent e){if(e.getLevel().isClientSide()||!(e.getEntity() instanceof BestiaryMob m)||m.awakenedVariant()==0||m.awakenedVariant()==3)return;int variant=m.awakenedVariant();double health=m.kind.boss?(variant==2?.25:.15):(variant==2?.7:.4),power=variant==2?.15:.1;modify(m,Attributes.MAX_HEALTH,"variant_health",health);modify(m,Attributes.ATTACK_DAMAGE,"variant_attack",power);m.setCustomName(net.minecraft.network.chat.Component.literal((variant==2?"변이 · ":"희귀 · ")+m.kind.name).withColor(variant==2?0xBD91FF:0xFFD16A));m.setCustomNameVisible(true);}
    private static void modify(BestiaryMob m,net.minecraft.core.Holder<Attribute> attribute,String key,double amount){var a=m.getAttribute(attribute);if(a==null)return;var id=ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,key);if(a.getModifier(id)!=null)return;float before=m.getMaxHealth(),health=m.getHealth();a.addPermanentModifier(new AttributeModifier(id,amount,AttributeModifier.Operation.ADD_MULTIPLIED_BASE));if(attribute==Attributes.MAX_HEALTH)m.setHealth(health/before*m.getMaxHealth());}
    @SubscribeEvent public static void found(net.neoforged.neoforge.event.tick.PlayerTickEvent.Post e){var p=e.getEntity();if(p.level().isClientSide()||p.tickCount%40!=0)return;for(var m:p.level().getEntitiesOfClass(BestiaryMob.class,p.getBoundingBox().inflate(24),m->m.awakenedVariant()>0&&m.awakenedVariant()<3&&m.isAlive()&&p.hasLineOfSight(m))){String key=(m.awakenedVariant()==2?"mutation_seen_":"rare_seen_")+m.kind.id;if(AwakeningData.number(p,key)==0)AwakeningData.set(p,key,1);}}
    @SubscribeEvent public static void killed(net.neoforged.neoforge.event.entity.living.LivingDropsEvent e){if(e.getEntity().level().isClientSide()||!(e.getEntity() instanceof BestiaryMob m)||!(e.getSource().getEntity() instanceof Player p)||p.isCreative()||p.isSpectator()||m.awakenedVariant()<1||m.awakenedVariant()>2||m.getPersistentData().hasUUID("starrpg_summoner")||m.getPersistentData().getBoolean("aw_variant_paid"))return;m.getPersistentData().putBoolean("aw_variant_paid",true);String key=m.awakenedVariant()==2?"mutation_":"rare_";AwakeningData.set(p,key+"seen_"+m.kind.id,1);AwakeningData.add(p,key+"kills_"+m.kind.id,1);e.getDrops().add(new net.minecraft.world.entity.item.ItemEntity(m.level(),m.getX(),m.getY(),m.getZ(),new ItemStack(m.awakenedVariant()==2?AwakeningItems.CRYSTAL.get():AwakeningItems.ESSENCE.get(),m.kind.boss?3:1)));}
    public static boolean claim(Player p,int species,int type){if(species<0||species>=53||type<1||type>2)return false;String key=(type==2?"mutation_":"rare_")+BestiaryKind.values()[species].id;if(AwakeningData.number(p,key+"_claimed")>0||AwakeningData.number(p,(type==2?"mutation_kills_":"rare_kills_")+BestiaryKind.values()[species].id)<(type==2?1:3)||!Economy.fits(p,new ItemStack(AwakeningItems.ESSENCE.get(),3)))return false;AwakeningData.set(p,key+"_claimed",1);LifeJobs.give(p,new ItemStack(AwakeningItems.ESSENCE.get(),3));return true;}
}
