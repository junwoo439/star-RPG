package com.junwo.starrpg.awakening;

import com.junwo.starrpg.*;
import com.junwo.starrpg.bestiary.*;
import java.util.*;
import net.minecraft.network.syncher.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.*;
import net.minecraft.world.phys.*;

/** Short-lived server projectiles and expanding shockwaves. Never save or force-load chunks. */
public final class BossSpell extends Entity {
    private static final EntityDataAccessor<Integer> STYLE=SynchedEntityData.defineId(BossSpell.class,EntityDataSerializers.INT),COLOR=SynchedEntityData.defineId(BossSpell.class,EntityDataSerializers.INT),LIFE=SynchedEntityData.defineId(BossSpell.class,EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> RADIUS=SynchedEntityData.defineId(BossSpell.class,EntityDataSerializers.FLOAT);
    private UUID owner;private float power;private boolean wave;private final Set<UUID> hit=new HashSet<>();
    public BossSpell(EntityType<? extends BossSpell> type,Level level){super(type,level);setNoGravity(true);noPhysics=true;}
    @Override protected void defineSynchedData(SynchedEntityData.Builder b){b.define(STYLE,60);b.define(COLOR,0xA3E2ED);b.define(LIFE,60);b.define(RADIUS,.4F);}
    public int style(){return entityData.get(STYLE);}public int color(){return entityData.get(COLOR);}public int life(){return entityData.get(LIFE);}public float radius(){return entityData.get(RADIUS);}
    public static void launch(BestiaryMob owner,Vec3 origin,Vec3 direction,int style,int color,float power,boolean wave,float radius){
        if(!(owner.level() instanceof ServerLevel level)||level.getEntitiesOfClass(BossSpell.class,owner.getBoundingBox().inflate(96)).size()>=96||level.getEntitiesOfClass(BossSpell.class,owner.getBoundingBox().inflate(64),spell->owner.getUUID().equals(spell.owner)).size()>=8)return;
        var spell=new BossSpell(AwakeningEntities.SPELL.get(),level);spell.owner=owner.getUUID();spell.power=power;spell.wave=wave;spell.setPos(origin);spell.entityData.set(STYLE,style);spell.entityData.set(COLOR,color);spell.entityData.set(RADIUS,radius);spell.entityData.set(LIFE,wave?30:70);spell.setDeltaMovement(wave?Vec3.ZERO:direction.normalize().scale(.32));level.addFreshEntity(spell);
    }
    @Override public void tick(){super.tick();if(tickCount>=life()){discard();return;}if(level().isClientSide()){setPos(position().add(getDeltaMovement()));return;}
        var level=(ServerLevel)level();if(owner==null||!(level.getEntity(owner) instanceof BestiaryMob boss)||!boss.isAlive()||boss.distanceToSqr(this)>4096){discard();return;}
        if(wave){double ring=radius()*tickCount/life();for(var target:level.getEntitiesOfClass(LivingEntity.class,getBoundingBox().inflate(radius()+1,2,radius()+1),t->(t instanceof Player||t==boss.getTarget())&&BestiaryCombat.valid(boss,t))){double distance=target.position().subtract(position()).horizontalDistance();if(distance<ring-.8||distance>ring+.8||Math.abs(target.getY()-getY())>1.8||hit.contains(target.getUUID())||!boss.hasLineOfSight(target))continue;hit.add(target.getUUID());UniqueBossCombat.damage(boss,target,power,false,true);}return;}
        Vec3 from=position(),to=from.add(getDeltaMovement());var block=level.clip(new ClipContext(from,to,ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,this));if(block.getType()!=HitResult.Type.MISS){discard();return;}
        for(var target:level.getEntitiesOfClass(LivingEntity.class,new AABB(from,to).inflate(.5),t->(t instanceof Player||t==boss.getTarget())&&BestiaryCombat.valid(boss,t))){if(!target.getBoundingBox().inflate(.4).contains(from)&&target.getBoundingBox().inflate(.4).clip(from,to).isEmpty())continue;UniqueBossCombat.damage(boss,target,power,false,false);if(style()==63||style()==67)target.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.POISON,50,0));ArcaneSigil.spawn(level,target.position(),getDeltaMovement(),style(),color(),1.3F,16);discard();return;}setPos(to);
    }
    @Override public boolean shouldBeSaved(){return false;}
    @Override protected void readAdditionalSaveData(CompoundTag t){discard();}
    @Override protected void addAdditionalSaveData(CompoundTag t){}
}
