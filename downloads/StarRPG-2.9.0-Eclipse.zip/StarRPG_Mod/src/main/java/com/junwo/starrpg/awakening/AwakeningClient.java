package com.junwo.starrpg.awakening;
import com.google.gson.*;
import com.junwo.starrpg.StarRPG;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
@EventBusSubscriber(modid=StarRPG.MODID,value=Dist.CLIENT)
public final class AwakeningClient {
    public static JsonObject data=new JsonObject();
    public static long revision;
    public static void receive(String value){try{data=JsonParser.parseString(value).getAsJsonObject();revision++;var level=net.minecraft.client.Minecraft.getInstance().level;if(level!=null&&data.has("auras"))for(var raw:data.getAsJsonArray("auras")){var row=raw.getAsJsonObject();var player=level.getEntity(row.get("id").getAsInt());if(player!=null){player.getPersistentData().putInt("aw_aura",row.get("star").getAsInt());player.getPersistentData().putLong("aw_aura_until",level.getGameTime()+30);}}}catch(JsonParseException ignored){}}
    @SubscribeEvent public static void logout(net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent.LoggingOut e){data=new JsonObject();revision++;}
    @SubscribeEvent public static void hud(net.neoforged.neoforge.client.event.RenderGuiEvent.Post e){var mc=net.minecraft.client.Minecraft.getInstance();if(mc.player==null||mc.options.hideGui||mc.screen!=null||!data.has("party"))return;var rows=data.getAsJsonArray("party");if(rows.isEmpty())return;var g=e.getGuiGraphics();int y=48;for(var value:rows){var row=value.getAsJsonObject();int hp=row.get("hp").getAsInt(),max=row.get("max").getAsInt();g.fill(5,y,153,y+24,0xB5101928);g.drawString(mc.font,row.get("name").getAsString()+"  "+hp+"/"+max,9,y+2,0xE1E9F6,false);g.fill(9,y+14,149,y+18,0xFF303C51);g.fill(9,y+14,9+(int)(140*Math.clamp(hp/(float)Math.max(1,max),0,1)),y+18,0xFF52BD9A);g.drawString(mc.font,row.get("state").getAsString(),101,y+2,0xB1C8D9,false);y+=26;}}
}
