package com.junwo.starrpg.awakening;
import com.junwo.starrpg.*;
import com.junwo.starrpg.bestiary.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
@EventBusSubscriber(modid=StarRPG.MODID)
public final class EncounterScaling {
    public static void scale(BestiaryMob boss,Player target){if(!boss.kind.boss||boss.awakenedVariant()==3||boss.getPersistentData().contains("aw_party_size")||target.isCreative()||target.isSpectator())return;int n=Math.clamp(Parties.nearby(target,32).size(),1,4);boss.getPersistentData().putInt("aw_party_size",n);if(n==1)return;float ratio=boss.getHealth()/boss.getMaxHealth();boss.getAttribute(Attributes.MAX_HEALTH).addPermanentModifier(new AttributeModifier(ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,"party_boss_health"),.45*(n-1),AttributeModifier.Operation.ADD_MULTIPLIED_BASE));boss.setHealth(ratio*boss.getMaxHealth());boss.getAttribute(Attributes.ATTACK_DAMAGE).addPermanentModifier(new AttributeModifier(ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,"party_boss_damage"),.08*(n-1),AttributeModifier.Operation.ADD_MULTIPLIED_BASE));}
    @SubscribeEvent public static void tick(net.neoforged.neoforge.event.tick.EntityTickEvent.Post e){if(!e.getEntity().level().isClientSide()&&e.getEntity() instanceof BestiaryMob b&&b.kind.boss&&b.getTarget() instanceof Player p)scale(b,p);}
    @SubscribeEvent(priority=net.neoforged.bus.api.EventPriority.HIGHEST) public static void hit(net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent e){if(!e.getEntity().level().isClientSide()&&e.getEntity() instanceof BestiaryMob b&&e.getSource().getEntity() instanceof Player p)scale(b,p);}
}
