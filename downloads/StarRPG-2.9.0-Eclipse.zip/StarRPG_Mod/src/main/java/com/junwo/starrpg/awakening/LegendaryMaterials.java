package com.junwo.starrpg.awakening;
import com.junwo.starrpg.StarRPG;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.*;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.registries.*;
public final class LegendaryMaterials {
    public static final DeferredRegister<ArmorMaterial> MATERIALS=DeferredRegister.create(Registries.ARMOR_MATERIAL,StarRPG.MODID);
    public static final java.util.List<DeferredHolder<ArmorMaterial,ArmorMaterial>> SETS=new java.util.ArrayList<>();
    static{for(String id:new String[]{"dragon","lich","golem","starforged"})SETS.add(MATERIALS.register(id,()->{var base=ArmorMaterials.DIAMOND.value();return new ArmorMaterial(base.defense(),base.enchantmentValue(),base.equipSound(),base.repairIngredient(),java.util.List.of(new ArmorMaterial.Layer(ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,id))),base.toughness(),base.knockbackResistance());}));}
    public static int set(ItemStack stack){var id=net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(stack.getItem());if(!id.getNamespace().equals(StarRPG.MODID)||!(stack.getItem() instanceof ArmorItem))return -1;for(int i=0;i<4;i++)if(id.getPath().startsWith(new String[]{"dragon_","lich_","golem_","starforged_"}[i]))return i;return -1;}
}
