package com.junwo.starrpg.awakening;
import com.junwo.starrpg.*;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.phys.Vec3;
public final class AwakeningVfx {
    private static void ring(PoseStack p,MultiBufferSource b,float radius,float y,int color,float alpha){int count=24+VisualOptions.quality()*12;for(int i=0;i<count;i++){double a=i*Math.PI*2/count,next=(i+1)*Math.PI*2/count;CinematicVfx.line(p,b,new Vec3(Math.cos(a)*radius,y,Math.sin(a)*radius),new Vec3(Math.cos(next)*radius,y,Math.sin(next)*radius),.035F,color,alpha);}}
    public static void draw(PoseStack p,MultiBufferSource b,int style,int color,float radius,float age,int life,float yaw,float pitch){float f=Math.clamp(age/Math.max(1,life),0,1),alpha=Math.min(1,age/3)*Math.min(1,(life-age)/6);int count=5+VisualOptions.quality()*3;p.pushPose();
        if(style==60||style==67||style==68){float core=radius*(.8F+(float)Math.sin(age*.18)*.15F);CinematicVfx.crystal(p,b,core*.45F,core,color,.9F);for(int i=0;i<3;i++){p.pushPose();p.mulPose(Axis.YP.rotation(age*.05F+i*2));p.mulPose(Axis.ZP.rotation(.6F+i));ring(p,b,core,0,color,.7F);p.popPose();}p.popPose();return;}
        if(style==64||style==65){float ring=radius*f;ring(p,b,ring,.12F,color,alpha);ring(p,b,Math.max(0,ring-.35F),.18F,0xD4E9D5,alpha*.6F);for(int i=0;i<count;i++){double a=i*6.283/count;p.pushPose();p.translate(Math.cos(a)*ring,0,Math.sin(a)*ring);CinematicVfx.crystal(p,b,.15F,.3F,color,alpha);p.popPose();}p.popPose();return;}
        if(style==61||style==66){for(int i=0;i<4;i++){p.pushPose();p.translate(0,.7+i*.4,0);p.mulPose(Axis.ZP.rotation(i%2==0?.4F:-.4F));ring(p,b,radius*(.65F+i*.05F),0,color,alpha*.8F);p.popPose();}CinematicVfx.seal(p,b,radius,age,color,alpha);p.popPose();return;}
        CinematicVfx.seal(p,b,radius*(.55F+.45F*f),age,color,alpha*.65F);
        if(style==58){for(int i=0;i<count;i++){double a=i*2.4;p.pushPose();p.translate(Math.cos(a)*radius*.5,0,Math.sin(a)*radius*.5);CinematicVfx.crystal(p,b,radius*.12F,radius*(.4F+(i%3)*.2F)*Math.min(1,f*3),color,alpha);p.popPose();}}
        else if(style==57||style==70){for(int i=0;i<3;i++){Vec3 last=new Vec3(Math.sin(i)*radius*.5,radius*2,Math.cos(i)*radius*.5);for(int j=1;j<=8;j++){var at=new Vec3(Math.sin(j*3+age*.2+i)*radius*.2,radius*2*(1-j/8.0),Math.cos(j*4+i)*radius*.2);CinematicVfx.line(p,b,last,at,.04F,0xC6ECFF,alpha);last=at;}}}
        else if(style==69||style==71){for(int i=0;i<3;i++){p.pushPose();p.translate(0,i*.8+.1,0);ring(p,b,radius*(1-i*.18F),0,color,alpha);p.popPose();}CinematicVfx.line(p,b,Vec3.ZERO,new Vec3(0,radius*2,0),.12F,color,alpha*.7F);}
        else{for(int i=0;i<count;i++){double a=age*.04+i*2.399;p.pushPose();p.translate(Math.cos(a)*radius*.5,.3+Math.sin(f*Math.PI)*radius*.5,Math.sin(a)*radius*.5);p.mulPose(Axis.YP.rotation((float)a));CinematicVfx.sprite(p,b,style==59?2:style==63?6:7,radius*.25F,radius*.35F,color,alpha*.6F);p.popPose();}}
        p.popPose();
    }
}
