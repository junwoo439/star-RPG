package com.junwo.starrpg.bestiary;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
/** Distinguishes metallic species sharing an optional CE anatomical rig without editing CE assets. */
public final class SpeciesTint implements VertexConsumer {
    private final VertexConsumer delegate;private final float r,g,b;
    private SpeciesTint(VertexConsumer delegate,float r,float g,float b){this.delegate=delegate;this.r=r;this.g=g;this.b=b;}
    public static MultiBufferSource buffers(BestiaryKind kind,MultiBufferSource source){return switch(kind){case GOLD_DRAGON->type->new SpeciesTint(source.getBuffer(type),1.18F,1.12F,.68F);case BRASS_DRAGON->type->new SpeciesTint(source.getBuffer(type),1.05F,.9F,.55F);case COPPER_DRAGON->type->new SpeciesTint(source.getBuffer(type),1.05F,.68F,.60F);default->source;};}
    public VertexConsumer addVertex(float x,float y,float z){delegate.addVertex(x,y,z);return this;}
    public VertexConsumer setColor(int red,int green,int blue,int alpha){delegate.setColor(Math.min(255,Math.round(red*r)),Math.min(255,Math.round(green*g)),Math.min(255,Math.round(blue*b)),alpha);return this;}
    public VertexConsumer setUv(float u,float v){delegate.setUv(u,v);return this;}
    public VertexConsumer setUv1(int u,int v){delegate.setUv1(u,v);return this;}
    public VertexConsumer setUv2(int u,int v){delegate.setUv2(u,v);return this;}
    public VertexConsumer setNormal(float x,float y,float z){delegate.setNormal(x,y,z);return this;}
}
