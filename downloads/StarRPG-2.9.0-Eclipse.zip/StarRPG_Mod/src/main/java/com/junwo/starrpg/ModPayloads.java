package com.junwo.starrpg;

import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;

@EventBusSubscriber(
        modid = StarRPG.MODID,
        bus = EventBusSubscriber.Bus.MOD
)
public class ModPayloads {

    @SubscribeEvent
    public static void registerPayloads(
            RegisterPayloadHandlersEvent event
    ) {
        event.registrar("16").playToClient(com.junwo.starrpg.awakening.AwakeningPayloads.Snapshot.TYPE,com.junwo.starrpg.awakening.AwakeningPayloads.Snapshot.CODEC,com.junwo.starrpg.awakening.AwakeningPayloads.Snapshot::handle);
        event.registrar("16").playToServer(com.junwo.starrpg.awakening.AwakeningPayloads.Action.TYPE,com.junwo.starrpg.awakening.AwakeningPayloads.Action.CODEC,com.junwo.starrpg.awakening.AwakeningPayloads.Action::handle);
        event.registrar("16").playToClient(PresentationCuePayload.TYPE,PresentationCuePayload.STREAM_CODEC,PresentationCuePayload::handle);
        event.registrar("16").playToClient(WeaponMotionPayload.TYPE,WeaponMotionPayload.STREAM_CODEC,WeaponMotionPayload::handle);
        event.registrar("16").playToServer(ActionPayload.TYPE,ActionPayload.STREAM_CODEC,ActionPayload::handle);
        event.registrar("16").playToServer(
                UseChestAbilityPayload.TYPE,
                UseChestAbilityPayload.STREAM_CODEC,
                UseChestAbilityPayload::handle
        );
    }
}
