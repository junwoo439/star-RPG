package com.junwo.starrpg;

import net.minecraft.client.Minecraft;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;

@EventBusSubscriber(modid=StarRPG.MODID,value=Dist.CLIENT)
public final class StarRevealController {
    private static Object player;private static int serial;
    @SubscribeEvent public static void tick(net.neoforged.neoforge.client.event.ClientTickEvent.Post event){
        var mc=Minecraft.getInstance();if(mc.player==null){player=null;serial=0;return;}
        if(player!=mc.player){player=mc.player;serial=mc.player.getPersistentData().getInt("starrpg_ceremony_serial");return;}
        var tag=mc.player.getPersistentData();int now=tag.getInt("starrpg_ceremony_serial");if(now==serial)return;serial=now;
        if(mc.screen instanceof StarRevealScreen)return;
        int cue=tag.getInt("starrpg_ceremony_kind");ItemStack item=ItemStack.EMPTY;
        if(mc.player.containerMenu instanceof EnhancementMenu menu){item=menu.getSlot(0).getItem().copy();if(!item.isEmpty())EnhancementData.setLevel(item,tag.getInt("starrpg_ceremony_value"));}
        if(cue==PresentationCues.CRAFT){int id=tag.getInt("starrpg_ceremony_value");if(id>=0&&id<12)item=new ItemStack(com.junwo.starrpg.adventure.LegendarySets.PIECES.get(id).get());else if(id>=100&&id<=106)item=new ItemStack(com.junwo.starrpg.awakening.AwakenedForge.result(id-100));}
        mc.setScreen(new StarRevealScreen(mc.screen,mc.player.containerMenu,cue,tag.getInt("starrpg_ceremony_value"),tag.getInt("starrpg_ceremony_color"),item));
    }
}
