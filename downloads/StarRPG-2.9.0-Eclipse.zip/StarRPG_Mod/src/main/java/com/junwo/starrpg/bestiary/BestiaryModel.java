package com.junwo.starrpg.bestiary;

import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.model.EntityModel;
import java.util.*;
import static com.junwo.starrpg.bestiary.CreatureMesh.*;

/** Detailed original voxel anatomy, material atlas, jointed jaws/wings/limbs and species silhouettes. */
public final class BestiaryModel extends EntityModel<BestiaryMob> {
    private final BestiaryKind kind;private final Node root=new Node("root",0,0,0,0,0,0);
    private final Map<String,Node> bones=new LinkedHashMap<>();
    private static final int IVORY=0xF4D9A4,IRON=0xB6BAC9,DARK=0x28252C;
    public BestiaryModel(BestiaryKind k){super(net.minecraft.client.renderer.RenderType::entityTranslucent);kind=k;switch(k.body){
        case DRAGON,WYVERN,HYDRA->dragon();case BEAR,WOLF,BOAR,LIZARD->beast();case ANT,SPIDER,INSECT->insect();case SHARK->shark();case BIRD->bird();case ELEMENTAL->elemental();default->humanoid();
    }decorate();naturalDetails();AwakenedAnatomy.decorate(k,root);root.collect(bones);}
    private int skin(){return kind.color;}private int dark(){return kind==BestiaryKind.BANSHEE?mix(skin(),0xF2FFFF,.6F):mix(skin(),0x242332,.5F);}private int light(){return mix(skin(),0xF9E8C3,.35F);}
    private int armor(){return switch(kind.family){case FIEND->0x493C4B;case CELESTIAL->0xD6C38C;case UNDEAD->0x637D78;case CONSTRUCT->0x778F98;default->kind.boss?0x85705A:0x626773;};}
    private void box(Node n,float x,float y,float z,float w,float h,float d,int mat,int color){n.box(x,y,z,w,h,d,mat,color);}
    private void eye(Node parent,String name,float x,float y,float z,int color,boolean side){
        var n=parent.node(name,x,y,z,0,side?r(x<0?-65:65):0,r(x<0?12:-12));n.box(-1.25F,-.65F,-.3F,2.5F,1.3F,.6F,LEATHER,0x16131A);
        n.box(-.9F,-.35F,-.6F,1.8F,.7F,.4F,HORN,color,true);n.box(-.16F,-.36F,-.85F,.32F,.72F,.3F,LEATHER,0x171119);
    }
    private void horn(Node parent,String name,float x,float y,float z,float side){
        var n=parent.node(name,x,y,z,r(-32),0,r(side*15));n.taper(5,1.5F,.8F,HORN,mix(IVORY,DARK,.15F));
        var tip=n.node(name+"Tip",0,-4,0,r(-30),0,r(side*12));tip.taper(6,.9F,.05F,HORN,IVORY);
    }
    private void claws(Node foot,float z,int count){for(int i=0;i<count;i++)foot.node("claw"+i,(i-(count-1)/2F)*1.6F,1,z,r(20),0,0).box(-.45F,-.5F,-3,.9F,1,3.2F,HORN,IVORY);}
    private Node dragonHead(String name,float x,float y,float z,float angle){
        var neck=root.node(name+"Neck",x,y+4,z+8,r(-22),angle,0);neck.box(-4,-5,-8,8,10,14,SCALES,skin());neck.box(-3,3,-9,6,1,14,BELLY,light());
        var h=root.node(name,x,y,z,0,angle,0);h.chamfer(-5.5F,-7,-5,11,8,11,1.8F,SCALES,skin());h.chamfer(-4,-4,-13,8,4,10,1.3F,SCALES,skin());h.box(-3.8F,-.4F,-11.8F,7.6F,.6F,12,LEATHER,0x762331);
        for(int side:new int[]{-1,1}){
            h.node(name+"Brow"+side,side*4,-5.5F,-4,0,0,r(side*12)).box(-2,-1,-3,4,2,6,SCALES,dark());
            eye(h,name+"Eye"+side,side*4.3F,-3.5F,-5.5F,kind.move==BestiaryKind.Move.FROST?0x8AF9FF:0xF4E73A,true);
            horn(h,name+"Horn"+side,side*4,-6,4,side);h.node(name+"Cheek"+side,side*4,0,4,r(-30),0,r(side*50)).box(-1,-4,-1,2,4,2,HORN,IVORY);
            h.box(side*2-0.6F,-4.2F,-11.9F,1.2F,1,1,LEATHER,DARK);
            for(int t=0;t<5;t++)h.box(side*3.1F-.45F,-.5F,-10+t*2,.9F,2,.9F,HORN,IVORY);
        }
        var jaw=h.node(name+"Jaw",0,.6F,1,r(12),0,0);jaw.box(-3.8F,0,-12,7.6F,2,14,SCALES,dark());jaw.box(-3.2F,-.1F,-11.4F,6.4F,.3F,11,LEATHER,0xAB3440);
        for(int side:new int[]{-1,1})for(int t=0;t<4;t++)jaw.box(side*3-.4F,-1.8F,-10+t*2.7F,.8F,2,.8F,HORN,IVORY);
        jaw.box(-1,-.25F,-8,2,.4F,7,LEATHER,0xE15B69);return h;
    }
    private void dragon(){
        root.node("body",0,11,0).chamfer(-8,-7,-11,16,14,25,2.8F,SCALES,skin()).box(-5.8F,6,-9,11.6F,.8F,24,BELLY,mix(light(),0xE4BB70,.35F));
        root.node("haunch",0,14,12).chamfer(-6.5F,-5,-4,13,10,13,2.2F,SCALES,skin());
        dragonHead("head",0,4,-21,0);
        if(kind.body==BestiaryKind.Body.HYDRA){dragonHead("head2",-10,5,-14,r(-18));dragonHead("head3",10,5,-14,r(18));}
        else {wing(root,"wingL",-1,kind.body==BestiaryKind.Body.WYVERN?1.1F:1,false);wing(root,"wingR",1,kind.body==BestiaryKind.Body.WYVERN?1.1F:1,false);}
        for(int i=0;i<4;i++){
            if(kind.body==BestiaryKind.Body.WYVERN&&i<2)continue;float side=i%2==0?-1:1;
            var leg=root.node("leg"+i,side*6,13,i<2?-7:12,r(i<2?-12:18),0,r(side*-8));leg.chamfer(-3,-1,-3.5F,6,7,7,1.2F,SCALES,dark());
            var foot=leg.node("foot"+i,0,7,-1,r(i<2?12:-18),0,0);foot.box(-2.4F,0,-5,4.8F,4,8,SCALES,skin());claws(foot,-4,3);
        }
        var tail=root.node("tail",0,14,21,r(-6),0,0);tail.box(-3,-3,0,6,6,10,SCALES,skin());
        var t2=tail.node("tail2",0,0,9,r(-8),r(10),0);t2.box(-2.2F,-2,0,4.4F,4,11,SCALES,skin());
        var t3=t2.node("tail3",0,0,10,r(-10),r(14),0);t3.box(-1.3F,-1.3F,0,2.6F,2.6F,12,SCALES,dark());
        t3.triangle(new float[]{0,-1,5},new float[]{-4,0,11},new float[]{0,0,16},MEMBRANE,skin());t3.triangle(new float[]{0,-1,5},new float[]{4,0,11},new float[]{0,0,16},MEMBRANE,skin());
        for(int i=0;i<8;i++){var n=root.node("spine"+i,0,5,i*4-11);n.triangle(new float[]{-1,0,0},new float[]{0,-5,2},new float[]{1,0,4},HORN,dark());}
    }
    private void wing(Node parent,String name,int side,float scale,boolean feathers){
        var w=parent.node(name,side*6,6,-4,r(-8),r(side*-8),r(side*8));
        float[][] points={{0,0,0},{side*13*scale,-5,2},{side*31*scale,-10,8},{side*25*scale,3,18},{side*15*scale,6,23},{side*6*scale,9,20},{0,5,10}};
        int color=mix(skin(),0xFFB86B,.35F);
        if(feathers){for(int i=0;i<8;i++){var feather=w.node(name+"Feather"+i,side*(4+i*2.7F),0,2+i,0,r(side*-20),r(side*-25));feather.box(-1.4F,-1,-1,2.8F,1,17-i*.9F,FEATHER,kind.family==BestiaryKind.Family.CELESTIAL?0xFFF4D6:light());}}
        else {for(int i=2;i<6;i++)w.triangle(points[0],points[i],points[i+1],MEMBRANE,color);w.triangle(points[0],points[1],points[2],MEMBRANE,color);}
        beam(w,name+"Arm",points[0],points[1],2.2F,SCALES,dark());beam(w,name+"Forearm",points[1],points[2],1.7F,SCALES,dark());
        for(int i=3;i<6;i++)beam(w,name+"Finger"+i,points[1],points[i],1.1F,SCALES,dark());
        horn(w,name+"Thumb",side*13*scale,-5,2,side);
    }
    private void beast(){
        boolean bear=kind.body==BestiaryKind.Body.BEAR,boar=kind.body==BestiaryKind.Body.BOAR,lizard=kind.body==BestiaryKind.Body.LIZARD;
        int mat=lizard?SCALES:bear?SHAG:FUR;float bulk=bear?14:boar?12:8;
        root.node("body",0,13,0).chamfer(-bulk/2,-5,-10,bulk,11,22,2,mat,skin()).box(-bulk*.35F,4,-7,bulk*.7F,2,16,mat,light());
        if(bear||boar)root.node("shoulder",0,11,-5).box(-bulk/2-1,-5,-5,bulk+2,10,10,mat,dark());
        var h=root.node("head",0,12,-12);h.chamfer(-4,-5,-4,8,8,8,1.3F,mat,skin());h.chamfer(-3,-1,-9,6,4,6,1,mat,light());h.box(-2.5F,-.8F,-9.5F,5,2,1,LEATHER,DARK);
        for(int side:new int[]{-1,1}){eye(h,"eye"+side,side*2.5F,-2.5F,-4.4F,0xE9CF65,false);h.node("ear"+side,side*3,-5,0,0,0,r(side*20)).box(-1,-3,-1,2,3,2,mat,dark());}
        var jaw=h.node("headJaw",0,3,-3,r(5),0,0);jaw.box(-2.6F,0,-5,5.2F,1.4F,7,mat,dark());
        if(boar)for(int side:new int[]{-1,1})horn(h,"tusk"+side,side*3.5F,3,-7,-side);
        else for(int side:new int[]{-1,1})jaw.box(side*2-.4F,-1.8F,-3,.8F,2,1,HORN,IVORY);
        for(int i=0;i<4;i++){float side=i%2==0?-1:1;var leg=root.node("leg"+i,side*(bulk/2-1),17,i<2?-7:8);leg.box(-1.7F,0,-2,3.4F,6,4,mat,dark());var foot=leg.node("foot"+i,0,5,-1);foot.box(-2,0,-2,4,2,5,mat,skin());if(!boar)claws(foot,-2,3);}
        var tail=root.node("tail",0,14,11,r(-20),r(8),0);tail.box(-1.5F,-1.5F,0,3,3,bear?3:boar?5:12,mat,dark());
        if(lizard){for(int i=0;i<7;i++){var n=root.node("crest"+i,0,7,i*3-7);n.triangle(new float[]{0,0,0},new float[]{0,-4,2},new float[]{0,0,4},MEMBRANE,0xD1D566);}}
    }
    private void insect(){
        boolean spider=kind.body==BestiaryKind.Body.SPIDER;int count=spider?8:6;
        root.node("body",0,15,6).chamfer(-6,-4,-4,12,8,14,2.5F,CHITIN,skin());root.node("thorax",0,16,-3).box(-3,-3,-3,6,6,6,CHITIN,dark());
        var h=root.node("head",0,16,-8);h.box(-3.7F,-3,-4,7.4F,6,7,CHITIN,skin());
        for(int i=0;i<(spider?8:2);i++)eye(h,"eye"+i,(i%4-1.5F)*1.8F,-1.5F+(i/4)*2,-4.4F,spider?0xFF5342:0xE9D36A,false);
        for(int side:new int[]{-1,1}){h.node("fang"+side,side*2,2,-4,r(-15),r(side*18),0).box(-.7F,0,-3,1.4F,4,3,HORN,IVORY);
            beam(h,"antenna"+side,new float[]{side*2,-3,0},new float[]{side*5,-7,-6},.7F,CHITIN,dark());}
        for(int i=0;i<count;i++){int side=i%2==0?-1:1;var leg=root.node("leg"+i,side*3,16,(i/2)*4-6);beam(leg,"upper"+i,new float[]{0,0,0},new float[]{side*7,-3,-2},1.4F,CHITIN,dark());beam(leg,"lower"+i,new float[]{side*7,-3,-2},new float[]{side*10,8,-4},1,CHITIN,skin());}
        if(kind.body==BestiaryKind.Body.INSECT){wing(root,"wingL",-1,.65F,false);wing(root,"wingR",1,.65F,false);}
    }
    private void bird(){
        root.node("body",0,13,1,r(-12),0,0).chamfer(-4,-5,-6,8,10,14,2,FEATHER,skin());
        var neck=root.node("neck",0,10,-5,r(-12),0,0);neck.chamfer(-2.5F,-6,-2.5F,5,9,5,1,FEATHER,light());
        var h=root.node("head",0,4,-7);h.chamfer(-3,-4,-4,6,6,7,1,SCALES,skin());h.box(-1.7F,-1.5F,-8,3.4F,2.7F,5,HORN,0xD2AC62);var jaw=h.node("headJaw",0,1,-3);jaw.box(-1.5F,0,-4,3,1,5,HORN,0xB99152);for(int side:new int[]{-1,1})eye(h,"birdEye"+side,side*2.7F,-2,-3,0xF4DC70,true);
        wing(root,"wingL",-1,.43F,true);wing(root,"wingR",1,.43F,true);
        for(int i=0;i<2;i++){int side=i==0?-1:1;var leg=root.node("leg"+i,side*2.6F,18,2,r(-16),0,0);leg.box(-.8F,-1,-1,1.6F,6,2,HORN,0xB29A62);var foot=leg.node("foot"+i,0,5,-1,r(16),0,0);foot.box(-1.2F,0,-2,2.4F,1.2F,4,SCALES,dark());claws(foot,-2,3);}
        var tail=root.node("tail",0,13,8,r(-24),0,0);tail.chamfer(-1.8F,-1.8F,0,3.6F,3.6F,10,1,SCALES,skin());var tip=tail.node("tail2",0,0,9,r(-18),r(12),0);tip.box(-1,-1,0,2,2,10,SCALES,dark());for(int i=-2;i<=2;i++)tip.node("tailFeather"+i,i,0,7,0,r(i*15),0).box(-.8F,-.3F,0,1.6F,.6F,8,FEATHER,light());
    }
    private void shark(){
        root.node("body",0,15,0).box(-5,-4,-9,10,8,18,HIDE,skin()).box(-4,3,-8,8,1,17,HIDE,0xE2E8DA);
        var h=root.node("head",0,15,-9);h.box(-4,-3,-7,8,6,8,HIDE,skin());h.box(-3,-2,-10,6,4,4,HIDE,skin());
        var jaw=h.node("headJaw",0,2,-2,r(8),0,0);jaw.box(-3.2F,0,-7,6.4F,1,8,HIDE,0xDDDFCA);for(int i=0;i<5;i++)jaw.box(i-2,-1.4F,-6,.6F,1.5F,.6F,BONE,IVORY);
        for(int side:new int[]{-1,1})eye(h,"eye"+side,side*3.5F,-1,-5.5F,0xBBCDC7,true);
        var fin=root.node("dorsal",0,11,-2);fin.triangle(new float[]{0,0,-3},new float[]{0,-10,1},new float[]{0,0,9},HIDE,dark());
        for(int side:new int[]{-1,1}){var w=root.node(side<0?"wingL":"wingR",side*4,17,-3);w.triangle(new float[]{0,0,0},new float[]{side*12,2,5},new float[]{0,1,8},HIDE,skin());}
        var tail=root.node("tail",0,15,9);tail.box(-2.5F,-2.5F,0,5,5,8,HIDE,skin());var t=tail.node("tail2",0,0,7);t.box(-1,-1,0,2,2,7,HIDE,skin());t.triangle(new float[]{0,0,3},new float[]{0,-10,10},new float[]{0,0,8},HIDE,dark());t.triangle(new float[]{0,0,3},new float[]{0,7,10},new float[]{0,0,8},HIDE,dark());
        for(int i=0;i<3;i++)root.node("gill"+i,0,14,-7+i*1.4F).box(-5.05F,-2,0,10.1F,4,.3F,HIDE,dark());
    }
    private void elemental(){
        root.node("body",0,9,0).box(-4,-5,-3,8,10,6,STONE,skin());var h=root.node("head",0,1,0,r(15),r(45),0);h.box(-3,-3,-3,6,6,6,STONE,light());
        root.node("core",0,8,-3.4F,r(15),0,r(45)).box(-1.8F,-1.8F,-1,3.6F,3.6F,2,HORN,light(),true);
        for(int i=0;i<6;i++){var n=root.node("orbit"+i,0,17,0,0,r(i*60),0);n.node("shard"+i,5,-i*.6F,0,r(i*15),0,r(45)).box(-1.5F,-2,-1.5F,3,4,3,STONE,skin());}
        for(int side:new int[]{-1,1})root.node(side<0?"armL":"armR",side*7,5,0,r(-15),0,r(side*-15)).box(-2,0,-2,4,10,4,STONE,skin());
    }
    private void humanoid(){
        boolean giant=kind.body==BestiaryKind.Body.GIANT||kind.body==BestiaryKind.Body.TWIN,golem=kind.body==BestiaryKind.Body.GOLEM;
        boolean robe=kind.body==BestiaryKind.Body.ROBED||kind.body==BestiaryKind.Body.GHOST,bones=kind.body==BestiaryKind.Body.SKELETON;
        int mat=kind.body==BestiaryKind.Body.ARMORED?METAL:golem||kind.family==BestiaryKind.Family.CONSTRUCT?STONE:kind.family==BestiaryKind.Family.FIEND?SCALES:HIDE;
        float width=giant||golem?14:9,arm=giant||golem?6:3.5F;
        var torso=root.node("body",0,0,0,r(giant?8:0),0,0);
        if(bones){torso.box(-1,0,-1,2,12,2,BONE,IVORY);for(int i=0;i<4;i++)torso.box(-4,i*2.5F,-2,8,1,4,BONE,IVORY);}
        else torso.chamfer(-width/2,0,-3.5F,width,12,7,1.2F,robe?CLOTH:mat,robe?dark():skin());
        if(!bones&&!robe){torso.chamfer(-width/2-.3F,1,-4,width+.6F,6,1,.25F,METAL,golem?light():armor());torso.box(-width/2-.2F,10,-3.8F,width+.4F,2,7.6F,LEATHER,0x5B3826);torso.box(-1,10,-4.3F,2,2,1,METAL,0xD9B662);}
        if(robe){torso.box(-5,8,-4,10,14,8,CLOTH,dark());for(int i=0;i<3;i++)torso.box(-4+i*3.2F,9,-4.2F,1,12,.4F,METAL,light());}
        if(kind.body==BestiaryKind.Body.TWIN){humanoidHead("head",-5,-1,0,mat);humanoidHead("head2",5,-1,0,mat);}else humanoidHead("head",0,0,0,mat);
        for(int side:new int[]{-1,1}){
            var a=root.node(side<0?"armL":"armR",side*(width/2+arm/2),2,0,r(-7),0,r(side*-7));a.box(-arm/2,-1,-arm/2,arm,8,arm,bones?BONE:robe?CLOTH:mat,bones?IVORY:robe?dark():skin());
            a.node("forearm"+side,0,6,0,r(-12),0,0).chamfer(-arm/2,0,-arm/2,arm,6,arm,.5F,bones?BONE:side<0?METAL:LEATHER,bones?IVORY:side<0?armor():0x674A3B);
            a.box(-arm/2,11,-arm/2,arm,3,arm,bones?BONE:mat,bones?IVORY:skin());
            if(!robe&&!bones&&(side<0||kind.boss||golem||kind.body==BestiaryKind.Body.ARMORED))a.node("pauldron"+side,0,-1,0,0,0,r(side*12)).chamfer(-arm/2-1,-2,-arm/2-1,arm+2,4,arm+2,.8F,METAL,golem?light():armor());
            if(kind.body!=BestiaryKind.Body.GHOST){var leg=root.node("leg"+(side<0?0:1),side*width*.25F,12,0);leg.box(-2,0,-2,4,10,4,bones?BONE:MAIL,bones?IVORY:dark());leg.box(-2.2F,8,-3.5F,4.4F,4,6,bones?BONE:METAL,bones?IVORY:0x626B7B);}
        }
        if(kind.body==BestiaryKind.Body.WINGED||kind.body==BestiaryKind.Body.BIRD){wing(root,"wingL",-1,.65F,kind.family==BestiaryKind.Family.CELESTIAL||kind.body==BestiaryKind.Body.BIRD);wing(root,"wingR",1,.65F,kind.family==BestiaryKind.Family.CELESTIAL||kind.body==BestiaryKind.Body.BIRD);}
        if(golem){root.node("core",0,5,-4.4F,0,0,r(45)).box(-2,-2,-.5F,4,4,1,HORN,0x62EDDF,true);for(int i=0;i<4;i++)root.node("rune"+i,0,4+i*2.3F,-4.6F,0,0,r(45)).box(-.4F,-.4F,-.2F,.8F,.8F,.4F,HORN,0x7EFFE0,true);}
        else if(kind.body!=BestiaryKind.Body.GHOST&&kind.body!=BestiaryKind.Body.BIRD)weapon(robe);
    }
    private void humanoidHead(String name,float x,float y,float z,int mat){
        boolean skull=kind.body==BestiaryKind.Body.SKELETON||kind==BestiaryKind.LICH;
        var h=root.node(name,x,y,z);h.chamfer(-3.6F,-7,-3.6F,7.2F,7,7.2F,1.1F,skull?BONE:mat,skull?IVORY:kind==BestiaryKind.VAMPIRE?0xD8CCC3:skin());
        if(kind.body==BestiaryKind.Body.ROBED||kind.body==BestiaryKind.Body.GHOST){h.box(-4.7F,-8.5F,-4.3F,9.4F,2,9,CLOTH,dark());for(int side:new int[]{-1,1})h.box(side<0?-4.7F:3.7F,-7,-4.4F,1,9,9,CLOTH,dark());h.box(-4,-7,3,8,9,1.5F,CLOTH,dark());}
        for(int side:new int[]{-1,1}){eye(h,name+"Eye"+side,side*1.9F,-4,-3.9F,kind==BestiaryKind.VAMPIRE?0xFF415E:kind.family==BestiaryKind.Family.UNDEAD?0x68FFEC:0xE8DD74,false);
            if(kind.family==BestiaryKind.Family.FIEND)horn(h,name+"Horn"+side,side*3,-7,0,side);
            if(kind==BestiaryKind.ORC||kind.body==BestiaryKind.Body.GIANT)h.node("tusk"+side,side*2.3F,0,-4,r(10),0,0).box(-.5F,-2.8F,-.5F,1,3,1,HORN,IVORY);
            if(kind.body==BestiaryKind.Body.SMALL)h.node("ear"+side,side*3.5F,-3,0,0,0,r(side*-25)).box(side<0?-4:0,-1,-1,4,2,2,HIDE,skin());}
        if(skull){h.box(-.6F,-2.5F,-3.9F,1.2F,1.5F,.7F,LEATHER,DARK);for(int i=0;i<5;i++)h.box(-2.5F+i,-1,-3.8F,.65F,1.5F,.5F,BONE,IVORY);}
        else h.box(-1,-2.8F,-5,2,3,2,HIDE,dark());
        for(int side:new int[]{-1,1}){
            h.node(name+"CheekGuard"+side,side*2.8F,-2.4F,-3.4F,0,r(side*15),r(side*10)).chamfer(-.8F,-1,-.7F,1.6F,2.5F,1.4F,.3F,skull?BONE:mat,skull?IVORY:dark());
            h.node(name+"BrowRidge"+side,side*1.9F,-5.1F,-3.9F,0,0,r(side*-14)).box(-1.25F,-.4F,-.2F,2.5F,.8F,.8F,skull?BONE:mat,skull?IVORY:dark());
        }
        if(kind.body==BestiaryKind.Body.BIRD){h.box(-2,-3,-8,4,3,5,HORN,0xD7AE4D);h.node("crest",0,-7,0,r(20),0,0).box(-1,-4,-2,2,4,5,FEATHER,0xB63A38);}
        if(kind==BestiaryKind.LICH||kind==BestiaryKind.SOLAR){h.box(-4,-7,-4,8,1.3F,8,METAL,0xDDB968);for(int side:new int[]{-1,1})h.node("crown"+side,side*3,-7,-3,0,0,r(side*12)).box(-.6F,-3,-.6F,1.2F,3,1.2F,METAL,0xE8C274);}
    }
    private void weapon(boolean staff){
        // The weapon is attached to the hand, so winding up moves the entire grip consistently.
        var arm=root.children.stream().filter(n->n.name.equals("armL")).findFirst().orElseThrow();var w=arm.node("weapon",0,staff?10:12,-1,r(staff?0:85),0,0);
        w.box(-.7F,-12,-.7F,1.4F,24,1.4F,WOOD,0x855D3B);
        if(staff){w.node("crystal",0,-14,0,r(20),r(45),r(45)).box(-2,-2,-2,4,4,4,HORN,light(),true);w.box(-3,-12,-1.2F,6,1.5F,2.4F,METAL,0xD3B579);}
        else if(kind.body==BestiaryKind.Body.GIANT){w.chamfer(-3.5F,-13,-3.5F,7,10,7,1.3F,WOOD,0x8F6747);for(int i=0;i<3;i++)w.box(-3.8F,-12+i*3.2F,-3.8F,7.6F,1.2F,7.6F,METAL,armor());for(int side:new int[]{-1,1})w.node("clubSpike"+side,side*3,-10,0,0,0,r(side*90)).taper(4,1,.05F,METAL,IRON);}
        else if(kind==BestiaryKind.ORC||kind==BestiaryKind.GOBLIN){w.chamfer(-.9F,-14,-1,1.8F,9,2,.4F,METAL,armor());w.node("axeHead",2,-11,0,0,0,r(-18)).chamfer(-1,-4,-1,6,8,2,.7F,METAL,IRON);w.node("axeEdge",6,-11,0).taper(5,.8F,.05F,METAL,IVORY);}
        else {w.box(-2,-15,-.8F,4,14,1.6F,METAL,IRON);w.box(-4,-1,-1,8,1.5F,2,METAL,0xC5A65B);}
    }
    private Node find(String name){var map=new java.util.HashMap<String,Node>();root.collect(map);return map.get(name);}
    private void decorate(){
        Node h=find("head"),body=find("body");
        if(kind.family==BestiaryKind.Family.DRAGON&&h!=null){
            // Element-specific crest silhouette in addition to species palette.
            switch(kind){
                case BLUE_DRAGON->h.node("stormHorn",0,-6,-4,r(35),0,0).taper(11,1.5F,.05F,HORN,0xC1EFFF);
                case WHITE_DRAGON->{for(int i=-2;i<=2;i++)h.node("iceCrown"+i,i*2,-6,2,r(-20),0,r(i*13)).taper(6-Math.abs(i),1,.05F,HORN,0xD6F8FF);}
                case GREEN_DRAGON,BRONZE_DRAGON,BRASS_DRAGON->{for(int side:new int[]{-1,1}){var f=h.node("frill"+side,side*4,-3,4);f.triangle(new float[]{0,0,0},new float[]{side*8,-6,8},new float[]{side*7,5,8},MEMBRANE,light());beam(f,"ridge"+side,new float[]{0,0,0},new float[]{side*8,-6,8},.7F,HORN,IVORY);}}
                case BLACK_DRAGON->{for(int side:new int[]{-1,1}){horn(h,"ramHorn"+side,side*5,-3,1,side*2);h.node("acidSac"+side,side*4,2,0).chamfer(-1.5F,0,-2,3,3,4,.7F,HIDE,0x6E9D44);}}
                case GOLD_DRAGON->{for(int side:new int[]{-1,1}){var a=h.node("antler"+side,side*4,-6,2,r(-20),0,r(side*20));a.taper(9,1,.1F,HORN,IVORY);for(int j=0;j<3;j++)a.node("branch"+side+j,0,-3-j*2,0,0,0,r(side*50)).taper(4,.6F,.05F,HORN,IVORY);beam(h,"whisker"+side,new float[]{side*3,-1,-9},new float[]{side*8,1,-5},.35F,HORN,IVORY);}}
                case SILVER_DRAGON->{for(int side:new int[]{-1,1})for(int j=0;j<4;j++)h.node("featherFrill"+side+j,side*4,-4+j,2,0,r(side*-30),r(side*25)).taper(5+j,1,.1F,FEATHER,0xEAF5FF);}
                case COPPER_DRAGON->{for(int side:new int[]{-1,1})beam(h,"copperWhisker"+side,new float[]{side*3,0,-9},new float[]{side*9,3,-3},.65F,HORN,IVORY);}
                default->{}
            }
        }
        if(kind.body==BestiaryKind.Body.GIANT){
            var arm=find("armR");if(arm!=null)for(int i=0;i<3;i++)arm.node("shoulderSpike"+i,i-1,-2,0,0,0,r(i*18-18)).taper(4,1,.05F,HORN,IVORY);
            if(kind==BestiaryKind.TROLL&&body!=null)for(int i=0;i<6;i++)body.node("moss"+i,(i%3-1)*4,i/3*5,4).chamfer(-2,0,-1,4,3,2,.6F,SHAG,0x637839);
        }
        if(kind==BestiaryKind.VAMPIRE&&body!=null){for(int side:new int[]{-1,1})body.node("cape"+side,side*3,1,4,r(8),r(side*8),0).box(-3,0,0,6,19,.7F,CLOTH,0x7F1E38);}
        if(kind.body==BestiaryKind.Body.GHOST&&body!=null)for(int i=0;i<5;i++)body.node("veil"+i,(i-2)*2,16,3,r(i*8),0,0).taper(-8,.8F,.15F,CLOTH,light());
        if(kind==BestiaryKind.KOBOLD&&h!=null){h.chamfer(-2.5F,-3,-7,5,3,4,.6F,SCALES,skin());root.node("tail",0,13,3,r(-15),r(20),0).box(-1,-1,0,2,2,12,SCALES,skin());}
        if(kind==BestiaryKind.GOBLIN){var a=find("armR");if(a!=null)a.node("scrapShield",0,8,-2).chamfer(-3,-3,-1,6,9,2,1.1F,WOOD,0x89633F);}
        if(kind.body==BestiaryKind.Body.GOLEM&&body!=null){for(int side:new int[]{-1,1})body.node("floatingPlate"+side,side*6,0,1,r(12),0,r(side*15)).chamfer(-2,-3,-2,4,6,4,1,STONE,light());}
        if(kind.body==BestiaryKind.Body.ELEMENTAL){for(int i=0;i<4;i++)root.node("shardHalo"+i,0,3,0,0,r(i*90),0).node("haloTip"+i,6,0,0,r(35),0,0).taper(5,1,.05F,STONE,light());}
    }
    private void naturalDetails(){
        var head=find("head");var body=find("body");
        if(kind.body==BestiaryKind.Body.BEAR){
            var shoulder=find("shoulder");if(shoulder!=null)shoulder.chamfer(-6,-8,-5,12,8,12,2,SHAG,skin());
            for(int side:new int[]{-1,1})for(int i=0;i<5;i++){var tuft=root.node("bearRuff"+side+i,side*(5+i%2),8+i*2,-8+i,r(15),r(side*10),r(side*-25));tuft.taper(-4,1.8F,.1F,SHAG,dark());}
            if(head!=null){head.chamfer(-4.3F,-2,-7,8.6F,6,5,1.5F,SHAG,skin());for(int side:new int[]{-1,1})head.node("bearCanine"+side,side*2,-.2F,-8,r(180),0,0).taper(3,.65F,.05F,HORN,IVORY);}
        }
        if(kind.body==BestiaryKind.Body.WOLF){
            for(int i=0;i<7;i++)root.node("wolfMane"+i,0,7+i*.4F,-9+i*2,r(-20),0,r(i%2==0?-12:12)).taper(4,1.6F,.05F,FUR,dark());
            if(head!=null)for(int side:new int[]{-1,1}){head.node("wolfEarTip"+side,side*3,-7,0,r(-10),0,r(side*-10)).taper(4,1.1F,.05F,FUR,dark());head.node("wolfCheek"+side,side*3,0,1,r(-12),0,r(side*45)).taper(-4,1.3F,.05F,FUR,light());}
        }
        if(kind.body==BestiaryKind.Body.SPIDER&&body!=null)for(int i=0;i<5;i++)body.node("venomMark"+i,(i%3-1)*2.5F,-4.1F,1+i*1.8F,0,0,r(45)).box(-.6F,-.2F,-.6F,1.2F,.4F,1.2F,HORN,0xEF483C,true);
        if(kind==BestiaryKind.VAMPIRE&&head!=null){head.chamfer(-4,-8,-3.5F,8,2.5F,7,1,CLOTH,0x26222E);for(int side:new int[]{-1,1}){head.node("vampireFang"+side,side*1.2F,-.8F,-4.4F,r(180),0,0).taper(1.8F,.35F,.03F,BONE,IVORY);head.node("vampireCollar"+side,side*4,1,2,r(-25),0,r(side*-45)).taper(7,1.4F,.1F,CLOTH,0x751B35);}}
        if(kind==BestiaryKind.CORRUPT_GUARD&&head!=null){head.chamfer(-4.2F,-8,-4.2F,8.4F,2.5F,8.4F,1,METAL,0x697A70);head.node("brokenVisor",3,-6,-4.1F,0,0,r(-15)).box(-.8F,-1,-.5F,1.6F,4,1,METAL,0x92754B);}
        if(kind==BestiaryKind.TROLL&&body!=null)for(int i=0;i<8;i++)body.node("hangingMoss"+i,(i%4-1.5F)*3,7,4,r(i*5),0,0).taper(-7-i%3,1,.1F,SHAG,0x647B38);
        if(kind.family==BestiaryKind.Family.DRAGON&&head!=null){for(int side:new int[]{-1,1}){head.node("jawSpine"+side,side*5,1,2,r(-30),0,r(side*40)).taper(4,1,.05F,HORN,IVORY);if(kind==BestiaryKind.RED_DRAGON)for(int i=0;i<3;i++)head.node("redCrown"+side+i,side*(2+i),-6,3+i,r(-35-i*10),0,r(side*20)).taper(7-i,1,.05F,HORN,IVORY);}}
    }
    @Override public void setupAnim(BestiaryMob m,float swing,float amount,float age,float yaw,float pitch){
        root.reset();float progress=m.progress(age-m.tickCount);boolean prep=m.phase()==BestiaryMob.HEAVY||m.phase()==BestiaryMob.QUICK;
        float eased=progress*progress*(3-2*progress);
        float lift=prep?eased:m.phase()==BestiaryMob.ACTIVE?1-1.28F*Math.min(1,progress*3):m.phase()==BestiaryMob.RECOVERY?-.28F*(1-eased):0;
        boolean insect=kind.body==BestiaryKind.Body.ANT||kind.body==BestiaryKind.Body.SPIDER||kind.body==BestiaryKind.Body.INSECT;
        boolean dragon=kind.body==BestiaryKind.Body.DRAGON||kind.body==BestiaryKind.Body.HYDRA||kind.body==BestiaryKind.Body.WYVERN;
        float airborne=dragon?m.flightBlend(age-m.tickCount):0,flap=age*.22F,beat=(float)(Math.sin(flap)+.22*Math.sin(flap*2)),descent=(float)Math.clamp(-m.getDeltaMovement().y*3,0,1);
        if(dragon){root.zRot+=m.flightBank(age-m.tickCount);root.xRot+=airborne*(float)Math.clamp(-m.getDeltaMovement().y*.65,-.18,.18);root.dy+=airborne*(float)Math.sin(flap-1)*.45F;if(m.onGround())root.dy+=airborne*(float)Math.sin(airborne*Math.PI)*1.3F;}
        for(var e:bones.entrySet()){
            String n=e.getKey();var b=e.getValue();
            if(n.length()==4&&n.startsWith("leg")&&n.charAt(3)>='0'&&n.charAt(3)<='7'){int i=n.charAt(3)-'0';float cycle=swing*(insect?1:.65F)+(insect?i*1.3F:(i%2)*3.14159F+(i>=2?3.14159F:0));b.xRot+=(float)Math.cos(cycle)*amount*.6F;b.dy-=Math.max(0,(float)Math.sin(cycle))*amount*1.4F;if(insect)b.yRot+=(float)Math.sin(cycle)*amount*.25F;}
            if(n.equals("head")||n.equals("head2")||n.equals("head3")){b.yRot+=r(Math.clamp(yaw,-28,28));b.xRot+=r(pitch)*.35F-(prep?eased*.4F:0)+(float)Math.sin(age*.06+n.length())*.025F;if(m.phase()==BestiaryMob.ACTIVE)b.dz=-3*(1-eased);}
            if(n.endsWith("Jaw"))b.xRot+=(prep?eased*.85F:(float)Math.sin(age*.07)*.055F)+(m.phase()==BestiaryMob.ACTIVE?.4F*(1-eased):0);
            if(n.equals("armL")||n.equals("armR")){b.xRot-=lift*(n.equals("armL")?2.3F:1.15F);if(!prep&&m.phase()==BestiaryMob.IDLE)b.xRot+=(float)Math.cos(swing*.65+(n.endsWith("L")?0:3.14))*amount*.3F;}
            if(n.equals("wingL")||n.equals("wingR")){float side=n.endsWith("L")?1:-1;b.zRot+=side*((float)Math.sin(age*.07)*.10F*(1-airborne)+beat*.55F*airborne+(prep?eased*.45F:0));b.yRot+=side*(prep?-.12F:dragon?.45F*(1-airborne)+.06F*airborne:.2F);b.xRot+=airborne*(float)Math.sin(flap-.5)*.09F;}
            if(dragon&&n.contains("wing")&&(n.endsWith("Forearm")||n.contains("Finger")))b.xRot+=airborne*(float)Math.sin(flap-.65)*.12F;
            if(dragon&&n.startsWith("leg")){b.xRot+=airborne*(1-descent)*(n.endsWith("0")||n.endsWith("1")?.7F:1.1F);b.dy-=airborne*(1-descent)*1.5F;}
            if(dragon&&n.startsWith("foot"))b.xRot-=airborne*(1-descent)*.5F;

            if(dragon&&n.startsWith("tail")){b.xRot+=airborne*(float)Math.sin(flap*.5-(n.equals("tail3")?1.2:n.equals("tail2")?.6:0))*.13F;b.yRot+=r(Math.clamp(m.headingLag(n.equals("tail3")?12:n.equals("tail2")?8:4),-35,35))*.32F;}
            if(n.startsWith("tail"))b.yRot+=(float)Math.sin(age*.065-(n.equals("tail3")?1.2:n.equals("tail2")?.6:0))*(.14F+amount*.12F);
            if(n.startsWith("orbit")||n.startsWith("shardHalo"))b.yRot+=age*(n.startsWith("orbit")?.025F:-.018F);
            if(n.startsWith("floatingPlate"))b.dy+=(float)Math.sin(age*.08+b.px)*1.1F;
            if(n.startsWith("cape")||n.startsWith("veil"))b.xRot+=(float)Math.sin(age*.07+b.px)*.10F+amount*.1F;
            if(n.equals("body")){b.sy*=1+(float)Math.sin(age*.08)*.013F;b.xRot+=prep&&dragon?eased*-.06F:0;if(!dragon&&!insect)b.yRot+=prep?eased*.2F:m.phase()==BestiaryMob.ACTIVE?.2F-.45F*Math.min(1,progress*3):m.phase()==BestiaryMob.RECOVERY?-.25F*(1-eased):0;}
        }
        if(prep&&kind.body==BestiaryKind.Body.BEAR)for(String n:new String[]{"leg0","leg1"})bones.get(n).xRot-=eased*1.2F;
        if(m.phase()==BestiaryMob.STAGGER){root.zRot=(float)Math.sin(age*1.1)*.06F;root.xRot=.16F;}
        else if(m.hurtTime>0)root.zRot=(float)Math.sin((m.hurtTime/10F)*Math.PI)*.075F;
        if(kind.body==BestiaryKind.Body.ELEMENTAL||kind.body==BestiaryKind.Body.GHOST)root.dy=(float)Math.sin(age*.085)*2;
        if(kind.body==BestiaryKind.Body.GHOST)root.alpha=.68F+(float)Math.sin(age*.05)*.08F;
        AwakenedAnatomy.pose(m,root,bones,swing,amount,age);
    }
    @Override public void renderToBuffer(PoseStack p,VertexConsumer v,int light,int overlay,int color){root.render(p,v,light,overlay,((color>>>24)&255)/255F);}
}
