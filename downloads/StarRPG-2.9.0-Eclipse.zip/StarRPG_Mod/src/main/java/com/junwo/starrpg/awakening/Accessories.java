package com.junwo.starrpg.awakening;

import com.junwo.starrpg.*;
import com.junwo.starrpg.adventure.*;
import java.util.*;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.item.component.CustomData;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;

@EventBusSubscriber(modid=StarRPG.MODID)
public final class Accessories {
    public static ItemStack equipped(Player p,int slot){var tag=AwakeningData.profile(p).getList("accessories",Tag.TAG_COMPOUND);return slot>=0&&slot<tag.size()?ItemStack.parseOptional(p.registryAccess(),tag.getCompound(slot)):ItemStack.EMPTY;}
    public static int level(ItemStack stack){return Math.clamp(stack.getOrDefault(DataComponents.CUSTOM_DATA,CustomData.EMPTY).copyTag().getInt("starrpg_accessory_level"),0,10);}
    public static int parryTicks(Player p){var charm=equipped(p,2);return charm.isEmpty()?0:1+(level(charm)>=5?1:0);}
    public static float elementPower(Player p){var item=equipped(p,1);return item.isEmpty()?1:1.03F+level(item)*.003F;}
    public static int mana(Player p){var item=equipped(p,1);return item.isEmpty()?0:6+level(item);}
    public static SimpleContainer inventory(Player p){ItemStack[] initial={equipped(p,0),equipped(p,1),equipped(p,2)};return new SimpleContainer(3){
        private boolean loading=true;
        {for(int i=0;i<3;i++)setItem(i,initial[i]);loading=false;}
        @Override public void setChanged(){if(loading||p.level().isClientSide())return;var list=new ListTag();for(int i=0;i<3;i++)list.add(getItem(i).saveOptional(p.registryAccess()));AwakeningData.profile(p).put("accessories",list);AwakeningData.get(p.getServer()).setDirty();}
    };}
    private static List<Item> outputs(){return List.of(AwakeningItems.RING.get(),AwakeningItems.NECKLACE.get(),AwakeningItems.CHARM.get(),AwakeningItems.LICH_RING.get(),AwakeningItems.DRAGON_NECKLACE.get(),AwakeningItems.GOLEM_CHARM.get());}
    public static boolean craft(Player p,int recipe){if(p.level().isClientSide()||recipe<0||recipe>=6)return false;var output=new ItemStack(outputs().get(recipe));Item material=recipe>=3?switch(recipe){case 3->AdventureItems.LICH.get();case 4->AdventureItems.DRAGON.get();default->AdventureItems.GOLEM.get();}:recipe==2?Items.IRON_INGOT:Items.GOLD_INGOT;int needed=recipe>=3?1:4,essence=recipe>=3?8:3;if(!Economy.fits(p,output)||p.getInventory().countItem(material)<needed||p.getInventory().countItem(AwakeningItems.ESSENCE.get())<essence||p.getInventory().countItem(Items.AMETHYST_SHARD)<2)return false;LifeJobs.consume(p,material,needed);LifeJobs.consume(p,AwakeningItems.ESSENCE.get(),essence);LifeJobs.consume(p,Items.AMETHYST_SHARD,2);LifeJobs.give(p,output);return true;}
    public static boolean upgrade(Player p,SimpleContainer inventory,int slot){if(slot<0||slot>2)return false;var stack=inventory.getItem(slot);if(!(stack.getItem() instanceof AwakeningItems.AccessoryItem))return false;int rank=level(stack);if(rank>=10||p.getInventory().countItem(AwakeningItems.ESSENCE.get())<rank+2||StarWallet.get(p.getServer()).balance(p.getUUID())<100*(rank+1))return false;LifeJobs.consume(p,AwakeningItems.ESSENCE.get(),rank+2);StarWallet.get(p.getServer()).debit(p.getUUID(),100*(rank+1));if(p.getRandom().nextFloat()<.9F-rank*.05F){var tag=stack.getOrDefault(DataComponents.CUSTOM_DATA,CustomData.EMPTY).copyTag();tag.putInt("starrpg_accessory_level",rank+1);stack.set(DataComponents.CUSTOM_DATA,CustomData.of(tag));}inventory.setChanged();return true;}
    private static void attribute(Player p,net.minecraft.core.Holder<Attribute> attribute,String key,double amount,AttributeModifier.Operation operation){var value=p.getAttribute(attribute);if(value==null)return;var id=ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,key);if(amount==0)value.removeModifier(id);else value.addOrUpdateTransientModifier(new AttributeModifier(id,amount,operation));}
    @SubscribeEvent public static void tick(net.neoforged.neoforge.event.tick.PlayerTickEvent.Post e){var p=e.getEntity();if(p.level().isClientSide()||p.tickCount%20!=0)return;var ring=equipped(p,0);attribute(p,Attributes.ATTACK_DAMAGE,"accessory_ring",ring.isEmpty()?0:.03+level(ring)*.003,AttributeModifier.Operation.ADD_MULTIPLIED_BASE);var charm=equipped(p,2);attribute(p,Attributes.ARMOR,"accessory_guard",charm.is(AwakeningItems.GOLEM_CHARM.get())?1+level(charm)*.15:0,AttributeModifier.Operation.ADD_VALUE);}
    @SubscribeEvent public static void power(net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent e){if(e.getEntity().level().isClientSide())return;if(e.getSource().getEntity() instanceof Player p&&e.getSource().is(MagicSystem.MAGIC_DAMAGE))e.setAmount(e.getAmount()*elementPower(p));if(e.getEntity() instanceof Player p&&equipped(p,1).is(AwakeningItems.DRAGON_NECKLACE.get())&&e.getSource().is(net.minecraft.tags.DamageTypeTags.IS_FIRE))e.setAmount(e.getAmount()*.9F);}
    @SubscribeEvent public static void heal(net.neoforged.neoforge.event.entity.living.LivingDamageEvent.Post e){if(e.getEntity().level().isClientSide()||e.getNewDamage()<=0||!(e.getSource().getEntity() instanceof Player p)||!SkillTrees.attack(e.getSource())||!equipped(p,0).is(AwakeningItems.LICH_RING.get())||p.getPersistentData().getLong("accessory_leech")>p.level().getGameTime())return;p.getPersistentData().putLong("accessory_leech",p.level().getGameTime()+20);p.heal(Math.min(1,e.getNewDamage()*.03F));}
}
