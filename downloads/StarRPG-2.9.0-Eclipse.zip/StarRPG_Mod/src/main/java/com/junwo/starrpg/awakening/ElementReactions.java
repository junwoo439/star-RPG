package com.junwo.starrpg.awakening;

import com.junwo.starrpg.*;
import com.junwo.starrpg.CombatRules;
import java.util.*;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.*;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.*;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;

@EventBusSubscriber(modid=StarRPG.MODID)
public final class ElementReactions {
    public enum Element {NONE,FIRE,WATER,ICE,EARTH,DARK,LIGHT,LIGHTNING,WIND}
    public static final ResourceKey<DamageType> DAMAGE=ResourceKey.create(Registries.DAMAGE_TYPE,ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,"element_reaction"));
    public static void mark(LivingEntity target,Element element,int ticks){if(element==Element.NONE)return;target.getPersistentData().putLong("aw_element_"+element.name(),target.level().getGameTime()+ticks);}
    public static boolean marked(LivingEntity target,Element element){return target.getPersistentData().getLong("aw_element_"+element.name())>target.level().getGameTime();}
    private static void consume(LivingEntity target,Element element){target.getPersistentData().remove("aw_element_"+element.name());}
    private static void damage(Player source,LivingEntity target,float amount){if(!CombatRules.canHarm(source,target))return;target.hurt(new DamageSource(source.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DAMAGE),source),amount);}
    public static void apply(Player source,LivingEntity target,Element incoming,float hit){
        if(!(target.level() instanceof ServerLevel level)||!(target.isAlive()?CombatRules.canHarm(source,target):CombatRules.canHarmDead(source,target))||hit<=0)return;long now=level.getGameTime();boolean ready=target.getPersistentData().getLong("aw_reaction_ready")<=now;int reaction=0;
        if(ready){boolean wet=marked(target,Element.WATER)||target.isInWaterOrRain();
            if(wet&&incoming==Element.LIGHTNING){reaction=57;consume(target,Element.WATER);if(target.getPersistentData().getLong("starrpg_heavy_stun_guard")<=now){target.addEffect(new MobEffectInstance(ModEffects.STUN,target instanceof Player?2:6));target.getPersistentData().putLong("starrpg_heavy_stun_guard",now+100);}int hits=0;for(var other:level.getEntitiesOfClass(LivingEntity.class,target.getBoundingBox().inflate(4),t->t!=target&&CombatRules.canHarm(source,t)&&source.hasLineOfSight(t))){if(++hits>3)break;damage(source,other,Math.min(6,hit*.25F));ArcaneSigil.spawn(level,other.position().add(0,.7,0),target.position().subtract(other.position()),55,0x8AE9FF,2,12);}}
            else if(wet&&incoming==Element.ICE){reaction=58;consume(target,Element.WATER);mark(target,Element.ICE,80);target.addEffect(new MobEffectInstance(ModEffects.ROOT,target instanceof Player?6:20));}
            else if(marked(target,Element.FIRE)&&incoming==Element.WIND){reaction=59;consume(target,Element.FIRE);int hits=0;for(var other:level.getEntitiesOfClass(LivingEntity.class,target.getBoundingBox().inflate(3),t->t!=target&&CombatRules.canHarm(source,t)&&source.hasLineOfSight(t))){if(++hits>3)break;other.igniteForSeconds(3);mark(other,Element.FIRE,60);damage(source,other,Math.min(4,hit*.15F));}}
            if(reaction!=0){target.getPersistentData().putLong("aw_reaction_ready",now+30);ArcaneSigil.spawn(level,target.position().add(0,.1,0),Vec3.ZERO,reaction,incoming==Element.ICE?0xB5EFFF:incoming==Element.WIND?0xFFB168:0x77DAFF,2.5F,24);}
        }
        mark(target,incoming,80);
    }
    @SubscribeEvent public static void shatter(net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent e){if(e.isCanceled()||e.getEntity().level().isClientSide()||!(e.getSource().getEntity() instanceof Player p)||!CombatRules.primary(e.getSource())||!CombatRules.charged(e.getSource())||!CombatRules.canHarm(p,e.getEntity())||!marked(e.getEntity(),Element.ICE)||e.getEntity().getPersistentData().getLong("aw_shatter_ready")>e.getEntity().level().getGameTime())return;consume(e.getEntity(),Element.ICE);e.getEntity().getPersistentData().putLong("aw_shatter_ready",e.getEntity().level().getGameTime()+30);e.getEntity().removeEffect(ModEffects.ROOT);e.setAmount(e.getAmount()+Math.min(e.getEntity() instanceof Player?4:12,e.getAmount()*(e.getEntity() instanceof Player?.15F:.35F)));ArcaneSigil.spawn((ServerLevel)e.getEntity().level(),e.getEntity().position(),p.getLookAngle(),58,0xD2F6FF,2,20);}
    @SubscribeEvent public static void hit(net.neoforged.neoforge.event.entity.living.LivingDamageEvent.Post e){if(e.getEntity().level().isClientSide()||e.getNewDamage()<=0||e.getSource().is(DAMAGE)||!(e.getSource().getEntity() instanceof Player p))return;Element element=Element.NONE;
        if(e.getSource().is(MagicSystem.MAGIC_DAMAGE)){int school=e.getSource().getDirectEntity() instanceof MagicBolt bolt?bolt.school():MagicSchools.school(p);if(school>=1&&school<=6)element=Element.values()[school];}
        else if(e.getSource().getDirectEntity() instanceof AbstractArrow arrow&&arrow.getWeaponItem()!=null){var bow=BowElements.get(arrow.getWeaponItem());if(bow!=null)element=switch(bow){case ICE->Element.ICE;case LIGHTNING->Element.LIGHTNING;case DARK->Element.DARK;case LIGHT->Element.LIGHT;};}
        else if(CombatRules.primary(e.getSource())){if(p.getMainHandItem().getItem() instanceof WarHammerItem&&CombatRules.charged(e.getSource()))element=Element.WIND;var rune=RuneDataHelper.getRuneEffect(p.getMainHandItem());if(rune!=null){String name=rune.name();if(name.contains("WIND")||name.contains("GALE")||name.contains("STORM"))element=Element.WIND;else if(name.contains("FLAME")||name.contains("FIRE"))element=Element.FIRE;}}
        apply(p,e.getEntity(),element,e.getNewDamage());
    }
}
