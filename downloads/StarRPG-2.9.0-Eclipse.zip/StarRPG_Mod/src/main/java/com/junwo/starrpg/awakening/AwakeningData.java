package com.junwo.starrpg.awakening;

import java.util.*;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.saveddata.SavedData;

/** Separate, additive save file. No 2.8 career, item, dungeon or journal schema is replaced. */
public final class AwakeningData extends SavedData {
    public final Map<UUID,CompoundTag> players=new HashMap<>();
    public CompoundTag world=new CompoundTag();
    public static AwakeningData get(MinecraftServer server){return server.overworld().getDataStorage().computeIfAbsent(new Factory<>(AwakeningData::new,AwakeningData::load),"starrpg_awakening");}
    public static CompoundTag profile(Player p){return get(p.getServer()).players.computeIfAbsent(p.getUUID(),id->new CompoundTag());}
    public static CompoundTag section(CompoundTag root,String key){if(!root.contains(key,Tag.TAG_COMPOUND))root.put(key,new CompoundTag());return root.getCompound(key);}
    public static int number(Player p,String key){return Math.max(0,profile(p).getInt(key));}
    public static void set(Player p,String key,int value){profile(p).putInt(key,Math.max(0,value));get(p.getServer()).setDirty();}
    public static void add(Player p,String key,int value){set(p,key,(int)Math.clamp((long)number(p,key)+value,0,Integer.MAX_VALUE));}
    public static AwakeningData load(CompoundTag root,HolderLookup.Provider lookup){var out=new AwakeningData();out.world=root.getCompound("world").copy();for(var value:root.getList("players",Tag.TAG_COMPOUND)){var row=(CompoundTag)value;if(row.hasUUID("id"))out.players.put(row.getUUID("id"),row.getCompound("data").copy());}return out;}
    @Override public CompoundTag save(CompoundTag root,HolderLookup.Provider lookup){root.putInt("schema",1);root.put("world",world.copy());var list=new ListTag();players.forEach((id,data)->{var row=new CompoundTag();row.putUUID("id",id);row.put("data",data.copy());list.add(row);});root.put("players",list);return root;}
}
