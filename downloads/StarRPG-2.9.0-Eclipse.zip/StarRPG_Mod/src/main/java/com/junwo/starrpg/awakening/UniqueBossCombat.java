package com.junwo.starrpg.awakening;

import com.junwo.starrpg.*;
import com.junwo.starrpg.bestiary.*;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.effect.*;
import net.minecraft.world.phys.*;
import net.neoforged.bus.api.*;
import net.neoforged.fml.common.EventBusSubscriber;

/** Explicit tells, bounded casts and recovery; every hit is evaluated on the server after its tell. */
@EventBusSubscriber(modid=StarRPG.MODID)
public final class UniqueBossCombat {
    public static boolean supports(BestiaryMob m){return m.kind.boss&&m.kind.body!=BestiaryKind.Body.DRAGON;}
    public static boolean parryable(int skill){return switch(skill){case 5,6,7,8,12,13,17,22,81->true;default->false;};}
    public static String name(int skill){return switch(skill){case 1->"영혼 구슬";case 2,20->"마법 보호막";case 3->"영혼 파열";case 4->"맹독 분사";case 5->"히드라 물기";case 6->"머리 휩쓸기";case 7->"군주의 돌진";case 8->"연속 강타";case 9,14->"지면 충격";case 10->"석화 충격파";case 11->"석갑 강화";case 12->"핵의 강타";case 13->"야수왕 도약";case 15->"독충 군집";case 16->"부패의 늪";case 17->"쌍두 연격";case 18->"마족의 교차포";case 19->"태양의 심판";case 21->"폭풍 낙뢰";case 22->"거신의 바람";case 23->"별을 삼키는 파동";case 24->"균열의 기둥";case 80->"변이 폭발";case 81->"희귀 돌진";default->"공격";};}
    public static boolean start(BestiaryMob m,LivingEntity target,boolean heavy){if(!heavy||!supports(m))return false;var data=m.getPersistentData();int sequence=data.getInt("aw_boss_sequence");data.putInt("aw_boss_sequence",sequence+1);int skill;
        if(m.awakenedVariant()==3)skill=sequence%3==0?23:sequence%3==1?24:10;
        else skill=switch(m.kind){case LICH->1+sequence%3;case HYDRA->{int head=Math.floorMod(sequence,3);for(int i=0;i<3;i++)if((m.headMask()&(1<<head))==0)head=(head+1)%3;data.putInt("aw_attack_head",head);yield 4+head;}case OGRE_WARLORD->7+sequence%3;case ANCIENT_GOLEM->10+sequence%3;case ELDER_BEAR->13+sequence%2;case BEELZEBUB->15+sequence%2;case DEMOGORGON->17+sequence%2;case SOLAR->19+sequence%2;case STORM_GIANT->21+sequence%2;default->9;};
        begin(m,target,skill);return true;
    }
    public static void begin(BestiaryMob m,LivingEntity target,int skill){m.bossSkill(skill);m.heavyAttack=true;m.attackOrigin=m.position();m.attackPoint=target.position();m.attackDirection=target.position().subtract(m.position()).multiply(1,0,1).normalize();m.setYRot((float)Math.toDegrees(Math.atan2(-m.attackDirection.x,m.attackDirection.z)));m.yBodyRot=m.getYRot();int ticks=skill==23?60:skill==3||skill==9||skill==10||skill==19||skill==21||skill==24?42:skill==2||skill==11||skill==20?24:32;m.phase(BestiaryMob.HEAVY,ticks);m.getNavigation().stop();
        if(m.level() instanceof ServerLevel level){boolean point=skill==3||skill==16||skill==19||skill==21||skill==24;Vec3 at=point?m.attackPoint:m.attackOrigin;float radius=skill==23?9:point?3.5F:skill==80?3:6;ArcaneSigil.spawn(level,at.add(0,.08,0),m.attackDirection,skill==7||skill==81?37:38,parryable(skill)?0xFFD271:0xFF4555,radius,ticks);if((skill==19||skill==21||skill==24)&&BossPhases.stage(m)>0)for(int side:new int[]{-1,1})ArcaneSigil.spawn(level,m.attackPoint.add(side*4,.08,0),m.attackDirection,38,0xFF4555,2,ticks);}
    }
    public static boolean tick(BestiaryMob m){int skill=m.bossSkill();if(skill==0||m.phase()==BestiaryMob.IDLE||m.phase()==BestiaryMob.STAGGER)return false;if(!BestiaryCombat.valid(m,m.getTarget())||ControlEffects.stunned(m)||ControlEffects.rooted(m)){m.bossSkill(0);m.phase(BestiaryMob.RECOVERY,24);m.nextAttack=m.level().getGameTime()+36;return true;}
        m.getNavigation().stop();if(m.phase()!=BestiaryMob.ACTIVE||skill!=7&&skill!=13&&skill!=81)m.setDeltaMovement(0,m.getDeltaMovement().y,0);m.countdown(m.remaining()-1);
        if(m.phase()==BestiaryMob.HEAVY){if(m.remaining()==0){int duration=skill==1||skill==15?48:skill==8||skill==17||skill==10?30:skill==7||skill==13||skill==81?12:6;m.phase(BestiaryMob.ACTIVE,duration);release(m,skill,0);}return true;}
        if(m.phase()==BestiaryMob.ACTIVE){int elapsed=m.duration()-m.remaining();if(elapsed>0)release(m,skill,elapsed);if(m.phase()==BestiaryMob.STAGGER)return true;}
        if(m.remaining()==0){if(m.phase()==BestiaryMob.ACTIVE){m.phase(BestiaryMob.RECOVERY,skill==23?55:36);m.nextAttack=m.level().getGameTime()+m.duration()+12;}else{m.phase(BestiaryMob.IDLE,0);m.bossSkill(0);}}return true;
    }
    public static boolean damage(BestiaryMob owner,LivingEntity target,float multiplier,boolean parry,boolean stun){if(!BestiaryCombat.valid(owner,target)||!owner.hasLineOfSight(target))return false;float before=target.getHealth();owner.parryableImpact=parry;boolean hit;try{hit=target.hurt(owner.damageSources().mobAttack(owner),(float)owner.getAttributeValue(Attributes.ATTACK_DAMAGE)*multiplier);}finally{owner.parryableImpact=false;}if(hit&&target.getHealth()<before&&stun&&target.getPersistentData().getLong("starrpg_heavy_stun_guard")<=owner.level().getGameTime()){target.addEffect(new MobEffectInstance(ModEffects.STUN,owner.kind.boss?12:6));target.getPersistentData().putLong("starrpg_heavy_stun_guard",owner.level().getGameTime()+100);}return hit&&target.getHealth()<before;}
    private static void area(BestiaryMob m,Vec3 at,double range,float power,boolean parry,boolean stun,boolean rear){if(!(m.level() instanceof ServerLevel level))return;int hits=0;for(var target:level.getEntitiesOfClass(LivingEntity.class,new AABB(at,at).inflate(range,3,range),t->(t instanceof Player||t==m.getTarget())&&BestiaryCombat.valid(m,t))){if(target.position().distanceToSqr(at)>range*range||!m.hasLineOfSight(target)||rear&&target.position().subtract(m.position()).normalize().dot(m.attackDirection)>.4)continue;if(++hits>(m.awakenedVariant()==3?16:6))break;damage(m,target,power,parry,stun);if(m.phase()==BestiaryMob.STAGGER)break;}}
    private static void effect(BestiaryMob m,Vec3 point,int style,float radius,int life){if(m.level() instanceof ServerLevel l)ArcaneSigil.spawn(l,point.add(0,.08,0),m.attackDirection,style,m.kind.color,radius,life);}
    private static void release(BestiaryMob m,int skill,int elapsed){if(!(m.level() instanceof ServerLevel level))return;int phase=BossPhases.stage(m);Vec3 at=m.attackPoint;
        if((skill==1||skill==15)&&(elapsed==0||elapsed%12==0&&elapsed<=phase*12+24)){Vec3 from=m.position().add(0,m.getBbHeight()*.65,0);Vec3 aim=m.getTarget().getEyePosition().add(m.getTarget().getDeltaMovement().scale(3));BossSpell.launch(m,from,aim.subtract(from),skill==1?60:67,m.kind.color,.7F,false,.45F);}
        if(skill==8||skill==17){if(elapsed%10==0&&elapsed<20+phase*5){area(m,m.position().add(m.attackDirection.scale(1.2)),4,.75F,true,elapsed>=20,false);effect(m,m.position(),skill==17?68:18,3,12);}return;}
        if(skill==7||skill==13||skill==81){m.setDeltaMovement(m.attackDirection.scale(skill==81?.4:.55).add(0,skill==13&&elapsed==0?.35:m.getDeltaMovement().y,0));if(elapsed==5)area(m,m.position().add(m.attackDirection.scale(1)),4,skill==81?.8F:1.6F,true,true,false);return;}
        if(skill==10){if(elapsed==0||phase>=1&&elapsed==12)BossSpell.launch(m,m.position().add(0,.1,0),Vec3.ZERO,65,0x91BDB9,1.1F,true,7+phase);return;}
        if(elapsed!=0)return;
        switch(skill){
            case 2,20->{m.ward(Math.min(90,m.getMaxHealth()*.08F));m.getPersistentData().putLong("aw_ward_until",level.getGameTime()+100);effect(m,m.position().add(0,1,0),skill==2?61:69,2.5F,60);}
            case 3->{area(m,at,3.5+phase*.3,1.6F,false,true,false);effect(m,at,62,3.5F,32);}
            case 4->{Vec3 from=m.position().add((m.getPersistentData().getInt("aw_attack_head")-1)*1.2,2,0).add(m.attackDirection.scale(2));for(int i=-1;i<=1;i++)BossSpell.launch(m,from,at.add(0,1,0).subtract(from).yRot(i*.15F),63,0x93BC58,.65F,false,.5F);}
            case 5,6->{area(m,m.position().add(m.attackDirection.scale(1.2)),5,1.5F,true,true,skill==6);effect(m,m.position(),skill==5?19:18,4,20);}
            case 9,14->{BossSpell.launch(m,m.position().add(0,.1,0),Vec3.ZERO,64,m.kind.color,1.65F,true,6+phase);}
            case 11->{m.getPersistentData().putLong("aw_golem_armor",level.getGameTime()+100);effect(m,m.position(),66,2.5F,50);}
            case 12->{area(m,m.position().add(m.attackDirection.scale(1.5)),4,1.5F,true,true,false);effect(m,m.position(),21,4,24);}
            case 16->{area(m,at,3,.7F,false,false,false);effect(m,at,63,3,45);for(var target:level.getEntitiesOfClass(LivingEntity.class,new AABB(at,at).inflate(3),t->(t instanceof Player||t==m.getTarget())&&BestiaryCombat.valid(m,t)))target.addEffect(new MobEffectInstance(MobEffects.POISON,70,0));}
            case 18->{for(int side:new int[]{-1,1}){Vec3 origin=m.position().add(side*1.2,2.5,0);BossSpell.launch(m,origin,m.getTarget().getEyePosition().subtract(origin),68,0xC286B8,.9F,false,.6F);}}
            case 19,21,24->{int style=skill==19?69:skill==21?70:71;area(m,at,3.5F,1.6F,false,true,false);effect(m,at,style,3.5F,35);if(phase>0){effect(m,at.add(4,0,0),style,2,30);effect(m,at.add(-4,0,0),style,2,30);area(m,at.add(4,0,0),2,.6F,false,false,false);area(m,at.add(-4,0,0),2,.6F,false,false,false);}}
            case 22->{area(m,m.position(),6,1,true,false,false);for(var target:level.getEntitiesOfClass(LivingEntity.class,m.getBoundingBox().inflate(6),t->(t instanceof Player||t==m.getTarget())&&BestiaryCombat.valid(m,t)&&m.hasLineOfSight(t))){target.knockback(.8,m.getX()-target.getX(),m.getZ()-target.getZ());target.hurtMarked=true;}effect(m,m.position(),70,5,24);}
            case 23->{for(var target:level.getEntitiesOfClass(LivingEntity.class,m.getBoundingBox().inflate(9),t->(t instanceof Player||t==m.getTarget())&&BestiaryCombat.valid(m,t))){double distance=target.position().subtract(m.position()).horizontalDistance();if(distance>3&&distance<9)damage(m,target,1.8F,false,true);}effect(m,m.position(),71,9,40);}
            case 80->{area(m,m.position(),3,.9F,false,false,false);effect(m,m.position(),72,3,24);}
            default->{}
        }
    }
    @SubscribeEvent(priority=EventPriority.LOW) public static void armor(net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent e){if(e.isCanceled()||e.getEntity().level().isClientSide()||!(e.getEntity() instanceof BestiaryMob m))return;long now=m.level().getGameTime();if(m.ward()>0&&m.getPersistentData().getLong("aw_ward_until")>now){float absorbed=Math.min(e.getAmount(),m.ward());m.ward(m.ward()-absorbed);e.setAmount(Math.max(0,e.getAmount()-absorbed));if(m.ward()==0)m.stagger(28);}
        if(m.kind==BestiaryKind.ANCIENT_GOLEM&&e.getSource().getEntity() instanceof Player p){int part=m.getPersistentData().contains("aw_hit_part")?m.getPersistentData().getInt("aw_hit_part"):-1;float armor=part==0?1.2F:part>0?.65F:p.position().subtract(m.position()).normalize().dot(DragonBattle.forward(m.yBodyRot))<-.25?1.1F:.85F;if(m.getPersistentData().getLong("aw_golem_armor")>now&&part!=0)armor*=.85F;e.setAmount(e.getAmount()*armor);}}
    public static void headHit(BestiaryMob m,int head,float damage){if(m.kind!=BestiaryKind.HYDRA||head<0||head>2||damage<=0)return;String key="aw_head_damage_"+head;float total=m.getPersistentData().getFloat(key)+damage;m.getPersistentData().putFloat(key,total);if(total>=Math.min(100,m.getMaxHealth()*.12F)&&(m.headMask()&(1<<head))!=0){m.headMask(m.headMask()&~(1<<head));m.getPersistentData().putLong("aw_head_regrow_"+head,m.level().getGameTime()+140);m.stagger(25);}}
    public static void update(BestiaryMob m){if(m.level().isClientSide()||m.isNoAi())return;long now=m.level().getGameTime();if(m.ward()>0&&m.getPersistentData().getLong("aw_ward_until")<=now)m.ward(0);if(m.kind==BestiaryKind.HYDRA&&!m.isOnFire())for(int i=0;i<3;i++)if((m.headMask()&(1<<i))==0&&m.getPersistentData().getLong("aw_head_regrow_"+i)<=now){m.headMask(m.headMask()|(1<<i));m.getPersistentData().putFloat("aw_head_damage_"+i,0);effect(m,m.position(),63,2,24);}if(m.awakenedVariant()>0&&m.awakenedVariant()<3&&!m.kind.boss&&m.phase()==BestiaryMob.IDLE&&BestiaryCombat.valid(m,m.getTarget())&&m.getPersistentData().getLong("aw_variant_ready")<=now){m.getPersistentData().putLong("aw_variant_ready",now+180);begin(m,m.getTarget(),m.awakenedVariant()==2?80:81);}}
}
