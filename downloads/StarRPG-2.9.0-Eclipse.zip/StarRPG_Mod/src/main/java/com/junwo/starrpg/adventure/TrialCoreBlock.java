package com.junwo.starrpg.adventure;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.phys.BlockHitResult;
public final class TrialCoreBlock extends Block {
    public static final net.minecraft.world.level.block.state.properties.BooleanProperty GRAND=net.minecraft.world.level.block.state.properties.BooleanProperty.create("grand");
    public static final net.minecraft.world.level.block.state.properties.BooleanProperty AWAKENED=net.minecraft.world.level.block.state.properties.BooleanProperty.create("awakened");
    public static final IntegerProperty VARIANT=IntegerProperty.create("variant",0,2);
    public TrialCoreBlock(){super(BlockBehaviour.Properties.of().strength(-1,3600000).lightLevel(s->10));registerDefaultState(stateDefinition.any().setValue(VARIANT,0).setValue(GRAND,false).setValue(AWAKENED,false));}
    @Override protected void createBlockStateDefinition(StateDefinition.Builder<Block,BlockState> b){b.add(VARIANT,GRAND,AWAKENED);}
    @Override protected InteractionResult useWithoutItem(BlockState state,Level l,BlockPos pos,Player p,BlockHitResult hit){if(!l.isClientSide())WorldTrials.startDungeon(p,pos,state.getValue(VARIANT),p.isShiftKeyDown());return InteractionResult.sidedSuccess(l.isClientSide());}
}
