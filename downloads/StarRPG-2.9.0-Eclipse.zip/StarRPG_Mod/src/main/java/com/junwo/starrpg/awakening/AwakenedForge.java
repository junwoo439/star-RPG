package com.junwo.starrpg.awakening;
import com.junwo.starrpg.*;
import com.junwo.starrpg.adventure.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
public final class AwakenedForge {
    public static String name(int recipe){return new String[]{"도전 열쇠","별을 삼킨 거신의 인장","적룡의 송곳니","영혼 수확자의 낫","태고의 심장 망치","월식의 창","성흔의 흉갑"}[Math.clamp(recipe,0,6)];}
    public static Item result(int recipe){return switch(recipe){case 0->AwakeningItems.DUNGEON_KEY.get();case 1->AwakeningItems.RAID_SIGIL.get();case 2->AwakeningItems.DRAGON_WEAPON.get();case 3->AwakeningItems.LICH_WEAPON.get();case 4->AwakeningItems.GOLEM_WEAPON.get();case 5->AwakeningItems.RAID_WEAPON.get();default->AwakeningItems.RAID_CHEST.get();};}
    public static boolean craft(Player p,int recipe){if(recipe<0||recipe>6||recipe>=2&&LifeJobs.active(p)!=1)return false;var out=new ItemStack(result(recipe));Item catalyst=switch(recipe){case 0->AdventureItems.RELIC.get();case 1->AwakeningItems.CRYSTAL.get();case 2->AdventureItems.DRAGON.get();case 3->AdventureItems.LICH.get();case 4->AdventureItems.GOLEM.get();default->AwakeningItems.RAID_CORE.get();};int essence=recipe<2?4:12,catalysts=recipe<2?2:3,alloy=recipe<2?0:6;if(!Economy.fits(p,out)||p.getInventory().countItem(catalyst)<catalysts||p.getInventory().countItem(AwakeningItems.ESSENCE.get())<essence||p.getInventory().countItem(AdventureItems.ALLOY.get())<alloy)return false;LifeJobs.consume(p,catalyst,catalysts);LifeJobs.consume(p,AwakeningItems.ESSENCE.get(),essence);if(alloy>0)LifeJobs.consume(p,AdventureItems.ALLOY.get(),alloy);LifeJobs.give(p,out);PresentationCues.play(p,PresentationCues.CRAFT,100+recipe,0xB8A0FF);return true;}
}
