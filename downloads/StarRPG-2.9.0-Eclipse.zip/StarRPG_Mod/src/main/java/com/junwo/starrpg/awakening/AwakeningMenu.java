package com.junwo.starrpg.awakening;

import com.junwo.starrpg.*;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.ItemStack;

/** Three persistent equipment slots. Closing never drops or copies equipped accessories. */
public final class AwakeningMenu extends AbstractContainerMenu {
    public final Player owner;
    public final SimpleContainer equipment;
    public AwakeningMenu(int id,Inventory inventory){super(ModMenus.AWAKENING.get(),id);owner=inventory.player;equipment=owner.level().isClientSide()?new SimpleContainer(3):Accessories.inventory(owner);
        for(int i=0;i<3;i++){final int slot=i;addSlot(new Slot(equipment,i,365,72+i*26){@Override public boolean mayPlace(ItemStack s){return s.getItem() instanceof AwakeningItems.AccessoryItem a&&a.slot==slot;}@Override public int getMaxStackSize(){return 1;}});}
        for(int y=0;y<3;y++)for(int x=0;x<9;x++)addSlot(new Slot(inventory,x+y*9+9,8+x*18,229+y*18));for(int x=0;x<9;x++)addSlot(new Slot(inventory,x,8+x*18,287));
    }
    public static void open(ServerPlayer p,int tab){p.openMenu(new SimpleMenuProvider((id,inv,who)->new AwakeningMenu(id,inv),Component.literal("별의 각성 · "+Math.clamp(tab,0,6))));AwakeningSync.send(p,true);}
    @Override public boolean stillValid(Player p){return owner==p&&p.isAlive()&&!p.isSpectator();}
    @Override public ItemStack quickMoveStack(Player p,int index){if(p!=owner||index<0||index>=slots.size())return ItemStack.EMPTY;var slot=slots.get(index);if(!slot.hasItem())return ItemStack.EMPTY;var stack=slot.getItem();var copy=stack.copy();if(index<3){if(!moveItemStackTo(stack,3,39,true))return ItemStack.EMPTY;}else if(stack.getItem() instanceof AwakeningItems.AccessoryItem a){if(!moveItemStackTo(stack,a.slot,a.slot+1,false))return ItemStack.EMPTY;}else if(index<30){if(!moveItemStackTo(stack,30,39,false))return ItemStack.EMPTY;}else if(!moveItemStackTo(stack,3,30,false))return ItemStack.EMPTY;if(stack.isEmpty())slot.setByPlayer(ItemStack.EMPTY);else slot.setChanged();slot.onTake(p,stack);return copy;}
}
