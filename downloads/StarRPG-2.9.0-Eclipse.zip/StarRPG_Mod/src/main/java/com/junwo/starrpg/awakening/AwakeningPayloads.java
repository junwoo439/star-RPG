package com.junwo.starrpg.awakening;
import com.junwo.starrpg.*;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.*;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public final class AwakeningPayloads {
    public record Snapshot(String json) implements CustomPacketPayload {
        public static final Type<Snapshot> TYPE=new Type<>(ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,"awakening_snapshot"));
        public static final StreamCodec<ByteBuf,Snapshot> CODEC=StreamCodec.composite(ByteBufCodecs.stringUtf8(60000),Snapshot::json,Snapshot::new);
        @Override public Type<? extends CustomPacketPayload> type(){return TYPE;}
        public static void handle(Snapshot m,IPayloadContext context){context.enqueueWork(()->AwakeningClient.receive(m.json));}
    }
    public record Action(int op,int argument,String target) implements CustomPacketPayload {
        public static final Type<Action> TYPE=new Type<>(ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,"awakening_action"));
        public static final StreamCodec<ByteBuf,Action> CODEC=StreamCodec.composite(ByteBufCodecs.VAR_INT,Action::op,ByteBufCodecs.VAR_INT,Action::argument,ByteBufCodecs.stringUtf8(36),Action::target,Action::new);
        @Override public Type<? extends CustomPacketPayload> type(){return TYPE;}
        public static void handle(Action m,IPayloadContext context){context.enqueueWork(()->{if(context.player() instanceof ServerPlayer p&&p.containerMenu instanceof AwakeningMenu menu&&menu.stillValid(p)&&!ControlEffects.stunned(p)){long now=p.level().getGameTime();if(p.getPersistentData().getLong("aw_action_ready")>now)return;p.getPersistentData().putLong("aw_action_ready",now+5);boolean ok=AwakeningActions.act(p,menu,m.op,m.argument,m.target);p.displayClientMessage(net.minecraft.network.chat.Component.literal(ok?"별빛이 응답했습니다.":"진행도·재료·위치·인벤토리 공간을 확인하세요."),true);menu.broadcastChanges();AwakeningSync.send(p,true);}});}
    }
}
