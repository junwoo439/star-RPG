package com.junwo.starrpg.awakening;
import com.junwo.starrpg.*;
import net.minecraft.server.level.ServerPlayer;
public final class AwakeningActions {
    public static boolean act(ServerPlayer p,AwakeningMenu menu,int op,int arg,String target){try{return switch(op){
        case 0->Parties.create(p);case 1->Parties.invite(p,java.util.UUID.fromString(target));case 2->Parties.accept(p);case 3->Parties.remove(p,java.util.UUID.fromString(target));case 4->Parties.questStart(p);case 5->Parties.questClaim(p);
        case 6->Accessories.craft(p,arg);case 7->Accessories.upgrade(p,menu.equipment,arg);case 8->Constellations.select(p,arg);case 9->Constellations.grow(p,arg);
        case 10->VillageReputation.chooseFaction(p,arg);case 11->VillageReputation.factionAccept(p);case 12->VillageReputation.factionClaim(p);case 13->VillageReputation.develop(p);case 14->VillageReputation.merchant(p);case 15->VillageReputation.defense(p);case 16->VillageReputation.specialBuy(p,arg);
        case 17->Mutations.claim(p,arg/2,arg%2+1);case 18->DungeonRooms.challenge(p);case 19->Raids.rally(p);case 20->Raids.joinRally(p,java.util.UUID.fromString(target));case 21->Raids.start(p);case 22->Raids.claim(p);case 23->AwakenedForge.craft(p,arg);default->false;};}catch(IllegalArgumentException invalid){return false;}}
}
