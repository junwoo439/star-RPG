package com.junwo.starrpg.bestiary;

import com.junwo.starrpg.StarRPG;
import com.mojang.blaze3d.platform.NativeImage;
import java.util.*;
import java.nio.file.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;

/** Original, deterministic albedo patterns generated from scratch, one atlas per species. */
public final class AwakenedTextures {
    private static final Map<BestiaryKind,ResourceLocation> CACHE=new EnumMap<>(BestiaryKind.class);
    public static ResourceLocation id(BestiaryKind k){return ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,"textures/entity/awakening/"+k.id+".png");}
    public static ResourceLocation get(BestiaryKind k){return CACHE.computeIfAbsent(k,key->{var client=Minecraft.getInstance();var baked=id(key);if(client.getResourceManager().getResource(baked).isPresent())return baked;return client.getTextureManager().register("starrpg_awakening_"+key.id,new DynamicTexture(draw(key)));});}
    private static int hash(int x,int y,int seed){int n=x*374761393+y*668265263+seed*144269;return (n^(n>>>13))*1274126177;}
    public static NativeImage draw(BestiaryKind k){
        var image=new NativeImage(256,256,false);int seed=k.id.hashCode();
        for(int y=0;y<256;y++)for(int x=0;x<256;x++){
            int tile=x/64+y/64*4,u=x%64,v=y%64,n=hash(u,v,seed+tile),grain=(n>>>24&31)-15;double shade=220;
            switch(tile){
                case 0->{int row=v/9;double dx=(u+row%2*5)%10-5,dy=v%9-4;shade=206+27*Math.cos(dx*.3)*Math.cos(dy*.3)-(Math.abs(dx)>4||dy>3?30:0);}
                case 1->shade=222+(v%10==0?-42:Math.sin(v*.63)*13);
                case 2->{double vein=Math.min(Math.abs(u-v*.43-8),Math.abs(u+v*.36-47));shade=217+(vein<1.2?-40:0)+Math.sin(u*.08)*10;}
                case 3,11->shade=229+Math.sin(u*.41+Math.sin(v*.08))*8-(u%13==0?15:0);
                case 4->shade=225+Math.sin(u*.07+v*.05)*22+(v%7==0?8:0);
                case 5->{double dx=(u+v/7%2*4)%8-4,dy=v%7-3;shade=dx*dx+dy*dy>10?170:235;}
                case 6->{int slab=v/16;shade=213+(hash(u/18,slab,seed)>>>27)-((u+slab%2*9)%18==0||v%16==0?45:0);}
                case 7->shade=220+((u+v)%2)*9+Math.sin(u*.18)*8;
                case 8,9->{double fiber=Math.sin(u*.9+Math.sin(v*.24+(seed&15))*2);shade=215+fiber*20+Math.sin(v*.11)*8;}
                case 10,15->shade=221+(n>>>20&7)-(n%29==0?24:0);
                case 12->shade=211+Math.sin(u*.33+Math.sin(v*.05)*2)*24;
                case 13->shade=211+Math.sin(u*.18)*Math.sin(v*.2)*21-(v%19==0?25:0);
                case 14->shade=224+Math.sin((u+v*.6)*.8)*14;
                default->{}
            }
            int c=Math.clamp((int)shade+grain/3,100,255);image.setPixelRGBA(x,y,0xFF000000|c<<16|c<<8|c);
        }return image;
    }
    public static void exportAll(Path directory)throws java.io.IOException{Files.createDirectories(directory);for(var k:BestiaryKind.values())try(var image=draw(k)){image.writeToFile(directory.resolve(k.id+".png"));}}
}
