package com.junwo.starrpg.awakening;
import com.junwo.starrpg.*;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.level.block.state.properties.*;
import net.minecraft.world.phys.BlockHitResult;
import net.neoforged.neoforge.registries.DeferredBlock;

public final class RoomBlocks {
    public static final DeferredBlock<Rune> RUNE=StarRPG.BLOCKS.register("dungeon_rune_lock",Rune::new);
    public static final DeferredBlock<Reward> REWARD=StarRPG.BLOCKS.register("dungeon_treasure",Reward::new);
    public static final DeferredBlock<Trap> TRAP=StarRPG.BLOCKS.register("dungeon_trap",Trap::new);
    public static void init(){}
    public static final class Rune extends Block {
        public static final IntegerProperty INDEX=IntegerProperty.create("index",0,2);
        public Rune(){super(BlockBehaviour.Properties.of().strength(-1,3600000).lightLevel(s->9));registerDefaultState(stateDefinition.any().setValue(INDEX,0));}
        @Override protected void createBlockStateDefinition(StateDefinition.Builder<Block,BlockState> b){b.add(INDEX);}
        @Override protected InteractionResult useWithoutItem(BlockState state,Level level,BlockPos pos,Player p,BlockHitResult hit){if(!level.isClientSide())DungeonRooms.rune(p,pos,state.getValue(INDEX));return InteractionResult.sidedSuccess(level.isClientSide());}
    }
    public static final class Reward extends Block {
        public static final IntegerProperty KIND=IntegerProperty.create("kind",0,1);
        public Reward(){super(BlockBehaviour.Properties.of().strength(-1,3600000).lightLevel(s->7));registerDefaultState(stateDefinition.any().setValue(KIND,0));}
        @Override protected void createBlockStateDefinition(StateDefinition.Builder<Block,BlockState> b){b.add(KIND);}
        @Override protected InteractionResult useWithoutItem(BlockState state,Level level,BlockPos pos,Player p,BlockHitResult hit){if(!level.isClientSide()&&!DungeonRooms.treasure(p,pos,state.getValue(KIND)==1))p.displayClientMessage(net.minecraft.network.chat.Component.literal("문양 봉인·수령 여부·인벤토리 공간을 확인하세요."),true);return InteractionResult.sidedSuccess(level.isClientSide());}
    }
    public static final class Trap extends Block {
        public static final BooleanProperty LIT=BooleanProperty.create("lit");
        public Trap(){super(BlockBehaviour.Properties.of().strength(-1,3600000).lightLevel(s->s.getValue(LIT)?12:1));registerDefaultState(stateDefinition.any().setValue(LIT,false));}
        @Override protected void createBlockStateDefinition(StateDefinition.Builder<Block,BlockState> b){b.add(LIT);}
        private String key(ServerLevel level,BlockPos pos){return level.dimension().location()+":"+pos.asLong();}
        @Override public void stepOn(Level level,BlockPos pos,BlockState state,Entity entity){super.stepOn(level,pos,state,entity);if(!(level instanceof ServerLevel server)||!(entity instanceof Player p)||p.isCreative()||p.isSpectator()||state.getValue(LIT))return;var rows=AwakeningData.section(AwakeningData.get(server.getServer()).world,"traps");var data=AwakeningData.section(rows,key(server,pos));if(data.getLong("ready")>level.getGameTime())return;data.putLong("ready",level.getGameTime()+100);data.putLong("trigger",level.getGameTime());level.setBlock(pos,state.setValue(LIT,true),3);server.scheduleTick(pos,this,24);ArcaneSigil.spawn(server,net.minecraft.world.phys.Vec3.atBottomCenterOf(pos.above()),net.minecraft.world.phys.Vec3.ZERO,38,0xFF654F,2.5F,24);AwakeningData.get(server.getServer()).setDirty();}
        @Override protected void tick(BlockState state,ServerLevel level,BlockPos pos,net.minecraft.util.RandomSource random){var row=AwakeningData.section(AwakeningData.section(AwakeningData.get(level.getServer()).world,"traps"),key(level,pos));level.setBlock(pos,state.setValue(LIT,false),3);if(level.getGameTime()-row.getLong("trigger")>40)return;for(var p:level.getEntitiesOfClass(Player.class,new net.minecraft.world.phys.AABB(pos).inflate(2.5),p->p.isAlive()&&!p.isCreative()&&!p.isSpectator()))p.hurt(level.damageSources().magic(),6);ArcaneSigil.spawn(level,net.minecraft.world.phys.Vec3.atBottomCenterOf(pos.above()),net.minecraft.world.phys.Vec3.ZERO,75,0xFF8B66,2.5F,20);}
    }
}
