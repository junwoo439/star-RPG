package com.junwo.starrpg.awakening;

import com.junwo.starrpg.*;
import net.minecraft.world.item.*;
import net.neoforged.neoforge.registries.DeferredItem;

public final class AwakeningItems {
    public static final DeferredItem<Item> ESSENCE=material("awakened_essence"),CRYSTAL=material("mutation_crystal"),STAR_CORE=material("constellation_core"),RAID_CORE=material("star_titan_core"),DUNGEON_KEY=material("challenge_key"),SECRET_RELIC=material("forgotten_relic"),RAID_SIGIL=material("raid_sigil");
    public static final DeferredItem<AccessoryItem> RING=accessory("astral_ring",0),NECKLACE=accessory("tide_pendant",1),CHARM=accessory("parrying_charm",2),LICH_RING=accessory("soulbound_ring",0),DRAGON_NECKLACE=accessory("dragonbone_pendant",1),GOLEM_CHARM=accessory("guardian_talisman",2);
    public static final DeferredItem<CareerWeaponItem> DRAGON_WEAPON=weapon("dragon_spear",0,7,-2.7F),LICH_WEAPON=weapon("lich_scythe",7,7,-2.8F),RAID_WEAPON=weapon("eclipse_lance",0,8,-2.7F);
    public static final DeferredItem<WarHammerItem> GOLEM_WEAPON=StarRPG.ITEMS.register("golem_hammer",()->new WarHammerItem(new Item.Properties().rarity(Rarity.EPIC)));
    public static final DeferredItem<Item> RAID_CHEST=StarRPG.ITEMS.register("starforged_chestplate",()->new ArmorItem(LegendaryMaterials.SETS.get(3),ArmorItem.Type.CHESTPLATE,new Item.Properties().rarity(Rarity.EPIC)));
    private static DeferredItem<Item> material(String id){return StarRPG.ITEMS.register(id,()->new Item(new Item.Properties().rarity(Rarity.RARE)));}
    private static DeferredItem<AccessoryItem> accessory(String id,int slot){return StarRPG.ITEMS.register(id,()->new AccessoryItem(slot,new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));}
    private static DeferredItem<CareerWeaponItem> weapon(String id,int job,int damage,float speed){return StarRPG.ITEMS.register(id,()->new CareerWeaponItem(new Item.Properties().rarity(Rarity.EPIC),job,damage,speed));}
    public static java.util.List<Item> all(){return java.util.List.of(ESSENCE.get(),CRYSTAL.get(),STAR_CORE.get(),RAID_CORE.get(),DUNGEON_KEY.get(),SECRET_RELIC.get(),RAID_SIGIL.get(),RING.get(),NECKLACE.get(),CHARM.get(),LICH_RING.get(),DRAGON_NECKLACE.get(),GOLEM_CHARM.get(),DRAGON_WEAPON.get(),LICH_WEAPON.get(),GOLEM_WEAPON.get(),RAID_WEAPON.get(),RAID_CHEST.get());}
    public static void init(){}
    public static final class AccessoryItem extends Item {public final int slot;public AccessoryItem(int slot,Properties properties){super(properties);this.slot=slot;}}
}
