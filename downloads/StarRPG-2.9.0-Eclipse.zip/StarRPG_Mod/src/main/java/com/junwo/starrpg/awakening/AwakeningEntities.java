package com.junwo.starrpg.awakening;
import com.junwo.starrpg.*;
import com.junwo.starrpg.bestiary.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
@EventBusSubscriber(modid=StarRPG.MODID,bus=EventBusSubscriber.Bus.MOD)
public final class AwakeningEntities {
    public static final DeferredHolder<EntityType<?>,EntityType<BossSpell>> SPELL=ModEntities.ENTITIES.register("boss_spell",()->EntityType.Builder.<BossSpell>of(BossSpell::new,MobCategory.MISC).sized(.4F,.4F).clientTrackingRange(8).updateInterval(1).build("starrpg:boss_spell"));
    public static final DeferredHolder<EntityType<?>,EntityType<BestiaryMob>> TITAN=BestiaryRegistry.ENTITIES.register("star_devourer",()->EntityType.Builder.<BestiaryMob>of((type,level)->{var m=new BestiaryMob(type,level,BestiaryKind.ANCIENT_GOLEM);m.awakenedVariant(3);return m;},MobCategory.MONSTER).sized(3.2F,5.2F).clientTrackingRange(12).updateInterval(2).build("starrpg:star_devourer"));
    @SubscribeEvent public static void attributes(net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent e){e.put(TITAN.get(),BestiaryMob.attributes(BestiaryKind.ANCIENT_GOLEM).add(Attributes.MAX_HEALTH,900).add(Attributes.ATTACK_DAMAGE,12).build());}
    public static void init(){}
}
