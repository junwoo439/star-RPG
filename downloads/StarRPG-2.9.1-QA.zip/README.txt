Actual Minecraft 1.21.1 native screenshots from isolated development worlds.
53 idle shots, UI shots, flight and legacy-world shots keep original resolution. Other combat state previews are resized to fit 640x400; no scene elements were added.
The cow is the attack target. Some dropped items remain from preceding scenarios. The first bear idle shot was taken before its chunk displayed; see its windup and the gallery.
16-participant performance uses ONE native client plus FIFTEEN server-only simulated actors. Two-native-client TCP results are separate.
See TESTING-2.9.1.md for exact scope, raw measurements and limitations. No player/world saves or raw JFR environment data are included.
