package com.junwo.starrpg.tests;

import com.junwo.starrpg.*;
import java.util.*;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.item.crafting.*;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.gametest.*;

@GameTestHolder(StarRPG.MODID)
@PrefixGameTestTemplate(false)
public class RunesAndTraitsGameTests {
    private static ItemStack runeArmor(Item item,RuneEffect effect) {
        ItemStack stack=new ItemStack(item);RuneDataHelper.setRuneEffect(stack,effect);return stack;
    }
    @GameTest(template="empty") public static void allArmorRaritiesEngraveAndPersist(GameTestHelper h) {
        Player player=h.makeMockPlayer(GameType.SURVIVAL);
        Item[] armor={Items.IRON_HELMET,Items.IRON_CHESTPLATE,Items.IRON_LEGGINGS,Items.IRON_BOOTS};
        Item[] runes={StarRPG.COMMON_RUNE.get(),StarRPG.RARE_RUNE.get(),StarRPG.EPIC_RUNE.get(),StarRPG.LEGENDARY_RUNE.get(),StarRPG.MYTHIC_RUNE.get()};
        for(Item item:armor) for(int g=0;g<5;g++) {
            var menu=new RuneEngravingMenu(1,player.getInventory());var gear=new ItemStack(item);EnhancementData.setLevel(gear,7);
            menu.getSlot(0).set(gear);menu.getSlot(1).set(new ItemStack(runes[g]));
            h.assertTrue(menu.clickMenuButton(player,0),"Armor rune rejected");
            var restored=ItemStack.parseOptional(h.getLevel().registryAccess(),(CompoundTag)gear.save(h.getLevel().registryAccess()));
            var effect=RuneDataHelper.getRuneEffect(restored);
            h.assertTrue(effect!=null && effect.getRarity().ordinal()==g && effect.getWeaponType()==RuneWeaponType.forItem(gear),"Wrong armor rune or lost on save");
            h.assertTrue(EnhancementData.level(restored)==7 && menu.getSlot(1).getItem().isEmpty(),"Lost upgrade or rune not consumed");
        }
        h.succeed();
    }
    @GameTest(template="empty") public static void armorRuneRejectsDowngradeAndWrongItems(GameTestHelper h) {
        Player player=h.makeMockPlayer(GameType.SURVIVAL);var menu=new RuneEngravingMenu(1,player.getInventory());
        menu.getSlot(0).set(runeArmor(Items.IRON_HELMET,RuneEffect.HELMET_MYTHIC));menu.getSlot(1).set(new ItemStack(StarRPG.COMMON_RUNE.get()));
        h.assertTrue(!menu.clickMenuButton(player,0) && !menu.getSlot(1).getItem().isEmpty(),"Downgrade accepted/consumed rune");
        menu.getSlot(1).set(new ItemStack(StarRPG.MYTHIC_RUNE.get()));
        h.assertTrue(!menu.clickMenuButton(player,0) && !menu.getSlot(1).getItem().isEmpty(),"Identical fixed armor rune wasted material");
        menu.getSlot(0).set(new ItemStack(Items.FISHING_ROD));h.assertTrue(!menu.clickMenuButton(player,0),"Non-armor tool accepted");
        player.setItemSlot(EquipmentSlot.HEAD,runeArmor(Items.IRON_HELMET,RuneEffect.CHESTPLATE_MYTHIC));
        h.assertTrue(ArmorRuneEffects.grade(player,EquipmentSlot.HEAD)==0,"Mismatched slot activates rune");h.succeed();
    }
    @GameTest(template="empty") public static void shiftClickMovesArmorWithoutDuplication(GameTestHelper h) {
        Player player=h.makeMockPlayer(GameType.SURVIVAL);var menu=new RuneEngravingMenu(1,player.getInventory());
        menu.getSlot(2).set(new ItemStack(Items.IRON_BOOTS));
        h.assertTrue(!menu.quickMoveStack(player,2).isEmpty() && menu.getSlot(2).getItem().isEmpty() && menu.getSlot(0).getItem().is(Items.IRON_BOOTS),"Armor shift-click failed");
        h.assertTrue(!menu.quickMoveStack(player,0).isEmpty() && menu.getSlot(0).getItem().isEmpty(),"Return shift-click failed");
        int count=0;for(int i=2;i<menu.slots.size();i++) if(menu.getSlot(i).getItem().is(Items.IRON_BOOTS)) count+=menu.getSlot(i).getItem().getCount();
        h.assertTrue(count==1,"Shift-click duplicated gear");h.succeed();
    }
    @GameTest(template="empty") public static void armorAttributesStopWhenUnequipped(GameTestHelper h) {
        Player p=h.makeMockPlayer(GameType.SURVIVAL);p.setSprinting(true);
        double speed=p.getAttributeValue(Attributes.MOVEMENT_SPEED),knockback=p.getAttributeValue(Attributes.KNOCKBACK_RESISTANCE);
        p.setItemSlot(EquipmentSlot.LEGS,runeArmor(Items.IRON_LEGGINGS,RuneEffect.LEGGINGS_MYTHIC));
        p.setItemSlot(EquipmentSlot.FEET,runeArmor(Items.IRON_BOOTS,RuneEffect.BOOTS_MYTHIC));ArmorRuneEffects.update(p);
        double boosted=p.getAttributeValue(Attributes.MOVEMENT_SPEED);
        h.assertTrue(boosted>speed && Math.abs(p.getAttributeValue(Attributes.KNOCKBACK_RESISTANCE)-knockback-0.3)<0.001,"Armor modifiers absent");
        for(int i=0;i<100;i++) ArmorRuneEffects.update(p);
        h.assertTrue(p.getAttributeValue(Attributes.MOVEMENT_SPEED)==boosted,"Armor modifier stacked");
        p.setItemSlot(EquipmentSlot.LEGS,ItemStack.EMPTY);p.setItemSlot(EquipmentSlot.FEET,ItemStack.EMPTY);ArmorRuneEffects.update(p);
        h.assertTrue(Math.abs(p.getAttributeValue(Attributes.MOVEMENT_SPEED)-speed)<0.0001 && p.getAttributeValue(Attributes.KNOCKBACK_RESISTANCE)==knockback,"Unequip retained attributes");h.succeed();
    }
    @GameTest(template="empty") public static void cleansingCooldownCannotBeResetBySwapping(GameTestHelper h) {
        Player p=h.makeMockPlayer(GameType.SURVIVAL);p.setItemSlot(EquipmentSlot.HEAD,runeArmor(Items.IRON_HELMET,RuneEffect.HELMET_COMMON));
        p.addEffect(new MobEffectInstance(MobEffects.POISON,100,0));ArmorRuneEffects.update(p);
        h.assertTrue(!p.hasEffect(MobEffects.POISON),"Helmet did not cleanse");
        p.setItemSlot(EquipmentSlot.HEAD,runeArmor(Items.IRON_HELMET,RuneEffect.HELMET_MYTHIC));p.addEffect(new MobEffectInstance(MobEffects.POISON,100,0));ArmorRuneEffects.update(p);
        h.assertTrue(p.hasEffect(MobEffects.POISON),"Swapping bypassed cleanse cooldown");h.succeed();
    }
    @GameTest(template="empty") public static void chestRuneReducesOnlyProjectileDamage(GameTestHelper h) {
        Player p=h.makeMockPlayer(GameType.SURVIVAL);p.setItemSlot(EquipmentSlot.CHEST,runeArmor(Items.IRON_CHESTPLATE,RuneEffect.CHESTPLATE_MYTHIC));
        var arrow=EntityType.ARROW.create(h.getLevel());var skeleton=EntityType.SKELETON.create(h.getLevel());
        var shot=new net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent(p,new net.neoforged.neoforge.common.damagesource.DamageContainer(h.getLevel().damageSources().arrow(arrow,skeleton),10));
        ArmorRuneEffects.incoming(shot);h.assertTrue(Math.abs(shot.getAmount()-8)<0.001,"Wrong projectile reduction");
        var melee=new net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent(p,new net.neoforged.neoforge.common.damagesource.DamageContainer(h.getLevel().damageSources().mobAttack(skeleton),10));
        ArmorRuneEffects.incoming(melee);h.assertTrue(melee.getAmount()==10,"Projectile rune reduced melee");h.succeed();
    }
    @GameTest(template="empty") public static void anchorRuneReducesActualHookPull(GameTestHelper h) {
        var zombie=h.spawn(EntityType.ZOMBIE,1,2,1);zombie.setItemSlot(EquipmentSlot.MAINHAND,new ItemStack(Items.FISHING_ROD));
        Player p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(zombie.position().add(2,0,0));zombie.setTarget(p);
        h.assertTrue(ZombieHook.pull(zombie,p),"Control pull failed");double normal=p.getDeltaMovement().length();
        p.getPersistentData().remove("starrpg_hook_immunity");p.setItemSlot(EquipmentSlot.LEGS,runeArmor(Items.IRON_LEGGINGS,RuneEffect.LEGGINGS_MYTHIC));
        h.assertTrue(ZombieHook.pull(zombie,p) && Math.abs(p.getDeltaMovement().length()/normal-0.4)<0.001,"Anchor does not reduce hook by 60%");h.succeed();
    }
    @GameTest(template="empty") public static void engravingRecipeProducesUsableTool(GameTestHelper h) {
        var dust=new ItemStack(StarRPG.STAR_DUST.get());var amethyst=new ItemStack(Items.AMETHYST_SHARD);var fragment=new ItemStack(StarRPG.STAR_FRAGMENT.get());
        var input=CraftingInput.of(3,3,List.of(dust,amethyst,dust,amethyst,fragment,amethyst,dust,amethyst,dust));
        var recipe=h.getLevel().getRecipeManager().getRecipeFor(RecipeType.CRAFTING,input,h.getLevel()).orElseThrow();
        h.assertTrue(recipe.value().assemble(input,h.getLevel().registryAccess()).is(StarRPG.RUNE_TABLE_ITEM.get()),"Recipe returned wrong/unregistered tool");
        h.assertTrue(h.getLevel().getServer().getAdvancements().get(ResourceLocation.fromNamespaceAndPath("starrpg","recipes/misc/rune_table_item"))!=null,"Recipe unlock advancement missing");h.succeed();
    }
    @GameTest(template="empty") public static void skeletonFrostArrowNeedsHitAndHasCooldown(GameTestHelper h) {
        var skeleton=h.spawn(EntityType.SKELETON,1,2,1);MonsterProgression.upgradeTier(skeleton,2);
        var arrow=EntityType.ARROW.create(h.getLevel());arrow.setOwner(skeleton);MobTraits.prepareArrow(arrow);
        var normal=EntityType.ARROW.create(h.getLevel());normal.setOwner(skeleton);MobTraits.prepareArrow(normal);
        h.assertTrue(arrow.getPersistentData().getInt("starrpg_frost_ticks")==40 && !normal.getPersistentData().contains("starrpg_frost_ticks"),"Frost shot cooldown broken");
        Player p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(skeleton.position().add(2,0,0));
        h.assertTrue(!p.hasEffect(MobEffects.MOVEMENT_SLOWDOWN),"Missed shot slowed player");
        p.hurt(h.getLevel().damageSources().arrow(arrow,skeleton),1);
        h.assertTrue(p.hasEffect(MobEffects.MOVEMENT_SLOWDOWN),"Frost hit did not slow player");
        var slow=p.getEffect(MobEffects.MOVEMENT_SLOWDOWN);slow.tick(p,()->{});int remaining=slow.getDuration();p.invulnerableTime=0;
        p.hurt(h.getLevel().damageSources().arrow(arrow,skeleton),1);
        h.assertTrue(p.getEffect(MobEffects.MOVEMENT_SLOWDOWN).getDuration()==remaining,"Frost hit bypassed victim guard");h.succeed();
    }
    @GameTest(template="hook_arena",timeoutTicks=60) public static void spiderTelegraphsPounceThenPoisons(GameTestHelper h) {
        var spider=h.spawn(EntityType.SPIDER,2,2,3);spider.removeFreeWill();spider.setOnGround(true);h.setBlock(new BlockPos(2,1,3),Blocks.STONE);
        MonsterProgression.upgradeTier(spider,3);
        Player p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(spider.position().add(5,0,0));spider.setTarget(p);MobTraits.updateSpider(spider);
        h.assertTrue(spider.getPersistentData().contains("starrpg_pounce_cast") && !spider.getPersistentData().contains("starrpg_pounce_venom"),"Spider skipped warning");
        h.runAfterDelay(18,()->{
            h.assertTrue(spider.getPersistentData().getLong("starrpg_pounce_ready")>h.getLevel().getGameTime() && spider.getDeltaMovement().x>0,"Spider never pounced");
            p.setPos(spider.position().add(1,0,0));p.hurt(h.getLevel().damageSources().mobAttack(spider),1);
            h.assertTrue(p.hasEffect(MobEffects.POISON),"Pounce hit did not poison");
            h.assertTrue(!spider.getPersistentData().contains("starrpg_pounce_venom"),"Pounce venom is reusable");h.succeed();
        });
    }
}
