package com.junwo.starrpg;

import net.minecraft.world.item.*;

public enum RuneWeaponType {
    SWORD, AXE, HELMET, CHESTPLATE, LEGGINGS, BOOTS;

    public static RuneWeaponType forItem(ItemStack stack) {
        if (stack.getItem() instanceof SwordItem) return SWORD;
        if (stack.getItem() instanceof AxeItem) return AXE;
        if (stack.getItem() instanceof ArmorItem armor) return switch (armor.getEquipmentSlot()) {
            case HEAD -> HELMET;
            case CHEST -> CHESTPLATE;
            case LEGS -> LEGGINGS;
            case FEET -> BOOTS;
            default -> null;
        };
        return null;
    }
    public boolean isArmor() { return this != SWORD && this != AXE; }
}
