package com.junwo.starrpg;

import java.util.List;

public class RuneEffectDescription {

    public static List<String> getDescriptionLines(RuneEffect effect) {
        return switch (effect) {

            // ===== 일반 검 =====
            case SWORD_WEAK_ABSORPTION -> List.of(
                    "적 처치 시 체력 2 회복",
                    "1초에 최대 1회 발동"
            );

            case SWORD_STAR_SLASH -> List.of(
                    "공격 시 15% 확률",
                    "추가 피해 1"
            );

            case SWORD_CHASE -> List.of(
                    "공격한 적에게 둔화 I, 2초",
                    "같은 대상에게 4초마다 1회 적용"
            );

            case SWORD_GUARD_RESPONSE -> List.of(
                    "공격 성공 시 10% 확률",
                    "저항 I, 2초",
                    "쿨타임 8초"
            );

            // ===== 희귀 검 =====
            case SWORD_STAR_HEAL -> List.of(
                    "적 처치 시 체력 4 회복",
                    "1초에 최대 1회 발동"
            );

            case SWORD_CONTINUOUS_SLASH -> List.of(
                    "같은 적을 4초 안에 3회 공격 시",
                    "추가 피해 3",
                    "대상이 바뀌면 연속 공격 초기화"
            );

            case SWORD_METEOR_FRAGMENT -> List.of(
                    "공격 시 15% 확률",
                    "주변 적에게 피해 2",
                    "범위 2칸 / 쿨타임 3초"
            );

            case SWORD_DUEL_WILL -> List.of(
                    "주변 6칸 안에 적이 1명뿐이면",
                    "공격 피해 +2"
            );

            // ===== 에픽 검 =====
            case SWORD_METEOR_STRIKE -> List.of(
                    "같은 적을 4회 공격 시",
                    "추가 피해 5",
                    "대상이 바뀌면 공격 횟수 초기화"
            );

            case SWORD_STAR_BIND -> List.of(
                    "공격 시 20% 확률",
                    "대상에게 둔화 II, 2초",
                    "쿨타임 5초"
            );

            case SWORD_HALF_MOON -> List.of(
                    "공격 성공 시 주변 적에게",
                    "피해 2",
                    "범위 3칸 / 쿨타임 4초"
            );

            case SWORD_LIFE_TRANSFER -> List.of(
                    "체력이 40% 이하일 때",
                    "주는 피해 25% 증가"
            );

            // ===== 레전더리 검 =====
            case SWORD_CELESTIAL_COLLAPSE -> List.of(
                    "같은 적을 8회 공격 시",
                    "주변 적에게 피해 6",
                    "블록은 파괴하지 않음"
            );

            case SWORD_RADIANCE -> List.of(
                    "공격 시 20% 확률",
                    "힘 I, 4초",
                    "쿨타임 10초"
            );

            case SWORD_STAR_OATH -> List.of(
                    "같은 적을 연속 공격할수록",
                    "공격 피해 +1씩 증가",
                    "최대 +5 / 4초 미공격 시 초기화"
            );

            case SWORD_ECLIPSE -> List.of(
                    "적 처치 시 주변 적에게",
                    "실명 I·둔화 I, 4초",
                    "범위 4칸 / 쿨타임 12초"
            );

            // ===== 신화 검 =====
            case SWORD_SUPERNOVA -> List.of(
                    "20초마다 다음 공격 강화",
                    "주변 적에게 피해 8",
                    "범위 4칸 / 블록은 파괴하지 않음"
            );

            case SWORD_TIME_SLASH -> List.of(
                    "공격 시 10% 확률",
                    "대상에게 둔화 II·나약함 I, 3초",
                    "쿨타임 8초"
            );

            case SWORD_CONSTELLATION -> List.of(
                    "적 처치 시 별자리 스택 1 획득",
                    "5스택 도달 시 힘 I·신속 I, 8초",
                    "발동 후 스택 초기화"
            );

            case SWORD_SKY_JUDGMENT -> List.of(
                    "공중에 떠 있는 적 공격 시",
                    "추가 피해 6"
            );

            // ===== 일반 도끼 =====
            case AXE_SHOCK -> List.of(
                    "공격 시 15% 확률",
                    "대상을 강하게 밀쳐냄"
            );

            case AXE_CRACK_TRACE -> List.of(
                    "공격한 적이 2초 동안",
                    "받는 피해 5% 증가",
                    "중복 적용 불가"
            );

            case AXE_WEIGHT -> List.of(
                    "공격한 적에게 둔화 I, 2초",
                    "쿨타임 4초"
            );

            case AXE_BREAK -> List.of(
                    "방패를 든 플레이어 공격 시",
                    "추가 피해 2"
            );

            // ===== 희귀 도끼 =====
            case AXE_CRACK -> List.of(
                    "공격한 적이 3초 동안",
                    "받는 피해 8% 증가",
                    "중복 적용 불가"
            );

            case AXE_HUNTER -> List.of(
                    "체력이 50% 이하인 적 공격 시",
                    "추가 피해 4"
            );

            case AXE_SMASH -> List.of(
                    "공격 시 15% 확률",
                    "추가 피해 3",
                    "쿨타임 3초"
            );

            case AXE_BATTLE_INSTINCT -> List.of(
                    "적 처치 시 힘 I, 3초",
                    "쿨타임 5초"
            );

            // ===== 에픽 도끼 =====
            case AXE_EXECUTION -> List.of(
                    "체력이 25% 이하인 적 공격 시",
                    "추가 피해 7"
            );

            case AXE_SHATTER -> List.of(
                    "공격 시 20% 확률",
                    "저항 제거 + 강화 흉갑 저항 3초 억제",
                    "쿨타임 8초"
            );

            case AXE_EXPLOSION -> List.of(
                    "같은 적을 5회 공격 시",
                    "주변 적에게 피해 4",
                    "범위 3칸"
            );

            case AXE_BLOOD_TRACE -> List.of(
                    "공격한 적에게 발광, 6초",
                    "벽 너머에서도 위치 확인 가능"
            );

            // ===== 레전더리 도끼 =====
            case AXE_BLOOD_OATH -> List.of(
                    "같은 적을 연속 공격할수록",
                    "공격 피해 +1씩 증가",
                    "최대 +5 / 4초 미공격 시 초기화"
            );

            case AXE_EARTH_SMASH -> List.of(
                    "웅크린 상태로 공격 시",
                    "주변 적에게 피해 4·둔화 I, 2초",
                    "범위 3칸 / 쿨타임 10초"
            );

            case AXE_DEATH_MARK -> List.of(
                    "같은 적을 6초 안에 5회 공격 시",
                    "피해 8",
                    "발동 후 표식 초기화"
            );

            case AXE_BERSERKER_RAGE -> List.of(
                    "체력이 35% 이하일 때",
                    "주는 피해 30% 증가"
            );

            // ===== 신화 도끼 =====
            case AXE_DOOM_MARK -> List.of(
                    "공격할 때마다 멸망의 표식 1중첩",
                    "6중첩 시 피해 12",
                    "8초 동안 공격하지 않으면 초기화"
            );

            case AXE_FINAL_BLOW -> List.of(
                    "20초마다 다음 공격 강화",
                    "주변 적에게 피해 8",
                    "범위 4칸 / 블록은 파괴하지 않음"
            );

            case AXE_BLOOD_STORM -> List.of(
                    "적 처치 시 주변 적에게 출혈",
                    "초당 피해 1, 4초",
                    "범위 4칸 / 쿨타임 12초"
            );

            case AXE_GIANT_STRENGTH -> List.of(
                    "공격 성공 시 힘 II·저항 I",
                    "4초간 지속",
                    "쿨타임 15초"
            );
            default -> ArmorRuneEffects.description(effect);
        };
    }
}