package com.junwo.starrpg;

import java.util.List;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

@EventBusSubscriber(modid = StarRPG.MODID)
public final class ArmorRuneEffects {
    private static final ResourceLocation ANCHOR = ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,"rune_anchor");
    private static final ResourceLocation STRIDE = ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,"rune_stride");
    public static int grade(Player player, EquipmentSlot slot) {
        var item = player.getItemBySlot(slot);
        var effect = RuneDataHelper.getRuneEffect(item);
        if (!(item.getItem() instanceof net.minecraft.world.item.ArmorItem armor) || armor.getEquipmentSlot() != slot
                || effect == null || !effect.getWeaponType().isArmor() || effect.getWeaponType() != RuneWeaponType.forItem(item)) return 0;
        return effect.getRarity().ordinal()+1;
    }
    public static double hookMultiplier(Player player) {
        int grade=grade(player,EquipmentSlot.LEGS);
        return grade==0 ? 1 : 1-(0.1+grade*0.1);
    }
    public static void update(Player player) {
        int legs=grade(player,EquipmentSlot.LEGS), boots=grade(player,EquipmentSlot.FEET);
        attribute(player.getAttribute(Attributes.KNOCKBACK_RESISTANCE),ANCHOR,legs==0?0:0.05+legs*0.05,AttributeModifier.Operation.ADD_VALUE);
        attribute(player.getAttribute(Attributes.MOVEMENT_SPEED),STRIDE,player.isSprinting()?boots*0.03:0,AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
        int head=grade(player,EquipmentSlot.HEAD);
        long now=player.level().getGameTime();
        if (head==0 || player.getPersistentData().getLong("starrpg_rune_cleanse_ready")>now) return;
        if (player.hasEffect(MobEffects.POISON) || player.hasEffect(MobEffects.BLINDNESS) || player.hasEffect(MobEffects.DARKNESS)) {
            player.removeEffect(MobEffects.POISON);player.removeEffect(MobEffects.BLINDNESS);player.removeEffect(MobEffects.DARKNESS);
            player.getPersistentData().putLong("starrpg_rune_cleanse_ready",now+(35-head*5)*20L);
        }
    }
    private static void attribute(AttributeInstance instance, ResourceLocation id, double value, AttributeModifier.Operation operation) {
        if (instance==null) return;
        if (value==0) { instance.removeModifier(id); return; }
        var old=instance.getModifier(id);
        if (old==null || Math.abs(old.amount()-value)>0.00001) instance.addOrUpdateTransientModifier(new AttributeModifier(id,value,operation));
    }
    @SubscribeEvent public static void tick(PlayerTickEvent.Post event) {
        if (!event.getEntity().level().isClientSide()) update(event.getEntity());
    }
    @SubscribeEvent public static void incoming(LivingIncomingDamageEvent event) {
        if (event.getEntity() instanceof Player player && event.getSource().is(DamageTypeTags.IS_PROJECTILE)
                && !event.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY))
            event.setAmount(event.getAmount()*(1-grade(player,EquipmentSlot.CHEST)*0.04F));
    }
    public static List<String> description(RuneEffect effect) {
        int grade=effect.getRarity().ordinal()+1;
        return switch(effect.getWeaponType()) {
            case HELMET -> List.of("착용 중 독·실명·어둠 자동 해제", "재사용 "+(35-grade*5)+"초 / 장비 교체로 초기화 불가");
            case CHESTPLATE -> List.of("착용 중 투사체 피해 "+grade*4+"% 감소", "방어력 계산 전에 적용");
            case LEGGINGS -> List.of("밀쳐짐 저항 +"+(5+grade*5)+"%p", "좀비 갈고리 당김 "+(10+grade*10)+"% 감소");
            case BOOTS -> List.of("질주 중 이동속도 +"+grade*3+"%", "착용 부위에서만 발동");
            default -> List.of();
        };
    }
}
