# StarRPG item art

The six original transparent PNG illustrations in generated/ were created with the image generation tool for StarRPG 1.3.0. Originals are preserved unchanged. Runtime item textures are exported at 64 × 64 with nearest-neighbor sampling and transparency, for a small, mipmap-compatible Minecraft atlas. No external texture pack is required.
