# StarRPG 2.9.1 — UI·전투·호환성 검수

Minecraft **1.21.1 / NeoForge21.1.235 / Java21**. [수정·설치 안내](UPDATE-2.9.1.md) · [측정·검증 범위](TESTING-2.9.1.md).

작은 창과 GUI 배율 변경에 맞춰 여섯 메뉴를 조절하고, 슬롯 입력·드래그·툴팁 좌표를 함께 변환합니다. 강화 정보의 겹침을 정리하고 각성 메뉴의 긴 설명을 스크롤할 수 있게 했습니다. 반복 경로 탐색과 장신구 재해석, 보스바 문자열·모델 회전 연산을 줄였습니다. 기존 수치·ID·저장 키와 2.9의 열 가지 기능을 유지합니다.

**용 10종은 삭제되지 않았습니다.** 기존 Ice and Fire CE 관절 모델·비행·브레스·꼬리·날개 공격을 유지합니다. 자연 출현은 월드 단계8~12 및 서식지 조건을 따릅니다. 소환 계약도 유지됩니다. 기존 용 외형을 보려면 설치 ZIP을 풀고 **install-all-mods.bat**을 실행한 뒤 생성된 **8개 JAR을 서버와 모든 참여자에게 동일하게 설치**하세요. CE 없이 실행하면 자체 용 모델이 사용됩니다.

Eclipse: `setup-adventure-eclipse.bat` → Existing Gradle Project → **StarRPG Client**. 빌드: `gradlew.bat build` → `build/libs/starrpg-2.9.1.jar`. 이전 StarRPG JAR은 교체합니다.

---
이전 버전 기록:

# StarRPG 2.9.0 — 몬스터의 각성

Minecraft **1.21.1 / NeoForge21.1.235 / Java21**. [설치와 열 가지 기능 안내](UPDATE-2.9.md) · [밸런스/통신](BALANCE-2.9.md) · [출처](THIRD-PARTY-2.9.md).

53종 외형·관절 동작, 고유 보스 기술, 문양/함정/비밀방과 던전 도전 모드, 입체 전설 장비, 2~4인 파티와 16인 연합 레이드, 장신구 3슬롯, 마을 평판/세력/방어, 원소 반응, 희귀·변이 도감, 성좌 성장을 추가했습니다. 기존2.8 진행과 CE 드래곤 연동을 유지합니다.

**Shift+H → 각성**. 설치 ZIP의 `install-all-mods.bat` → 생성된 여덟 JAR을 서버와 참여자 모두 동일하게 설치합니다. Eclipse는 `setup-adventure-eclipse.bat` → Existing Gradle Project → StarRPG Client. 직접 빌드는 `gradlew.bat build`, 결과는 `build/libs/starrpg-2.9.0.jar`입니다.

---
아래는 이전 버전 기록입니다.

# StarRPG 2.8.0 — IceAndFire CE 드래곤

Minecraft1.21.1 / NeoForge21.1.235 / Java21. **[UPDATE-2.8.md](UPDATE-2.8.md)**에 설치·전투·테스트 안내가 있습니다. 호환 커뮤니티 이식판인 IceAndFire CE2.0과 연결해 StarRPG 용10종의 외형과 관절 모션을 개선하고, 브레스 쓸기·꼬리·날개·공중 브레스·급강하를 추가했습니다. 기존 전투 개체와 보상/성장/도감을 유지합니다.

일반 설치는 통합 설치 ZIP의 `install-dragon-mods.bat` → 생성된 다섯JAR을 서버와 참여자 모두 설치합니다. Eclipse에서는 `setup-adventure-eclipse.bat` 실행 후 **StarRPG Client**입니다. 배포 JAR은 `gradlew.bat build` → `build/libs/starrpg-2.8.0.jar`. 출처·라이선스는 [THIRD-PARTY-2.8.md](THIRD-PARTY-2.8.md)입니다.

---
아래는 이전 버전 기록입니다.

# StarRPG 2.7.0 — 자연스러운 직업명·용 동작·지형별 고대 던전

직업 이름을 정리하고, 용의 이륙·날갯짓·하강·착륙을 연결했으며, 지형별 재료와 높은 기둥·아치·탑을 사용하는 새 던전 건축을 추가했습니다.

**현재 안내:** [UPDATE-2.7.md](UPDATE-2.7.md). 이전의 뽑기식 결과 화면과8가지 모험 시스템도 포함합니다. 사용법은 [ADVENTURE-2.6.md](ADVENTURE-2.6.md)를 참고하세요.

Minecraft1.21.1 / NeoForge21.1.235 / Java21. Eclipse는 `setup-eclipse.bat` → **StarRPG Client**. 직접 빌드는 `gradlew.bat build`, 결과는 `build/libs/starrpg-2.7.0.jar`입니다. 새 건축물은 새 청크에서 생성됩니다.

---
아래는 이전 버전 기록입니다.

# StarRPG 2.6.0 — 별의 연대기

참고한 뽑기식 강화·전직 결과 화면, 새 몬스터 재질과 체형, 자연 생성 시련 던전, 보스 전투 단계/용의 공중 공격, 직업별 두 경로 성장, NPC 스토리/일일 의뢰, 전설 2·4세트, 네 생활 직업, 균열 침공, 53종 도감을 추가했습니다.

**현재 설치·사용 안내:** [ADVENTURE-2.6.md](ADVENTURE-2.6.md) · [TESTING-2.6.md](TESTING-2.6.md) · [ART-2.6.md](ART-2.6.md)

Minecraft 1.21.1 / NeoForge 21.1.235 / Java 21. **Shift+H → 모험**에서 새 기능을 엽니다. Eclipse는 `setup-eclipse.bat` → Existing Gradle Project → **StarRPG Client**입니다. 배포 빌드는 `gradlew.bat build`, 결과는 `build/libs/starrpg-2.6.0.jar`입니다.

---

아래는 이전 버전 기록입니다. 현재 안내는 위의 2.6 문서를 사용하세요.

# StarRPG 2.5.0 — 몬스터 외형·마법·무기 이펙트

종류별 용 장식과 몬스터 관절 움직임, 원소별 입체 마법과 궁극기, 무기 궤적, 보스 브레스를 개편했습니다. **V 패링의 준비/성공 자세, 무기별 1·3인칭 공격, 강화·전직 때 색이 다른 별 낙하 연출**도 포함합니다. **F8**로 이펙트 품질을 바꿀 수 있습니다.

- 변경 내용·설치: [VISUALS-2.5.md](VISUALS-2.5.md)
- 플레이 확인: [TESTING-2.5.md](TESTING-2.5.md)
- 제작 리소스: [ART-2.5.md](ART-2.5.md)
- 몬스터 수치·출현 지역: [BALANCE-2.4.md](BALANCE-2.4.md), [BESTIARY-2.4.csv](BESTIARY-2.4.csv)

**Minecraft 1.21.1 / NeoForge 21.1.235 / JDK 21.** Eclipse는 `setup-eclipse.bat` → Existing Gradle Project → **StarRPG Client**로 실행합니다. 외부 모드 설치도 필요하면 `setup-adventure-eclipse.bat`을 사용합니다.

일반 배포용 JAR: `gradlew.bat build` → `build/libs/starrpg-2.5.0.jar`. 서버와 참여자의 `mods` 폴더에 같은 버전을 설치합니다. Eclipse 개발 실행에는 별도 StarRPG JAR을 넣지 않습니다.

---

아래는 이전 버전 기능 기록입니다. 현재 설치 안내와 변경점은 위의 2.5 문서를 사용하세요.

# StarRPG

Minecraft 1.21.1 / NeoForge 21.1.235용 장비 강화·무기/방어구 룬·월드 공통 난이도·장비/낚싯대 좀비 모드.
기록된 이전 버전: **2.3.0**.

## Eclipse에서 게임 실행

**[Eclipse 실행 안내](ECLIPSE.md)**를 따라 Existing Gradle Project로 가져오고
`Run > Run Configurations > Java Application > StarRPG Client`를 실행하세요.
게임의 싱글플레이에서 테스트할 수 있습니다. JDK 21이 필요합니다.

Windows 명령줄 실행:

```bat
gradlew.bat runClient
```

클라이언트 월드와 설정은 `run-client/`에 저장됩니다.
변경 내용, 밸런스 설정, 기존 강화 장비 이전 방법은 [BALANCE-2.3.md](BALANCE-2.3.md)를 참조하세요.

## 빌드 및 개발자 테스트

```bash
bash gradlew build
bash gradlew runGameTestServer
```

Windows에서는 `gradlew.bat`를 사용합니다. 배포 파일은 `build/libs/starrpg-2.3.0.jar`입니다.
GameTest는 별도의 `run-gametest/`를 사용합니다.

2.3.0 변경 내용과 빠른 확인 순서는 [TESTING-2.3.md](TESTING-2.3.md)를 참고하세요.

이번 버전은 **3D 공격 궤적·원소별 궁극기, 양손 건틀릿/장창과 실제 좌우 삼연타, 역할 중복을 정리한 13개 직업, 원소별 전용 지팡이 6종, 실제 전직 추가타**를 포함합니다. 높은 고도에서 커스텀 이펙트가 사라지던 거리 계산도 수정했습니다. 직업 통합은 기록과 장비를 보존하며, 직접 다른 직업으로 변경할 때만 이전 직업 소지 무기를 +0으로 초기화합니다.

일반 룬 결과는 일반 70% / 희귀 25% / 에픽 4.9% / 레전더리 0.1%입니다. 모든 입력 룬이 결과 등급을 보장하지 않으며 재각인 때 등급이 낮아질 수 있습니다. 룬 확률·수치는 [BALANCE-1.8.md](BALANCE-1.8.md), 전체 룬은 [RUNE-EFFECTS-1.8.csv](RUNE-EFFECTS-1.8.csv), 플레이 확인 순서는 [TESTING-2.3.md](TESTING-2.3.md)에 있습니다.

**Shift+H:** 상점·판매·직업·마법 / **R:** 무기 스킬 / **G:** 직업 능력. 지팡이 우클릭은 선택 주문, Shift+우클릭은 주문 변경입니다. 장비 강화는 설치한 **인챈트 테이블 우클릭**, 룬 각인은 **룬 각인 도구**를 사용합니다. 별조각은 강화 재료로 유지합니다.

별가루 기본 구매 가격은 40 G, 별조각은 400 G입니다. 전체 판매 가격은 [SELL-PRICES-2.3.csv](SELL-PRICES-2.3.csv)에 있습니다. 기존 월드와 프로젝트는 백업한 뒤 업데이트하세요.

외부 모드는 [MODS-1.5.1.md](MODS-1.5.1.md)를 따릅니다. setup-adventure-eclipse.bat으로 Twilight Forest 4.8.3802, Mowzie 1.8.2, GeckoLib 4.9.2를 설치하고 Eclipse 실행을 준비합니다. Ice and Fire는 호환 공식 빌드가 없어 제외했습니다. 생활직은 보류했습니다.

외부 Twilight Forest·Mowzie·GeckoLib과 함께 자동 GameTest **174개 통과**. 실제 클라이언트의 새 테스트 월드에서 1/3인칭 양손 무기와 높은 고도의 이펙트를 확인했습니다. TESTING-2.3.md를 참고하세요. 배포 ZIP은 실행에 불필요한 art/ 원화·스크린샷을 제외하며 게임용 텍스처는 모두 포함합니다. Windows Eclipse와 실제 다인 PvP 체감은 별도 확인이 필요합니다.

**Shift+R:** 무기 각성기 (+15). +20·25에서 추가 발전합니다. 무기 설명에서 모든 해금을 확인하세요. 전체 단계표는 [WEAPON-UNLOCKS-2.0.csv](WEAPON-UNLOCKS-2.0.csv)에 있습니다.
