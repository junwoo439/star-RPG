package com.junwo.starrpg.awakening;
import com.google.gson.*;
import net.minecraft.client.gui.*;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.neoforged.neoforge.network.PacketDistributor;

public final class AwakeningScreen extends com.junwo.starrpg.ui.ResponsiveContainerScreen<AwakeningMenu> {
    private int tab,entry,bodyScroll;private long revision=-1;private JsonArray lastBody=new JsonArray();private java.util.List<net.minecraft.util.FormattedCharSequence> bodyLines=java.util.List.of();private String actionKey="";
    public AwakeningScreen(AwakeningMenu m,Inventory inv,Component title){super(m,inv,title);imageWidth=400;imageHeight=312;inventoryLabelY=10000;String t=title.getString();try{tab=Math.clamp(Integer.parseInt(t.substring(t.lastIndexOf(' ')+1)),0,6);}catch(NumberFormatException ignored){}}
    private JsonArray entries(){var data=AwakeningClient.data;if(!data.has("tabs"))return new JsonArray();return data.getAsJsonArray("tabs").get(tab).getAsJsonArray();}
    private JsonObject selected(){var rows=entries();return rows.isEmpty()?new JsonObject():rows.get(Math.clamp(entry,0,rows.size()-1)).getAsJsonObject();}
    private void button(String s,int x,int y,int w,Runnable action){addRenderableWidget(Button.builder(Component.literal(s),b->action.run()).bounds(leftPos+x,topPos+y,w,18).build());}
    @Override protected void init(){super.init();build();}
    @Override protected void containerTick(){super.containerTick();if(revision!=AwakeningClient.revision){revision=AwakeningClient.revision;entry=Math.clamp(entry,0,Math.max(0,entries().size()-1));String key=tab+":"+entry+":"+selected().get("actions");if(!key.equals(actionKey))build();}}
    private void build(){actionKey=tab+":"+entry+":"+selected().get("actions");clearWidgets();String[] names={"파티","장신구","성좌","마을","변이 도감","던전·레이드","별빛 공방"};for(int i=0;i<7;i++){int n=i;button(names[i],7+i*55,25,53,()->{tab=n;entry=0;build();});}button("◀",8,197,30,()->{entry=Math.max(0,entry-1);build();});button("▶",137,197,30,()->{entry=Math.min(Math.max(0,entries().size()-1),entry+1);build();});var e=selected();if(e.has("actions")){int n=0;for(var value:e.getAsJsonArray("actions")){var a=value.getAsJsonObject();button(a.get("name").getAsString(),180,148+n*22,170,()->PacketDistributor.sendToServer(new AwakeningPayloads.Action(a.get("op").getAsInt(),a.get("arg").getAsInt(),a.get("target").getAsString())));n++;}}}
    @Override protected void renderBg(GuiGraphics g,float pt,int x,int y){g.fillGradient(leftPos,topPos,leftPos+imageWidth,topPos+imageHeight,0xFF202D49,0xFF080F1D);g.fill(leftPos+6,topPos+47,leftPos+354,topPos+194,0xD00B1629);for(var slot:menu.slots)g.fill(leftPos+slot.x-1,topPos+slot.y-1,leftPos+slot.x+17,topPos+slot.y+17,0xFF334664);}
    private void text(GuiGraphics g,String s,int x,int y,int c){g.drawString(font,s,x,y,c,false);}
    @Override protected void renderLabels(GuiGraphics g,int x,int y){text(g,"별의 각성",8,9,0xF5D58A);if(AwakeningClient.data.has("gold"))text(g,AwakeningClient.data.get("gold").getAsString()+" G",235,9,0xFFD679);var e=selected();if(e.has("title")){fitText(g,e.get("title").getAsString(),12,54,330,0xD1BDFF);var body=e.getAsJsonArray("body");if(!body.equals(lastBody)){lastBody=body;var lines=new java.util.ArrayList<net.minecraft.util.FormattedCharSequence>();for(var line:body)lines.addAll(font.split(Component.literal(line.getAsString()),330));bodyLines=java.util.List.copyOf(lines);bodyScroll=0;}for(int i=bodyScroll;i<Math.min(bodyLines.size(),bodyScroll+5);i++)g.drawString(font,bodyLines.get(i),12,73+(i-bodyScroll)*12,0xBFCFE1,false);if(bodyLines.size()>5)text(g,"설명 스크롤 "+(bodyScroll+1)+" / "+(bodyLines.size()-4),12,136,0x91ACC6);}text(g,(entry+1)+" / "+Math.max(1,entries().size()),65,202,0xAFBFD6);text(g,"인벤토리",8,219,0xBBCADA);text(g,"장착",360,52,0xD2C2FA);text(g,"반지",362,61,0x96B6CD);text(g,"목걸이",358,88,0x96B6CD);text(g,"부적",362,114,0x96B6CD);text(g,"Shift + 클릭으로 장착",180,240,0x9FBBD0);text(g,"장신구는 사망해도 유지됩니다.",180,258,0x9FBBD0);}
    @Override protected boolean scrollCanvas(double x,double y,double dx,double dy){if(x>=leftPos+8&&x<leftPos+354&&y>=topPos+70&&y<topPos+146&&bodyLines.size()>5){bodyScroll=Math.clamp(bodyScroll-(int)Math.signum(dy),0,bodyLines.size()-5);return true;}return super.scrollCanvas(x,y,dx,dy);}
    @Override public void render(GuiGraphics g,int x,int y,float pt){super.render(g,x,y,pt);renderTooltip(g,x,y);}
}
