package com.junwo.starrpg;

import com.mojang.math.Axis;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;

/** Original reveal presentation inspired by the supplied Gacha Craft reference.
 * The server has already committed the result. Skip/close never awards or refunds anything. */
public final class StarRevealScreen extends com.junwo.starrpg.ui.ResponsiveScreen {
    private final Screen previous;private final AbstractContainerMenu menu;private final int cue,value,color;
    private final ItemStack item;private int age;private Button next;
    public StarRevealScreen(Screen previous,AbstractContainerMenu menu,int cue,int value,int color,ItemStack item){
        super(Component.literal("별의 계시"));this.previous=previous;this.menu=menu;this.cue=cue;this.value=value;this.color=color;this.item=item.copy();
    }
    @Override protected void init(){super.init();next=addRenderableWidget(Button.builder(Component.literal("연출 건너뛰기"),b->{if(age<100){age=100;next.setMessage(Component.literal("계속"));}else onClose();}).bounds(width-134,height-28,124,20).build());}
    @Override public boolean isPauseScreen(){return false;}
    @Override public void renderBackground(GuiGraphics g,int mouseX,int mouseY,float partial){} // This screen paints its own sky before the widgets.
    public int animationTick(){return age;}
    @Override public void tick(){
        age++;if(minecraft.player==null||!minecraft.player.isAlive()||minecraft.player.containerMenu!=menu){onClose();return;}
        if(age==2)sound(0);if(age==30)sound(1);if(age==65)sound(2);if(age==98)sound(3);
        if(age==100)next.setMessage(Component.literal("계속"));
    }
    private void sound(int n){var event=switch(n){case 0->SoundEvents.BEACON_ACTIVATE;case 1->SoundEvents.AMETHYST_BLOCK_CHIME;case 2->SoundEvents.AMETHYST_CLUSTER_BREAK;default->cue==PresentationCues.FAILURE?SoundEvents.NOTE_BLOCK_BASS.value():SoundEvents.PLAYER_LEVELUP;};minecraft.getSoundManager().play(SimpleSoundInstance.forUI(event,n==3?1.1F:.8F,.45F));}
    @Override public void onClose(){if(minecraft!=null)minecraft.setScreen(minecraft.player!=null&&minecraft.player.isAlive()&&minecraft.player.containerMenu==menu?previous:null);}
    @Override public void render(GuiGraphics g,int mouseX,int mouseY,float partial){
        float t=age+partial,cx=width*.5F,cy=height*.48F;int tint=cue==PresentationCues.FAILURE?0x9194AB:color;
        g.fillGradient(0,0,width,height,0xFF040916,0xFF172843);
        for(int i=0;i<66;i++){float x=(i*127.13F)%width,y=(i*67.87F)%height;float a=.2F+.4F*(float)Math.pow(Math.sin(i+t*.025),2);CeremonyOverlay.sprite(g,7,x,y,i%5==0?8:3,0,0xB4CDE8,a);}
        if(t<35){float gather=Math.min(1,t/28);for(int i=0;i<12;i++){double a=i*2.4+t*.03;float r=(1-gather)*Math.min(width,height)*.7F;CeremonyOverlay.sprite(g,7,cx+(float)Math.cos(a)*r,cy+(float)Math.sin(a)*r*.5F,10,0,0xAECFFF,gather);}
            CeremonyOverlay.sprite(g,0,cx,cy,Math.round(30+t*2),t*.025F,0x96D4FF,Math.min(1,t/12)*.7F);
        }else if(t<76){float f=Math.clamp((t-35)/32,0,1),x=width*.12F+width*.38F*f,y=-height*.18F+height*.66F*f*f;int c=t<53?0xC4E6FF:tint;
            for(int i=12;i>0;i--)CeremonyOverlay.sprite(g,7,x-i*5,y-i*7,Math.max(4,36-i*2),0,c,(13-i)/18F);
            CeremonyOverlay.sprite(g,7,x,y,64,t*.01F,c,1);
        }
        if(t>=65){float burst=Math.min(1,(t-65)/20),fade=t<90?1:Math.max(.3F,1-(t-90)/35);CeremonyOverlay.sprite(g,0,cx,cy,Math.round(100+burst*120),t*.012F,tint,fade*.6F);
            for(int i=0;i<16;i++){double a=i*Math.PI/8+t*.007;float r=burst*height*.4F;CeremonyOverlay.sprite(g,7,cx+(float)Math.cos(a)*r,cy+(float)Math.sin(a)*r*.55F,8+i%3*3,0,tint,fade*.7F);}
        }
        if(t>=80&&!item.isEmpty()){
            float rise=Math.min(1,(t-80)/20),scale=3.3F+rise*1.4F;g.pose().pushPose();g.pose().translate(cx,cy+(1-rise)*42-5,1200);g.pose().mulPose(Axis.ZP.rotationDegrees(t<105?(105-t)*-.7F:0));g.pose().scale(scale,scale,scale);g.renderItem(item,-8,-8);g.pose().popPose();
        }
        if(t>=98){g.pose().pushPose();g.pose().translate(0,0,1600);String title=switch(cue){case PresentationCues.CRAFT->value>=100&&value<102?"별빛 공방 제작 완료":"전설 장비 제작 완료";case PresentationCues.UPGRADE->"강화 성공  +"+value;case PresentationCues.FAILURE->"강화 실패 · +"+value+" 유지";case PresentationCues.ADVANCE->value+"차 전직 완료";default->"새로운 운명의 시작";};
            g.drawCenteredString(font,title,(int)cx,(int)(cy+66),0xFF000000|tint);
            if(!item.isEmpty())g.drawCenteredString(font,item.getHoverName(),(int)cx,(int)(cy+84),0xFFEAF2FF);
            String stars="✦ ".repeat(Math.min(6,Math.max(1,cue==PresentationCues.UPGRADE?value/5+1:cue==PresentationCues.FAILURE?1:3)));
            g.drawCenteredString(font,stars,(int)cx,(int)(cy+103),0xFF000000|tint);
            g.pose().popPose();
        }
        super.render(g,mouseX,mouseY,partial);
    }
}
