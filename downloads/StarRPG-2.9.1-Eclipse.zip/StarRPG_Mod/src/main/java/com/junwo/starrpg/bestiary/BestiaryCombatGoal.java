package com.junwo.starrpg.bestiary;

import java.util.EnumSet;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.goal.Goal;

public final class BestiaryCombatGoal extends Goal {
    private final BestiaryMob mob;
    private long nextPathUpdate;
    private int pathTarget=-1;
    private BlockPos targetPosition;

    public BestiaryCombatGoal(BestiaryMob mob){this.mob=mob;setFlags(EnumSet.of(Flag.MOVE,Flag.LOOK));}
    @Override public boolean canUse(){return mob.phase()!=BestiaryMob.IDLE||BestiaryCombat.valid(mob,mob.getTarget());}
    @Override public boolean requiresUpdateEveryTick(){return true;}
    @Override public void stop(){nextPathUpdate=0;pathTarget=-1;targetPosition=null;}
    @Override public void tick(){
        if(BossPhases.flying(mob))return;
        if(mob.phase()!=BestiaryMob.IDLE){mob.combatTick();return;}
        var target=mob.getTarget();
        if(!BestiaryCombat.valid(mob,target))return;
        mob.getLookControl().setLookAt(target,25,25);
        double range=mob.kind.move.ordinal()>=BestiaryKind.Move.HEX.ordinal()?mob.kind.reach()*.8:Math.max(2.1,mob.getBbWidth()+.8);
        if(mob.distanceToSqr(target)>range*range||!mob.hasLineOfSight(target)){
            long now=mob.level().getGameTime();
            BlockPos position=target.blockPosition();
            // Keep following the existing path. Changed targets/positions still react immediately.
            if(now>=nextPathUpdate||pathTarget!=target.getId()||!position.equals(targetPosition)){
                pathTarget=target.getId();targetPosition=position.immutable();
                boolean found=mob.getNavigation().moveTo(target,1);
                nextPathUpdate=now+(found?10:20);
            }
            return;
        }
        mob.getNavigation().stop();
        if(mob.level().getGameTime()>=mob.nextAttack&&mob.lifeTicks()>40)mob.startAttack(target,mob.distanceToSqr(target)>16||mob.nextHeavy());
    }
}
