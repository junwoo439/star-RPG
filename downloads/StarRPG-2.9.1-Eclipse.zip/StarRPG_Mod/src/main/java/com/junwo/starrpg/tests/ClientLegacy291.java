package com.junwo.starrpg.tests;

import com.junwo.starrpg.*;
import com.junwo.starrpg.awakening.*;
import com.junwo.starrpg.adventure.*;
import java.nio.file.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.nbt.*;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;

/** Opens a disposable COPY of a released-version save, verifies live deserialization, then saves normally. */
@EventBusSubscriber(modid=StarRPG.MODID,value=Dist.CLIENT)
public final class ClientLegacy291 {
    private static boolean started;private static volatile boolean checked;private static int ticks;
    private static void check(boolean ok,String why){if(!ok)throw new IllegalStateException("LEGACY291: "+why);}
    private static CompoundTag read(Path p)throws java.io.IOException{return NbtIo.readCompressed(p,NbtAccounter.unlimitedHeap());}
    @SubscribeEvent public static void client(net.neoforged.neoforge.client.event.ClientTickEvent.Post event)throws Exception{
        String source=System.getProperty("starrpg.legacy291","");if(source.isEmpty())return;var mc=Minecraft.getInstance();
        if(!started&&mc.screen instanceof TitleScreen&&mc.getOverlay()==null){started=true;Path original=mc.gameDirectory.toPath().resolve("saves").resolve(source);check(Files.isDirectory(original),"Missing original fixture");String copy="qa291-legacy-"+System.currentTimeMillis();Path destination=original.resolveSibling(copy);try(var paths=Files.walk(original)){for(var path:paths.toList()){if(path.getFileName().toString().equals("session.lock"))continue;Path target=destination.resolve(original.relativize(path));if(Files.isDirectory(path))Files.createDirectories(target);else Files.copy(path,target);}}mc.options.pauseOnLostFocus=false;mc.options.renderDistance().set(3);mc.getWindow().setWindowed(1000,740);mc.resizeDisplay();mc.createWorldOpenFlows().openWorld(copy,()->{throw new IllegalStateException("Legacy copy failed to open");});return;}
        if(mc.player==null||mc.getSingleplayerServer()==null)return;
        if(++ticks==1){var server=mc.getSingleplayerServer();var id=mc.player.getUUID();server.execute(()->{try{ServerPlayer p=server.getPlayerList().getPlayer(id);p.setInvulnerable(true);Path original=mc.gameDirectory.toPath().resolve("saves").resolve(source);var owner=read(original.resolve("level.dat")).getCompound("Data").getCompound("Player");var current=new CompoundTag();p.saveWithoutId(current);check(owner.get("Inventory").equals(current.get("Inventory")),"Inventory/enhancement/rune components changed");for(var key:new String[]{"SelectedItemSlot","EnderItems"})check(java.util.Objects.equals(owner.get(key),current.get(key)),key+" changed");
            var lookup=p.registryAccess();if(Files.exists(original.resolve("data/starrpg_awakening.dat"))){var oldAw=AwakeningData.load(read(original.resolve("data/starrpg_awakening.dat")).getCompound("data"),lookup);var liveAw=AwakeningData.get(server);for(var entry:oldAw.players.entrySet())check(entry.getValue().equals(liveAw.players.get(entry.getKey())),"Accessory/star/collection player profile changed");check(oldAw.world.equals(liveAw.world),"Party/village/raid world data changed");}
            if(Files.exists(original.resolve("data/starrpg_wallets.dat"))){var oldMoney=read(original.resolve("data/starrpg_wallets.dat")).getCompound("data");var liveMoney=StarWallet.get(server);for(var raw:oldMoney.getList("accounts",Tag.TAG_COMPOUND)){var account=(CompoundTag)raw;check(liveMoney.balance(account.getUUID("id"))==account.getLong("balance"),"Wallet changed");}}
            if(Files.exists(original.resolve("data/starrpg_adventure.dat"))){var oldProgress=AdventureData.load(read(original.resolve("data/starrpg_adventure.dat")).getCompound("data"),lookup).save(new CompoundTag(),lookup);check(oldProgress.equals(AdventureData.get(server).save(new CompoundTag(),lookup)),"Quest/dungeon/life progress changed");}
            if(source.startsWith("starrpg-dragon-280-")){int dragons=p.serverLevel().getEntitiesOfClass(com.junwo.starrpg.bestiary.BestiaryMob.class,p.getBoundingBox().inflate(64),m->m.kind.body==com.junwo.starrpg.bestiary.BestiaryKind.Body.DRAGON).size();check(dragons>0,"Existing 2.8 dragon disappeared");StarRPG.LOGGER.info("QA291_LEGACY_280_SAVED_DRAGON_RETAINED count={}",dragons);}
            Path careers=original.resolve("data/starrpg_careers.dat");if(Files.exists(careers)){var before=CareerData.load(read(careers).getCompound("data"),lookup).save(new CompoundTag(),lookup);var live=CareerData.get(server).save(new CompoundTag(),lookup);for(var raw:before.getList("profiles",Tag.TAG_COMPOUND)){var row=(CompoundTag)raw;check(live.getList("profiles",Tag.TAG_COMPOUND).stream().anyMatch(row::equals),"Career/skill counters changed");}}StarRPG.LOGGER.info("QA291_LEGACY_COPY_LIVE_INVENTORY_COMPONENTS_WALLETS_ACCESSORIES_STARS_PARTIES_QUESTS_OK source={} careersPresent={}",source,Files.exists(careers));checked=true;
        }catch(Exception e){throw new RuntimeException(e);}});}
        if(ticks==120&&source.startsWith("starrpg-dragon-280-"))net.minecraft.client.Screenshot.grab(mc.gameDirectory,"qa291-legacy-280-dragon.png",mc.getMainRenderTarget(),m->{});
        if(ticks>160&&checked){StarRPG.LOGGER.info("QA291_LEGACY_SAVE_EXIT_OK");mc.stop();}
    }
}
