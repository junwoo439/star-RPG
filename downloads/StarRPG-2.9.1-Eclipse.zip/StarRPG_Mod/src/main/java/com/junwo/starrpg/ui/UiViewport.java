package com.junwo.starrpg.ui;

/** Reversible screen/canvas mapping. Server slot coordinates and GUI preferences never change. */
public record UiViewport(int width,int height,float scale,float offsetX,float offsetY) {
    public static UiViewport fit(int screenWidth,int screenHeight,int contentWidth,int contentHeight) {
        int actualWidth=Math.max(1,screenWidth),actualHeight=Math.max(1,screenHeight);
        int width=Math.max(actualWidth,contentWidth+16),height=Math.max(actualHeight,contentHeight+16);
        float scale=Math.min(1,Math.min(actualWidth/(float)width,actualHeight/(float)height));
        return new UiViewport(width,height,scale,(actualWidth-width*scale)/2,(actualHeight-height*scale)/2);
    }
    public double mouseX(double x){return (x-offsetX)/scale;}
    public double mouseY(double y){return (y-offsetY)/scale;}
    public float screenX(float x){return offsetX+x*scale;}
    public float screenY(float y){return offsetY+y*scale;}
}
