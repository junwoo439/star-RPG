package com.junwo.starrpg.tests;

import com.junwo.starrpg.StarRPG;
import com.junwo.starrpg.bestiary.*;
import com.mojang.blaze3d.vertex.*;
import com.mojang.math.Axis;
import java.util.*;

/** Compares all 53 authored meshes against the released per-vertex transform path. Client QA only. */
public final class VertexOracle291 {
    private static Object field(Object object,String name)throws ReflectiveOperationException{var f=object.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(object);}
    private static float number(Object object,String name)throws ReflectiveOperationException{return (float)field(object,name);}
    private record Vertex(float x,float y,float z,float u,float v,float nx,float ny,float nz,int color,int overlay,int light){}
    private static final class Capture implements VertexConsumer {
        final List<Vertex> vertices=new ArrayList<>();float x,y,z,u,v;int color,overlay,light;
        public VertexConsumer addVertex(float x,float y,float z){this.x=x;this.y=y;this.z=z;return this;}
        public VertexConsumer setColor(int r,int g,int b,int a){color=a<<24|r<<16|g<<8|b;return this;}
        public VertexConsumer setUv(float u,float v){this.u=u;this.v=v;return this;}
        public VertexConsumer setUv1(int u,int v){overlay=u|v<<16;return this;}
        public VertexConsumer setUv2(int u,int v){light=u|v<<16;return this;}
        public VertexConsumer setNormal(float nx,float ny,float nz){vertices.add(new Vertex(x,y,z,u,v,nx,ny,nz,color,overlay,light));return this;}
    }
    private static void released(CreatureMesh.Node node,PoseStack pose,VertexConsumer consumer,int light,int overlay,float alpha)throws ReflectiveOperationException{
        if(!node.visible)return;alpha*=node.alpha;if(alpha<.01F)return;pose.pushPose();pose.translate((node.px+node.dx)/16,(node.py+node.dy)/16,(node.pz+node.dz)/16);pose.mulPose(Axis.ZP.rotation(node.zRot));pose.mulPose(Axis.YP.rotation(node.yRot));pose.mulPose(Axis.XP.rotation(node.xRot));pose.scale(node.sx,node.sy,node.sz);
        for(var face:(List<?>)field(node,"faces")){int color=((int)(Math.clamp(alpha,0,1)*255)<<24)|(int)field(face,"color");float[][] points=(float[][])field(face,"points");float u=number(face,"u"),t=number(face,"t"),su=number(face,"spanU"),sv=number(face,"spanV"),nx=number(face,"nx"),ny=number(face,"ny"),nz=number(face,"nz");for(int i=0;i<4;i++){var q=points[i];consumer.addVertex(pose.last(),q[0]/16,q[1]/16,q[2]/16).setColor(color).setUv(u+(i==1||i==2?su:0),t+(i>=2?sv:0)).setOverlay(overlay).setLight((boolean)field(face,"glow")?15728880:light).setNormal(pose.last(),nx,ny,nz);}}
        for(var child:node.children)released(child,pose,consumer,light,overlay,alpha);pose.popPose();
    }
    private static void perturb(CreatureMesh.Node node){node.xRot+=.13F;node.yRot-=.21F;node.zRot+=.09F;node.sx*=1.2F;node.sy*=.8F;node.sz*=1.1F;node.alpha=.87F;for(var child:node.children)perturb(child);}
    public static void verify(){try{long count=0;for(var kind:BestiaryKind.values())for(int state=0;state<2;state++){var model=new BestiaryModel(kind);var root=(CreatureMesh.Node)field(model,"root");if(state==1)perturb(root);var expected=new Capture();var actual=new Capture();released(root,new PoseStack(),expected,123456,654321,.73F);root.render(new PoseStack(),actual,123456,654321,.73F);if(expected.vertices.size()!=actual.vertices.size())throw new IllegalStateException("Vertex count changed "+kind);for(int i=0;i<actual.vertices.size();i++){var a=actual.vertices.get(i);var b=expected.vertices.get(i);boolean same=a.color==b.color&&a.overlay==b.overlay&&a.light==b.light;float[] x={a.x,a.y,a.z,a.u,a.v,a.nx,a.ny,a.nz},y={b.x,b.y,b.z,b.u,b.v,b.nx,b.ny,b.nz};for(int k=0;k<x.length;k++)same&=Float.isFinite(x[k])&&Math.abs(x[k]-y[k])<.00002F;if(!same)throw new IllegalStateException("Vertex/normal/material changed "+kind+" state="+state+" vertex="+i+" actual="+a+" expected="+b);}count+=actual.vertices.size();}StarRPG.LOGGER.info("QA291_ALL53_VERTEX_NORMAL_COLOR_UV_LIGHT_ORACLE_OK vertices={}",count);}catch(ReflectiveOperationException e){throw new RuntimeException(e);}}
}
