package com.junwo.starrpg.tests;

import com.junwo.starrpg.StarRPG;
import java.util.*;
import java.nio.file.*;
import com.google.gson.*;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.*;
import net.neoforged.fml.common.EventBusSubscriber;

/** Opt-in measurement only. Excluded from the released JAR. Times do not include deliberate tick sleep. */
@EventBusSubscriber(modid=StarRPG.MODID,value=Dist.CLIENT)
public final class QaMeasurements291 {
    private static final List<Double> ticks=new ArrayList<>(),frames=new ArrayList<>();
    private static long tickStart,frameStart;private static volatile String scenario="";
    public static synchronized void begin(String name){scenario=name;ticks.clear();frames.clear();frameStart=0;tickStart=0;}
    @SubscribeEvent(priority=EventPriority.HIGHEST) public static void before(net.neoforged.neoforge.event.tick.ServerTickEvent.Pre e){if(!scenario.isEmpty())tickStart=System.nanoTime();}
    @SubscribeEvent(priority=EventPriority.LOWEST) public static synchronized void after(net.neoforged.neoforge.event.tick.ServerTickEvent.Post e){if(!scenario.isEmpty()&&tickStart!=0&&ticks.size()<10000)ticks.add((System.nanoTime()-tickStart)/1e6);}
    @SubscribeEvent public static synchronized void frame(net.neoforged.neoforge.client.event.RenderFrameEvent.Post e){if(scenario.isEmpty())return;long now=System.nanoTime();if(frameStart!=0&&frames.size()<10000)frames.add((now-frameStart)/1e6);frameStart=now;}
    private static JsonObject distribution(List<Double> values){var out=new JsonObject();if(values.isEmpty())return out;var sorted=new ArrayList<>(values);Collections.sort(sorted);out.addProperty("samples",sorted.size());out.addProperty("mean_ms",values.stream().mapToDouble(Double::doubleValue).average().orElse(0));for(int p:new int[]{50,95,99})out.addProperty("p"+p+"_ms",sorted.get(Math.min(sorted.size()-1,(int)Math.ceil(sorted.size()*p/100.0)-1)));out.addProperty("max_ms",sorted.getLast());return out;}
    public static synchronized void finish(Path output)throws java.io.IOException{var row=new JsonObject();row.addProperty("scenario",scenario);row.addProperty("participants",scenario.equals("two-native-tcp-clients")?2:Integer.getInteger("starrpg.qa291.players",1));row.addProperty("participant_kind",scenario.equals("two-native-tcp-clients")?"two native TCP clients":"one native client plus server-only simulated actors");row.addProperty("renderer","native Minecraft / Mesa llvmpipe; simulated participants are server-only actors");row.add("server_tick",distribution(ticks));row.add("client_frame",distribution(frames));Files.createDirectories(output.getParent());Files.writeString(output,row+"\n",StandardOpenOption.CREATE,StandardOpenOption.APPEND);StarRPG.LOGGER.info("QA291_MEASUREMENT {}",row);scenario="";}
}
