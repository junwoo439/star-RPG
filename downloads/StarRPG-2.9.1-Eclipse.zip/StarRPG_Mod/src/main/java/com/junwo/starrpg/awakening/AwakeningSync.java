package com.junwo.starrpg.awakening;

import com.google.gson.*;
import com.junwo.starrpg.*;
import com.junwo.starrpg.adventure.*;
import com.junwo.starrpg.bestiary.*;
import java.util.*;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.network.PacketDistributor;

@EventBusSubscriber(modid=StarRPG.MODID)
public final class AwakeningSync {
    private static final Map<ServerPlayer,String> LAST=new WeakHashMap<>();
    public static JsonObject snapshot(ServerPlayer p,boolean menu){var root=new JsonObject();var hud=new JsonArray();var party=Parties.party(p);for(var id:Parties.members(party)){var member=p.getServer().getPlayerList().getPlayer(id);var row=new JsonObject();row.addProperty("name",member==null?"접속 종료":member.getGameProfile().getName());row.addProperty("hp",member==null?0:Math.round(member.getHealth()));row.addProperty("max",member==null?0:Math.round(member.getMaxHealth()));row.addProperty("state",member==null?"오프라인":!member.isAlive()?"사망":member.level()!=p.level()?"다른 차원":ControlEffects.stunned(member)?"기절":member.isOnFire()?"화상":Math.round(member.distanceTo(p))+"m");hud.add(row);}root.add("party",hud);var auras=new JsonArray();for(var other:p.serverLevel().players())if(other.distanceToSqr(p)<1024&&Constellations.active(other)>=0){var aura=new JsonObject();aura.addProperty("id",other.getId());aura.addProperty("star",Constellations.active(other));auras.add(aura);}root.add("auras",auras);if(!menu)return root;
        root.addProperty("gold",StarWallet.get(p.getServer()).balance(p.getUUID()));root.add("tabs",AwakeningPages.build(p));return root;
    }
    public static void send(ServerPlayer p,boolean force){String value=snapshot(p,p.containerMenu instanceof AwakeningMenu).toString();if(force||p.tickCount%20==0&&value.contains("\"star\"")||!value.equals(LAST.get(p))){LAST.put(p,value);PacketDistributor.sendToPlayer(p,new AwakeningPayloads.Snapshot(value));}}
    @SubscribeEvent public static void tick(net.neoforged.neoforge.event.tick.PlayerTickEvent.Post e){if(e.getEntity() instanceof ServerPlayer p&&p.tickCount%10==0)send(p,false);}
}
