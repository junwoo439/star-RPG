package com.junwo.starrpg.bestiary;

import com.junwo.starrpg.StarRPG;
import com.mojang.blaze3d.vertex.PoseStack;
import java.lang.reflect.*;
import java.util.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.world.entity.*;
import net.neoforged.fml.ModList;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;

/** Optional CE 2.0 visual adapter. Proxies are never added to a level or ticked as game entities. */
@EventBusSubscriber(modid=StarRPG.MODID,value=Dist.CLIENT)
public final class IceAndFireDragonVisual {
    private static final Map<BestiaryMob,View> VIEWS=new WeakHashMap<>();
    private static final Map<String,Field> FIELDS=new HashMap<>();
    private static final Map<String,Method> METHODS=new HashMap<>();
    private static final Map<Class<?>,Map<String,Method>> BUFFER_METHODS=new HashMap<>();
    private static Class<?> dragonClass,animationClass;
    private static Object level;
    private static boolean failed,announced;
    @SubscribeEvent public static void disconnect(net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent.LoggingOut event){VIEWS.clear();level=null;}
    private static Field field(String name)throws ReflectiveOperationException {
        Field f=FIELDS.get(name);if(f==null){f=dragonClass.getField(name);FIELDS.put(name,f);}return f;
    }
    private static void value(Object proxy,String name,Object value)throws ReflectiveOperationException {field(name).set(proxy,value);}
    private static Method method(String name,Class<?>... types)throws ReflectiveOperationException {var cached=METHODS.get(name);if(cached==null){cached=dragonClass.getMethod(name,types);METHODS.put(name,cached);}return cached;}
    private static void call(Object proxy,String name,Class<?> type,Object value)throws ReflectiveOperationException {method(name,type).invoke(proxy,value);}
    public static boolean available(){return !failed&&ModList.get().isLoaded("iceandfire");}
    public static String entity(BestiaryKind k){return switch(k){case WHITE_DRAGON,SILVER_DRAGON->"iceandfire:ice_dragon";case BLUE_DRAGON,BRONZE_DRAGON,BLACK_DRAGON->"iceandfire:lightning_dragon";default->"iceandfire:fire_dragon";};}
    public static String variant(BestiaryKind k){return switch(k){case GREEN_DRAGON->"green";case GOLD_DRAGON,BRASS_DRAGON,COPPER_DRAGON->"bronze";case WHITE_DRAGON->"white";case SILVER_DRAGON->"silver";case BLUE_DRAGON->"electric";case BRONZE_DRAGON->"copper";case BLACK_DRAGON->"black";default->"red";};}
    @SuppressWarnings({"rawtypes","unchecked"})
    public static boolean render(BestiaryMob source,float yaw,float partial,PoseStack pose,MultiBufferSource buffers,int light){
        if(source.kind.body!=BestiaryKind.Body.DRAGON||!available())return false;
        try{
            if(dragonClass==null){dragonClass=Class.forName("com.iafenvoy.iceandfire.entity.DragonBaseEntity");animationClass=Class.forName("com.iafenvoy.uranus.animation.Animation");}
            if(level!=source.level()){VIEWS.clear();level=source.level();}
            View view=VIEWS.get(source);
            if(view==null){var type=EntityType.byString(entity(source.kind)).orElseThrow();var proxy=(Mob)type.create(source.level());if(proxy==null)throw new IllegalStateException("Missing CE dragon type");view=new View(proxy);VIEWS.put(source,view);call(proxy,"setAgeInDays",int.class,75);call(proxy,"setVariant",String.class,variant(source.kind));proxy.setSilent(true);proxy.setNoGravity(true);}
            view.update(source,partial);
            EntityRenderer renderer=Minecraft.getInstance().getEntityRenderDispatcher().getRenderer(view.proxy);
            pose.pushPose();
            // Adult proportions fit the original StarRPG collision envelope; do not scale with difficulty.
            pose.scale(.82F,.82F,.82F);
            try{renderer.render(view.proxy,yaw,partial,pose,SpeciesTint.buffers(source.kind,buffers),light);}finally{pose.popPose();}
            if(!announced){announced=true;StarRPG.LOGGER.info("ICE_AND_FIRE_CE_VISUAL_ACTIVE: CE models and articulated animation, StarRPG entity/combat/rewards retained");}
            return true;
        }catch(ReflectiveOperationException|RuntimeException|LinkageError error){failed=true;VIEWS.clear();StarRPG.LOGGER.error("IceAndFire CE visual adapter unavailable; using StarRPG dragon renderer",error);return false;}
    }
    private static final class View {
        final Mob proxy;int lastTick=-1,action=-1,phase=-1,animationTick;float breath,dive,air;
        View(Mob proxy){this.proxy=proxy;}
        void update(BestiaryMob source,float partial)throws ReflectiveOperationException {
            proxy.setPos(source.position());proxy.xo=source.xo;proxy.yo=source.yo;proxy.zo=source.zo;
            proxy.setYRot(source.getYRot());proxy.yRotO=source.yRotO;proxy.yBodyRot=source.yBodyRot;proxy.yBodyRotO=source.yBodyRotO;
            proxy.yHeadRot=source.yHeadRot;proxy.yHeadRotO=source.yHeadRotO;proxy.setXRot(source.getXRot());proxy.xRotO=source.xRotO;
            proxy.setDeltaMovement(source.getDeltaMovement());proxy.setOnGround(source.onGround());proxy.tickCount=source.tickCount;
            proxy.hurtTime=source.hurtTime;proxy.deathTime=source.deathTime;
            if(lastTick==source.tickCount)return;
            lastTick=source.tickCount;proxy.walkAnimation.update(source.walkAnimation.speed(),1);
            float[] previous=(float[])field("prevAnimationProgresses").get(proxy);previous[2]=0;previous[3]=air*20;previous[4]=breath;
            value(proxy,"prevFireBreathProgress",breath);value(proxy,"prevDiveProgress",dive);
            air=source.flightBlend(1);boolean breathing=source.dragonAction()==DragonBattle.BREATH&&(source.phase()==BestiaryMob.HEAVY||source.phase()==BestiaryMob.ACTIVE||air>.1F);
            breath+=Math.clamp((breathing?10:0)-breath,-.8F,.8F);dive+=Math.clamp((source.dragonAction()==DragonBattle.DIVE?10:0)-dive,-.8F,.8F);
            value(proxy,"flyProgress",air*20);value(proxy,"hoverProgress",0F);value(proxy,"fireBreathProgress",breath);value(proxy,"diveProgress",dive);
            value(proxy,"flightCycle",source.tickCount*2%60);value(proxy,"walkCycle",(int)(source.walkAnimation.position()*7)%40);
            value(proxy,"fireBreathTicks",breathing?40:0);call(proxy,"setFlying",boolean.class,air>.05F);call(proxy,"setHovering",boolean.class,false);call(proxy,"setBreathingFire",boolean.class,breathing);
            float pitch=(float)Math.clamp(-source.getDeltaMovement().y*55,-25,35);value(proxy,"prevDragonPitch",method("getDragonPitch").invoke(proxy));call(proxy,"setDragonPitch",float.class,pitch);
            int nextAction=source.dragonAction(),nextPhase=source.phase();
            if(action!=nextAction||phase!=nextPhase){if(action!=nextAction||nextPhase==BestiaryMob.HEAVY||nextPhase==BestiaryMob.QUICK||nextPhase==BestiaryMob.IDLE)animationTick=0;action=nextAction;phase=nextPhase;String animation=phase==BestiaryMob.IDLE||phase==BestiaryMob.STAGGER?null:action==DragonBattle.TAIL?"ANIMATION_TAILWHACK":action==DragonBattle.WING?"ANIMATION_WINGBLAST":action==DragonBattle.BITE?"ANIMATION_BITE":null;Object clip=animation==null?Class.forName("com.iafenvoy.uranus.animation.IAnimatedEntity").getField("NO_ANIMATION").get(null):field(animation).get(null);call(proxy,"setAnimation",animationClass,clip);}
            call(proxy,"setAnimationTick",int.class,Math.min((int)(++animationTick*(action==DragonBattle.BITE?1.5F:1)),action==DragonBattle.BITE?30:action==DragonBattle.TAIL?40:45));
            buffer("tail_buffer","calculateChainSwingBuffer",70,10,4);
            buffer("turn_buffer","calculateChainSwingBuffer",25,0,2);
            buffer("roll_buffer","calculateChainFlapBuffer",35,0,3);
            buffer("pitch_buffer_body","calculateChainWaveBuffer",35,0,3);
            buffer("pitch_buffer","calculateChainWaveBuffer",35,0,3);
        }
        void buffer(String fieldName,String method,float limit,int delay,float speed)throws ReflectiveOperationException {Object buffer=field(fieldName).get(proxy);if(buffer!=null){var methods=BUFFER_METHODS.computeIfAbsent(buffer.getClass(),key->new HashMap<>());var cached=methods.get(method);if(cached==null){cached=buffer.getClass().getMethod(method,float.class,int.class,float.class,LivingEntity.class);methods.put(method,cached);}cached.invoke(buffer,limit,delay,speed,proxy);}}
    }
}
