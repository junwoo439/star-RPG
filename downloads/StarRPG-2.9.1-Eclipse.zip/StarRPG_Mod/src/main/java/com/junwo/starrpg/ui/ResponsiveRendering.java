package com.junwo.starrpg.ui;
import com.junwo.starrpg.StarRPG;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.*;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ScreenEvent;

/** Includes Screen's final deferred-tooltip pass; only StarRPG screens opt in. */
@EventBusSubscriber(modid=StarRPG.MODID,value=Dist.CLIENT)
public final class ResponsiveRendering {
    @SubscribeEvent(priority=EventPriority.LOWEST)
    public static void render(ScreenEvent.Render.Pre event){
        if(event.isCanceled()||!(event.getScreen() instanceof ResponsiveUi screen))return;
        var viewport=screen.viewport();if(viewport.scale()==1)return;
        event.setCanceled(true);var graphics=event.getGuiGraphics();graphics.pose().pushPose();
        try{graphics.pose().translate(viewport.offsetX(),viewport.offsetY(),0);graphics.pose().scale(viewport.scale(),viewport.scale(),1);event.getScreen().renderWithTooltip(graphics,(int)Math.floor(viewport.mouseX(event.getMouseX())),(int)Math.floor(viewport.mouseY(event.getMouseY())),event.getPartialTick());}
        finally{graphics.pose().popPose();}
    }
}
