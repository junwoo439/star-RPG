package com.junwo.starrpg.tests;

import com.junwo.starrpg.*;
import com.junwo.starrpg.awakening.*;
import com.junwo.starrpg.bestiary.*;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.item.*;
import net.minecraft.world.phys.Vec3;

/** Real server damage/cast paths with explicitly simulated party sizes; never a network-client claim. */
public final class QaCombat291 {
    private static void check(boolean ok,String why){if(!ok)throw new IllegalStateException("QA291_COMBAT: "+why);}
    private static Item weapon(int job){return switch(job){case 0->StarRPG.STAR_SPEAR.get();case 1->StarRPG.STAR_DAGGER.get();case 2->Items.BOW;case 4->StarRPG.WAR_HAMMER.get();case 5->StarRPG.BERSERKER_BLADE.get();case 7->StarRPG.SOUL_SCYTHE.get();case 8->StarRPG.STAR_GAUNTLET.get();default->StarRPG.MAGIC_STAFF.get();};}
    public static void run(ServerPlayer owner){
        var actors=QaActors291.actors();var positions=actors.stream().map(Entity::position).toList();var original=owner.getMainHandItem().copy();var profile=Careers.profile(owner);int selected=profile.selected;int[] ranks=profile.ranks.clone();var l=owner.serverLevel();
        for(int count:new int[]{1,2,4,16}){
            for(int i=0;i<actors.size();i++)actors.get(i).setPos(owner.position().add(i<Math.min(count-1,3)?new Vec3(1+i*.6,0,0):new Vec3(48,i*.1,0)));
            var boss=BestiaryRegistry.TYPES.get(BestiaryKind.LICH).get().create(l);boss.setPos(owner.position().add(0,0,8));float base=boss.getMaxHealth();EncounterScaling.scale(boss,owner);check(Math.abs(boss.getMaxHealth()/base-(1+.45*(Math.min(4,count)-1)))<.001,"Party scaling "+count);float hp=boss.getMaxHealth();EncounterScaling.scale(boss,owner);check(boss.getMaxHealth()==hp,"Scaling stacked");
            for(int job:Careers.ACTIVE){
                owner.removeAllEffects();WeaponAbilities.cancel(owner);profile.selected=job;profile.ranks[job]=10;var stack=new ItemStack(weapon(job));EnhancementData.setLevel(stack,25);owner.setItemInHand(InteractionHand.MAIN_HAND,stack);Careers.updateAttributes(owner);owner.setYRot(0);owner.setXRot(12);owner.getPersistentData().putLong("starrpg_career_ready",0);check(Careers.cast(owner)&&!Careers.cast(owner),"G activation/cooldown "+job);
                var victim=EntityType.COW.create(l);victim.setPos(owner.position().add(0,0,4));victim.setNoGravity(true);victim.setNoAi(true);victim.getAttribute(Attributes.MAX_HEALTH).setBaseValue(1000000);victim.setHealth(1000000);l.addFreshEntity(victim);float before=victim.getHealth();
                if(Careers.mage(job)){owner.getPersistentData().putLong("starrpg_spell_ready",0);MagicSystem.restore(owner,1000);MagicSystem.choose(owner,0);check(MagicSystem.cast(owner)&&!MagicSystem.cast(owner),"Spell activation/cooldown "+job);var bolts=l.getEntitiesOfClass(MagicBolt.class,owner.getBoundingBox().inflate(8),b->b.getOwner()==owner);check(!bolts.isEmpty(),"Missing projectile");for(var bolt:bolts){for(int t=0;t<10&&!bolt.isRemoved();t++)bolt.tick();bolt.discard();}}
                else if(job==2){var arrow=new Arrow(l,owner,new ItemStack(Items.ARROW),stack);arrow.setPos(owner.position().add(0,.8,1));arrow.shoot(0,0,1,1.5F,0);l.addFreshEntity(arrow);for(int t=0;t<8&&!arrow.isRemoved();t++)arrow.tick();arrow.discard();}
                else{victim.setPos(owner.position().add(0,0,1.5));owner.attack(victim);}
                check(victim.getHealth()<before&&Float.isFinite(victim.getHealth()),"Actual damage missing "+job+" group "+count);check(EnhancementData.level(stack)==25,"Combat erased enhancement");StarRPG.LOGGER.info("QA291_COMBAT_JOB_OK simulatedParticipants={} job={} damage={}",count,job,before-victim.getHealth());victim.discard();
            }
        }
        for(int i=0;i<actors.size();i++)actors.get(i).setPos(positions.get(i));owner.removeAllEffects();owner.setItemInHand(InteractionHand.MAIN_HAND,original);profile.selected=selected;profile.ranks=ranks;Careers.updateAttributes(owner);StarRPG.LOGGER.info("QA291_COMBAT_13_JOBS_FOUR_GROUP_SIZES_OK");
    }
}
