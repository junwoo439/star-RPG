package com.junwo.starrpg.tests;

import com.junwo.starrpg.*;
import com.junwo.starrpg.adventure.*;
import com.junwo.starrpg.awakening.*;
import com.junwo.starrpg.bestiary.*;
import com.junwo.starrpg.ui.*;
import net.minecraft.client.*;
import net.minecraft.client.gui.screens.*;
import net.minecraft.core.*;
import net.minecraft.server.level.*;
import net.minecraft.world.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.*;
import net.minecraft.world.level.levelgen.presets.WorldPresets;
import net.minecraft.world.phys.*;
import java.nio.file.*;
import java.lang.management.ManagementFactory;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;

/** Reproducible visual/CPU scenarios, using real AI and native rendering in a new isolated world. */
@EventBusSubscriber(modid=StarRPG.MODID,value=Dist.CLIENT)
public final class ClientQa291 {
    private static boolean started,configured;private static volatile boolean failed,ready,done,benchReady;private static int tick;private static volatile int serverTick;private static jdk.jfr.Recording recording;private static BestiaryMob specimen;private static LivingEntity target;
    private static String mode(){return System.getProperty("starrpg.qa291","");}
    private static void check(boolean value,String reason){if(!value)throw new IllegalStateException("QA291: "+reason);}
    private static void server(net.minecraft.server.MinecraftServer s,Runnable action){s.execute(()->{try{action.run();}catch(Throwable error){failed=true;throw error;}});}
    private static void clean(ServerPlayer p){p.closeContainer();p.serverLevel().getEntitiesOfClass(Entity.class,p.getBoundingBox().inflate(100),e->e instanceof BestiaryMob||e instanceof ArcaneSigil||e instanceof BossSpell||e instanceof net.minecraft.world.entity.animal.Cow).forEach(Entity::discard);}
    private static void screenshot(Minecraft mc,String name){Screenshot.grab(mc.gameDirectory,"qa291-"+mode()+"-"+name+".png",mc.getMainRenderTarget(),m->{});}
    @SubscribeEvent public static void client(net.neoforged.neoforge.client.event.ClientTickEvent.Post event)throws Exception{
        if(mode().isEmpty())return;var mc=Minecraft.getInstance();if(!started&&mc.screen instanceof TitleScreen&&mc.getOverlay()==null){started=true;mc.options.pauseOnLostFocus=false;mc.options.guiScale().set(2);mc.options.renderDistance().set(3);mc.options.simulationDistance().set(5);mc.options.cloudStatus().set(CloudStatus.OFF);mc.options.framerateLimit().set(60);mc.options.enableVsync().set(false);mc.getWindow().setWindowed(1280,800);mc.resizeDisplay();mc.createWorldOpenFlows().createFreshLevel("starrpg-qa291-"+mode()+"-"+System.currentTimeMillis(),new LevelSettings("StarRPG 291 isolated QA",GameType.CREATIVE,false,Difficulty.NORMAL,true,new GameRules(),WorldDataConfiguration.DEFAULT),new WorldOptions(291,false,false),registry->registry.registryOrThrow(net.minecraft.core.registries.Registries.WORLD_PRESET).getHolderOrThrow(WorldPresets.FLAT).value().createWorldDimensions(),mc.screen);return;}
        if(mc.player==null||mc.level==null||mc.getSingleplayerServer()==null)return;if(failed)throw new IllegalStateException("QA291 server assertion failed; inspect log");var s=mc.getSingleplayerServer();var id=mc.player.getUUID();
        if(!configured){configured=true;mc.setScreen(null);server(s,()->{var p=s.getPlayerList().getPlayer(id);var l=p.serverLevel();l.setDayTime(6000);l.getGameRules().getRule(GameRules.RULE_DAYLIGHT).set(false,s);l.getGameRules().getRule(GameRules.RULE_DOMOBSPAWNING).set(false,s);l.getGameRules().getRule(GameRules.RULE_DOBLOCKDROPS).set(false,s);WorldDifficulty.get(s).setTier(0);for(int x=-48;x<=48;x++)for(int z=-40;z<=48;z++)l.setBlock(new BlockPos(x,180,z),Blocks.SMOOTH_STONE.defaultBlockState(),2);p.teleportTo(l,0,181,-6,0,0);p.setNoGravity(true);p.setGameMode(GameType.SURVIVAL);p.setInvulnerable(true);ready=true;});return;}
        if(!ready)return;if(tick==0)VertexOracle291.verify();tick++;
        if(mode().equals("ui-extra")||mode().equals("ui-tooltip")){uiExtra(mc,s,id);return;}
        if(mode().equals("ui")){ui(mc,s,id);return;}
        if(mode().equals("audit")){audit(mc,s,id);return;}
        if(mode().startsWith("bench")){if(tick==1)server(s,()->{try{QaActors291.group(s.getPlayerList().getPlayer(id),Integer.getInteger("starrpg.qa291.players",1));benchReady=true;}catch(ReflectiveOperationException e){throw new RuntimeException(e);}});if(done){StarRPG.LOGGER.info("QA291_BENCH_COMPLETE");mc.stop();}return;}
    }
    private static void ui(Minecraft mc,net.minecraft.server.MinecraftServer s,java.util.UUID id){
        int[][] cases={{854,480,4},{640,480,3},{1280,720,4},{1280,800,2},{1920,1080,5}};int scenario=(tick-1)/100,step=tick%100;int screen=scenario%6,size=scenario/6;
        if(size>=cases.length){if(tick%20==0){StarRPG.LOGGER.info("QA291_UI_COMPLETE_30_RESIZE_CASES");mc.stop();}return;}
        if(step==1){mc.getWindow().setWindowed(cases[size][0],cases[size][1]);mc.options.guiScale().set(cases[size][2]);mc.resizeDisplay();server(s,()->{var p=s.getPlayerList().getPlayer(id);p.closeContainer();switch(screen){case 0->p.openMenu(new net.minecraft.world.SimpleMenuProvider((n,inv,who)->new MaterialShopMenu(n,inv),net.minecraft.network.chat.Component.literal("StarRPG")));case 1->AwakeningMenu.open(p,0);case 2->p.openMenu(new net.minecraft.world.SimpleMenuProvider((n,inv,who)->new AdventureMenu(n,inv),net.minecraft.network.chat.Component.literal("모험")));case 3->p.openMenu(new net.minecraft.world.SimpleMenuProvider((n,inv,who)->new EnhancementMenu(n,inv),net.minecraft.network.chat.Component.literal("강화")));case 4->p.openMenu(new net.minecraft.world.SimpleMenuProvider((n,inv,who)->new RuneEngravingMenu(n,inv),net.minecraft.network.chat.Component.literal("룬")));default->{} }if(screen==1){p.getInventory().setItem(9,new ItemStack(AwakeningItems.RING.get()));Accessories.inventory(p).setItem(0,ItemStack.EMPTY);p.containerMenu.broadcastChanges();}});}
        if(screen==5&&step==20)mc.setScreen(new StarRevealScreen(null,mc.player.containerMenu,PresentationCues.UPGRADE,25,0xFFD76A,new ItemStack(StarRPG.STAR_SPEAR.get())));
        if(step==45){check(mc.screen instanceof ResponsiveUi,"Screen missing viewport "+screen);var view=((ResponsiveUi)mc.screen).viewport();for(var child:mc.screen.children())if(child instanceof net.minecraft.client.gui.components.AbstractWidget w){check(view.screenX(w.getX())>=-1&&view.screenY(w.getY())>=-1&&view.screenX(w.getRight())<=mc.getWindow().getGuiScaledWidth()+1&&view.screenY(w.getBottom())<=mc.getWindow().getGuiScaledHeight()+1,"Widget clipped at "+scenario);}
            if(mc.screen instanceof ResponsiveContainerScreen<?> container)for(var slot:container.getMenu().slots){var left=(view.width()-((net.minecraft.client.gui.screens.inventory.AbstractContainerScreen<?>)mc.screen).getXSize())/2;var top=(view.height()-((net.minecraft.client.gui.screens.inventory.AbstractContainerScreen<?>)mc.screen).getYSize())/2;check(view.screenX(left+slot.x)>=0&&view.screenY(top+slot.y)>=0&&view.screenX(left+slot.x+16)<=mc.getWindow().getGuiScaledWidth()&&view.screenY(top+slot.y+16)<=mc.getWindow().getGuiScaledHeight(),"Slot clipped "+scenario);}
            screenshot(mc,"screen-"+screen+"-"+cases[size][0]+"x"+cases[size][1]+"-scale"+cases[size][2]);StarRPG.LOGGER.info("QA291_UI_CASE_OK {} {}",scenario,view);
        }
        if(screen==1&&step==55&&mc.screen instanceof AwakeningScreen awake){var v=awake.viewport();var slot=awake.getMenu().getSlot(3);int left=(v.width()-400)/2,top=(v.height()-312)/2;double x=v.screenX(left+slot.x+8),y=v.screenY(top+slot.y+8);check(awake.mouseClicked(x,y,0),"Scaled slot click unhandled");awake.mouseReleased(x,y,0);var dest=awake.getMenu().getSlot(0);x=v.screenX(left+dest.x+8);y=v.screenY(top+dest.y+8);awake.mouseClicked(x,y,0);awake.mouseReleased(x,y,0);}
        if(screen==1&&step==85)server(s,()->check(Accessories.equipped(s.getPlayerList().getPlayer(id),0).is(AwakeningItems.RING.get()),"Scaled click did not equip ring on server"));
    }
    private static void uiExtra(Minecraft mc,net.minecraft.server.MinecraftServer server,java.util.UUID id){
        int scene=(tick-1)/160,step=tick%160;if(scene>=2){if(mode().equals("ui-tooltip")){if(step==10){StarRPG.LOGGER.info("QA291_UI_TOOLTIP_POINTER_AND_EMPTY_CARRIED_OK");mc.stop();}}else dragonFlight(mc,server,id);return;}
        if(step==1){mc.getWindow().setWindowed(640,480);mc.options.guiScale().set(4);mc.resizeDisplay();server(server,()->{var p=server.getPlayerList().getPlayer(id);p.closeContainer();if(scene==0)AwakeningMenu.open(p,0);else p.openMenu(new net.minecraft.world.SimpleMenuProvider((n,inv,who)->new EnhancementMenu(n,inv),net.minecraft.network.chat.Component.literal("강화")));for(int slot=9;slot<=12;slot++)p.getInventory().setItem(slot,slot==9?new ItemStack(StarRPG.STAR_DUST.get(),10):ItemStack.EMPTY);p.containerMenu.broadcastChanges();});}
        if(step==35){mc.getWindow().setWindowed(854,480);mc.options.guiScale().set(3);mc.resizeDisplay();}
        if(step==55){mc.getWindow().setWindowed(640,480);mc.options.guiScale().set(4);mc.resizeDisplay();}
        if(mc.screen instanceof ResponsiveContainerScreen<?> screen){
            var v=screen.viewport();int left=(v.width()-screen.getXSize())/2,top=(v.height()-screen.getYSize())/2;
            java.util.function.IntFunction<net.minecraft.world.inventory.Slot> slot=inv->screen.getMenu().slots.stream().filter(a->a.container==mc.player.getInventory()&&a.getContainerSlot()==inv).findFirst().orElseThrow();
            java.util.function.IntFunction<Vec3> point=inv->{var a=slot.apply(inv);return new Vec3(v.screenX(left+a.x+8),v.screenY(top+a.y+8),0);};
            if(step==75){var a=point.apply(9);screen.mouseClicked(a.x,a.y,0);screen.mouseReleased(a.x,a.y,0);}
            if(step==85){var a=point.apply(10);screen.mouseClicked(a.x,a.y,1);for(int inv=10;inv<=12;inv++){var b=point.apply(inv);screen.mouseDragged(b.x,b.y,1,b.x-a.x,b.y-a.y);a=b;}screen.mouseReleased(a.x,a.y,1);}
            if(step==100)server(server,()->{var p=server.getPlayerList().getPlayer(id);for(int inv=10;inv<=12;inv++)check(p.getInventory().getItem(inv).is(StarRPG.STAR_DUST.get())&&p.getInventory().getItem(inv).getCount()==1,"Scaled quick craft drag failed slot "+inv+" scene "+scene);});
            if(step==105){var a=point.apply(13);screen.mouseClicked(a.x,a.y,0);screen.mouseReleased(a.x,a.y,0);}
            if(step==110){var a=point.apply(10);try{var move=net.minecraft.client.MouseHandler.class.getDeclaredMethod("onMove",long.class,double.class,double.class);move.setAccessible(true);move.invoke(mc.mouseHandler,mc.getWindow().getWindow(),a.x*mc.getWindow().getScreenWidth()/mc.getWindow().getGuiScaledWidth(),a.y*mc.getWindow().getScreenHeight()/mc.getWindow().getGuiScaledHeight());}catch(ReflectiveOperationException e){throw new RuntimeException(e);}}
            if(step==125){check(screen.getMenu().getCarried().isEmpty(),"Cursor still carries an item during tooltip check");screenshot(mc,"live-resize-drag-tooltip-"+scene);}
        }
    }
    private static void dragonFlight(Minecraft mc,net.minecraft.server.MinecraftServer server,java.util.UUID id){
        int age=tick-320,scene=(age-1)/240,step=age%240;if(scene>=2){if(step==10){mc.options.hideGui=false;StarRPG.LOGGER.info("QA291_UI_LIVE_RESIZE_DRAG_TOOLTIP_OK");StarRPG.LOGGER.info("QA291_DRAGON_FLIGHT_LANDING_BOTH_PHASES_OK");mc.stop();}return;}
        if(step==1){mc.setScreen(null);mc.options.hideGui=true;mc.getWindow().setWindowed(1280,800);mc.options.guiScale().set(2);mc.resizeDisplay();server(server,()->{var p=server.getPlayerList().getPlayer(id);clean(p);var l=p.serverLevel();specimen=BestiaryRegistry.TYPES.get(BestiaryKind.RED_DRAGON).get().create(l);specimen.moveTo(0,181,5,180,0);specimen.yBodyRot=specimen.yBodyRotO=180;specimen.nextAttack=l.getGameTime()+10000;l.addFreshEntity(specimen);target=EntityType.COW.create(l);target.moveTo(0,181,-2,0,0);target.setNoGravity(true);((Mob)target).setNoAi(true);target.getAttribute(Attributes.MAX_HEALTH).setBaseValue(1024);target.setHealth(1024);l.addFreshEntity(target);specimen.setTarget(target);specimen.setHealth(specimen.getMaxHealth()*(scene==0?.49F:.24F));specimen.getPersistentData().putInt("starrpg_boss_phase",scene+1);p.teleportTo(l,16,186,-12,40,7);DragonBattle.beginFlight(specimen);});}
        if(step==100){check(IceAndFireDragonVisual.available(),"CE fell back during flight");screenshot(mc,"dragon-flight-"+scene);server(server,()->check(BossPhases.flying(specimen)&&specimen.getY()>184,"Dragon failed flight "+scene));}
        if(step==230)server(server,()->{check(!BossPhases.flying(specimen)&&!specimen.isNoGravity(),"Dragon failed landing "+scene);StarRPG.LOGGER.info("QA291_DRAGON_PHASE_FLIGHT_LAND_OK {}",scene+2);});
    }
    private static void audit(Minecraft mc,net.minecraft.server.MinecraftServer s,java.util.UUID id){int scene=(tick-1)/130,step=tick%130;if(scene>=53){if(tick%20==0){StarRPG.LOGGER.info("QA291_AUDIT_COMPLETE_53");mc.stop();}return;}var k=BestiaryKind.values()[scene];if(step==1)server(s,()->{var p=s.getPlayerList().getPlayer(id);clean(p);specimen=BestiaryRegistry.TYPES.get(k).get().create(p.serverLevel());specimen.moveTo(0,181,5,180,0);specimen.nextAttack=p.level().getGameTime()+10000;p.serverLevel().addFreshEntity(specimen);target=EntityType.COW.create(p.serverLevel());target.moveTo(0,181,5-(k.body==BestiaryKind.Body.DRAGON?6:2),0,0);target.setNoGravity(true);((Mob)target).setNoAi(true);target.getAttribute(Attributes.MAX_HEALTH).setBaseValue(10000);target.setHealth(10000);p.serverLevel().addFreshEntity(target);specimen.setTarget(target);double distance=k.body==BestiaryKind.Body.DRAGON?16:k.boss?9:5;p.teleportTo(p.serverLevel(),distance*.6,181+Math.max(1.5,k.height()*.6),5-distance,32,9);});
        if(step==20)screenshot(mc,"species-"+k.id+"-idle");if(step==25)server(s,()->{specimen.getNavigation().moveTo(2,181,5,1);specimen.setDeltaMovement(.08,0,0);});
        if(step==40)server(s,()->{specimen.getNavigation().stop();specimen.moveTo(0,181,5,180,0);specimen.yBodyRot=180;target.setPos(0,181,5-(k.body==BestiaryKind.Body.DRAGON?6:2));specimen.startAttack(target,true);check(specimen.phase()==BestiaryMob.HEAVY,"Missing heavy tell "+k.id);});
        if(step==60)screenshot(mc,"species-"+k.id+"-windup");if(step==95){screenshot(mc,"species-"+k.id+"-impact");server(s,()->{check(specimen.isAlive()&&Float.isFinite(specimen.getHealth()),"Invalid combat state "+k.id);specimen.invulnerableTime=0;specimen.hurt(specimen.damageSources().generic(),1);specimen.setTarget(null);specimen.setNoAi(true);});}
        if(step==103)screenshot(mc,"species-"+k.id+"-hurt");if(step==106)server(s,()->{specimen.invulnerableTime=0;specimen.hurt(specimen.damageSources().genericKill(),100000);});if(step==116)screenshot(mc,"species-"+k.id+"-death");if(step==125)StarRPG.LOGGER.info("QA291_SPECIES_AUDITED {} {}",scene,k.id);
    }
    @SubscribeEvent public static void benchmark(net.neoforged.neoforge.event.tick.ServerTickEvent.Post event)throws Exception{
        if(!mode().startsWith("bench")||!ready||!benchReady)return;var s=event.getServer();var mc=Minecraft.getInstance();if(mc.player==null)return;var p=s.getPlayerList().getPlayer(mc.player.getUUID());if(p==null)return;serverTick++;for(var fake:QaActors291.actors()){fake.tickCount=serverTick;net.neoforged.neoforge.common.NeoForge.EVENT_BUS.post(new net.neoforged.neoforge.event.tick.PlayerTickEvent.Post(fake));}
        int scene=(serverTick-1)/360,step=serverTick%360;
        if(scene>=4){if(recording!=null){recording.stop();recording.dump(Path.of("/workspace/.star-rpg-tools/qa291-"+mode()+".jfr"));recording.close();recording=null;}QaActors291.clear(p);done=true;return;}if(serverTick==50){recording=new jdk.jfr.Recording(jdk.jfr.Configuration.getConfiguration("profile"));recording.start();}
        if(step==1){clean(p);p.teleportTo(p.serverLevel(),0,184,-12,0,7);if(scene==1||scene==3){for(int i=0;i<(scene==3?4:1);i++){var k=i%2==0?BestiaryKind.LICH:BestiaryKind.OGRE_WARLORD;var b=BestiaryRegistry.TYPES.get(k).get().create(p.serverLevel());b.moveTo(i*5-5,181,4,180,0);p.serverLevel().addFreshEntity(b);b.setTarget(p);}}
            if(scene==2||scene==3)for(int i=0;i<64;i++){var k=BestiaryKind.values()[i%20];if(k.boss)k=BestiaryKind.ORC;var b=BestiaryRegistry.TYPES.get(k).get().create(p.serverLevel());b.moveTo(i%8*2-7,181,i/8*2+2,180,0);p.serverLevel().addFreshEntity(b);b.setTarget(p);}
            if(scene==3){p.containerMenu=new AwakeningMenu(71,p.getInventory());for(var fake:QaActors291.actors())fake.containerMenu=new AwakeningMenu(71,fake.getInventory());}
        }
        if(step==100)QaMeasurements291.begin(mode()+"-"+new String[]{"idle","boss","64-mobs","boss64-menu"}[scene]);
        if(scene==3&&step>=100&&step<340)for(var fake:QaActors291.actors())if(serverTick%10==0)AwakeningSync.send(fake,false);
        if(step==340){QaMeasurements291.finish(Path.of("/workspace/.star-rpg-tools/qa291-"+mode()+"-p"+Integer.getInteger("starrpg.qa291.players",1)+".jsonl"));if(scene==0){microbench(p);if(mode().equals("bench-final"))QaCombat291.run(p);}}
    }
    private static void microbench(ServerPlayer p){
        var bean=(com.sun.management.ThreadMXBean)ManagementFactory.getThreadMXBean();long thread=Thread.currentThread().threadId(),bytes=bean.getThreadAllocatedBytes(thread),start=System.nanoTime();int chars=0;for(int i=0;i<500;i++)chars+=AwakeningSync.snapshot(p,true).toString().length();StarRPG.LOGGER.info("QA291_MICRO snapshot500 ns={} allocated={} chars={}",System.nanoTime()-start,bean.getThreadAllocatedBytes(thread)-bytes,chars);
        var gear=Accessories.inventory(p);var originalGear=new ItemStack[]{gear.getItem(0).copy(),gear.getItem(1).copy(),gear.getItem(2).copy()};gear.setItem(0,new ItemStack(AwakeningItems.RING.get()));gear.setItem(1,new ItemStack(AwakeningItems.NECKLACE.get()));gear.setItem(2,new ItemStack(AwakeningItems.CHARM.get()));
        for(int warm=0;warm<2000;warm++){legacyAccessory(p,warm%3);Accessories.equipped(p,warm%3);}
        for(int repeat=0;repeat<4;repeat++)for(int order=0;order<2;order++){boolean cached=(order+repeat)%2==0;bytes=bean.getThreadAllocatedBytes(thread);start=System.nanoTime();int count=0;for(int i=0;i<6000;i++)count+=(cached?Accessories.equipped(p,i%3):legacyAccessory(p,i%3)).getCount();check(count==6000,"Accessory micro changed results");StarRPG.LOGGER.info("QA291_MICRO geared-accessories6000 cached={} repeat={} ns={} allocated={} count={}",cached,repeat,System.nanoTime()-start,bean.getThreadAllocatedBytes(thread)-bytes,count);}
        for(int i=0;i<3;i++)gear.setItem(i,originalGear[i]);
    }
    private static ItemStack legacyAccessory(ServerPlayer p,int slot){var source=AwakeningData.profile(p).getList("accessories",net.minecraft.nbt.Tag.TAG_COMPOUND);return slot>=0&&slot<source.size()?ItemStack.parseOptional(p.registryAccess(),source.getCompound(slot)):ItemStack.EMPTY;}
}
