package com.junwo.starrpg.ui;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
public abstract class ResponsiveScreen extends Screen implements ResponsiveUi {
    private UiViewport viewport=UiViewport.fit(1,1,1,1);
    protected ResponsiveScreen(Component title){super(title);}
    @Override public final UiViewport viewport(){return viewport;}
    @Override protected void init(){viewport=UiViewport.fit(minecraft.getWindow().getGuiScaledWidth(),minecraft.getWindow().getGuiScaledHeight(),360,280);width=viewport.width();height=viewport.height();super.init();}

    @Override public void mouseMoved(double x,double y){super.mouseMoved(viewport.mouseX(x),viewport.mouseY(y));}
    @Override public boolean mouseClicked(double x,double y,int button){return super.mouseClicked(viewport.mouseX(x),viewport.mouseY(y),button);}
    @Override public boolean mouseReleased(double x,double y,int button){return super.mouseReleased(viewport.mouseX(x),viewport.mouseY(y),button);}
    @Override public boolean mouseDragged(double x,double y,int button,double dx,double dy){return super.mouseDragged(viewport.mouseX(x),viewport.mouseY(y),button,dx/viewport.scale(),dy/viewport.scale());}
    @Override public boolean mouseScrolled(double x,double y,double dx,double dy){return scrollCanvas(viewport.mouseX(x),viewport.mouseY(y),dx,dy);}
    protected boolean scrollCanvas(double x,double y,double dx,double dy){return super.mouseScrolled(x,y,dx,dy);}
}
