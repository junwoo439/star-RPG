package com.junwo.starrpg.ui;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.network.chat.Component;

/** One input transform for buttons, slot dragging, quick craft and tooltips. */
public abstract class ResponsiveContainerScreen<T extends AbstractContainerMenu> extends AbstractContainerScreen<T> implements ResponsiveUi {
    private UiViewport viewport=UiViewport.fit(1,1,1,1);
    protected ResponsiveContainerScreen(T menu,Inventory inventory,Component title){super(menu,inventory,title);}
    @Override public final UiViewport viewport(){return viewport;}
    @Override protected void init(){viewport=UiViewport.fit(minecraft.getWindow().getGuiScaledWidth(),minecraft.getWindow().getGuiScaledHeight(),imageWidth,imageHeight);width=viewport.width();height=viewport.height();super.init();}

    @Override public void mouseMoved(double x,double y){super.mouseMoved(viewport.mouseX(x),viewport.mouseY(y));}
    @Override public boolean mouseClicked(double x,double y,int button){return super.mouseClicked(viewport.mouseX(x),viewport.mouseY(y),button);}
    @Override public boolean mouseReleased(double x,double y,int button){return super.mouseReleased(viewport.mouseX(x),viewport.mouseY(y),button);}
    @Override public boolean mouseDragged(double x,double y,int button,double dx,double dy){return super.mouseDragged(viewport.mouseX(x),viewport.mouseY(y),button,dx/viewport.scale(),dy/viewport.scale());}
    @Override public boolean mouseScrolled(double x,double y,double dx,double dy){return scrollCanvas(viewport.mouseX(x),viewport.mouseY(y),dx,dy);}
    protected boolean scrollCanvas(double x,double y,double dx,double dy){return super.mouseScrolled(x,y,dx,dy);}
    protected void fitText(net.minecraft.client.gui.GuiGraphics g,String text,int x,int y,int maxWidth,int color){g.pose().pushPose();g.pose().translate(x,y,0);float scale=Math.min(1,maxWidth/(float)Math.max(1,font.width(text)));g.pose().scale(scale,scale,1);g.drawString(font,text,0,0,color,false);g.pose().popPose();}
}
