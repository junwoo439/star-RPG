package com.junwo.starrpg.ui;
public interface ResponsiveUi { UiViewport viewport(); }
