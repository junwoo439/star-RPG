package com.junwo.starrpg.awakening;

import com.google.gson.*;
import com.junwo.starrpg.*;
import com.junwo.starrpg.adventure.*;
import com.junwo.starrpg.bestiary.*;
import net.minecraft.server.level.ServerPlayer;

/** Content builders are isolated from transport and keep the 2.9 wire schema unchanged. */
final class AwakeningPages {
    private static JsonObject entry(JsonArray tab,String title,String...lines){var e=new JsonObject();e.addProperty("title",title);var body=new JsonArray();for(String line:lines)body.add(line);e.add("body",body);e.add("actions",new JsonArray());tab.add(e);return e;}
    private static void action(JsonObject entry,String name,int op,int arg,String target){var a=new JsonObject();a.addProperty("name",name);a.addProperty("op",op);a.addProperty("arg",arg);a.addProperty("target",target);entry.getAsJsonArray("actions").add(a);}
    private static void action(JsonObject entry,String name,int op,int arg){action(entry,name,op,arg,"");}
    static JsonArray build(ServerPlayer player){
        var tabs=new JsonArray();
        var party=new JsonArray(); party(player,party); tabs.add(party);
        var accessories=new JsonArray(); accessories(player,accessories); tabs.add(accessories);
        var constellations=new JsonArray(); constellations(player,constellations); tabs.add(constellations);
        var village=new JsonArray(); village(player,village); tabs.add(village);
        var variants=new JsonArray(); variants(player,variants); tabs.add(variants);
        var expeditions=new JsonArray(); expeditions(player,expeditions); tabs.add(expeditions);
        var forge=new JsonArray(); forge(player,forge); tabs.add(forge);
        return tabs;
    }

    private static void party(ServerPlayer p,JsonArray tab){
        JsonObject e;
        var party=Parties.party(p);
e=entry(tab,"별빛 원정대 · 최대 4명","파티원 사이의 공격은 보호됩니다.","초대는 60초 동안 유효합니다.","레이드 전투 중에는 파티를 나갈 수 없습니다.");action(e,"파티 만들기",0,0);action(e,"초대 수락",2,0);if(!party.isEmpty())action(e,"파티 나가기",3,0,p.getUUID().toString());
        for(var id:Parties.members(party)){var member=p.getServer().getPlayerList().getPlayer(id);e=entry(tab,member==null?id.toString().substring(0,8):member.getGameProfile().getName(),member==null?"오프라인":Math.round(member.getHealth())+" / "+Math.round(member.getMaxHealth())+" HP",party.hasUUID("leader")&&party.getUUID("leader").equals(id)?"파티장":"파티원");if(Parties.leader(p)&&!id.equals(p.getUUID()))action(e,"내보내기",3,0,id.toString());}
        for(var other:p.getServer().getPlayerList().getPlayers())if(other!=p&&!Parties.same(p,other)&&Parties.party(other).isEmpty()){e=entry(tab,other.getGameProfile().getName(),"함께 모험할 플레이어");action(e,"초대",1,0,other.getUUID().toString());}
        e=entry(tab,"파티 의뢰 · 연합 토벌",Math.min(20,party.getInt("quest_kills"))+" / 20 처치","수락할 때 32m 안에 생존 파티원 2명 필요","보상: 각자 200G + 각성 정수 1","최소 3회 처치에 가까이 참여해야 합니다.");action(e,"의뢰 수락",4,0);action(e,"개인 보상 수령",5,0);
    }

    private static void accessories(ServerPlayer p,JsonArray tab){
        JsonObject e;
String[] accessoryNames={"별빛 반지","조수의 목걸이","패링의 부적","영혼 결속 반지","용골 목걸이","수호자의 부적"};String[] effects={"기본 공격력 +3~6%","마나 +6~16 · 원소 피해 +3~6%","패링 판정 +1틱 / +5강부터 +2틱","공격력 · 초당 최대 1 생명 흡수","마나·원소 피해 · 화염 피해 완화","패링 · 방어력 +1~2.5"};for(int i=0;i<6;i++){e=entry(tab,accessoryNames[i],effects[i],i<3?(i==2?"철 4":"금 4")+" + 정수 3 + 자수정 2":"해당 보스 재료 1 + 정수 8 + 자수정 2");action(e,"제작",6,i);}for(int i=0;i<3;i++){var item=Accessories.equipped(p,i);int level=Accessories.level(item);e=entry(tab,new String[]{"반지","목걸이","부적"}[i]+" 강화",item.isEmpty()?"오른쪽 칸에 장착하세요.":item.getHoverName().getString()+" +"+level,"정수 "+(level+2)+" + "+100*(level+1)+"G","성공 "+Math.round((.9-level*.05)*100)+"% · 파괴 없음 · 최대 +10");action(e,"장착 장신구 강화",7,i);}
    }

    private static void constellations(ServerPlayer p,JsonArray tab){
        JsonObject e;
for(int i=0;i<3;i++){int lv=Constellations.level(p,i);e=entry(tab,Constellations.NAMES[i]+(Constellations.active(p)==i?" · 활성":""),(AwakeningData.number(p,"constellation_unlocked")&(1<<i))==0?"최상위 보스 또는 레이드 정복으로 해금":"해금됨 · 성장 "+lv+" / 5",new String[]{"단계마다 기본 공격력 +1.5%","단계마다 방어력 +1","단계마다 마나 +6 · 마법 +1.5%"}[i],"성좌 핵 "+(lv+1)+" · 정수 "+5*(lv+1)+" · "+1000*(lv+1)+"G","완성된 직업 스킬 트리와 추가 공명");action(e,"활성화",8,i);action(e,"성장",9,i);}
    }

    private static void village(ServerPlayer p,JsonArray tab){
        JsonObject e;
var town=VillageReputation.current(p);e=entry(tab,town.isEmpty()?"마을을 찾아주세요":"마을의 신뢰","평판 "+VillageReputation.reputation(p)+" / 1000 · 상점 할인 "+VillageReputation.discount(p)+"%","발전 "+town.getInt("development")+" / 3","발전: 돌32·참나무16 · 500G × 다음 단계","단계마다 철 골렘 경비병과 추가 방어력");action(e,"마을 발전",13,0);action(e,"특수 상인 해금 · 평판100",14,0);action(e,"마을 방어전",15,0);
        for(int i=0;i<3;i++){e=entry(tab,VillageReputation.FACTIONS[i]+(AwakeningData.number(p,"faction")==i+1?" · 소속":""),new String[]{"몬스터 12마리 토벌","던전 1회 정복","광석 12개 채굴"}[i],"첫 가입 무료 · 세력 변경 500G","하루 한 번 · 정수1 + 250G + 평판12");action(e,"세력 선택",10,i);}int faction=AwakeningData.number(p,"faction")-1;int progress=faction<0?0:AdventureData.value(p,faction==0?"kills":faction==1?"dungeons":"ores")-AwakeningData.number(p,"faction_quest_base");e=entry(tab,"세력 의뢰",AwakeningData.number(p,"faction_quest_active")>0?"수행 중 · "+Math.max(0,progress)+" / "+(faction==1?1:12):"소속 세력을 정하고 마을에서 수락하세요.","보상은 수락한 마을에서 받습니다.");action(e,"의뢰 수락",11,0);action(e,"완료 보상",12,0);e=entry(tab,"성흔 무역상 · 평판 100","각성 정수 "+VillageReputation.price(p,300)+"G","도전 열쇠 "+VillageReputation.price(p,900)+"G");action(e,"정수 구매",16,0);action(e,"열쇠 구매",16,1);
    }

    private static void variants(ServerPlayer p,JsonArray tab){
        JsonObject e;
for(var k:BestiaryKind.values())for(int type=1;type<=2;type++){String prefix=type==2?"mutation_":"rare_";int kills=AwakeningData.number(p,prefix+"kills_"+k.id);if(AwakeningData.number(p,prefix+"seen_"+k.id)==0&&kills==0)continue;e=entry(tab,(type==2?"변이 · ":"희귀 · ")+k.name,"출현: "+JournalText.region(k),"공격: "+JournalText.attack(k),"강화 패턴: "+(type==2?"결정 폭발":"돌진"),"처치 "+kills+" / "+(type==2?1:3)+" · 각성 정수 3",AwakeningData.number(p,prefix+k.id+"_claimed")>0?"수집 보상 수령 완료":"수집 보상을 받을 수 있습니다.");action(e,"수집 보상",17,k.ordinal()*2+type-1);}if(tab.isEmpty())entry(tab,"희귀·변이 도감","빛나는 왕관이나 결정이 돋은 개체를 관찰하세요.","일반 도감과 별도로 기록됩니다.","세계 단계가 높을수록 등장 확률이 증가합니다.");
    }

    private static void expeditions(ServerPlayer p,JsonArray tab){
        JsonObject e;
e=entry(tab,"각성 던전 · 도전 모드","새 유적: 보물·함정·문양 퍼즐·비밀방","벽의 붉음0·푸름1·금빛2 순서로 문양을 누르세요.","도전 열쇠 1개 · 방을 다시 섞고 더 강한 적 등장","코어 8m 안 · 다른 보스 전투가 없어야 합니다.");action(e,"도전 시작",18,0);e=entry(tab,"별을 삼킨 거신 · 연합 레이드","2~16명 · 4개 파티까지 연합","근처에 모인 생존 플레이어만 등록됩니다.","소환: 레이드 인장 1 · 마을 바깥 넓은 지상","피해·치유·탱킹·패링으로 개인 보상을 얻습니다.");action(e,"연합 모집 · 2분",19,0);action(e,"레이드 소환",21,0);action(e,"개인 보상 수령 ("+Raids.pending(p)+")",22,0);for(var host:Raids.publicHosts(p)){e=entry(tab,host.getGameProfile().getName()+"의 연합","파티장이 자신의 파티를 등록할 수 있습니다.");action(e,"파티로 연합 참여",20,0,host.getUUID().toString());}
    }

    private static void forge(ServerPlayer p,JsonArray tab){
        JsonObject e;
for(int i=0;i<7;i++){e=entry(tab,AwakenedForge.name(i),i<2?(i==0?"유적의 잔영 2":"변이 결정 2")+" + 각성 정수 4":(i<5?"해당 보스 재료 3":"거신의 핵 3")+" + 각성 정수 12 + 별철 합금 6",i<2?"누구나 제작 가능":"생활 직업 대장장이 필요",i>=2&&i<=5?"전용 입체 외형 · 무한 강화 · 기존 무기 스킬 연동":"별빛 공방");action(e,"제작",23,i);}entry(tab,"원소 연계","물 + 번개: 감전과 연쇄 타격","물 + 얼음: 빙결 / 빙결 + 강공격: 쇄빙","불 + 바람: 주변 적에게 화염 확산","바람: 바람 룬 또는 충전한 전투 망치 타격");
    }
}
