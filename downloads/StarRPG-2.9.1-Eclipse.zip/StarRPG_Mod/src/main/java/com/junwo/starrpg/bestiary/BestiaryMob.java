package com.junwo.starrpg.bestiary;

import com.junwo.starrpg.*;
import net.minecraft.network.syncher.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.*;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.*;
import net.minecraft.world.entity.ai.navigation.*;
import net.minecraft.world.entity.ai.control.SmoothSwimmingMoveControl;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.sounds.*;

public final class BestiaryMob extends Monster {
    public static final int IDLE=0,QUICK=1,HEAVY=2,ACTIVE=3,RECOVERY=4,STAGGER=5;
    private static final EntityDataAccessor<Integer> PHASE=SynchedEntityData.defineId(BestiaryMob.class,EntityDataSerializers.INT),LEFT=SynchedEntityData.defineId(BestiaryMob.class,EntityDataSerializers.INT),TOTAL=SynchedEntityData.defineId(BestiaryMob.class,EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DRAGON_ACTION=SynchedEntityData.defineId(BestiaryMob.class,EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> AW_VARIANT=SynchedEntityData.defineId(BestiaryMob.class,EntityDataSerializers.INT),AW_SKILL=SynchedEntityData.defineId(BestiaryMob.class,EntityDataSerializers.INT),AW_HEADS=SynchedEntityData.defineId(BestiaryMob.class,EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> AW_WARD=SynchedEntityData.defineId(BestiaryMob.class,EntityDataSerializers.FLOAT);
    public final BestiaryKind kind;
    public Vec3 attackOrigin=Vec3.ZERO,attackDirection=new Vec3(0,0,1),attackPoint=Vec3.ZERO;
    public boolean heavyAttack,parryableImpact;
    private float flightVisual,flightVisualOld;
    private float bank,bankOld;private final float[] headingHistory=new float[32];private int historyIndex;private boolean historyReady;
    public float flightBlend(float partial){return net.minecraft.util.Mth.lerp(partial,flightVisualOld,flightVisual);}
    public float flightBank(float partial){return net.minecraft.util.Mth.lerp(partial,bankOld,bank);}
    public float headingLag(int ticks){return net.minecraft.util.Mth.wrapDegrees(headingHistory[(historyIndex-Math.clamp(ticks,0,31))&31]-yBodyRot);}
    public int dragonAction(){return entityData.get(DRAGON_ACTION);}public void dragonAction(int value){entityData.set(DRAGON_ACTION,value);}
    public int awakenedVariant(){return entityData.get(AW_VARIANT);}public void awakenedVariant(int value){entityData.set(AW_VARIANT,Math.clamp(value,0,3));}
    public int bossSkill(){return entityData.get(AW_SKILL);}public void bossSkill(int value){entityData.set(AW_SKILL,value);}
    public int headMask(){return entityData.get(AW_HEADS);}public void headMask(int value){entityData.set(AW_HEADS,value&7);}
    public float ward(){return entityData.get(AW_WARD);}public void ward(float value){entityData.set(AW_WARD,Math.max(0,value));}
    public void countdown(int remaining){entityData.set(LEFT,Math.max(0,remaining));}
    private int attackCounter;public long nextAttack;private int lifeTicks;
    private final net.neoforged.neoforge.entity.PartEntity<?>[] dragonParts;
    private final ServerBossEvent bar=new ServerBossEvent(net.minecraft.network.chat.Component.empty(),BossEvent.BossBarColor.RED,BossEvent.BossBarOverlay.PROGRESS);
    public BestiaryMob(EntityType<? extends Monster> t,Level l,BestiaryKind k){
        super(t,l);kind=k;xpReward=k.boss?80:8;
        dragonParts=k.body==BestiaryKind.Body.DRAGON?new DragonHitPart[]{new DragonHitPart(this,1.8F,1.5F),new DragonHitPart(this,2F,1.8F),new DragonHitPart(this,2F,1.4F)}:k.body==BestiaryKind.Body.HYDRA?new net.neoforged.neoforge.entity.PartEntity<?>[]{new com.junwo.starrpg.awakening.BossHitPart(this,0,1.7F,1.4F),new com.junwo.starrpg.awakening.BossHitPart(this,1,1.7F,1.4F),new com.junwo.starrpg.awakening.BossHitPart(this,2,1.7F,1.4F)}:k==BestiaryKind.ANCIENT_GOLEM?new net.neoforged.neoforge.entity.PartEntity<?>[]{new com.junwo.starrpg.awakening.BossHitPart(this,0,.9F,.9F),new com.junwo.starrpg.awakening.BossHitPart(this,1,1.3F,1.8F),new com.junwo.starrpg.awakening.BossHitPart(this,2,1.3F,1.8F)}:null;
        if(k.aquatic()){navigation=new WaterBoundPathNavigation(this,l);moveControl=new SmoothSwimmingMoveControl(this,85,10,.04F,.1F,true);}
    }
    public static AttributeSupplier.Builder attributes(BestiaryKind k){return Monster.createMonsterAttributes().add(Attributes.MAX_HEALTH,k.health).add(Attributes.ATTACK_DAMAGE,k.damage).add(Attributes.MOVEMENT_SPEED,k.body==BestiaryKind.Body.SMALL?.30:.24).add(Attributes.FOLLOW_RANGE,k.boss?36:24).add(Attributes.KNOCKBACK_RESISTANCE,k.boss?.7:k.body==BestiaryKind.Body.GOLEM?.4:0).add(Attributes.ARMOR,k.family==BestiaryKind.Family.CONSTRUCT?5:0);}
    @Override protected void defineSynchedData(SynchedEntityData.Builder b){super.defineSynchedData(b);b.define(PHASE,0);b.define(LEFT,0);b.define(TOTAL,1);b.define(DRAGON_ACTION,0);b.define(AW_VARIANT,0);b.define(AW_SKILL,0);b.define(AW_HEADS,7);b.define(AW_WARD,0F);}
    @Override protected void registerGoals(){
        goalSelector.addGoal(0,new FloatGoal(this){@Override public boolean canUse(){return kind!=null&&!kind.aquatic()&&super.canUse();}});goalSelector.addGoal(1,new BestiaryCombatGoal(this));
        goalSelector.addGoal(6,new RandomStrollGoal(this,.8){@Override public boolean canUse(){return kind!=null&&!kind.aquatic()&&super.canUse();}});
        goalSelector.addGoal(6,new RandomSwimmingGoal(this,1,40){@Override public boolean canUse(){return kind!=null&&kind.aquatic()&&super.canUse();}});goalSelector.addGoal(7,new LookAtPlayerGoal(this,Player.class,8));goalSelector.addGoal(8,new RandomLookAroundGoal(this));
        targetSelector.addGoal(1,new HurtByTargetGoal(this));
        targetSelector.addGoal(2,new NearestAttackableTargetGoal<>(this,Player.class,10,true,false,p->kind!=null&&!kind.neutral));
    }
    public int phase(){return entityData.get(PHASE);}public int remaining(){return entityData.get(LEFT);}public int duration(){return entityData.get(TOTAL);}
    public float progress(float partial){return Math.clamp(1-(remaining()-partial)/(float)Math.max(1,duration()),0,1);}
    public void phase(int phase,int ticks){entityData.set(PHASE,phase);entityData.set(LEFT,ticks);entityData.set(TOTAL,Math.max(1,ticks));}
    public void startAttack(LivingEntity target,boolean heavy){
        if(level().isClientSide()||!BestiaryCombat.valid(this,target))return;
        if(DragonBattle.start(this,target,heavy))return;
        if(com.junwo.starrpg.awakening.UniqueBossCombat.start(this,target,heavy))return;
        heavyAttack=heavy;attackOrigin=position();attackPoint=target.position();attackDirection=target.position().subtract(position()).multiply(1,0,1).normalize();
        phase(heavy?HEAVY:QUICK,heavy?kind.windup():10);getNavigation().stop();
        setYRot((float)Math.toDegrees(Math.atan2(-attackDirection.x,attackDirection.z)));yBodyRot=getYRot();
        BestiaryCombat.telegraph(this);playSound(heavy?SoundEvents.IRON_GOLEM_REPAIR:SoundEvents.PLAYER_ATTACK_WEAK,.6F,heavy?.6F:1.3F);
    }
    public void stagger(int ticks){phase(STAGGER,ticks);nextAttack=level().getGameTime()+ticks+12;getNavigation().stop();setDeltaMovement(0,getDeltaMovement().y,0);}
    public boolean nextHeavy(){return ++attackCounter%3==0||kind.move.ordinal()>=BestiaryKind.Move.HEX.ordinal()&&attackCounter%2==0;}
    public void combatTick(){
        if(phase()==IDLE)return;
        if(com.junwo.starrpg.awakening.UniqueBossCombat.tick(this))return;
        if(DragonBattle.groundTick(this))return;
        if(!isAlive()||ControlEffects.stunned(this)||ControlEffects.rooted(this)){phase(RECOVERY,20);nextAttack=level().getGameTime()+30;return;}
        if(phase()==QUICK||phase()==HEAVY){
            if(!BestiaryCombat.valid(this,getTarget())||getTarget().distanceToSqr(attackOrigin)>Math.pow(kind.reach()+8,2)){phase(RECOVERY,16);nextAttack=level().getGameTime()+24;return;}
            getNavigation().stop();setDeltaMovement(0,getDeltaMovement().y,0);
        }
        int left=remaining()-1;entityData.set(LEFT,Math.max(0,left));if(left>0)return;
        switch(phase()){
            case QUICK,HEAVY->{phase(ACTIVE,4);if(heavyAttack&&kind.move==BestiaryKind.Move.LUNGE)setDeltaMovement(attackDirection.scale(.8).add(0,.12,0));BestiaryCombat.resolve(this);}
            case ACTIVE->{phase(RECOVERY,heavyAttack?32:18);nextAttack=level().getGameTime()+remaining()+8;}
            case RECOVERY,STAGGER->phase(IDLE,0);
        }
    }
    @Override public void tick(){
        super.tick();updateDragonParts();if(level().isClientSide()){
            flightVisualOld=flightVisual;float target=isNoGravity()&&!isNoAi()?1:0;flightVisual+=Math.clamp(target-flightVisual,-.06F,.06F);
            if(!historyReady){java.util.Arrays.fill(headingHistory,yBodyRot);historyReady=true;}historyIndex=(historyIndex+1)&31;headingHistory[historyIndex]=yBodyRot;
            bankOld=bank;float desired=Math.clamp(net.minecraft.util.Mth.wrapDegrees(yBodyRot-yBodyRotO)*.045F,-.32F,.32F)*flightVisual;bank+=(desired-bank)*.14F;return;
        }lifeTicks++;
        com.junwo.starrpg.awakening.UniqueBossCombat.update(this);
        if(kind.aquatic()&&!isInWater()&&tickCount%20==0)hurt(damageSources().dryOut(),2);
        if(kind.boss){
            BossPhases.tick(this);
            var title=new BossTitle(awakenedVariant(),MonsterProgression.tier(this),BossPhases.stage(this),ward()>0?(int)ward()+1:0,phase()==HEAVY?bossSkill():0,phase()==HEAVY?1:phase()==STAGGER?2:0,
                    kind.parryable()||com.junwo.starrpg.awakening.UniqueBossCombat.parryable(bossSkill())||DragonBattle.dragon(this)&&(dragonAction()==DragonBattle.TAIL||dragonAction()==DragonBattle.WING));
            if(!title.equals(lastTitle)){lastTitle=title;bar.setName(net.minecraft.network.chat.Component.literal(title.text(kind)));}
            bar.setProgress(Math.clamp(getHealth()/getMaxHealth(),0,1));bar.setVisible(isAlive());
        }
    }
    private BossTitle lastTitle;
    private record BossTitle(int variant,int tier,int stage,int ward,int skill,int tell,boolean parryable){
        String text(BestiaryKind kind){
            return (variant==3?"별을 삼킨 거신":kind.name)+" · "+tier+"단계 · "+(stage+1)+"페이즈"
                    +(ward>0?" · 보호막 "+(ward-1):"")
                    +(skill>0?" · "+com.junwo.starrpg.awakening.UniqueBossCombat.name(skill):"")
                    +(tell==1?(parryable?" · 강공격 / 패링 가능":" · 강공격 / 회피"):tell==2?" · 반격 기회":"");
        }
    }
    public int lifeTicks(){return lifeTicks;}
    @Override public boolean isMultipartEntity(){return dragonParts!=null;}
    @Override public net.neoforged.neoforge.entity.PartEntity<?>[] getParts(){return dragonParts;}
    @Override public void setId(int id){super.setId(id);if(dragonParts!=null)for(int i=0;i<dragonParts.length;i++)dragonParts[i].setId(id+i+1);}
    public void updateDragonParts(){
        if(dragonParts==null)return;var forward=DragonBattle.forward(yBodyRot);var side=new Vec3(forward.z,0,-forward.x);
        if(kind==BestiaryKind.ANCIENT_GOLEM){double size=awakenedVariant()==3?1.4:1;dragonParts[0].setPos(position().add(forward.scale(.55*size)).add(0,1.65*size,0));for(int i=1;i<3;i++)dragonParts[i].setPos(position().add(side.scale((i==1?-1:1)*1.4*size)).add(0,1.1*size,0));return;}
        if(kind==BestiaryKind.HYDRA){dragonParts[0].setPos(position().add(forward.scale(3.3)).add(0,2,0));for(int i=1;i<3;i++)dragonParts[i].setPos(position().add(forward.scale(2.8)).add(side.scale(i==1?-1.4:1.4)).add(0,2.1,0));return;}
        boolean ce=net.neoforged.fml.ModList.get().isLoaded("iceandfire");
        dragonParts[0].setPos(position().add(forward.scale(ce?4.2:3.3)).add(0,ce?2.2:1.8,0));
        dragonParts[1].setPos(position().add(forward.scale(ce?2.7:2)).add(0,1.7,0));
        dragonParts[2].setPos(position().add(forward.scale(ce?-4.8:-3.5)).add(0,.65,0));
    }
    @Override public void startSeenByPlayer(ServerPlayer p){super.startSeenByPlayer(p);if(kind.boss)bar.addPlayer(p);}
    @Override public void stopSeenByPlayer(ServerPlayer p){super.stopSeenByPlayer(p);bar.removePlayer(p);}
    @Override public void remove(RemovalReason reason){bar.removeAllPlayers();super.remove(reason);}
    @Override public boolean removeWhenFarAway(double d){return !kind.boss&&!hasCustomName();}
    @Override public void travel(Vec3 v){if(kind!=null&&kind.aquatic()&&isInWater()&&isEffectiveAi()){moveRelative(getSpeed(),v);move(MoverType.SELF,getDeltaMovement());setDeltaMovement(getDeltaMovement().scale(.9));}else super.travel(v);}
    @Override public boolean causeFallDamage(float d,float m,DamageSource s){return kind.body!=BestiaryKind.Body.DRAGON&&kind.body!=BestiaryKind.Body.WYVERN&&kind.body!=BestiaryKind.Body.GHOST&&super.causeFallDamage(d,m,s);}
    @Override protected SoundEvent getHurtSound(DamageSource s){return kind.family==BestiaryKind.Family.CONSTRUCT?SoundEvents.IRON_GOLEM_HURT:kind.family==BestiaryKind.Family.DRAGON?SoundEvents.ENDER_DRAGON_HURT:SoundEvents.RAVAGER_HURT;}
    @Override protected SoundEvent getDeathSound(){return kind.family==BestiaryKind.Family.CONSTRUCT?SoundEvents.IRON_GOLEM_DEATH:SoundEvents.RAVAGER_DEATH;}
    @Override public void addAdditionalSaveData(CompoundTag tag){super.addAdditionalSaveData(tag);tag.putInt("bestiaryAttacks",attackCounter);tag.putInt("awakened_variant",awakenedVariant());tag.putInt("awakened_heads",headMask());}
    @Override public void readAdditionalSaveData(CompoundTag tag){super.readAdditionalSaveData(tag);attackCounter=Math.max(0,tag.getInt("bestiaryAttacks"));awakenedVariant(tag.contains("awakened_variant")?tag.getInt("awakened_variant"):awakenedVariant());headMask(tag.contains("awakened_heads")?tag.getInt("awakened_heads"):7);ward(0);bossSkill(0);phase(IDLE,0);nextAttack=level().getGameTime()+40;}
}
