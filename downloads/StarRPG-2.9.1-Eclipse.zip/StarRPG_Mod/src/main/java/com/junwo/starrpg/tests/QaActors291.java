package com.junwo.starrpg.tests;
import com.junwo.starrpg.*;
import com.junwo.starrpg.awakening.*;
import java.util.*;
import com.mojang.authlib.GameProfile;
import net.minecraft.server.level.*;
import net.minecraft.server.players.PlayerList;
import net.minecraft.world.level.GameType;
import net.neoforged.neoforge.common.util.FakePlayer;

/** Fake server actors never pretend to be network clients; no login events or authentication are bypassed. */
public final class QaActors291 {
    private static final List<FakePlayer> ACTORS=new ArrayList<>();
    @SuppressWarnings("unchecked") private static <T>T field(PlayerList list,String name)throws ReflectiveOperationException{var f=PlayerList.class.getDeclaredField(name);f.setAccessible(true);return (T)f.get(list);}
    public static List<ServerPlayer> group(ServerPlayer owner,int count)throws ReflectiveOperationException{
        clear(owner);Parties.remove(owner,owner.getUUID());var players=new ArrayList<ServerPlayer>();players.add(owner);var server=owner.getServer();var list=server.getPlayerList();List<ServerPlayer> raw=field(list,"players");Map<UUID,ServerPlayer> byId=field(list,"playersByUUID");
        for(int i=1;i<count;i++){var actor=new FakePlayer(owner.serverLevel(),new GameProfile(UUID.nameUUIDFromBytes(("starrpg-qa291-"+i).getBytes(java.nio.charset.StandardCharsets.UTF_8)),"QA_"+i));if(actor.connection.getConnection().channel()==null)new io.netty.channel.embedded.EmbeddedChannel(actor.connection.getConnection());actor.setGameMode(GameType.SURVIVAL);actor.moveTo(owner.position().add(i%4*.6,0,i/4*.6));actor.setNoGravity(true);raw.add(actor);byId.put(actor.getUUID(),actor);owner.serverLevel().addNewPlayer(actor);ACTORS.add(actor);players.add(actor);Careers.profile(actor).selected=Careers.ACTIVE[i%Careers.ACTIVE.length];Careers.profile(actor).ranks[Careers.profile(actor).selected]=10;var equipment=Accessories.inventory(actor);equipment.setItem(0,new net.minecraft.world.item.ItemStack(AwakeningItems.RING.get()));equipment.setItem(1,new net.minecraft.world.item.ItemStack(AwakeningItems.NECKLACE.get()));equipment.setItem(2,new net.minecraft.world.item.ItemStack(AwakeningItems.CHARM.get()));}
        for(int start=0;start<players.size();start+=4){var leader=players.get(start);Parties.create(leader);for(int i=start+1;i<Math.min(start+4,players.size());i++){if(!Parties.invite(leader,players.get(i).getUUID())||!Parties.accept(players.get(i)))throw new IllegalStateException("Simulated party failed");}}
        return players;
    }
    public static List<FakePlayer> actors(){return List.copyOf(ACTORS);}
    public static void clear(ServerPlayer owner)throws ReflectiveOperationException{var list=owner.getServer().getPlayerList();List<ServerPlayer> raw=field(list,"players");Map<UUID,ServerPlayer> byId=field(list,"playersByUUID");for(var actor:ACTORS){Parties.remove(actor,actor.getUUID());raw.remove(actor);byId.remove(actor.getUUID());actor.serverLevel().removePlayerImmediately(actor,net.minecraft.world.entity.Entity.RemovalReason.DISCARDED);actor.connection.getConnection().channel().close();}ACTORS.clear();}
}
