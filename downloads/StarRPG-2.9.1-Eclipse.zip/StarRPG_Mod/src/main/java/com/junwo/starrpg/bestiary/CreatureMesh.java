package com.junwo.starrpg.bestiary;

import com.mojang.blaze3d.vertex.*;
import com.mojang.math.Axis;
import java.util.*;
import net.minecraft.world.phys.Vec3;

/** Articulated original mesh with per-surface atlas materials, tint and emissive eyes. */
public final class CreatureMesh {
    public static final int SCALES=0,BELLY=1,MEMBRANE=2,HORN=3,METAL=4,MAIL=5,STONE=6,CLOTH=7,FUR=8,SHAG=9,HIDE=10,BONE=11,WOOD=12,CHITIN=13,FEATHER=14,LEATHER=15;
    public static final class Node {
        public final String name;public final float px,py,pz,bx,by,bz;
        public float xRot,yRot,zRot,dx,dy,dz,sx=1,sy=1,sz=1,alpha=1;public boolean visible=true;
        private float restSx=1,restSy=1,restSz=1,restX,restY,restZ;
        public final List<Node> children=new ArrayList<>();private final List<Face> faces=new ArrayList<>();
        public Node(String name,float x,float y,float z,float rx,float ry,float rz){this.name=name;px=x;py=y;pz=z;bx=rx;by=ry;bz=rz;reset();}
        public Node node(String name,float x,float y,float z){return node(name,x,y,z,0,0,0);}
        public Node node(String name,float x,float y,float z,float rx,float ry,float rz){var n=new Node(name,x,y,z,rx,ry,rz);children.add(n);return n;}
        public void reset(){xRot=bx;yRot=by;zRot=bz;dx=restX;dy=restY;dz=restZ;sx=restSx;sy=restSy;sz=restSz;alpha=1;visible=true;children.forEach(Node::reset);}
        public Node proportions(float x,float y,float z){restSx=x;restSy=y;restSz=z;sx=x;sy=y;sz=z;return this;}
        public Node offset(float x,float y,float z){restX=x;restY=y;restZ=z;dx=x;dy=y;dz=z;return this;}
        public Node box(float x,float y,float z,float w,float h,float d,int tile,int color){return box(x,y,z,w,h,d,tile,color,false);}
        public Node box(float x,float y,float z,float w,float h,float d,int tile,int color,boolean glow){
            float X=x+w,Y=y+h,Z=z+d;
            quad(tile,color,glow,new float[][]{{x,y,z},{X,y,z},{X,Y,z},{x,Y,z}});
            quad(tile,color,glow,new float[][]{{X,y,Z},{x,y,Z},{x,Y,Z},{X,Y,Z}});
            quad(tile,color,glow,new float[][]{{x,y,Z},{x,y,z},{x,Y,z},{x,Y,Z}});
            quad(tile,color,glow,new float[][]{{X,y,z},{X,y,Z},{X,Y,Z},{X,Y,z}});
            quad(tile,color,glow,new float[][]{{x,y,Z},{X,y,Z},{X,y,z},{x,y,z}});
            quad(tile,color,glow,new float[][]{{x,Y,z},{X,Y,z},{X,Y,Z},{x,Y,Z}});return this;
        }
        private void quad(int tile,int color,boolean glow,float[][] points){faces.add(new Face(points,tile,color,glow));}
        public void triangle(float[] a,float[] b,float[] c,int tile,int color){quad(tile,color,false,new float[][]{a,b,c,c});quad(tile,color,false,new float[][]{c,b,a,a});}
        public void render(PoseStack p,VertexConsumer v,int light,int overlay){render(p,v,light,overlay,1);}
        public void render(PoseStack p,VertexConsumer v,int light,int overlay,float opacity){
            if(!visible)return;opacity*=alpha;if(opacity<.01F)return;
            p.pushPose();p.translate((px+dx)/16,(py+dy)/16,(pz+dz)/16);if(zRot!=0)p.mulPose(Axis.ZP.rotation(zRot));if(yRot!=0)p.mulPose(Axis.YP.rotation(yRot));if(xRot!=0)p.mulPose(Axis.XP.rotation(xRot));if(sx!=1||sy!=1||sz!=1)p.scale(sx,sy,sz);
            for(var f:faces)f.render(p,v,light,overlay,opacity);for(var n:children)n.render(p,v,light,overlay,opacity);p.popPose();
        }
        /** Octagonal cross-section gives shoulders, thighs and muzzles actual silhouette changes. */
        public Node chamfer(float x,float y,float z,float w,float h,float d,float cut,int tile,int color){
            float c=Math.min(cut,Math.min(w,d)*.4F);float[][] ring={{x+c,z},{x+w-c,z},{x+w,z+c},{x+w,z+d-c},{x+w-c,z+d},{x+c,z+d},{x,z+d-c},{x,z+c}};
            for(int i=0;i<8;i++){var a=ring[i];var b=ring[(i+1)%8];quad(tile,color,false,new float[][]{{a[0],y,a[1]},{b[0],y,b[1]},{b[0],y+h,b[1]},{a[0],y+h,a[1]}});
                quad(tile,color,false,new float[][]{{x+w/2,y,z+d/2},{b[0],y,b[1]},{a[0],y,a[1]},{x+w/2,y,z+d/2}});
                quad(tile,color,false,new float[][]{{x+w/2,y+h,z+d/2},{a[0],y+h,a[1]},{b[0],y+h,b[1]},{x+w/2,y+h,z+d/2}});}
            return this;
        }
        public Node taper(float height,float base,float tip,int tile,int color){
            float[][] a={{-base,0,-base},{base,0,-base},{base,0,base},{-base,0,base}},b={{-tip,-height,-tip},{tip,-height,-tip},{tip,-height,tip},{-tip,-height,tip}};
            for(int i=0;i<4;i++)quad(tile,color,false,new float[][]{a[i],a[(i+1)%4],b[(i+1)%4],b[i]});quad(tile,color,false,new float[][]{b[3],b[2],b[1],b[0]});return this;
        }
        public void collect(Map<String,Node> map){map.put(name,this);children.forEach(n->n.collect(map));}
    }
    private record RenderVectors(org.joml.Vector3f position,org.joml.Vector3f normal){}
    private static final ThreadLocal<RenderVectors> RENDER_VECTORS=ThreadLocal.withInitial(()->new RenderVectors(new org.joml.Vector3f(),new org.joml.Vector3f()));
    private static final class Face {
        final float[][] points;final int color;final boolean glow;final float nx,ny,nz,u,t,spanU,spanV;
        Face(float[][] points,int tile,int color,boolean glow){
            this.points=points;this.color=color;this.glow=glow;
            var a=points[0];var b=points[1];var c=points[2];var edge=new Vec3(b[0]-a[0],b[1]-a[1],b[2]-a[2]);var normal=edge.cross(new Vec3(c[0]-a[0],c[1]-a[1],c[2]-a[2])).normalize();nx=(float)-normal.x;ny=(float)-normal.y;nz=(float)-normal.z;
            u=tile%4*.25F+.003F;t=tile/4*.25F+.003F;
            // Stable texel density: a toe no longer wears the same giant scale patch as a torso.
            spanU=.242F*(float)Math.clamp(edge.length()/18,.14,1);spanV=.242F*(float)Math.clamp(new Vec3(c[0]-b[0],c[1]-b[1],c[2]-b[2]).length()/18,.14,1);
        }
        void render(PoseStack p,VertexConsumer v,int light,int overlay,float alpha){
            int rgba=((int)(Math.clamp(alpha,0,1)*255)<<24)|color;
            var vectors=RENDER_VECTORS.get();var pose=p.last();var normal=pose.transformNormal(nx,ny,nz,vectors.normal());
            float normalX=normal.x(),normalY=normal.y(),normalZ=normal.z();
            for(int i=0;i<4;i++){
                var q=points[i];var position=pose.pose().transformPosition(q[0]/16,q[1]/16,q[2]/16,vectors.position());
                v.addVertex(position.x(),position.y(),position.z()).setColor(rgba).setUv(u+(i==1||i==2?spanU:0),t+(i>=2?spanV:0)).setOverlay(overlay).setLight(glow?15728880:light).setNormal(normalX,normalY,normalZ);
            }
        }
    }
    public static Node beam(Node p,String name,float[] a,float[] b,float thick,int tile,int color){
        float dx=b[0]-a[0],dy=b[1]-a[1],dz=b[2]-a[2],len=(float)Math.sqrt(dx*dx+dy*dy+dz*dz);
        var n=p.node(name,a[0],a[1],a[2],(float)Math.acos(Math.clamp(dy/len,-1,1)),(float)Math.atan2(dx,dz),0);n.box(-thick/2,0,-thick/2,thick,len,thick,tile,color);return n;
    }
    public static float r(float degrees){return degrees*(float)Math.PI/180;}
    public static int mix(int a,int b,float f){return ((int)(((a>>16)&255)*(1-f)+((b>>16)&255)*f)<<16)|((int)(((a>>8)&255)*(1-f)+((b>>8)&255)*f)<<8)|(int)((a&255)*(1-f)+(b&255)*f);}
}
