package com.junwo.starrpg;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.tick.EntityTickEvent;

@EventBusSubscriber(modid = StarRPG.MODID)
public final class MonsterProgression {
    private static final String TIER = "starrpg_monster_tier";
    public static final TagKey<EntityType<?>> BOSSES = tag("bosses");
    public static final TagKey<EntityType<?>> EXCLUDED = tag("scaling_excluded");
    private static TagKey<EntityType<?>> tag(String name) {
        return TagKey.create(Registries.ENTITY_TYPE, ResourceLocation.fromNamespaceAndPath(StarRPG.MODID, name));
    }
    public static boolean eligible(LivingEntity mob) {
        return !(mob instanceof Player) && !mob.getType().is(EXCLUDED)
                && !(mob instanceof TamableAnimal pet && pet.isTame())
                && (mob instanceof Enemy || mob.getType().is(BOSSES));
    }
    public static int tier(LivingEntity mob) { return Math.clamp(mob.getPersistentData().getInt(TIER), 0, 5); }
    @SubscribeEvent
    public static void join(EntityJoinLevelEvent event) {
        if (!event.getLevel().isClientSide() && event.getEntity() instanceof LivingEntity mob) tryScale(mob);
    }
    @SubscribeEvent
    public static void tick(EntityTickEvent.Post event) {
        if (event.getEntity() instanceof LivingEntity mob && !mob.level().isClientSide() && mob.tickCount % 100 == 0) tryScale(mob);
    }
    public static void tryScale(LivingEntity mob) {
        if (!Config.MOB_SCALING.get() || !eligible(mob) || mob.getServer() == null) return;
        int worldTier = WorldDifficulty.get(mob.getServer()).tier();
        if (!mob.getPersistentData().contains(TIER)) applyTier(mob, worldTier);
        else if (worldTier > tier(mob)) upgradeTier(mob, worldTier);
        if (mob instanceof net.minecraft.world.entity.monster.Zombie zombie) ZombieEquipment.equip(zombie, tier(mob));
    }

    /** Upgrade existing enemies without stacking modifiers or restoring lost health. */
    public static void upgradeTier(LivingEntity mob, int requested) {
        if (!eligible(mob) || requested <= tier(mob)) return;
        float health = mob.getHealth();
        mob.getPersistentData().remove(TIER);
        applyTier(mob, requested);
        mob.setHealth(Math.min(health, mob.getMaxHealth()));
    }
    public static void applyTier(LivingEntity mob, int requested) {
        if (!eligible(mob) || mob.getPersistentData().contains(TIER)) return;
        int tier = Math.clamp(requested, 0, Config.MAX_TIER.get());
        float healthRatio = mob.getHealth() / mob.getMaxHealth();
        double factor = mob.getType().is(BOSSES) ? Config.BOSS_SCALING.get() : 1.0;
        modifier(mob, Attributes.MAX_HEALTH, "monster_health", tier * Config.MOB_HEALTH.get() * factor, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
        modifier(mob, Attributes.ATTACK_DAMAGE, "monster_damage", tier * Config.MOB_DAMAGE.get() * factor, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
        modifier(mob, Attributes.ARMOR, "monster_armor", tier * factor, AttributeModifier.Operation.ADD_VALUE);
        modifier(mob, Attributes.MOVEMENT_SPEED, "monster_speed", tier * 0.02 * factor, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
        mob.getPersistentData().putInt(TIER, tier);
        mob.setHealth(Math.max(0, Math.min(mob.getMaxHealth(), mob.getMaxHealth() * healthRatio)));
    }
    @SubscribeEvent
    public static void rangedDamage(net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent event) {
        if (!(event.getSource().getEntity() instanceof LivingEntity attacker) || !eligible(attacker)) return;
        if (event.getSource().is(net.minecraft.world.damagesource.DamageTypes.MOB_ATTACK)
                && attacker.getAttribute(Attributes.ATTACK_DAMAGE) != null) return;
        double factor = attacker.getType().is(BOSSES) ? Config.BOSS_SCALING.get() : 1.0;
        event.setAmount(event.getAmount() * (float) (1 + tier(attacker) * Config.MOB_DAMAGE.get() * factor));
    }
    private static void modifier(LivingEntity mob, net.minecraft.core.Holder<Attribute> attribute,
                                 String name, double amount, AttributeModifier.Operation operation) {
        AttributeInstance instance = mob.getAttribute(attribute);
        if (instance == null || amount == 0) return;
        ResourceLocation id = ResourceLocation.fromNamespaceAndPath(StarRPG.MODID, name);
        instance.removeModifier(id);
        instance.addPermanentModifier(new AttributeModifier(id, amount, operation));
    }
}
