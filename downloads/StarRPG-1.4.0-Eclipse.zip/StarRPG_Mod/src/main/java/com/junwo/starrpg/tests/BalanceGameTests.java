package com.junwo.starrpg.tests;

import com.junwo.starrpg.*;
import net.minecraft.core.component.DataComponents;
import net.minecraft.gametest.framework.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.level.GameType;
import net.minecraft.world.effect.MobEffects;
import net.neoforged.neoforge.gametest.*;
import net.neoforged.neoforge.event.entity.living.*;
import net.neoforged.neoforge.event.entity.player.CriticalHitEvent;
import java.util.*;

@GameTestHolder(StarRPG.MODID)
@PrefixGameTestTemplate(false)
public class BalanceGameTests {
    private static void check(GameTestHelper h, boolean ok, String message) { h.assertTrue(ok, message); }
    private static ItemStack enhanced(Item item, int level) {
        ItemStack stack = new ItemStack(item); EnhancementData.setLevel(stack, level); return stack;
    }
    private static Player player(GameTestHelper h) { return h.makeMockPlayer(GameType.SURVIVAL); }
    private static void fullGear(Player p) {
        p.setItemSlot(EquipmentSlot.MAINHAND, enhanced(Items.DIAMOND_SWORD, 10));
        p.setItemSlot(EquipmentSlot.HEAD, enhanced(Items.DIAMOND_HELMET, 10));
        p.setItemSlot(EquipmentSlot.CHEST, enhanced(Items.DIAMOND_CHESTPLATE, 10));
        p.setItemSlot(EquipmentSlot.LEGS, enhanced(Items.DIAMOND_LEGGINGS, 10));
        p.setItemSlot(EquipmentSlot.FEET, enhanced(Items.DIAMOND_BOOTS, 10));
    }
    @GameTest(template="empty") public static void renamedWeaponIsNotEnhanced(GameTestHelper h) {
        ItemStack stack = new ItemStack(Items.DIAMOND_SWORD);
        stack.set(DataComponents.CUSTOM_NAME, Component.literal("+99999999999999999999 Sword"));
        check(h, EnhancementData.level(stack)==0, "Anvil name granted enhancement");
        EnhancementData.setLevel(stack, 7); RuneDataHelper.setRuneEffect(stack, RuneEffect.SWORD_STAR_SLASH);
        stack.set(DataComponents.CUSTOM_NAME, Component.literal("Renamed again"));
        ItemStack restored = ItemStack.parseOptional(h.getLevel().registryAccess(), (CompoundTag)stack.save(h.getLevel().registryAccess()));
        check(h, EnhancementData.level(restored)==7, "Enhancement lost on rename or save");
        check(h, RuneDataHelper.getRuneEffect(restored)==RuneEffect.SWORD_STAR_SLASH, "Rune data overwritten");
        EnhancementData.setLevel(restored, 500);check(h, EnhancementData.level(restored)==10,"Level not clamped");
        h.succeed();
    }
    @GameTest(template="empty") public static void enhancementConsumesExactMaterials(GameTestHelper h) {
        Player p=player(h); EnhancementMenu menu=new EnhancementMenu(1,p.getInventory());
        ItemStack sword=enhanced(Items.IRON_SWORD,9); RuneDataHelper.setRuneEffect(sword,RuneEffect.SWORD_STAR_SLASH);
        for(int i=0;i<10;i++) EnhancementData.recordFailure(sword);
        menu.getSlot(0).set(sword);menu.getSlot(1).set(new ItemStack(StarRPG.STAR_DUST.get(),20));
        menu.getSlot(2).set(new ItemStack(StarRPG.STAR_FRAGMENT.get(),10));
        check(h,menu.clickMenuButton(p,0),"Valid upgrade rejected");
        check(h,EnhancementData.level(sword)==10,"Pity did not guarantee upgrade");
        check(h,menu.getSlot(1).getItem().getCount()==5 && menu.getSlot(2).getItem().getCount()==5,"Wrong material cost");
        check(h,RuneDataHelper.hasRuneEffect(sword),"Upgrade lost rune");
        check(h,!menu.clickMenuButton(p,0),"Allowed level 11");h.succeed();
    }
    @GameTest(template="empty") public static void failedUpgradeKeepsEquipment(GameTestHelper h) {
        Player p=player(h);EnhancementMenu menu=new EnhancementMenu(1,p.getInventory());
        ItemStack sword=enhanced(Items.IRON_SWORD,9);menu.getSlot(0).set(sword);
        menu.getSlot(1).set(new ItemStack(StarRPG.STAR_DUST.get(),20));menu.getSlot(2).set(new ItemStack(StarRPG.STAR_FRAGMENT.get(),10));
        long seed=0;
        while(true){p.getRandom().setSeed(seed);if(p.getRandom().nextInt(100)>=30)break;seed++;}
        p.getRandom().setSeed(seed);menu.clickMenuButton(p,0);
        check(h,EnhancementData.level(sword)==9 && !menu.getSlot(0).getItem().isEmpty(),"Failed upgrade destroyed/downgraded gear");
        check(h,EnhancementMenu.getSuccessChance(sword)==40,"Failure did not add pity");h.succeed();
    }
    @GameTest(template="empty") public static void wrongMaterialsAreRejected(GameTestHelper h) {
        Player p=player(h);EnhancementMenu menu=new EnhancementMenu(1,p.getInventory());
        menu.getSlot(0).set(new ItemStack(Items.IRON_SWORD));menu.getSlot(1).set(new ItemStack(Items.DIRT,64));
        check(h,!menu.clickMenuButton(p,0),"Server trusted client slot material");
        check(h,EnhancementData.level(menu.getSlot(0).getItem())==0,"Invalid upgrade changed level");h.succeed();
    }
    @GameTest(template="empty") public static void axeCriticalIsBounded(GameTestHelper h) {
        Player p=player(h);p.setItemSlot(EquipmentSlot.MAINHAND,enhanced(Items.DIAMOND_AXE,10));
        var target=EntityType.ZOMBIE.create(h.getLevel());
        CriticalHitEvent event=new CriticalHitEvent(p,target,1.5F,true);
        EnhancementEffects.onCriticalHit(event);
        check(h,Math.abs(event.getDamageMultiplier()-2.0F)<0.001,"+10 axe is not 2x critical");h.succeed();
    }
    @GameTest(template="empty") public static void armorMitigatesEnhancement(GameTestHelper h) {
        Player p=player(h);p.setItemSlot(EquipmentSlot.MAINHAND,enhanced(Items.DIAMOND_AXE,7));
        var bare=h.spawn(EntityType.ZOMBIE,1,2,1);var armored=h.spawn(EntityType.ZOMBIE,3,2,1);
        bare.setNoAi(true);armored.setNoAi(true);
        for(EquipmentSlot slot:EquipmentSlot.values()) bare.setItemSlot(slot,ItemStack.EMPTY);
        armored.setItemSlot(EquipmentSlot.HEAD,new ItemStack(Items.DIAMOND_HELMET));
        armored.setItemSlot(EquipmentSlot.CHEST,new ItemStack(Items.DIAMOND_CHESTPLATE));
        armored.setItemSlot(EquipmentSlot.LEGS,new ItemStack(Items.DIAMOND_LEGGINGS));
        armored.setItemSlot(EquipmentSlot.FEET,new ItemStack(Items.DIAMOND_BOOTS));
        h.runAfterDelay(2, () -> {
        check(h,armored.getArmorValue()>=20,"Test armor attributes were not equipped");
        bare.hurt(h.getLevel().damageSources().playerAttack(p),2);
        armored.hurt(h.getLevel().damageSources().playerAttack(p),2);
        check(h,bare.getHealth()<14,"Enhancement was not applied");
        check(h,armored.getHealth()>17,"Enhancement bypassed armor: remaining HP="+armored.getHealth());h.succeed();
        });
    }
    @GameTest(template="empty") public static void lifestealDoesNotHealOverkill(GameTestHelper h) {
        Player p=player(h);p.setItemSlot(EquipmentSlot.MAINHAND,enhanced(Items.DIAMOND_SWORD,10));p.setHealth(10);
        var victim=EntityType.ZOMBIE.create(h.getLevel());victim.setHealth(2);
        victim.hurt(h.getLevel().damageSources().playerAttack(p),100);
        check(h,p.getHealth()>10 && p.getHealth()<=10.25F,"Lifesteal used overkill damage");h.succeed();
    }
    @GameTest(template="empty") public static void runeDamageDoesNotRecurse(GameTestHelper h) {
        Player p=player(h);p.setItemSlot(EquipmentSlot.MAINHAND,enhanced(Items.DIAMOND_SWORD,10));
        RuneDataHelper.setRuneEffect(p.getMainHandItem(),RuneEffect.SWORD_SUPERNOVA);
        var target=EntityType.COW.create(h.getLevel());float before=target.getHealth();
        CombatRules.runeDamage(p,target,2);
        check(h,Math.abs(target.getHealth()-(before-2))<0.01,"Secondary damage re-triggered enhancement");h.succeed();
    }
    @GameTest(template="empty") public static void tameAnimalsAreProtected(GameTestHelper h) {
        Player p=player(h);var pet=EntityType.WOLF.create(h.getLevel());pet.setTame(true,true);
        float before=pet.getHealth();CombatRules.runeDamage(p,pet,100);
        check(h,pet.getHealth()==before,"Rune hit a tame animal");
        var horse=EntityType.HORSE.create(h.getLevel());horse.setTamed(true);
        check(h,!CombatRules.canHarm(p,horse),"Rune can hit a tamed horse");h.succeed();
    }
    @GameTest(template="empty") public static void bloodStormCanActivate(GameTestHelper h) {
        Player p=player(h);ItemStack axe=new ItemStack(Items.IRON_AXE);RuneDataHelper.setRuneEffect(axe,RuneEffect.AXE_BLOOD_STORM);
        p.setItemSlot(EquipmentSlot.MAINHAND,axe);var dead=h.spawn(EntityType.ZOMBIE,2,2,2);var nearby=h.spawn(EntityType.ZOMBIE,3,2,2);
        nearby.setNoAi(true);nearby.setInvulnerable(false);
        AxeRuneEffects.onLivingDeath(new LivingDeathEvent(dead,h.getLevel().damageSources().playerAttack(p)));
        // Effect is now attributed bleed; verify stored state through a tick using an online attacker is covered separately.
        check(h,EnhancementEffects.hasBleed(nearby),"Mythic blood storm never activated");h.succeed();
    }
    @GameTest(template="empty") public static void scalingIsBoundedAndPersistent(GameTestHelper h) {
        var mob=EntityType.ZOMBIE.create(h.getLevel());MonsterProgression.applyTier(mob,99);
        check(h,MonsterProgression.tier(mob)==5 && Math.abs(mob.getMaxHealth()-50)<0.01,"Tier cap/health wrong");
        check(h,Math.abs(mob.getAttributeValue(Attributes.ATTACK_DAMAGE)-4.8)<0.01,"Damage scale wrong");
        mob.setHealth(25);MonsterProgression.applyTier(mob,1);check(h,mob.getHealth()==25,"Rescaling healed mob");
        CompoundTag saved=new CompoundTag();mob.saveWithoutId(saved);
        var restored=EntityType.ZOMBIE.create(h.getLevel());restored.load(saved);MonsterProgression.applyTier(restored,5);
        check(h,MonsterProgression.tier(restored)==5 && restored.getMaxHealth()==50 && restored.getHealth()==25,"Reload stacked/reset scaling");h.succeed();
    }
    @GameTest(template="empty") public static void bossesAndAnimalsUseDifferentScaling(GameTestHelper h) {
        var boss=EntityType.WITHER.create(h.getLevel());MonsterProgression.applyTier(boss,5);
        check(h,Math.abs(boss.getMaxHealth()-525)<0.01,"Boss did not get reduced scaling");
        var cow=EntityType.COW.create(h.getLevel());MonsterProgression.applyTier(cow,5);
        check(h,cow.getMaxHealth()==10 && MonsterProgression.tier(cow)==0,"Cow was scaled");h.succeed();
    }
    @GameTest(template="empty") public static void worldClockPersistsAndIgnoresGear(GameTestHelper h) {
        var clock=new WorldDifficulty();
        for(int i=0;i<100;i++) clock.advance(false);
        check(h,clock.activeTicks()==0,"Empty/creative-only server advanced the clock");
        clock.setTier(2);long before=clock.activeTicks();clock.advance(true);
        check(h,clock.activeTicks()==before+1 && clock.tier()==2,"Active clock increment wrong");
        var saved=clock.save(new CompoundTag(),h.getLevel().registryAccess());
        var restored=WorldDifficulty.load(saved,h.getLevel().registryAccess());
        check(h,restored.activeTicks()==clock.activeTicks() && restored.tier()==2,"World clock lost on save");
        long boundary=Config.MINUTES_PER_TIER.get()*1200L;
        check(h,WorldDifficulty.tierAt(boundary-1)==0 && WorldDifficulty.tierAt(boundary)==1,"Tier boundary wrong");
        check(h,WorldDifficulty.tierAt(Long.MAX_VALUE)==5,"World tier unbounded");
        Player p=player(h);fullGear(p);
        var mob=EntityType.ZOMBIE.create(h.getLevel());MonsterProgression.tryScale(mob);
        check(h,MonsterProgression.tier(mob)==WorldDifficulty.get(h.getLevel().getServer()).tier(),"Gear overrode shared world tier");
        h.succeed();
    }
    @GameTest(template="empty") public static void secondaryKillsRewardBossButNotLivestock(GameTestHelper h) {
        Player p=player(h);var boss=EntityType.WITHER.create(h.getLevel());
        var source=new net.minecraft.world.damagesource.DamageSource(h.getLevel().registryAccess().registryOrThrow(net.minecraft.core.registries.Registries.DAMAGE_TYPE).getHolderOrThrow(CombatRules.RUNE),p);
        List<ItemEntity> drops=new ArrayList<>();MobDropEvents.onLivingDrops(new LivingDropsEvent(boss,source,drops,true));
        check(h,drops.stream().anyMatch(e->e.getItem().is(StarRPG.STAR_FRAGMENT.get())),"Attributed rune kill lost boss reward");
        check(h,drops.stream().anyMatch(e->RuneItemHelper.isRune(e.getItem())),"Boss did not drop rune");
        drops.clear();MobDropEvents.onLivingDrops(new LivingDropsEvent(EntityType.COW.create(h.getLevel()),source,drops,true));
        check(h,drops.isEmpty(),"Livestock awarded progression resources");h.succeed();
    }
    @GameTest(template="empty") public static void runeRerollConsumesOneAndPreservesEnhancement(GameTestHelper h) {
        Player p=player(h);RuneEngravingMenu menu=new RuneEngravingMenu(1,p.getInventory());
        var sword=enhanced(Items.DIAMOND_SWORD,7);RuneDataHelper.setRuneEffect(sword,RuneEffect.SWORD_STAR_SLASH);
        menu.getSlot(0).set(sword);menu.getSlot(1).set(new ItemStack(StarRPG.RARE_RUNE.get()));
        check(h,menu.clickMenuButton(p,0),"Rune replacement rejected");
        check(h,RuneDataHelper.getRuneEffect(sword).getRarity()==RuneRarity.RARE && EnhancementData.level(sword)==7,"Rune replacement lost level");
        check(h,menu.getSlot(1).getItem().isEmpty(),"Rune replacement was free");h.succeed();
    }

    @GameTest(template="empty") public static void rapidAttackDoesNotGetFullEnhancement(GameTestHelper h) {
        Player p=player(h);p.setItemSlot(EquipmentSlot.MAINHAND,enhanced(Items.IRON_SWORD,10));
        p.resetAttackStrengthTicker();var target=EntityType.COW.create(h.getLevel());
        CombatRules.attack(new net.neoforged.neoforge.event.entity.player.AttackEntityEvent(p,target));
        var source=h.getLevel().damageSources().playerAttack(p);
        check(h,!CombatRules.charged(source),"Uncharged swing can proc runes");
        target.hurt(source,1);
        check(h,target.getHealth()>6 && target.getHealth()<8,"Rapid swing received full enhancement or none");h.succeed();
    }
    @GameTest(template="empty") public static void lifestealHasPerSecondCap(GameTestHelper h) {
        Player p=player(h);p.setItemSlot(EquipmentSlot.MAINHAND,enhanced(Items.DIAMOND_SWORD,10));p.setHealth(1);
        for(int i=0;i<6;i++){var target=EntityType.COW.create(h.getLevel());target.hurt(h.getLevel().damageSources().playerAttack(p),100);}
        check(h,Math.abs(p.getHealth()-5)<0.01,"Lifesteal exceeded or did not reach 4 HP cap");h.succeed();
    }
    @GameTest(template="empty") public static void skeletonProjectilesScale(GameTestHelper h) {
        var skeleton=EntityType.SKELETON.create(h.getLevel());MonsterProgression.applyTier(skeleton,5);
        var arrow=EntityType.ARROW.create(h.getLevel());var target=EntityType.COW.create(h.getLevel());
        target.hurt(h.getLevel().damageSources().arrow(arrow,skeleton),2);
        check(h,Math.abs(target.getHealth()-6.8F)<0.01,"Ranged monster damage was not scaled");h.succeed();
    }
    @GameTest(template="empty") public static void enhancedBossSurvivesOpeningCombo(GameTestHelper h) {
        var boss=EntityType.WITHER.create(h.getLevel());MonsterProgression.applyTier(boss,5);
        Player p=player(h);p.setItemSlot(EquipmentSlot.MAINHAND,enhanced(Items.DIAMOND_AXE,10));
        for(int i=0;i<5;i++){boss.invulnerableTime=0;boss.hurt(h.getLevel().damageSources().playerAttack(p),18);}
        check(h,boss.getHealth()>350 && boss.getHealth()<500,"Boss combat damage out of expected bounds: "+boss.getHealth());h.succeed();
    }
}
