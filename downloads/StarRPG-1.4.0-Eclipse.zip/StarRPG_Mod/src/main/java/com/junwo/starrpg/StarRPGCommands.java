package com.junwo.starrpg;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

@EventBusSubscriber(modid = StarRPG.MODID)
public final class StarRPGCommands {
    @SubscribeEvent
    public static void register(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("starrpg")
            .then(Commands.literal("setlevel").requires(s -> s.hasPermission(2))
                .then(Commands.argument("level", IntegerArgumentType.integer(0,10)).executes(ctx -> {
                    var player = ctx.getSource().getPlayerOrException();
                    var item = player.getMainHandItem();
                    if (!EnhancementData.supports(item)) { ctx.getSource().sendFailure(Component.literal("장비를 손에 들어 주세요.")); return 0; }
                    EnhancementData.setLevel(item, IntegerArgumentType.getInteger(ctx,"level"));
                    EnhancementLore.update(item);
                    ctx.getSource().sendSuccess(() -> Component.literal("장비 강화 데이터 적용 완료"), true);
                    return 1;
                })))
            .then(Commands.literal("difficulty").executes(ctx -> {
                WorldDifficulty world = WorldDifficulty.get(ctx.getSource().getServer());
                ctx.getSource().sendSuccess(() -> Component.literal("월드 난이도: " + world.tier()
                        + " / " + Config.MAX_TIER.get() + " | 누적 생존 시간: " + world.activeTicks() / 1200
                        + "분 | 단계당 " + Config.MINUTES_PER_TIER.get() + "분"), false);
                return 1;
            }))
            .then(Commands.literal("worldtier").requires(s -> s.hasPermission(2))
                .then(Commands.argument("tier", IntegerArgumentType.integer(0,5)).executes(ctx -> {
                    WorldDifficulty world = WorldDifficulty.get(ctx.getSource().getServer());
                    world.setTier(IntegerArgumentType.getInteger(ctx, "tier"));
                    ctx.getSource().sendSuccess(() -> Component.literal("월드 난이도 " + world.tier()
                            + "단계로 설정. 기존 몬스터는 내려가지 않으므로 새 몬스터로 비교하세요."), true);
                    return 1;
                }))));
    }
}
