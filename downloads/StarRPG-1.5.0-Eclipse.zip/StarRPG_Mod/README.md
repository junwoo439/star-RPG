# StarRPG

Minecraft 1.21.1 / NeoForge 21.1.235용 장비 강화·무기/방어구 룬·월드 공통 난이도·장비/낚싯대 좀비 모드.
현재 버전: **1.5.0**.

## Eclipse에서 게임 실행

**[Eclipse 실행 안내](ECLIPSE.md)**를 따라 Existing Gradle Project로 가져오고
`Run > Run Configurations > Java Application > StarRPG Client`를 실행하세요.
게임의 싱글플레이에서 테스트할 수 있습니다. JDK 21이 필요합니다.

Windows 명령줄 실행:

```bat
gradlew.bat runClient
```

클라이언트 월드와 설정은 `run-client/`에 저장됩니다.
변경 내용, 밸런스 설정, 기존 강화 장비 이전 방법은 [BALANCE.md](BALANCE.md)를 참조하세요.

## 빌드 및 개발자 테스트

```bash
bash gradlew build
bash gradlew runGameTestServer
```

Windows에서는 `gradlew.bat`를 사용합니다. 배포 파일은 `build/libs/starrpg-1.5.0.jar`입니다.
GameTest는 별도의 `run-gametest/`를 사용합니다.

1.5.0 변경 내용과 빠른 확인 순서는 [TESTING-1.5.md](TESTING-1.5.md)를 참고하세요.

이번 버전은 몬스터 단계 분포, 좀비 약화·불완전 방어구, 골드 지갑·재료 상점을 추가합니다. `/starrpg shop`으로 상점을 열 수 있습니다.

외부 모드 설치와 지원 한계는 [MODS-1.5.md](MODS-1.5.md)를 확인하세요. Twilight Forest 설치 도구가 포함되지만 외부 모드 JAR은 포함되지 않습니다. 직업·전면 인챈트 제거 등 앞선 검토안은 구현하지 않았습니다.
