package com.junwo.starrpg;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.*;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.*;
import net.neoforged.neoforge.event.tick.EntityTickEvent;

@EventBusSubscriber(modid=StarRPG.MODID)
public final class SpecialWeaponEffects {
    private static final ResourceLocation BREAK=ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,"hammer_break");
    @SubscribeEvent(priority=EventPriority.LOW) public static void incoming(LivingIncomingDamageEvent e) {
        if(!CombatRules.primary(e.getSource()) || !CombatRules.charged(e.getSource()) || !(e.getSource().getEntity() instanceof Player p)
                || !(p.getMainHandItem().getItem() instanceof StarDaggerItem) || !CombatRules.canHarm(p,e.getEntity()))return;
        long now=p.level().getGameTime();if(p.getPersistentData().getLong("starrpg_dagger_ready")>now)return;
        var direction=p.position().subtract(e.getEntity().position()).multiply(1,0,1).normalize();
        var facing=e.getEntity().getLookAngle().multiply(1,0,1).normalize();
        if(direction.dot(facing)<-0.5) {
            e.setAmount(e.getAmount()*1.2F);p.getPersistentData().putLong("starrpg_dagger_ready",now+60);
        }
    }
    @SubscribeEvent public static void hit(LivingDamageEvent.Post e) {
        if(e.getNewDamage()<=0 || !CombatRules.primary(e.getSource()) || !CombatRules.charged(e.getSource())
                || !(e.getSource().getEntity() instanceof Player p) || !(p.getMainHandItem().getItem() instanceof WarHammerItem)
                || !CombatRules.canHarm(p,e.getEntity()))return;
        long now=p.level().getGameTime();if(p.getPersistentData().getLong("starrpg_hammer_ready")>now)return;
        var armor=e.getEntity().getAttribute(Attributes.ARMOR);if(armor==null)return;
        armor.addOrUpdateTransientModifier(new AttributeModifier(BREAK,-3,AttributeModifier.Operation.ADD_VALUE));
        e.getEntity().getPersistentData().putLong("starrpg_hammer_until",now+60);
        p.getPersistentData().putLong("starrpg_hammer_ready",now+120);
    }
    @SubscribeEvent public static void tick(EntityTickEvent.Post e) {
        if(e.getEntity().level().isClientSide() || !(e.getEntity() instanceof net.minecraft.world.entity.LivingEntity target))return;
        if(target.getPersistentData().contains("starrpg_hammer_until") && target.level().getGameTime()>=target.getPersistentData().getLong("starrpg_hammer_until")) {
            var armor=target.getAttribute(Attributes.ARMOR);if(armor!=null)armor.removeModifier(BREAK);
            target.getPersistentData().remove("starrpg_hammer_until");
        }
    }
}
