package com.junwo.starrpg;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.*;

public final class WarHammerItem extends AxeItem {
    public WarHammerItem(Properties properties) { super(Tiers.IRON,properties.attributes(AxeItem.createAttributes(Tiers.IRON,7,-3.2F))); }
    @Override public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> lines, TooltipFlag flag) {
        super.appendHoverText(stack,context,lines,flag);
        lines.add(Component.literal("충전 타격 후 적 방어력 -3, 3초 / 재사용 6초"));
        lines.add(Component.literal("느린 강타 무기 / 도끼 룬 사용"));
    }
}
