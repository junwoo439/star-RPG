package com.junwo.starrpg;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

@EventBusSubscriber(
        modid = StarRPG.MODID,
        value = Dist.CLIENT
)
public class StarRPGClientEvents {

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        while (StarRPGKeyMappings.CHEST_ABILITY.consumeClick()) {
            PacketDistributor.sendToServer(
                    UseChestAbilityPayload.INSTANCE
            );
        }
    }
}