package com.junwo.starrpg;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.*;
import net.neoforged.neoforge.registries.*;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(Registries.ENTITY_TYPE, StarRPG.MODID);
    public static final DeferredHolder<EntityType<?>, EntityType<ZombieHook>> ZOMBIE_HOOK = ENTITIES.register("zombie_hook",
            () -> EntityType.Builder.<ZombieHook>of(ZombieHook::new, MobCategory.MISC)
                    .sized(0.25F, 0.25F).clientTrackingRange(4).updateInterval(1).noSave().build("starrpg:zombie_hook"));
}
