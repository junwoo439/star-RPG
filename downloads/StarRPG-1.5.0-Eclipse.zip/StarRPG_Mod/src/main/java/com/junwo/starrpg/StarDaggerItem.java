package com.junwo.starrpg;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.*;

public final class StarDaggerItem extends SwordItem {
    public StarDaggerItem(Properties properties) {
        super(Tiers.IRON, properties.attributes(SwordItem.createAttributes(Tiers.IRON,1,-1.6F)));
    }
    @Override public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> lines, TooltipFlag flag) {
        super.appendHoverText(stack,context,lines,flag);
        lines.add(Component.literal("충전된 후방 공격: 피해 +20% / 재사용 3초"));
        lines.add(Component.literal("검 룬 사용 / 강화 피해는 단계당 +0.6"));
    }
}
