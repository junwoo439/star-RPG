package com.junwo.starrpg;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

public final class MaterialShopScreen extends AbstractContainerScreen<MaterialShopMenu> {
    private final Button[] purchases=new Button[6];
    public MaterialShopScreen(MaterialShopMenu menu,Inventory inventory,Component title) {
        super(menu,inventory,title);imageWidth=270;imageHeight=178;
    }
    @Override protected void init() {
        super.init();
        for(int i=0;i<6;i++) {
            final int id=i;
            purchases[i]=addRenderableWidget(Button.builder(Component.literal(i%2==0?"1개":"8개"),b->{
                if(minecraft!=null && minecraft.gameMode!=null)minecraft.gameMode.handleInventoryButtonClick(menu.containerId,id);
            }).bounds(leftPos+166+(i%2)*48,topPos+51+(i/2)*33,44,20).build());
        }
    }
    @Override protected void containerTick() {
        super.containerTick();
        for(int i=0;i<6;i++) purchases[i].active=menu.enabled() && menu.price(i/2)>0 && menu.balance()>=menu.price(i/2)*(i%2==0?1:8);
    }
    @Override protected void renderBg(GuiGraphics g,float tick,int x,int y) {
        g.fill(leftPos,topPos,leftPos+imageWidth,topPos+imageHeight,0xFF16212C);
        g.fill(leftPos+2,topPos+2,leftPos+imageWidth-2,topPos+imageHeight-2,0xFF263644);
        for(var p:Economy.Product.values())g.renderItem(p.stack(1),leftPos+12,topPos+53+p.ordinal()*33);
    }
    @Override protected void renderLabels(GuiGraphics g,int x,int y) {
        g.drawString(font,title,12,12,0xFFFFFF,false);
        g.drawString(font,"보유 골드: "+menu.balance()+" G",12,29,0xFFD978,false);
        for(var p:Economy.Product.values()) {
            int row=51+p.ordinal()*33;
            g.drawString(font,p.label,35,row,0xFFFFFF,false);
            g.drawString(font,menu.price(p.ordinal())+" G / 개",35,row+12,0xBCD0E0,false);
        }
        g.drawString(font,menu.enabled()?"적 처치로 골드 획득 · 구매 즉시 지급":"경제 기능이 꺼져 있습니다.",12,155,0xBCD0E0,false);
    }
    @Override public void render(GuiGraphics g,int x,int y,float tick) { super.render(g,x,y,tick);renderTooltip(g,x,y); }
}
