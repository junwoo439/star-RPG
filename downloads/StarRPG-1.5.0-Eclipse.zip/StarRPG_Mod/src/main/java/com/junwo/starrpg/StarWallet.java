package com.junwo.starrpg;

import java.util.*;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/** UUID accounts live in world data, so death and dimension travel cannot copy or erase money. */
public final class StarWallet extends SavedData {
    public static final int MAX_BALANCE = 1_000_000_000;
    private final Map<UUID, Integer> balances = new HashMap<>();
    private final Map<UUID, long[]> huntingWindows = new HashMap<>();
    public static StarWallet get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(new SavedData.Factory<>(StarWallet::new, StarWallet::load), "starrpg_wallets");
    }
    public static StarWallet load(CompoundTag tag, HolderLookup.Provider registries) {
        StarWallet result = new StarWallet();
        for (Tag entry : tag.getList("accounts", Tag.TAG_COMPOUND)) {
            CompoundTag account = (CompoundTag) entry;
            if (!account.hasUUID("id")) continue;
            UUID id = account.getUUID("id");
            result.balances.put(id, (int)Math.clamp(account.getLong("balance"), 0, MAX_BALANCE));
            result.huntingWindows.put(id, new long[]{Math.max(0, account.getLong("window")), Math.clamp(account.getLong("earned"),0,240)});
        }
        return result;
    }
    @Override public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        ListTag accounts = new ListTag();
        balances.forEach((id,balance) -> {
            CompoundTag account = new CompoundTag(); account.putUUID("id",id); account.putLong("balance",balance);
            long[] window = huntingWindows.getOrDefault(id,new long[2]);
            account.putLong("window",window[0]); account.putLong("earned",window[1]); accounts.add(account);
        });
        tag.put("accounts",accounts); return tag;
    }
    public int balance(UUID id) { return balances.getOrDefault(id,0); }
    public int credit(UUID id, int amount) {
        if (amount <= 0) return 0;
        int added = (int)Math.min((long)amount, (long)MAX_BALANCE - balance(id));
        if (added > 0) { balances.put(id,balance(id)+added); setDirty(); }
        return added;
    }
    public boolean debit(UUID id, int amount) {
        if (amount <= 0 || amount > balance(id)) return false;
        balances.put(id,balance(id)-amount); setDirty(); return true;
    }
    public boolean transfer(UUID from, UUID to, int amount) {
        if (from.equals(to) || amount <= 0 || amount > balance(from) || (long)balance(to)+amount > MAX_BALANCE) return false;
        debit(from,amount); credit(to,amount); return true;
    }
    /** Ordinary hunting is capped per player per 1200 server ticks. Boss rewards are separate. */
    public int huntingReward(UUID id, int amount, boolean boss, long now) {
        if (amount <= 0) return 0;
        if (boss) return credit(id,amount);
        long[] window = huntingWindows.computeIfAbsent(id,k -> new long[]{now,0});
        if (now < window[0] || now-window[0] >= 1200) { window[0]=now;window[1]=0; }
        int added = credit(id,Math.min(amount,(int)Math.max(0,240-window[1])));
        window[1]+=added; setDirty(); return added;
    }
}
