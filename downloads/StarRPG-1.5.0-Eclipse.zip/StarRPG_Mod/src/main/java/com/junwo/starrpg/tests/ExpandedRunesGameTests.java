package com.junwo.starrpg.tests;

import com.junwo.starrpg.*;
import java.util.*;
import net.minecraft.core.registries.Registries;
import net.minecraft.gametest.framework.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.*;
import net.minecraft.world.item.*;
import net.minecraft.world.item.crafting.*;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.GameType;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.common.damagesource.DamageContainer;
import net.neoforged.neoforge.gametest.*;

@GameTestHolder(StarRPG.MODID)
@PrefixGameTestTemplate(false)
public class ExpandedRunesGameTests {
    private static Player player(GameTestHelper h){return h.makeMockPlayer(GameType.SURVIVAL);}
    private static ItemStack gear(Item item,RuneEffect rune,int enhancement) {
        ItemStack stack=new ItemStack(item);EnhancementData.setLevel(stack,enhancement);if(rune!=null)RuneDataHelper.setRuneEffect(stack,rune);return stack;
    }
    private static LivingEntity target(GameTestHelper h) {
        var target=EntityType.ZOMBIE.create(h.getLevel());target.getAttribute(Attributes.ARMOR).setBaseValue(0);return target;
    }
    private static Arrow arrow(GameTestHelper h,Player p,ItemStack weapon,double speed) {
        Arrow arrow=new Arrow(h.getLevel(),p,new ItemStack(Items.ARROW),weapon);arrow.setDeltaMovement(0,0,speed);RangedRuneEffects.prepare(arrow);return arrow;
    }
    @GameTest(template="empty") public static void fourCandidatesForEverySlotAndRarity(GameTestHelper h) {
        h.assertTrue(RuneEffect.values().length==180,"Expected 180 total rune variants");
        for(var type:RuneWeaponType.values())for(var rarity:RuneRarity.values()) {
            var list=RuneEffectManager.getPossibleEffects(rarity,type);
            h.assertTrue(list.size()==4 && new HashSet<>(list).size()==4,"Wrong rune candidate count: "+type+" "+rarity);
            for(var effect:list)h.assertTrue(!RuneEffectDescription.getDescriptionLines(effect).isEmpty(),"Missing effect description");
        }
        h.assertTrue(RuneEffect.valueOf("HELMET_MYTHIC").getVariant()==0,"Legacy rune ID changed");h.succeed();
    }
    @GameTest(template="empty") public static void rareRuneCostsExactlyNineCommons(GameTestHelper h) {
        var common=new ItemStack(StarRPG.COMMON_RUNE.get());
        var input=CraftingInput.of(3,3,Collections.nCopies(9,common));
        var recipe=h.getLevel().getRecipeManager().getRecipeFor(RecipeType.CRAFTING,input,h.getLevel()).orElseThrow();
        var result=recipe.value().assemble(input,h.getLevel().registryAccess());
        h.assertTrue(result.is(StarRPG.RARE_RUNE.get()) && result.getCount()==1,"9 common recipe wrong");
        var eight=new ArrayList<ItemStack>(Collections.nCopies(9,common));eight.set(8,ItemStack.EMPTY);
        h.assertTrue(h.getLevel().getRecipeManager().getRecipeFor(RecipeType.CRAFTING,CraftingInput.of(3,3,eight),h.getLevel()).isEmpty(),"8 commons accepted");
        var old=CraftingInput.of(3,2,List.of(common,common,common,common,new ItemStack(StarRPG.STAR_FRAGMENT.get()),ItemStack.EMPTY));
        h.assertTrue(h.getLevel().getRecipeManager().getRecipeFor(RecipeType.CRAFTING,old,h.getLevel()).isEmpty(),"Old cheap rare recipe remains");h.succeed();
    }
    @GameTest(template="empty") public static void rangedWeaponsCanEngraveAndEnhance(GameTestHelper h) {
        Player p=player(h);
        for(Item item:List.of(Items.BOW,Items.CROSSBOW,Items.TRIDENT,StarRPG.STAR_DAGGER.get(),StarRPG.WAR_HAMMER.get())) {
            var stack=new ItemStack(item);var menu=new RuneEngravingMenu(1,p.getInventory());menu.getSlot(0).set(stack);menu.getSlot(1).set(new ItemStack(StarRPG.EPIC_RUNE.get()));
            h.assertTrue(menu.clickMenuButton(p,0),"New weapon cannot engrave");
            var rune=RuneDataHelper.getRuneEffect(stack);h.assertTrue(rune.getWeaponType()==RuneWeaponType.forItem(stack),"Wrong weapon rune family");
            var enhance=new EnhancementMenu(2,p.getInventory());enhance.getSlot(0).set(stack);enhance.getSlot(1).set(new ItemStack(StarRPG.STAR_DUST.get()));
            h.assertTrue(enhance.clickMenuButton(p,0) && EnhancementData.level(stack)==1 && RuneDataHelper.getRuneEffect(stack)==rune,"Enhancement lost rune / weapon unsupported");
        }h.succeed();
    }
    @GameTest(template="empty") public static void arrowKeepsFiredWeaponAfterSwitchAndSave(GameTestHelper h) {
        Player p=player(h);var bow=gear(Items.BOW,RuneEffect.BOW_HUNTER_MYTHIC,10);var shot=arrow(h,p,bow,3);
        EnhancementData.setLevel(bow,0);p.setItemSlot(EquipmentSlot.MAINHAND,gear(Items.DIAMOND_AXE,RuneEffect.AXE_GIANT_STRENGTH,10));
        CompoundTag saved=new CompoundTag();shot.saveWithoutId(saved);var restored=EntityType.ARROW.create(h.getLevel());restored.load(saved);restored.setOwner(p);
        var target=target(h);target.hurt(h.getLevel().damageSources().arrow(restored,p),2);
        h.assertTrue(Math.abs(target.getHealth()-10)<0.01,"Projectile used current hand / lost saved weapon: "+target.getHealth());h.succeed();
    }
    @GameTest(template="empty") public static void weakBowDrawScalesDamageAndCannotProcControl(GameTestHelper h) {
        Player p=player(h);var shot=arrow(h,p,gear(Items.BOW,RuneEffect.BOW_FROST_MYTHIC,10),0.6);
        var target=target(h);target.hurt(h.getLevel().damageSources().arrow(shot,p),2);
        h.assertTrue(target.getHealth()>17.7 && target.getHealth()<17.9 && !target.hasEffect(MobEffects.MOVEMENT_SLOWDOWN),"Weak draw got full enhancement or proc");h.succeed();
    }
    @GameTest(template="empty") public static void crossbowMultiShotSharesRuneCooldown(GameTestHelper h) {
        Player p=player(h);var crossbow=gear(Items.CROSSBOW,RuneEffect.CROSSBOW_WEAKEN_MYTHIC,0);
        var a=target(h);var b=target(h);a.hurt(h.getLevel().damageSources().arrow(arrow(h,p,crossbow,3),p),1);b.hurt(h.getLevel().damageSources().arrow(arrow(h,p,crossbow,3),p),1);
        h.assertTrue(a.hasEffect(MobEffects.WEAKNESS) && !b.hasEffect(MobEffects.WEAKNESS),"Multi-shot repeated rune control");h.succeed();
    }
    @GameTest(template="empty") public static void tridentRecoveryUsesActualDamageAndCooldown(GameTestHelper h) {
        Player p=player(h);p.setHealth(5);var stack=gear(Items.TRIDENT,RuneEffect.TRIDENT_RECOVERY_MYTHIC,10);
        var trident=new ThrownTrident(h.getLevel(),p,stack);var target=target(h);target.setHealth(2);
        target.hurt(h.getLevel().damageSources().trident(trident,p),100);
        h.assertTrue(Math.abs(p.getHealth()-5.3F)<0.001,"Trident healed overkill or failed on kill: "+p.getHealth());
        var second=target(h);second.setHealth(2);second.hurt(h.getLevel().damageSources().trident(new ThrownTrident(h.getLevel(),p,stack),p),100);
        h.assertTrue(Math.abs(p.getHealth()-5.3F)<0.001,"Trident ignored recovery cooldown");
        h.assertTrue(EnhancementData.level(trident.getWeaponItem())==10 && RuneDataHelper.getRuneEffect(trident.getWeaponItem())==RuneEffect.TRIDENT_RECOVERY_MYTHIC,"Thrown trident lost item data");h.succeed();
    }
    @GameTest(template="empty") public static void rangedSplashIsCappedAndProtectsPets(GameTestHelper h) {
        Player p=player(h);p.setItemSlot(EquipmentSlot.MAINHAND,gear(Items.DIAMOND_SWORD,RuneEffect.SWORD_SUPERNOVA,10));
        var primary=h.spawn(EntityType.ZOMBIE,2,2,2);primary.setNoAi(true);
        var pet=h.spawn(EntityType.WOLF,3,2,2);pet.setTame(true,true);pet.setNoAi(true);float health=pet.getHealth();
        List<LivingEntity> victims=new ArrayList<>();for(int i=0;i<10;i++){var cow=h.spawn(EntityType.COW,3,2,2);cow.setNoAi(true);victims.add(cow);}
        var shot=arrow(h,p,gear(Items.BOW,RuneEffect.BOW_FRAGMENT_MYTHIC,0),3);primary.hurt(h.getLevel().damageSources().arrow(shot,p),1);
        h.assertTrue(victims.stream().filter(e->Math.abs(e.getHealth()-8)<0.01).count()==8,"Splash cap or recursion wrong");
        h.assertTrue(pet.getHealth()==health,"Splash hit tame pet");h.succeed();
    }
    @GameTest(template="empty") public static void armorVariantsDoNotRetainOtherVariantBonuses(GameTestHelper h) {
        Player p=player(h);float base=p.getMaxHealth();
        p.setItemSlot(EquipmentSlot.LEGS,gear(Items.IRON_LEGGINGS,RuneEffect.LEGGINGS_VITALITY_MYTHIC,0));ArmorRuneEffects.update(p);
        h.assertTrue(p.getMaxHealth()==base+10 && ArmorRuneEffects.hookMultiplier(p)==1,"Vitality accidentally grants anchor");p.setHealth(p.getMaxHealth());
        p.setItemSlot(EquipmentSlot.LEGS,gear(Items.IRON_LEGGINGS,RuneEffect.LEGGINGS_MYTHIC,0));ArmorRuneEffects.update(p);
        h.assertTrue(p.getMaxHealth()==base && p.getHealth()<=base && ArmorRuneEffects.hookMultiplier(p)<0.41,"Variant switch retained max health / lost anchor");
        double swim=p.getAttributeValue(net.neoforged.neoforge.common.NeoForgeMod.SWIM_SPEED),step=p.getAttributeValue(Attributes.STEP_HEIGHT);
        p.setItemSlot(EquipmentSlot.FEET,gear(Items.IRON_BOOTS,RuneEffect.BOOTS_AQUATIC_MYTHIC,0));ArmorRuneEffects.update(p);
        h.assertTrue(p.getAttributeValue(net.neoforged.neoforge.common.NeoForgeMod.SWIM_SPEED)>swim,"Aquatic modifier missing");
        p.setItemSlot(EquipmentSlot.FEET,gear(Items.IRON_BOOTS,RuneEffect.BOOTS_PATHFINDER_MYTHIC,0));ArmorRuneEffects.update(p);
        h.assertTrue(p.getAttributeValue(net.neoforged.neoforge.common.NeoForgeMod.SWIM_SPEED)==swim && Math.abs(p.getAttributeValue(Attributes.STEP_HEIGHT)-step-0.5)<0.001,"Pathfinder switch kept swim / wrong step height");h.succeed();
    }
    @GameTest(template="empty") public static void composureCleansesSlowButNotPoison(GameTestHelper h) {
        Player p=player(h);p.setItemSlot(EquipmentSlot.HEAD,gear(Items.IRON_HELMET,RuneEffect.HELMET_COMPOSURE_MYTHIC,0));
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,100,0));p.addEffect(new MobEffectInstance(MobEffects.POISON,100,0));ArmorRuneEffects.update(p);
        h.assertTrue(!p.hasEffect(MobEffects.MOVEMENT_SLOWDOWN) && p.hasEffect(MobEffects.POISON),"Composure incorrectly duplicates cleanse");h.succeed();
    }
    private static float reduced(Player p,DamageSource source) {
        var event=new LivingIncomingDamageEvent(p,new DamageContainer(source,10));ArmorRuneEffects.incoming(event);return event.getAmount();
    }
    @GameTest(template="empty") public static void chestVariantsRespectDamageTypeAndLowHealth(GameTestHelper h) {
        Player p=player(h);var enemy=EntityType.ZOMBIE.create(h.getLevel());
        p.setItemSlot(EquipmentSlot.CHEST,gear(Items.IRON_CHESTPLATE,RuneEffect.CHESTPLATE_FIRE_MYTHIC,0));
        h.assertTrue(Math.abs(reduced(p,h.getLevel().damageSources().onFire())-7)<0.01 && reduced(p,h.getLevel().damageSources().mobAttack(enemy))==10,"Fire rune filters wrong");
        p.setItemSlot(EquipmentSlot.CHEST,gear(Items.IRON_CHESTPLATE,RuneEffect.CHESTPLATE_MELEE_MYTHIC,0));
        h.assertTrue(Math.abs(reduced(p,h.getLevel().damageSources().mobAttack(enemy))-8.5)<0.01,"Melee rune wrong");
        p.setItemSlot(EquipmentSlot.CHEST,gear(Items.IRON_CHESTPLATE,RuneEffect.CHESTPLATE_LAST_STAND_MYTHIC,0));
        h.assertTrue(reduced(p,h.getLevel().damageSources().mobAttack(enemy))==10,"Last stand active at full health");p.setHealth(5);
        h.assertTrue(Math.abs(reduced(p,h.getLevel().damageSources().mobAttack(enemy))-8.4)<0.01 && reduced(p,h.getLevel().damageSources().fellOutOfWorld())==10,"Last stand threshold/bypass wrong");h.succeed();
    }
    @GameTest(template="empty") public static void daggerBackstabHasDirectionAndCooldown(GameTestHelper h) {
        Player p=player(h);p.setItemSlot(EquipmentSlot.MAINHAND,new ItemStack(StarRPG.STAR_DAGGER.get()));var victim=target(h);victim.setYRot(0);p.setPos(0,0,-1);
        victim.hurt(h.getLevel().damageSources().playerAttack(p),10);
        h.assertTrue(Math.abs(victim.getHealth()-8)<0.001,"Dagger backstab missing");victim.setHealth(20);victim.invulnerableTime=0;
        victim.hurt(h.getLevel().damageSources().playerAttack(p),10);h.assertTrue(victim.getHealth()==10,"Dagger cooldown missing");
        var front=target(h);front.setYRot(0);p.getPersistentData().remove("starrpg_dagger_ready");p.setPos(0,0,1);front.hurt(h.getLevel().damageSources().playerAttack(p),10);
        h.assertTrue(front.getHealth()==10,"Front attack counted as backstab");h.succeed();
    }
    @GameTest(template="empty",timeoutTicks=100) public static void hammerArmorBreakExpiresWithoutStacking(GameTestHelper h) {
        Player p=player(h);p.setItemSlot(EquipmentSlot.MAINHAND,new ItemStack(StarRPG.WAR_HAMMER.get()));var victim=h.spawn(EntityType.COW,2,2,2);victim.setNoAi(true);victim.getAttribute(Attributes.ARMOR).setBaseValue(10);
        victim.hurt(h.getLevel().damageSources().playerAttack(p),1);h.assertTrue(victim.getArmorValue()==7,"Hammer did not reduce armor");victim.invulnerableTime=0;
        victim.hurt(h.getLevel().damageSources().playerAttack(p),1);h.assertTrue(victim.getArmorValue()==7,"Hammer debuff stacked");
        h.runAfterDelay(65,()->{h.assertTrue(victim.getArmorValue()==10,"Hammer armor reduction never expired");h.succeed();});
    }
    @GameTest(template="empty") public static void newWeaponRecipesAndEnchantmentsWork(GameTestHelper h) {
        var iron=new ItemStack(Items.IRON_INGOT);var fragment=new ItemStack(StarRPG.STAR_FRAGMENT.get());var stick=new ItemStack(Items.STICK);
        var daggerInput=CraftingInput.of(1,3,List.of(iron,fragment,stick));
        var hammerInput=CraftingInput.of(3,3,List.of(iron,iron,iron,iron,fragment,iron,ItemStack.EMPTY,stick,ItemStack.EMPTY));
        for(var input:List.of(daggerInput,hammerInput)) {
            var recipe=h.getLevel().getRecipeManager().getRecipeFor(RecipeType.CRAFTING,input,h.getLevel()).orElseThrow();var item=recipe.value().assemble(input,h.getLevel().registryAccess());
            h.assertTrue(item.is(StarRPG.STAR_DAGGER.get()) || item.is(StarRPG.WAR_HAMMER.get()),"New weapon recipe incorrect");
            h.assertTrue(h.getLevel().registryAccess().registryOrThrow(Registries.ENCHANTMENT).getHolderOrThrow(Enchantments.SHARPNESS).value().canEnchant(item),"Sharpness cannot enchant new weapon");
        }
        h.assertTrue(new ItemStack(StarRPG.STAR_DAGGER.get()).is(ItemTags.SWORDS) && new ItemStack(StarRPG.WAR_HAMMER.get()).is(ItemTags.AXES),"Weapon tags missing");h.succeed();
    }
    @GameTest(template="empty") public static void focusAndDaggerEnhancementStayBounded(GameTestHelper h) {
        Player p=player(h);p.setItemSlot(EquipmentSlot.HEAD,gear(Items.IRON_HELMET,RuneEffect.HELMET_FOCUS_MYTHIC,0));
        var event=new net.neoforged.neoforge.event.entity.player.CriticalHitEvent(p,target(h),1.5F,true);ArmorRuneEffects.critical(event);
        h.assertTrue(Math.abs(event.getDamageMultiplier()-1.65F)<0.001,"Focus multiplier wrong");
        p.setItemSlot(EquipmentSlot.MAINHAND,gear(StarRPG.STAR_DAGGER.get(),null,10));p.setPos(0,0,1);var victim=target(h);victim.setYRot(0);
        victim.hurt(h.getLevel().damageSources().playerAttack(p),2);
        h.assertTrue(Math.abs(victim.getHealth()-12)<0.01,"Fast dagger got full sword enhancement damage");h.succeed();
    }
    @GameTest(template="empty") public static void sentryAndEscapeTriggerOnlyOnActualDamage(GameTestHelper h) {
        Player p=player(h);p.setItemSlot(EquipmentSlot.HEAD,gear(Items.IRON_HELMET,RuneEffect.HELMET_SENTRY_MYTHIC,0));
        p.setItemSlot(EquipmentSlot.FEET,gear(Items.IRON_BOOTS,RuneEffect.BOOTS_ESCAPE_MYTHIC,0));double base=p.getAttributeValue(Attributes.MOVEMENT_SPEED);
        ArmorRuneEffects.update(p);h.assertTrue(p.getAttributeValue(Attributes.MOVEMENT_SPEED)==base,"Escape active before damage");
        var enemy=target(h);p.hurt(h.getLevel().damageSources().mobAttack(enemy),1);ArmorRuneEffects.update(p);
        h.assertTrue(enemy.hasEffect(MobEffects.GLOWING) && p.getAttributeValue(Attributes.MOVEMENT_SPEED)>base,"Sentry or escape did not trigger");
        long now=p.level().getGameTime();p.getPersistentData().putLong("starrpg_escape_until",now);ArmorRuneEffects.update(p);
        h.assertTrue(p.getAttributeValue(Attributes.MOVEMENT_SPEED)==base,"Escape speed did not expire");
        p.invulnerableTime=0;p.hurt(h.getLevel().damageSources().mobAttack(enemy),1);ArmorRuneEffects.update(p);
        h.assertTrue(p.getAttributeValue(Attributes.MOVEMENT_SPEED)==base,"Escape cooldown bypassed");h.succeed();
    }
    @GameTest(template="empty") public static void bulwarkAndRecoveryRequireTheirConditions(GameTestHelper h) {
        Player p=player(h);double armor=p.getAttributeValue(Attributes.ARMOR);
        p.setItemSlot(EquipmentSlot.LEGS,gear(Items.IRON_LEGGINGS,RuneEffect.LEGGINGS_BULWARK_MYTHIC,0));p.setShiftKeyDown(true);p.setPose(Pose.CROUCHING);ArmorRuneEffects.update(p);
        h.assertTrue(Math.abs(p.getAttributeValue(Attributes.ARMOR)-armor-5)<0.001,"Crouch armor missing");
        p.setShiftKeyDown(false);p.setPose(Pose.STANDING);ArmorRuneEffects.update(p);h.assertTrue(p.getAttributeValue(Attributes.ARMOR)==armor,"Crouch armor retained while standing");
        p.setItemSlot(EquipmentSlot.LEGS,gear(Items.IRON_LEGGINGS,RuneEffect.LEGGINGS_RECOVERY_MYTHIC,0));p.setHealth(5);long now=p.level().getGameTime();
        p.getPersistentData().putLong("starrpg_armor_last_damage",now);ArmorRuneEffects.update(p);h.assertTrue(p.getHealth()==5,"Recovery active during combat");
        p.getPersistentData().putLong("starrpg_armor_last_damage",now-200);ArmorRuneEffects.update(p);h.assertTrue(p.getHealth()==7.5F,"Out of combat recovery wrong");
        ArmorRuneEffects.update(p);h.assertTrue(p.getHealth()==7.5F,"Recovery healed every tick");
        p.getFoodData().setFoodLevel(5);p.getPersistentData().putLong("starrpg_recovery_ready",now);ArmorRuneEffects.update(p);
        h.assertTrue(p.getHealth()==7.5F,"Recovery ignored hunger");h.succeed();
    }
}
