package com.junwo.starrpg;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

public class ChestAbilityManager {

    private static final Map<UUID, Long> LAST_USE_TIME = new HashMap<>();

    private static final long COOLDOWN_TICKS = 1200L; // 60초

    public static void tryUse(ServerPlayer player) {
        ItemStack chestplate =
                player.getItemBySlot(EquipmentSlot.CHEST);

        if (getEnhancementLevel(chestplate) < 10) {
            player.displayClientMessage(
                    Component.literal("§c+10 흉갑이 필요합니다."),
                    true
            );
            return;
        }

        long now = player.level().getGameTime();
        long lastUse = LAST_USE_TIME.getOrDefault(
                player.getUUID(),
                -COOLDOWN_TICKS
        );

        long remaining = COOLDOWN_TICKS - (now - lastUse);

        if (remaining > 0) {
            long seconds = (remaining + 19) / 20;

            player.displayClientMessage(
                    Component.literal(
                            "§c재생 능력 쿨타임: "
                            + seconds + "초"
                    ),
                    true
            );
            return;
        }

        if (!player.isAlive() || player.isSpectator()) return;
        LAST_USE_TIME.put(player.getUUID(), now);
        player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 120, 1));

        player.addEffect(
                new MobEffectInstance(
                        MobEffects.REGENERATION,
                        60,
                        1,
                        false,
                        true,
                        true
                )
        );

        player.displayClientMessage(
                Component.literal("§d재생 II + 보호막 발동!"),
                true
        );
    }

    public static void showCooldown(ServerPlayer player) {
        ItemStack chestplate =
                player.getItemBySlot(EquipmentSlot.CHEST);

        if (getEnhancementLevel(chestplate) < 10) {
            return;
        }

        long now = player.level().getGameTime();
        long lastUse = LAST_USE_TIME.getOrDefault(
                player.getUUID(),
                -COOLDOWN_TICKS
        );

        long remaining = COOLDOWN_TICKS - (now - lastUse);

        if (remaining > 0) {
            long seconds = (remaining + 19) / 20;

            player.displayClientMessage(
                    Component.literal(
                            "§c재생 능력 쿨타임: "
                            + seconds + "초"
                    ),
                    true
            );
        } else {
            player.displayClientMessage(
                    Component.literal("§aX키: 재생 능력 사용 가능"),
                    true
            );
        }
    }

    private static int getEnhancementLevel(ItemStack item) {
        return EnhancementData.level(item);
    }

    public static void pruneState(long now) {
        LAST_USE_TIME.entrySet().removeIf(e -> {
            if (now - e.getValue() < 1200) return false;
            return true;
        });
    }
    public static void clearState() {
        LAST_USE_TIME.clear();
    }
}
