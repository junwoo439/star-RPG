package com.junwo.starrpg;

import net.minecraft.world.entity.player.*;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.ItemStack;

public final class MaterialShopMenu extends AbstractContainerMenu {
    private final Player owner;
    private final ContainerData data=new SimpleContainerData(6);
    public MaterialShopMenu(int id, Inventory inventory) {
        super(ModMenus.MATERIAL_SHOP.get(),id); owner=inventory.player;addDataSlots(data);refresh();
    }
    private void refresh() {
        if (owner.level().isClientSide() || owner.getServer()==null) return;
        int balance=StarWallet.get(owner.getServer()).balance(owner.getUUID());
        data.set(0,balance&65535);data.set(1,(balance>>>16)&65535);
        for (var p:Economy.Product.values()) data.set(2+p.ordinal(),p.price());
        data.set(5,Config.ECONOMY_ENABLED.get()?1:0);
    }
    public int balance() { return (data.get(0)&65535)|((data.get(1)&65535)<<16); }
    public int price(int product) { return data.get(2+product); }
    public boolean enabled() { return data.get(5)==1; }
    @Override public void broadcastChanges() { refresh();super.broadcastChanges(); }
    @Override public boolean clickMenuButton(Player player,int button) {
        if (player!=owner || player.level().isClientSide() || !player.isAlive() || button<0 || button>=6) return false;
        var product=Economy.Product.values()[button/2];int count=button%2==0?1:8;
        var result=Economy.buy(player,product,count);player.displayClientMessage(Economy.feedback(result,product,count),false);broadcastChanges();
        return result==Economy.Purchase.OK;
    }
    @Override public boolean stillValid(Player player) { return player==owner && player.isAlive(); }
    @Override public ItemStack quickMoveStack(Player player,int index) { return ItemStack.EMPTY; }
}
