@echo off
setlocal
cd /d "%~dp0"
echo Installing Twilight Forest for Minecraft 1.21.1 / NeoForge...
echo Close Minecraft before running this installer.
call gradlew.bat --no-daemon installAdventureMods
if errorlevel 1 (
    echo Installation failed. See the error above and MODS-1.5.md.
    pause
    exit /b 1
)
echo Done. Launch StarRPG Client from Eclipse.
pause
