# StarRPG

Minecraft 1.21.1 / NeoForge 21.1.235용 장비 강화·무기/방어구 룬·월드 공통 난이도·장비/낚싯대 좀비 모드.
현재 버전: **2.2.0**.

## Eclipse에서 게임 실행

**[Eclipse 실행 안내](ECLIPSE.md)**를 따라 Existing Gradle Project로 가져오고
`Run > Run Configurations > Java Application > StarRPG Client`를 실행하세요.
게임의 싱글플레이에서 테스트할 수 있습니다. JDK 21이 필요합니다.

Windows 명령줄 실행:

```bat
gradlew.bat runClient
```

클라이언트 월드와 설정은 `run-client/`에 저장됩니다.
변경 내용, 밸런스 설정, 기존 강화 장비 이전 방법은 [BALANCE-2.2.md](BALANCE-2.2.md)를 참조하세요.

## 빌드 및 개발자 테스트

```bash
bash gradlew build
bash gradlew runGameTestServer
```

Windows에서는 `gradlew.bat`를 사용합니다. 배포 파일은 `build/libs/starrpg-2.2.0.jar`입니다.
GameTest는 별도의 `run-gametest/`를 사용합니다.

2.2.0 변경 내용과 빠른 확인 순서는 [TESTING-2.2.md](TESTING-2.2.md)를 참고하세요.

이번 버전은 **직업 무기의 손잡이·크기·각도·두께 개선, 새로 그린 효과 16종, 마법/직업별 능력 연출, 직업 변경 시 소지한 이전 직업 무기 +0 초기화**를 포함합니다. 초기화는 룬·내구도를 유지하며, 같은 직업 전직이나 실패한 변경에는 적용하지 않습니다. 2.1의 강화 피해와 16개 직업은 유지합니다.

일반 룬 결과는 일반 70% / 희귀 25% / 에픽 4.9% / 레전더리 0.1%입니다. 모든 입력 룬이 결과 등급을 보장하지 않으며 재각인 때 등급이 낮아질 수 있습니다. 룬 확률·수치는 [BALANCE-1.8.md](BALANCE-1.8.md), 전체 룬은 [RUNE-EFFECTS-1.8.csv](RUNE-EFFECTS-1.8.csv), 플레이 확인 순서는 [TESTING-2.2.md](TESTING-2.2.md)에 있습니다.

**Shift+H:** 상점·판매·직업·마법 / **R:** 무기 스킬 / **G:** 직업 능력. 지팡이 우클릭은 선택 주문, Shift+우클릭은 주문 변경입니다. 장비 강화는 설치한 **인챈트 테이블 우클릭**, 룬 각인은 **룬 각인 도구**를 사용합니다. 별조각은 강화 재료로 유지합니다.

별가루 기본 구매 가격은 40 G, 별조각은 400 G입니다. 전체 판매 가격은 [SELL-PRICES-2.2.csv](SELL-PRICES-2.2.csv)에 있습니다. 기존 월드와 프로젝트는 백업한 뒤 업데이트하세요.

외부 모드는 [MODS-1.5.1.md](MODS-1.5.1.md)를 따릅니다. setup-adventure-eclipse.bat으로 Twilight Forest 4.8.3802, Mowzie 1.8.2, GeckoLib 4.9.2를 설치하고 Eclipse 실행을 준비합니다. Ice and Fire는 호환 공식 빌드가 없어 제외했습니다. 생활직은 보류했습니다.

외부 Twilight Forest·Mowzie·GeckoLib과 함께 자동 GameTest **163개 통과**. 실제 클라이언트에서 아이템 표시 변환과 새 이펙트 렌더러를 확인했습니다. TESTING-2.2.md를 참고하세요. 배포 ZIP은 실행에 불필요한 art/ 원화·스크린샷을 제외하며 게임용 텍스처는 모두 포함합니다. Windows Eclipse와 실제 다인 PvP 체감은 별도 확인이 필요합니다.

**Shift+R:** 무기 각성기 (+15). +20·25에서 추가 발전합니다. 무기 설명에서 모든 해금을 확인하세요. 전체 단계표는 [WEAPON-UNLOCKS-2.0.csv](WEAPON-UNLOCKS-2.0.csv)에 있습니다.
