package com.junwo.starrpg;

import net.minecraft.core.particles.*;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.*;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/** Small bounded particle batches; no terrain edits or global camera shake. */
public final class CombatVisuals {
    public static void at(ServerLevel level,Vec3 pos,ParticleOptions particle,int count,double spread){level.sendParticles(particle,pos.x,pos.y,pos.z,count,spread,spread,spread,0.02);}
    public static void burst(Entity e,ParticleOptions particle,int count){if(e.level() instanceof ServerLevel level)at(level,e.position().add(0,1,0),particle,count,0.5);}
    public static void circle(Entity e,double radius,ParticleOptions particle){
        if(!(e.level() instanceof ServerLevel level))return;
        for(int i=0;i<24;i++){double a=i*Math.PI/12;at(level,e.position().add(Math.cos(a)*radius,0.15,Math.sin(a)*radius),particle,1,0);}
    }
    public static void ringAt(ServerLevel level,Vec3 center,double radius,ParticleOptions particle,int points){
        for(int i=0;i<points;i++){double a=i*Math.PI*2/points;at(level,center.add(Math.cos(a)*radius,0.1,Math.sin(a)*radius),particle,1,0);}
    }
    public static void line(ServerLevel level,Vec3 from,Vec3 to,ParticleOptions particle,int steps){
        for(int i=0;i<=steps;i++)at(level,from.lerp(to,(double)i/steps),particle,1,0);
    }
    /** Short silhouettes unique to each weapon family; at most 3 glyphs per cast. */
    public static void flourish(net.minecraft.world.entity.player.Player p,int kind){
        if(!(p.level() instanceof ServerLevel level))return;
        int color=WeaponArt.color(kind);Vec3 aim=p.getLookAngle(),eye=p.getEyePosition();
        switch(kind){
            case 3->{ArcaneSigil.spawn(level,p.position().add(aim.multiply(1,0,1).normalize().scale(1.5)),aim,9,color,2.0F,30);ArcaneSigil.spawn(level,p.position().add(0,0.1,0),aim,0,color,3,28);}
            case 5->{CombatVisuals.line(level,eye,eye.add(aim.scale(5)),ParticleTypes.ELECTRIC_SPARK,20);ArcaneSigil.spawn(level,eye.add(aim.scale(3)),aim,13,color,2.4F,22);}
            case 6,8->{for(int i=0;i<3;i++){double a=i*Math.PI*2/3;ArcaneSigil.spawn(level,p.position().add(Math.cos(a)*1.5,1,Math.sin(a)*1.5),new Vec3(Math.cos(a),0,Math.sin(a)),kind==8?10:2,color,1.5F,18+i*3);}}
            case 7->{CombatVisuals.line(level,p.position(),p.position().add(0,5,0),ParticleTypes.END_ROD,24);ArcaneSigil.spawn(level,p.position().add(0,0.1,0),aim,16,color,2,32);}
            case 9->{for(int i=1;i<=3;i++)ArcaneSigil.spawn(level,eye.add(aim.scale(i)),aim,14,color,0.5F+i*0.25F,12+i*3);}
            case 10->ArcaneSigil.spawn(level,eye.add(aim),aim,11,color,1.8F,32);
            case 11,12->{ArcaneSigil.spawn(level,eye.add(aim.scale(1.4)),aim,1,color,1,22);line(level,eye.add(aim),eye.add(aim.scale(3)),ParticleTypes.END_ROD,12);}
            case 13->{ringAt(level,p.position(),2,ParticleTypes.SPLASH,24);ringAt(level,p.position().add(0,0.6,0),1.4,ParticleTypes.SPLASH,24);}
            default->ArcaneSigil.spawn(level,eye.add(aim.scale(1.2)),aim,2,color,1.6F,16);
        }
    }
    public static void careerAura(net.minecraft.world.entity.player.Player p,int job){
        if(!(p.level() instanceof ServerLevel level))return;
        int school=MagicSchools.ofJob(job),kind=WeaponArt.kind(p.getMainHandItem());
        int style=Careers.mage(job)?MagicSchools.supportStyle(school):switch(job){case 0,9->11;case 1->10;case 2->1;case 4->7;case 5->5;case 6->16;case 7->15;case 8->14;default->0;};
        var point=style==11||style==10||style==14?p.position().add(0,1.1,0):style==1?p.getEyePosition().add(p.getLookAngle()):p.position().add(0,0.08,0);
        ArcaneSigil.spawn(level,point,p.getLookAngle(),style,Careers.mage(job)?MagicSchools.color(school):WeaponArt.color(kind),1.65F,36);
    }
    public static void sound(Entity e,net.minecraft.core.Holder<SoundEvent> sound,float volume,float pitch){sound(e,sound.value(),volume,pitch);}
    public static void sound(Entity e,SoundEvent sound,float volume,float pitch){e.level().playSound(null,e.blockPosition(),sound,SoundSource.PLAYERS,volume,pitch);}
}
