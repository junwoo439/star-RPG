package com.junwo.starrpg.tests;

import com.junwo.starrpg.*;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.*;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

@EventBusSubscriber(modid=StarRPG.MODID,value=Dist.CLIENT)
public final class ClientModelSmoke {
    private static int ticks,stage;private static boolean checked;
    private static Item[] weapons(){return new Item[]{StarRPG.STAR_DAGGER.get(),StarRPG.WAR_HAMMER.get(),StarRPG.MAGIC_STAFF.get(),StarRPG.STAR_SPEAR.get(),StarRPG.BERSERKER_BLADE.get(),StarRPG.SUN_SCEPTER.get(),StarRPG.SOUL_SCYTHE.get(),StarRPG.STAR_GAUNTLET.get(),StarRPG.AEGIS_BLADE.get()};}
    @SubscribeEvent public static void tick(ClientTickEvent.Post event){
        if(!Boolean.getBoolean("starrpg.clientSmoke"))return;
        var mc=Minecraft.getInstance();if(mc.getOverlay()!=null||mc.screen==null)return;
        if(!checked){
            for(Item weapon:weapons()){
                var model=mc.getItemRenderer().getModel(new ItemStack(weapon),null,null,0);
                if(model==mc.getModelManager().getMissingModel()||!model.isCustomRenderer()
                    ||!(net.neoforged.neoforge.client.extensions.common.IClientItemExtensions.of(weapon).getCustomRenderer() instanceof ArtisanItemRenderer))throw new IllegalStateException("Wrong weapon renderer: "+weapon);
                StarRPG.LOGGER.info("CLIENT_GRIP_CHECK PASSED: {}",weapon);
            }
            for(var weapon:new Item[]{Items.IRON_SWORD,Items.IRON_AXE,Items.BOW,Items.CROSSBOW,Items.TRIDENT})
                if(net.neoforged.neoforge.client.extensions.common.IClientItemExtensions.of(weapon).getCustomRenderer() instanceof ArtisanItemRenderer)throw new IllegalStateException("Vanilla weapon overridden");
            checked=true;mc.options.guiScale().set(1);mc.getWindow().setWindowed(1280,800);mc.resizeDisplay();mc.setScreen(new Preview(0));return;
        }
        if(++ticks>=80&&stage==0){stage=1;Screenshot.grab(mc.gameDirectory,"starrpg-2.2-grips.png",mc.getMainRenderTarget(),message->{StarRPG.LOGGER.info("CLIENT_GRIP_SCREENSHOT: {}",message.getString());mc.execute(()->mc.setScreen(new Preview(1)));});}
        if(ticks>=160&&stage==1){stage=2;Screenshot.grab(mc.gameDirectory,"starrpg-2.2-effects.png",mc.getMainRenderTarget(),message->{StarRPG.LOGGER.info("CLIENT_EFFECT_SCREENSHOT: {}",message.getString());mc.execute(mc::stop);});}
    }
    private static final class Preview extends Screen {
        private final int mode;
        Preview(int mode){super(Component.literal("StarRPG renderer verification"));this.mode=mode;}
        @Override public void render(GuiGraphics g,int x,int y,float partial){
            g.fillGradient(0,0,width,height,0xFF101C2C,0xFF160C20);
            g.drawCenteredString(font,mode==0?"StarRPG 2.2 - weapon grip & thickness calibration":"StarRPG 2.2 - painted spell and profession effects",width/2,12,0xF0D8FF);
            if(mode==0)grips(g);else effects(g);
            g.drawCenteredString(font,mode==0?"Actual item display transforms; cyan cross marks the hand origin (renderer preview)":"Original transparent art, tinted and animated on crossed planes / layered circles",width/2,height-15,0xA9C7D3);
        }
        private void grips(GuiGraphics g){
            String[] names={"Dagger","Hammer","Magic staff","Spear","Greatblade","Sun scepter","Soul scythe","Single gauntlet","Aegis blade"};
            var mc=Minecraft.getInstance();var buffer=mc.renderBuffers().bufferSource();
            for(int i=0;i<9;i++){
                int col=(width-50)/3,row=(height-65)/3,bx=25+(i%3)*col,by=32+(i/3)*row;
                g.fill(bx,by,bx+col-10,by+row-8,0xFF091322);g.drawCenteredString(font,names[i],bx+(col-10)/2,by+5,0xDBE8F0);
                for(int view=0;view<2;view++){
                    int cx=bx+col/4+view*col/2,cy=by+row-42;g.fill(cx-5,cy,cx+6,cy+1,0xFF52DDEE);g.fill(cx,cy-5,cx+1,cy+6,0xFF52DDEE);g.flush();
                    g.pose().pushPose();g.pose().translate(cx,cy,100);g.pose().scale(108,-108,108);g.pose().mulPose(Axis.YP.rotationDegrees(75));g.pose().mulPose(Axis.XP.rotationDegrees(-8));
                    var w=new ItemStack(weapons()[i]);var context=view==0?ItemDisplayContext.THIRD_PERSON_RIGHT_HAND:ItemDisplayContext.FIRST_PERSON_RIGHT_HAND;
                    mc.getItemRenderer().renderStatic(w,context,15728880,net.minecraft.client.renderer.texture.OverlayTexture.NO_OVERLAY,g.pose(),buffer,null,0);buffer.endBatch();g.pose().popPose();
                    g.drawCenteredString(font,view==0?"Third person":"First person",cx,by+row-23,0xA5B8C9);
                }
            }
        }
        private void effects(GuiGraphics g){
            int[] styles={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
            int[] colors={0x7FDBFF,0xFF7777,0x86BAFF,0xA8F2FF,0x5BFFD0,0xFFF0A1,0xFF913B,0x4DB9FF,0xF5BA75,0xD38CFF,0xFFD866,0xFFFFFF,0x72C5FF,0x80FFD0,0xB56EFF,0x97FFC8};
            String[] names={"Casting circles","Blade arc","Arcane lightning","Ice eruption","Water vortex","Light pillar","Fire plume","Water crown","Forge / earth","Soul wing","Guardian shield","Impact star","Spear thrust","Martial strike","Dark portal","Healing bloom"};
            var buffer=Minecraft.getInstance().renderBuffers().bufferSource();
            for(int i=0;i<16;i++){
                int col=(width-40)/4,row=(height-60)/4,bx=20+(i%4)*col,by=30+(i/4)*row;
                g.fill(bx,by,bx+col-8,by+row-8,0xFF081221);g.flush();g.pose().pushPose();g.pose().translate(bx+(col-8)/2,by+row-32,110);g.pose().scale(32,-32,32);
                g.pose().mulPose(Axis.XP.rotationDegrees(12));g.pose().mulPose(Axis.YP.rotationDegrees(styles[i]==13?65:25));
                if(styles[i]==1||styles[i]==2||styles[i]==10||styles[i]==11||styles[i]==12||styles[i]==14)g.pose().translate(0,1.6,0);
                ArcaneSigilRenderer.draw(g.pose(),buffer,styles[i],colors[i],1.5F,12+(ticks%10),50,0,0);buffer.endBatch();g.pose().popPose();
                g.drawCenteredString(font,names[i],bx+(col-8)/2,by+row-22,colors[i]);
            }
        }
    }
}
