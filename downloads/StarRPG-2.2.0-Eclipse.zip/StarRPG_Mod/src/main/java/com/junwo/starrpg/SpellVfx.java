package com.junwo.starrpg;

import com.mojang.blaze3d.vertex.*;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/** Original painted sprite atlas, animated on crossed planes and layered circles. */
public final class SpellVfx {
    public static final ResourceLocation ATLAS=ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,"textures/effect/spell_effects.png");
    public static void quad(PoseStack pose,VertexConsumer out,int cell,float width,float height,int color,float alpha){
        // The painted fire/water cells have glow from the row above at their top edge.
        // Trim only that transparent/stray margin through UVs; keep the original PNG intact.
        float top=cell==6||cell==7?0.020F:0.001F;
        float u=(cell%4)*0.25F+0.001F,v=(cell/4)*0.25F+top,span=0.248F,spanV=0.249F-top;
        float[][] pts={{-width,-height,u,v+spanV},{width,-height,u+span,v+spanV},{width,height,u+span,v},{-width,height,u,v}};
        for(int side=0;side<2;side++)for(int n=0;n<4;n++){
            var a=pts[side==0?n:3-n];out.addVertex(pose.last(),a[0],a[1],side==0?0.001F:-0.001F)
                .setColor((color>>16)&255,(color>>8)&255,color&255,(int)(Math.clamp(alpha,0,1)*255))
                .setUv(a[2],a[3]).setOverlay(OverlayTexture.NO_OVERLAY).setLight(15728880).setNormal(pose.last(),0,0,side==0?1:-1);
        }
    }
    private static void floor(PoseStack p,VertexConsumer out,int cell,int color,float radius,float y,float angle,float alpha){
        p.pushPose();p.translate(0,y,0);p.mulPose(Axis.XP.rotationDegrees(90));p.mulPose(Axis.ZP.rotationDegrees(angle));quad(p,out,cell,radius,radius,color,alpha);p.popPose();
    }
    private static void column(PoseStack p,VertexConsumer out,int cell,int color,float radius,float height,float angle,float alpha){
        for(int i=0;i<2;i++){p.pushPose();p.mulPose(Axis.YP.rotationDegrees(angle+i*90));p.translate(0,height*0.72,0);quad(p,out,cell,radius,height,color,alpha*(i==0?0.85F:0.65F));p.popPose();}
    }
    public static void draw(PoseStack p,MultiBufferSource buffers,int style,int color,float radius,float age,int life,float yaw,float pitch){
        float fade=Math.min(1,age/4)*Math.min(1,Math.max(0,(life-age)/12));
        if(fade<=0)return;float grow=0.55F+0.45F*Math.min(1,age/9),r=radius*grow;
        var out=buffers.getBuffer(RenderType.beaconBeam(ATLAS,true));
        p.pushPose();
        switch(style){
            case 0->{floor(p,out,0,color,r,0,age*1.8F,fade*0.9F);floor(p,out,0,color,r*0.66F,0.03F,-age*2.4F,fade*0.6F);}
            case 1->{p.mulPose(Axis.YP.rotationDegrees(-yaw));p.mulPose(Axis.XP.rotationDegrees(pitch));for(int i=0;i<3;i++){p.pushPose();p.translate(0,0,i*1.35);p.mulPose(Axis.ZP.rotationDegrees((i%2==0?1:-1)*age*2+i*30));quad(p,out,0,r*(1-i*0.12F),r*(1-i*0.12F),color,fade*0.85F);p.popPose();}}
            case 2,10,11,14->{p.mulPose(Axis.YP.rotationDegrees(-yaw));p.mulPose(Axis.XP.rotationDegrees(pitch));int cell=style==2?1:style==10?9:style==11?10:13;
                p.mulPose(Axis.ZP.rotationDegrees(style==11?age*0.8F:age*3));quad(p,out,cell,r,r,color,fade);}
            case 3->{floor(p,out,0,color,r,0,age,fade*0.65F);column(p,out,2,color,r*0.8F,r*1.8F,20,fade);}
            case 4->{floor(p,out,0,color,r,0,age,fade*0.6F);column(p,out,3,color,r,r*1.05F,25,fade);}
            case 5->{floor(p,out,0,color,r,0,age*2,fade);column(p,out,4,color,r*0.8F,r*1.5F,age*3,fade);floor(p,out,0,color,r*0.55F,r*1.5F,-age*2,fade*0.5F);}
            case 6->{floor(p,out,0,color,r,0,age,fade);column(p,out,5,color,r*0.8F,r*1.65F,10,fade);}
            case 7->{floor(p,out,0,color,r,0,-age*2,fade*0.6F);column(p,out,6,color,r,r*1.2F,age,fade);}
            case 8->{floor(p,out,0,color,r,0,age*2,fade*0.6F);column(p,out,7,color,r,r*0.8F,20,fade);}
            case 9->{floor(p,out,0,color,r,0,age,fade*0.6F);column(p,out,8,color,r*0.85F,r*1.1F,age*0.8F,fade);}
            case 12->{for(int i=0;i<3;i++){p.pushPose();p.mulPose(Axis.YP.rotationDegrees(i*60));p.mulPose(Axis.ZP.rotationDegrees(age*2));quad(p,out,11,r,r,color,fade);p.popPose();}}
            case 13->{p.mulPose(Axis.YP.rotationDegrees(-yaw));p.mulPose(Axis.XP.rotationDegrees(pitch));p.mulPose(Axis.YP.rotationDegrees(-90));for(int i=0;i<2;i++){p.pushPose();p.mulPose(Axis.XP.rotationDegrees(i*90));quad(p,out,12,r,r*0.30F,color,fade);p.popPose();}}
            case 15->{floor(p,out,14,color,r,0,age*3,fade);column(p,out,9,color,r*0.65F,r,age*2,fade*0.7F);}
            case 16->{floor(p,out,0,color,r,0,-age*1.2F,fade);column(p,out,15,color,r,r*0.95F,10,fade);}
        }
        p.popPose();
    }
}
