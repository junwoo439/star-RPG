package com.junwo.starrpg;

import net.minecraft.core.particles.*;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.effect.*;
import net.minecraft.world.phys.Vec3;

/** Stable school IDs travel with a projectile, independent of later job changes. */
public final class MagicSchools {
    public static int ofJob(int job){return job>=10&&job<16?job-9:0;}
    public static int school(Player p){return ofJob(Careers.profile(p).selected);}
    private static final String[][] SPELLS={
        {"마나탄","화염구","회복"},{"불꽃탄","화염 폭발","화염 장막"},{"물탄","해일","샘물 회복"},
        {"빙창","빙결 폭발","얼음 갑옷"},{"암석탄","대지 진동","돌의 방벽"},
        {"암흑탄","영혼 폭발","그림자 걸음"},{"빛살","성광 폭발","정화 치유"}};
    private static final String[] ULTIMATES={"유성","홍염 낙하","용오름","빙하 낙하","대지 붕괴","심연 강림","천상의 심판"};
    public static String spellName(int job,int spell){return SPELLS[ofJob(job)][Math.clamp(spell,0,2)];}
    public static String ultimateName(int job){return ULTIMATES[ofJob(job)];}
    public static int impactStyle(int school){return switch(school){case 1->7;case 2->5;case 3->4;case 4->9;case 5->15;case 6->6;default->3;};}
    public static int supportStyle(int school){return school==0||school==2||school==6?16:school==5?15:11;}
    public static int color(int school){return switch(school){case 1->0xFF6B22;case 2->0x269FFF;case 3->0xA2F5FF;case 4->0xD6AA5D;case 5->0x9F42FF;case 6->0xFFF3AC;default->0xC48CFF;};}
    public static ParticleOptions particle(int school){return switch(school){case 1->ParticleTypes.FLAME;case 2->ParticleTypes.SPLASH;case 3->ParticleTypes.SNOWFLAKE;case 4->ParticleTypes.CRIT;case 5->ParticleTypes.SOUL;case 6->ParticleTypes.END_ROD;default->ParticleTypes.ENCHANT;};}
    public static void bless(Player p,int s){
        switch(s){
            case 1->p.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE,160,0));
            case 2->{p.clearFire();p.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING,200,0));}
            case 3->p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,80,0));
            case 4->p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,100,0));
            case 5->p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED,80,0));
            case 6->{p.removeEffect(MobEffects.POISON);p.removeEffect(MobEffects.WITHER);p.removeEffect(MobEffects.BLINDNESS);}
        }
    }
    public static boolean support(Player p,int s,double power){
        if(s==0||s==2||s==6){
            boolean cleansing=s==2&&p.isOnFire()||s==6&&(p.hasEffect(MobEffects.POISON)||p.hasEffect(MobEffects.WITHER)||p.hasEffect(MobEffects.BLINDNESS));
            if(p.getHealth()>=p.getMaxHealth()&&!cleansing)return false;
            p.heal((float)(4+power*0.5));
        }else if(s==1)p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,100,0));
        else if(s==3)p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,120,0));
        else if(s==4)p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,100,1));
        else if(s==5)p.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY,60,0));
        bless(p,s);ArcaneSigil.spawn((ServerLevel)p.level(),p.position().add(0,supportStyle(s)==11?1.1:0.08,0),p.getLookAngle(),supportStyle(s),color(s),1.6F,38);return true;
    }
    public static void castVisual(Player p){
        var level=(ServerLevel)p.level();int s=school(p);var point=p.getEyePosition().add(p.getLookAngle().scale(1.2));
        ArcaneSigil.spawn(level,point,p.getLookAngle(),1,color(s),1.4F,24);
        // Two corkscrew trails form a visible casting funnel around the aim direction.
        Vec3 forward=p.getLookAngle(),right=forward.cross(new Vec3(0,1,0));
        if(right.lengthSqr()<0.01)right=new Vec3(1,0,0);right=right.normalize();Vec3 up=right.cross(forward).normalize();
        for(int i=0;i<20;i++){double a=i*Math.PI/5;Vec3 pos=point.add(forward.scale(i*0.12)).add(right.scale(Math.cos(a)*0.45)).add(up.scale(Math.sin(a)*0.45));CombatVisuals.at(level,pos,particle(s),1,0);}
    }
    public static void impact(ServerLevel level,Vec3 at,int s,double radius,boolean ultimate){
        int color=color(s);float r=(float)Math.min(5,radius);
        ArcaneSigil.spawn(level,at.add(0,0.12,0),new Vec3(0,0,1),impactStyle(s),color,ultimate?r:r*0.75F,ultimate?44:26);
        CombatVisuals.ringAt(level,at,r,particle(s),32);
        if(s==1){CombatVisuals.at(level,at.add(0,1,0),ParticleTypes.FLAME,40,r*0.3);CombatVisuals.at(level,at,ParticleTypes.EXPLOSION,3,0.4);}
        else if(s==2){for(int y=0;y<3;y++)CombatVisuals.ringAt(level,at.add(0,y*0.6,0),r*(1-y*0.2),ParticleTypes.SPLASH,24);}
        else if(s==3){for(int i=0;i<6;i++){double a=i*Math.PI/3;var tip=at.add(Math.cos(a)*r,1.5,Math.sin(a)*r);CombatVisuals.line(level,at,tip,ParticleTypes.SNOWFLAKE,10);}}
        else if(s==4){for(int i=0;i<4;i++){double a=i*Math.PI/2;var base=at.add(Math.cos(a)*r*0.7,0,Math.sin(a)*r*0.7);CombatVisuals.line(level,base,base.add(0,2,0),ParticleTypes.CRIT,10);}}
        else if(s==5){ArcaneSigil.spawn(level,at.add(0,1,0),new Vec3(0,0,1),2,color,r,28);CombatVisuals.at(level,at.add(0,0.8,0),ParticleTypes.SOUL,30,r*0.3);}
        else {CombatVisuals.line(level,at.add(0,ultimate?7:3,0),at,ParticleTypes.END_ROD,32);CombatVisuals.at(level,at.add(0,1,0),ParticleTypes.ENCHANT,28,r*0.4);}
    }
}
