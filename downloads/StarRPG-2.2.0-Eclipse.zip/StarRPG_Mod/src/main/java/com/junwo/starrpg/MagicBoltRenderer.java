package com.junwo.starrpg;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.*;

/** A full-bright, rotating spell core remains visible even with reduced particles. */
public final class MagicBoltRenderer extends ThrownItemRenderer<MagicBolt> {
    public MagicBoltRenderer(EntityRendererProvider.Context context){super(context,1.8F,true);}
    @Override public void render(MagicBolt bolt,float yaw,float partial,PoseStack pose,MultiBufferSource buffers,int light){
        pose.pushPose();pose.mulPose(entityRenderDispatcher.cameraOrientation());drawHalo(pose,buffers,bolt.school(),bolt.tickCount+partial);pose.popPose();
        pose.pushPose();float scale=bolt.spellId()==1?1.3F:1;pose.scale(scale,scale,scale);
        pose.mulPose(Axis.YP.rotationDegrees((bolt.tickCount+partial)*12));super.render(bolt,yaw,partial,pose,buffers,15728880);pose.popPose();
    }
    public static void drawHalo(PoseStack pose,MultiBufferSource buffers,int school,float age){
        pose.pushPose();pose.translate(0,0.15,0);pose.mulPose(Axis.YP.rotationDegrees(15+(float)Math.sin(age*0.06F)*20));
        var out=buffers.getBuffer(net.minecraft.client.renderer.RenderType.beaconBeam(SpellVfx.ATLAS,true));
        for(int i=0;i<2;i++){pose.pushPose();pose.mulPose(Axis.XP.rotationDegrees(i==0?25:-25));pose.mulPose(Axis.ZP.rotationDegrees(age*(i==0?7:-9)));
            SpellVfx.quad(pose,out,0,0.9F,0.9F,MagicSchools.color(school),0.85F);pose.popPose();}
        pose.popPose();
    }
}
