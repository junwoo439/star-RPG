package com.junwo.starrpg;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/** Resets only carried weapons of the previous profession after a successful paid switch. */
public final class CareerWeaponReset {
    public static boolean belongs(int job,ItemStack stack){
        int weaponJob=Careers.weaponJob(stack);
        return job>=0&&weaponJob>=0&&(job==weaponJob||Careers.mage(job)&&weaponJob==3);
    }
    private static int reset(int oldJob,ItemStack stack){
        if(!belongs(oldJob,stack)||EnhancementData.level(stack)==0&&EnhancementData.failures(stack)==0)return 0;
        EnhancementData.setLevel(stack,0);EnhancementLore.update(stack);return stack.getCount();
    }
    public static int carried(Player p,int oldJob){
        int changed=0;
        // Includes the hotbar, backpack and offhand; armor does not match a weapon profession.
        for(int i=0;i<p.getInventory().getContainerSize();i++)changed+=reset(oldJob,p.getInventory().getItem(i));
        // These stacks still belong to this player's inventory while the career menu is open.
        changed+=reset(oldJob,p.containerMenu.getCarried());
        if(p.containerMenu instanceof MaterialShopMenu shop)changed+=reset(oldJob,shop.saleItem());
        p.getInventory().setChanged();p.containerMenu.broadcastChanges();return changed;
    }
}
