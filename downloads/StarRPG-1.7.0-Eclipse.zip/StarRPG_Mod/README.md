# StarRPG

Minecraft 1.21.1 / NeoForge 21.1.235용 장비 강화·무기/방어구 룬·월드 공통 난이도·장비/낚싯대 좀비 모드.
현재 버전: **1.7.0**.

## Eclipse에서 게임 실행

**[Eclipse 실행 안내](ECLIPSE.md)**를 따라 Existing Gradle Project로 가져오고
`Run > Run Configurations > Java Application > StarRPG Client`를 실행하세요.
게임의 싱글플레이에서 테스트할 수 있습니다. JDK 21이 필요합니다.

Windows 명령줄 실행:

```bat
gradlew.bat runClient
```

클라이언트 월드와 설정은 `run-client/`에 저장됩니다.
변경 내용, 밸런스 설정, 기존 강화 장비 이전 방법은 [BALANCE-1.7.md](BALANCE-1.7.md)를 참조하세요.

## 빌드 및 개발자 테스트

```bash
bash gradlew build
bash gradlew runGameTestServer
```

Windows에서는 `gradlew.bat`를 사용합니다. 배포 파일은 `build/libs/starrpg-1.7.0.jar`입니다.
GameTest는 별도의 `run-gametest/`를 사용합니다.

1.7.0 변경 내용과 빠른 확인 순서는 [TESTING-1.7.md](TESTING-1.7.md)를 참고하세요.

이번 버전은 **직업별 전용 무기·성장 조건, 3차 이후 계속 전직, 강화된 G 능력, 회전하며 자동 귀환하는 투척 단검, 지팡이·마나·마법**을 추가합니다. 전사는 검·망치, 척후병은 단검, 사수는 활·석궁, 마법사는 지팡이를 사용합니다. 다른 직업의 무기로 일반 공격은 가능하지만 전용 능력은 제한됩니다.

**Shift+H:** 통합 메뉴 / **R:** 무기 스킬 / **G:** 직업 능력. 지팡이 우클릭은 선택 주문, Shift+우클릭은 주문 변경입니다. 자세한 수치·전직 비용은 [BALANCE-1.7.md](BALANCE-1.7.md), 테스트 순서는 [TESTING-1.7.md](TESTING-1.7.md)에 있습니다.

판매 가격은 [SELL-PRICES-1.7.csv](SELL-PRICES-1.7.csv)에 있습니다. 골드·판매·활 전용 4속성 룬·몬스터 성장·기본 인챈트 제거 등 기존 기능은 유지합니다. 기존 월드는 백업하고 새 월드에서 먼저 확인하세요.

외부 모드는 [MODS-1.5.1.md](MODS-1.5.1.md)를 따릅니다. `setup-adventure-eclipse.bat`으로 Twilight Forest 4.8.3802, Mowzie 1.8.2, GeckoLib 4.9.2 설치와 Eclipse 준비를 한 번에 실행합니다. Ice and Fire는 호환 공식 빌드가 없어 제외했습니다. 생활직은 보류했습니다.

검증 결과: Twilight Forest 4.8.3802, Mowzie 1.8.2, GeckoLib 4.9.2를 함께 로드한 자동 GameTest **105개 모두 통과**. Gradle build, eclipse, neoForgeIdeSync, prepareClientRun 성공. Windows 화면과 실제 다인 PvP는 직접 확인하지 못했습니다.
