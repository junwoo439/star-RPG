package com.junwo.starrpg;

import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.*;
import net.minecraft.world.item.component.CustomData;

/** Authoritative server-owned data. Display names are never trusted. */
public final class EnhancementData {
    private static final String LEVEL = "starrpg_enhancement";
    private static final String FAILURES = "starrpg_enhancement_failures";
    public static boolean supports(ItemStack stack) {
        return stack.getItem() instanceof MagicStaffItem || RuneWeaponType.forItem(stack) != null;
    }
    public static int level(ItemStack stack) {
        return supports(stack) ? Math.clamp(data(stack).getInt(LEVEL), 0, 10) : 0;
    }
    public static int failures(ItemStack stack) { return Math.clamp(data(stack).getInt(FAILURES), 0, 100); }
    public static void setLevel(ItemStack stack, int level) {
        if (!supports(stack)) return;
        CompoundTag tag = data(stack);
        tag.putInt(LEVEL, Math.clamp(level, 0, 10));
        tag.putInt(FAILURES, 0);
        stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
    }
    public static void recordFailure(ItemStack stack) {
        CompoundTag tag = data(stack);
        tag.putInt(FAILURES, failures(stack) + 1);
        stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
    }
    private static CompoundTag data(ItemStack stack) {
        return stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
    }
}
