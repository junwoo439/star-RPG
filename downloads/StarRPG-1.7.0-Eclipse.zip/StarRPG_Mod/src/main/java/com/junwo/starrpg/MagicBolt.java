package com.junwo.starrpg;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.*;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.*;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.*;

public final class MagicBolt extends AbstractArrow implements ItemSupplier {
    private static final EntityDataAccessor<Integer> SPELL=SynchedEntityData.defineId(MagicBolt.class,EntityDataSerializers.INT);
    private float damage=6;private double travelled;
    public MagicBolt(EntityType<? extends MagicBolt> type,Level level){super(type,level);pickup=Pickup.DISALLOWED;setNoGravity(true);}
    public MagicBolt(Level level,Player p,int spell,float damage){super(ModEntities.MAGIC_BOLT.get(),p,level,new ItemStack(Items.AMETHYST_SHARD),null);entityData.set(SPELL,spell);this.damage=damage;pickup=Pickup.DISALLOWED;setNoGravity(true);}
    @Override protected void defineSynchedData(SynchedEntityData.Builder builder){super.defineSynchedData(builder);builder.define(SPELL,0);}
    @Override protected ItemStack getDefaultPickupItem(){return new ItemStack(Items.AMETHYST_SHARD);}
    @Override public ItemStack getItem(){return new ItemStack(entityData.get(SPELL)==1?Items.FIRE_CHARGE:Items.AMETHYST_SHARD);}
    @Override public void playerTouch(Player p){} // Never mint an item from a spell.
    @Override protected boolean canHitEntity(Entity e){return super.canHitEntity(e)&&(!(getOwner() instanceof Player p)||!(e instanceof LivingEntity l)||CombatRules.canHarm(p,l));}
    private void impact(Vec3 at,LivingEntity target){
        if(!level().isClientSide()&&getOwner() instanceof Player p&&p.isAlive()){
            if(entityData.get(SPELL)==1)MagicSystem.explode(p,at,damage,2,this);
            else if(target!=null){MagicSystem.damage(p,target,damage,this);CombatVisuals.burst(target,ParticleTypes.ENCHANTED_HIT,12);}
        }discard();
    }
    @Override protected void onHitEntity(EntityHitResult hit){impact(hit.getLocation(),hit.getEntity() instanceof LivingEntity l?l:null);}
    @Override protected void onHitBlock(BlockHitResult hit){impact(hit.getLocation().subtract(getDeltaMovement().normalize().scale(0.1)),null);}
    @Override public void tick(){
        if(!level().isClientSide()){
            travelled+=getDeltaMovement().length();if(travelled>28||tickCount>60||!(getOwner() instanceof Player p)||!p.isAlive()){discard();return;}
            if(tickCount%2==0)CombatVisuals.at((ServerLevel)level(),position(),entityData.get(SPELL)==1?ParticleTypes.FLAME:ParticleTypes.END_ROD,2,0.06);
        }super.tick();
    }
    @Override public void addAdditionalSaveData(CompoundTag tag){super.addAdditionalSaveData(tag);tag.putInt("spell",entityData.get(SPELL));tag.putFloat("spellDamage",damage);tag.putDouble("spellTravel",travelled);}
    @Override public void readAdditionalSaveData(CompoundTag tag){super.readAdditionalSaveData(tag);entityData.set(SPELL,Math.clamp(tag.getInt("spell"),0,1));float value=tag.getFloat("spellDamage");damage=Float.isFinite(value)?Math.clamp(value,0,50):6;travelled=Math.max(0,tag.getDouble("spellTravel"));setNoGravity(true);pickup=Pickup.DISALLOWED;}
}
