package com.junwo.starrpg;

import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.*;
import net.neoforged.bus.api.*;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.common.util.FakePlayer;
import net.neoforged.neoforge.event.entity.living.*;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

@EventBusSubscriber(modid=StarRPG.MODID)
public final class Careers {
    public static final String[] NAMES={"전사","척후병","사수","마법사"};
    public static final String[] WEAPONS={"검·전투 망치","별빛 단검","활·석궁","별의 지팡이"};
    public static final String[] TRIALS={"전용 무기 근접 처치","단검 후방·투척 처치","활·석궁 원거리 처치","지팡이 마법 처치"};
    public static CareerData.Profile profile(Player p){return CareerData.get(p.getServer()).profile(p.getUUID());}
    public static int weaponJob(ItemStack w){
        if(w.getItem() instanceof MagicStaffItem)return 3;
        if(w.getItem() instanceof StarDaggerItem)return 1;
        if(w.getItem() instanceof BowItem||w.getItem() instanceof CrossbowItem)return 2;
        if(w.getItem() instanceof SwordItem||w.getItem() instanceof WarHammerItem)return 0;
        return -1;
    }
    public static boolean qualified(Player p,ItemStack w){return p.getServer()!=null&&profile(p).selected==weaponJob(w)&&weaponJob(w)>=0;}
    public static boolean requireWeapon(Player p,ItemStack w){
        if(qualified(p,w))return true;
        p.displayClientMessage(Component.literal("전용 능력은 해당 직업·무기가 필요합니다. Shift+H → 직업"),true);return false;
    }
    /** No gameplay rank cap; the asymptote prevents limitless PvP damage/health. */
    public static double power(int rank){return rank<=3?Math.max(0,rank):3+3*(-Math.expm1(-(rank-3)/12.0));}
    public static double power(Player p){return power(profile(p).rank());}
    public static int xpCost(int rank){return (int)Math.min(100000L,300L*Math.max(1,rank));}
    public static int goldCost(int rank){return (int)Math.min(100000L,1000L*Math.max(1,rank));}
    public static int masteryCost(int rank){return (int)Math.min(200L,12L+4L*(Math.max(1,rank)-1));}
    public static int materialCount(int rank){return (int)Math.min(64L,8L+2L*(Math.max(1,rank)-1));}
    public static Item material(int job){return switch(job){case 0->Items.IRON_INGOT;case 1->Items.ENDER_PEARL;case 2->Items.FLINT;default->Items.AMETHYST_SHARD;};}
    public static String materialName(int job){return switch(job){case 0->"철 주괴";case 1->"엔더 진주";case 2->"부싯돌";default->"자수정 조각";};}
    public static boolean select(Player p,int id){
        if(p.level().isClientSide()||p.getServer()==null||id<0||id>3||!p.isAlive()||p.isSpectator()||ControlEffects.stunned(p))return false;
        var data=CareerData.get(p.getServer());var v=data.profile(p.getUUID());long now=p.getServer().overworld().getGameTime();
        if(v.selected==id)return false;
        if(v.switchReady>now){p.sendSystemMessage(Component.literal("직업 교체는 30초마다 가능합니다."));return false;}
        if(v.selected>=0&&(!Config.ECONOMY_ENABLED.get()||!StarWallet.get(p.getServer()).debit(p.getUUID(),500))){p.sendSystemMessage(Component.literal("직업 교체에 500 G가 필요합니다."));return false;}
        WeaponAbilities.cancel(p);v.selected=id;v.ranks[id]=Math.max(1,v.ranks[id]);v.switchReady=now+600;data.setDirty();updateAttributes(p);
        p.getPersistentData().remove("starrpg_focus_until");
        p.sendSystemMessage(Component.literal(NAMES[id]+" 선택 · 전용 무기: "+WEAPONS[id]+" · G: 직업 능력"));return true;
    }
    public static boolean advance(Player p){
        if(p.level().isClientSide()||p.getServer()==null||!p.isAlive()||p.isSpectator()||ControlEffects.stunned(p))return false;
        var v=profile(p);int rank=v.rank();if(rank<1||rank==Integer.MAX_VALUE)return false;
        int xp=xpCost(rank),trial=masteryCost(rank),count=materialCount(rank);Item item=material(v.selected);
        if(v.xp()<xp||v.mastery()<trial||p.getInventory().countItem(item)<count){
            p.sendSystemMessage(Component.literal("전직 필요: XP "+xp+" / "+TRIALS[v.selected]+" "+trial+"회 / "+materialName(v.selected)+" "+count+"개 / "+goldCost(rank)+" G"));return false;
        }
        if(!Config.ECONOMY_ENABLED.get()||!StarWallet.get(p.getServer()).debit(p.getUUID(),goldCost(rank))){p.sendSystemMessage(Component.literal("전직 골드가 부족합니다."));return false;}
        int remaining=count;
        for(int i=0;i<p.getInventory().getContainerSize()&&remaining>0;i++){
            var stack=p.getInventory().getItem(i);if(stack.is(item)){int n=Math.min(remaining,stack.getCount());stack.shrink(n);remaining-=n;}
        }
        v.xp[v.selected]-=xp;v.mastery[v.selected]-=trial;v.ranks[v.selected]++;
        p.getInventory().setChanged();CareerData.get(p.getServer()).setDirty();updateAttributes(p);
        CombatVisuals.burst(p,net.minecraft.core.particles.ParticleTypes.TOTEM_OF_UNDYING,30);
        p.sendSystemMessage(Component.literal(NAMES[v.selected]+" "+v.rank()+"차 전직 완료! 다음 전직에 계속 도전할 수 있습니다."));return true;
    }
    public static void gain(Player p,boolean boss,int tier){
        var v=profile(p);if(v.selected<0)return;
        v.xp[v.selected]=Math.min(1000000,v.xp()+(boss?60:10+Math.clamp(tier,0,5)));
        if(boss)v.bosses[v.selected]=Math.min(10000,v.bosses()+1);CareerData.get(p.getServer()).setDirty();
    }
    public static boolean trialMatches(Player p,LivingEntity target,net.minecraft.world.damagesource.DamageSource source){
        int job=profile(p).selected;
        if(job==3)return source.is(MagicSystem.MAGIC_DAMAGE);
        if(job==2&&source.getDirectEntity() instanceof AbstractArrow arrow){var w=arrow.getWeaponItem();return w!=null&&weaponJob(w)==2;}
        if(job==1)return source.is(WeaponAbilities.DAGGER_DAMAGE)||(weaponJob(p.getMainHandItem())==1&&source.getDirectEntity()==p&&SpecialWeaponEffects.behind(p,target));
        return job==0&&weaponJob(p.getMainHandItem())==0&&source.getDirectEntity()==p;
    }
    @SubscribeEvent(priority=EventPriority.LOWEST) public static void death(LivingDropsEvent e){
        var mob=e.getEntity();if(mob.level().isClientSide()||!(e.getSource().getEntity() instanceof Player p)||p.getServer()==null||p.isCreative()||p.isSpectator()||p instanceof FakePlayer||!MonsterProgression.eligible(mob)||!CombatRules.canHarmDead(p,mob)||mob.getPersistentData().getBoolean("starrpg_career_paid"))return;
        mob.getPersistentData().putBoolean("starrpg_career_paid",true);gain(p,mob.getType().is(MonsterProgression.BOSSES),MonsterProgression.tier(mob));
        var v=profile(p);if(v.selected>=0&&trialMatches(p,mob,e.getSource())){v.mastery[v.selected]=Math.min(1000000,v.mastery()+1);CareerData.get(p.getServer()).setDirty();}
    }
    private static void attr(Player p,net.minecraft.core.Holder<Attribute> attribute,String key,double value,AttributeModifier.Operation operation){
        var a=p.getAttribute(attribute);if(a==null)return;var id=ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,key);
        if(value==0){a.removeModifier(id);return;}var old=a.getModifier(id);if(old==null||old.amount()!=value)a.addOrUpdateTransientModifier(new AttributeModifier(id,value,operation));
    }
    public static void updateAttributes(Player p){
        var v=profile(p);double power=qualified(p,p.getMainHandItem())?power(v.rank()):0;
        attr(p,Attributes.MAX_HEALTH,"career_health",v.selected==0?power*4:0,AttributeModifier.Operation.ADD_VALUE);
        attr(p,Attributes.ARMOR,"career_armor",v.selected==0?power:0,AttributeModifier.Operation.ADD_VALUE);
        attr(p,Attributes.MOVEMENT_SPEED,"career_speed",v.selected==1?power*0.03:0,AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
        attr(p,Attributes.ATTACK_DAMAGE,"career_damage",v.selected==0?power*0.05:v.selected==1?power*0.06:0,AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
        p.setHealth(Math.min(p.getHealth(),p.getMaxHealth()));
    }
    @SubscribeEvent public static void tick(PlayerTickEvent.Post e){if(!e.getEntity().level().isClientSide()&&e.getEntity().getServer()!=null&&e.getEntity().tickCount%5==0)updateAttributes(e.getEntity());}
    public static double arrowBonus(Player p){var v=profile(p);return v.selected==2?power(v.rank())*0.05+(p.getPersistentData().getLong("starrpg_focus_until")>p.level().getGameTime()?0.20:0):0;}
    public static boolean cast(Player p){
        if(p.level().isClientSide()||!p.isAlive()||p.isSpectator()||ControlEffects.rooted(p)||p.hasEffect(ModEffects.COMBO)||p.containerMenu!=p.inventoryMenu||!requireWeapon(p,p.getMainHandItem()))return false;
        var v=profile(p);long now=p.level().getGameTime();
        if(p.getPersistentData().getLong("starrpg_career_ready")>now){p.displayClientMessage(Component.literal("직업 능력 재사용 대기 중"),true);return false;}
        double power=power(v.rank());
        switch(v.selected){
            case 0->{p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,100+(int)(power*10),1));CombatVisuals.circle(p,2,net.minecraft.core.particles.ParticleTypes.ENCHANTED_HIT);}
            case 1->{p.setDeltaMovement(p.getDeltaMovement().add(p.getLookAngle().multiply(1,0,1).normalize().scale(0.9+power*0.06)).add(0,0.15,0));p.hurtMarked=true;p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED,80,1));p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,40,0));CombatVisuals.burst(p,net.minecraft.core.particles.ParticleTypes.CLOUD,20);}
            case 2->{p.getPersistentData().putLong("starrpg_focus_until",now+160);CombatVisuals.circle(p,1,net.minecraft.core.particles.ParticleTypes.END_ROD);}
            case 3->{MagicSystem.restore(p,30);p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,100,0));CombatVisuals.circle(p,1.5,net.minecraft.core.particles.ParticleTypes.ENCHANT);}
        }
        p.getPersistentData().putLong("starrpg_career_ready",now+(v.selected==3?500:v.selected==1?200:v.selected==2?360:440));
        p.displayClientMessage(Component.literal(NAMES[v.selected]+" 능력 사용"),true);return true;
    }
}
