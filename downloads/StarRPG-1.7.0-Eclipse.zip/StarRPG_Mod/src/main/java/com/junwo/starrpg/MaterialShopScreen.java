package com.junwo.starrpg;

import java.util.*;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

public final class MaterialShopScreen extends AbstractContainerScreen<MaterialShopMenu> {
    private final List<Button> pageButtons=new ArrayList<>();
    private final List<Integer> ids=new ArrayList<>();
    public MaterialShopScreen(MaterialShopMenu m,Inventory i,Component t){super(m,i,t);imageWidth=320;imageHeight=230;}
    @Override protected void init(){super.init();build();}
    private void action(String text,int id,int x,int y,int width){
        var b=Button.builder(Component.literal(text),button->{if(minecraft!=null&&minecraft.gameMode!=null)minecraft.gameMode.handleInventoryButtonClick(menu.containerId,id);}).bounds(leftPos+x,topPos+y,width,18).build();
        if(id>=40&&id<=43)b.setTooltip(net.minecraft.client.gui.components.Tooltip.create(Component.literal(new String[]{
            "검·망치 전용. 체력·방어·피해 강화. G: 저항 II 5~8초 / 22초. 교체 500 G, 성장 보존",
            "단검 전용. 속도·피해 강화. G: 돌진 + 가속 4초 + 저항 2초 / 10초. 교체 500 G",
            "활·석궁 전용. 화살 피해 강화. G: 8초간 추가 피해 +20% / 18초. 교체 500 G",
            "지팡이 전용. 우클릭 주문, R 유성. G: 마나 30 회복 + 보호막 / 25초. 교체 500 G"}[id-40])));
        pageButtons.add(addRenderableWidget(b));ids.add(id);
    }
    private void build(){
        clearWidgets();pageButtons.clear();ids.clear();String[] names={"상점","판매","직업","활 속성","마법"};
        for(int i=0;i<5;i++){final int tab=i;var b=addRenderableWidget(Button.builder(Component.literal(names[i]),button->{menu.clientTab=tab;build();}).bounds(leftPos+8+i*61,topPos+27,59,18).build());b.active=i!=menu.clientTab;}
        switch(menu.clientTab){
            case 0->{for(int i=0;i<3;i++){action("1개",i*2,204,58+i*25,46);action("8개",i*2+1,258,58+i*25,46);}}
            case 1->{action("1개 판매",20,158,79,68);action("전량 판매",21,233,79,72);}
            case 2->{for(int i=0;i<4;i++)action(Careers.NAMES[i],40+i,8+i*77,71,74);action("다음 전직",50,237,112,68);}
            case 3->{String[] n={"얼음","전기","어둠","빛"};for(int i=0;i<4;i++)action(n[i],60+i,8+i*77,79,74);}
            case 4->{for(int i=0;i<3;i++)action(MagicSystem.SPELLS[i],70+i,8+i*103,76,98);}
        }
        updateButtons();
    }
    private void updateButtons(){for(int i=0;i<ids.size();i++){int id=ids.get(i);boolean active=true;
        if(id<6)active=menu.enabled()&&menu.price(id/2)>0&&menu.balance()>=menu.price(id/2)*(id%2==0?1:8);
        else if(id==20||id==21)active=menu.enabled()&&menu.canSell()&&menu.sellPrice()>0&&!menu.saleItem().isEmpty();
        else if(id>=40&&id<=43)active=menu.job()!=id-40;
        else if(id==50)active=menu.rank()>0&&menu.rank()<Integer.MAX_VALUE;
        else if(id>=70)active=menu.job()==3&&menu.spell()>=0&&menu.spell()!=id-70;
        else if(id>=60)active=menu.holdingBow()&&menu.element()!=id-60&&menu.enabled();pageButtons.get(i).active=active;
    }}
    @Override protected void containerTick(){super.containerTick();updateButtons();}
    @Override protected void renderBg(GuiGraphics g,float t,int x,int y){
        g.fill(leftPos,topPos,leftPos+imageWidth,topPos+imageHeight,0xFF16212C);g.fill(leftPos+2,topPos+2,leftPos+imageWidth-2,topPos+imageHeight-2,0xFF263644);
        for(var slot:menu.slots)if(slot.isActive())g.fill(leftPos+slot.x-1,topPos+slot.y-1,leftPos+slot.x+17,topPos+slot.y+17,0xFF101820);
        if(menu.clientTab==0)for(var p:Economy.Product.values())g.renderItem(p.stack(1),leftPos+12,topPos+59+p.ordinal()*25);
    }
    private void text(GuiGraphics g,String s,int x,int y,int color){g.drawString(font,s,x,y,color,false);}
    @Override protected void renderLabels(GuiGraphics g,int x,int y){
        text(g,"StarRPG",8,10,0xFFFFFF);text(g,String.format(java.util.Locale.ROOT,"%,d G",menu.balance()),190,10,0xFFD978);
        switch(menu.clientTab){
            case 0->{for(var p:Economy.Product.values())text(g,p.label+"  "+menu.price(p.ordinal())+" G",35,64+p.ordinal()*25,0xFFFFFF);}
            case 1->{text(g,"판매할 아이템을 왼쪽 칸에 넣으세요.",8,55,0xFFFFFF);text(g,"개당 "+menu.sellPrice()+" G",54,80,0xFFD978);text(g,"전량 "+menu.sellPrice()*menu.saleItem().getCount()+" G",54,93,0xFFD978);text(g,menu.canSell()?"내구도 반영 · 내용물 있는 보관함은 판매 불가":"판매는 생존·모험 모드에서 가능합니다.",8,116,0xBCD0E0);}
            case 2->{String name=menu.job()<0?"미선택":Careers.NAMES[menu.job()]+" "+menu.rank()+"차";
                text(g,name+" | XP "+menu.xp()+" | 보스 "+menu.bosses(),8,54,0xFFFFFF);
                if(menu.job()<0){text(g,"첫 선택 무료 · 전직 횟수 제한 없음",8,95,0xBCD0E0);text(g,"버튼에 마우스를 올리면 전용 무기·능력 설명",8,116,0xFFD978);}
                else{
                    text(g,"다음: XP "+Careers.xpCost(menu.rank())+" + "+Careers.goldCost(menu.rank())+" G",8,94,0xBCD0E0);
                    text(g,Careers.materialName(menu.job())+" "+menu.materials()+"/"+Careers.materialCount(menu.rank())+"개",8,105,0xBCD0E0);
                    text(g,Careers.TRIALS[menu.job()]+" "+menu.mastery()+"/"+Careers.masteryCost(menu.rank()),8,119,0xFFD978);
                }}
            case 3->{text(g,"주 손에 활을 들고 속성을 선택하세요.",8,54,0xFFFFFF);text(g,"현재: "+(menu.element()<0?"없음":BowElements.Element.values()[menu.element()].label),8,66,0xFFD978);text(g,"비용: 일반 룬 1개 + 200 G / 기존 룬 유지",8,104,0xBCD0E0);text(g,"속박 1초 · 기절 0.5초 · 반전 1초 / 재사용 8초",8,117,0xBCD0E0);}
            case 4->{
                text(g,"마나 "+menu.mana()+" / "+menu.maxMana()+" · 마법사 + 지팡이 필요",8,54,0xC2A8FF);
                text(g,"우클릭: 선택 주문 / Shift+우클릭: 다음 주문",8,65,0xFFFFFF);
                text(g,"마나탄 8 MP · 화염구 18 MP · 회복 25 MP",8,102,0xBCD0E0);
                text(g,"R: 유성 40 MP / G: 마나 회복·보호막",8,117,0xFFD978);
            }
        }
    }
    @Override public void render(GuiGraphics g,int x,int y,float t){super.render(g,x,y,t);renderTooltip(g,x,y);}
}
