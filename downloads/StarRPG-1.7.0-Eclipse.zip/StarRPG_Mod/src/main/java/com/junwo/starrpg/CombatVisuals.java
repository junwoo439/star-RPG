package com.junwo.starrpg;

import net.minecraft.core.particles.*;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.*;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/** Small bounded particle batches; no terrain edits or global camera shake. */
public final class CombatVisuals {
    public static void at(ServerLevel level,Vec3 pos,ParticleOptions particle,int count,double spread){level.sendParticles(particle,pos.x,pos.y,pos.z,count,spread,spread,spread,0.02);}
    public static void burst(Entity e,ParticleOptions particle,int count){if(e.level() instanceof ServerLevel level)at(level,e.position().add(0,1,0),particle,count,0.5);}
    public static void circle(Entity e,double radius,ParticleOptions particle){
        if(!(e.level() instanceof ServerLevel level))return;
        for(int i=0;i<24;i++){double a=i*Math.PI/12;at(level,e.position().add(Math.cos(a)*radius,0.15,Math.sin(a)*radius),particle,1,0);}
    }
    public static void line(ServerLevel level,Vec3 from,Vec3 to,ParticleOptions particle,int steps){
        for(int i=0;i<=steps;i++)at(level,from.lerp(to,(double)i/steps),particle,1,0);
    }
    public static void sound(Entity e,net.minecraft.core.Holder<SoundEvent> sound,float volume,float pitch){sound(e,sound.value(),volume,pitch);}
    public static void sound(Entity e,SoundEvent sound,float volume,float pitch){e.level().playSound(null,e.blockPosition(),sound,SoundSource.PLAYERS,volume,pitch);}
}
