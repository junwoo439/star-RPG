package com.junwo.starrpg;

import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.*;
import net.minecraft.world.effect.*;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.neoforged.bus.api.*;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.*;

/** Inherent profession traits; neither a rune nor a promotion is required. */
@EventBusSubscriber(modid=StarRPG.MODID)
public final class JobWeaponTraits {
    public static ItemStack weapon(DamageSource source,Player p){
        if(source.getDirectEntity() instanceof MagicBolt bolt)return bolt.staff();
        if(source.getDirectEntity() instanceof AbstractArrow arrow)return arrow.getWeaponItem()==null?ItemStack.EMPTY:arrow.getWeaponItem();
        return CombatRules.primary(source)||source.is(MagicSystem.MAGIC_DAMAGE)||source.is(WeaponAbilities.DAGGER_DAMAGE)?p.getMainHandItem():ItemStack.EMPTY;
    }
    private static boolean charged(DamageSource source){
        if(CombatRules.primary(source))return CombatRules.charged(source);
        return !(source.getDirectEntity() instanceof AbstractArrow arrow)||!arrow.getPersistentData().contains("starrpg_shot_power")||arrow.getPersistentData().getFloat("starrpg_shot_power")>=0.9F;
    }
    public static float huntingFactor(ItemStack w,LivingEntity target){
        if(!EnhancementData.unlimited(w)||!MonsterProgression.eligible(target)||target.getType().is(MonsterProgression.BOSSES))return 1;
        return 1+(float)Math.min(25,EnhancementData.level(w))*0.08F;
    }
    @SubscribeEvent(priority=EventPriority.LOWEST) public static void hunt(LivingIncomingDamageEvent e){
        if(e.getEntity().level().isClientSide()||!(e.getSource().getEntity() instanceof Player p)||!CombatRules.canHarm(p,e.getEntity())||!charged(e.getSource()))return;
        ItemStack w=weapon(e.getSource(),p);
        if(!WeaponAwakening.allowed(p,w))return;
        e.setAmount(e.getAmount()*huntingFactor(w,e.getEntity()));
    }
    @SubscribeEvent(priority=EventPriority.LOWEST) public static void before(LivingDamageEvent.Pre e){
        if(e.getSource().getEntity() instanceof Player&&!e.getSource().is(CombatRules.RUNE))e.getEntity().getPersistentData().putFloat("starrpg_job_before",e.getEntity().getHealth());
    }
    @SubscribeEvent public static void hit(LivingDamageEvent.Post e){
        if(e.getEntity().level().isClientSide()||e.getSource().is(CombatRules.RUNE)||!(e.getSource().getEntity() instanceof Player p))return;
        var target=e.getEntity();float before=target.getPersistentData().getFloat("starrpg_job_before");target.getPersistentData().remove("starrpg_job_before");
        if(!charged(e.getSource()))return;
        int school=e.getSource().getDirectEntity() instanceof MagicBolt bolt?bolt.school():MagicSchools.school(p);
        apply(p,weapon(e.getSource(),p),target,Math.max(0,Math.min(e.getNewDamage(),before-target.getHealth())),school);
    }
    /** Skills explicitly call this once; bleed/runes/sweeps cannot recursively trigger traits. */
    public static void skillDamage(Player p,LivingEntity target,float amount){
        var w=p.getMainHandItem();float before=target.getHealth();
        CombatRules.runeDamage(p,target,amount*huntingFactor(w,target));
        float actual=Math.max(0,before-target.getHealth());
        apply(p,w,target,actual,MagicSchools.school(p));if(Careers.qualified(p,w))CareerTechniques.proc(p,target,actual);
    }
    private static boolean ready(Player p,String key,int ticks){long now=p.level().getGameTime();if(p.getPersistentData().getLong(key)>now)return false;p.getPersistentData().putLong(key,now+ticks);return true;}
    public static void apply(Player p,ItemStack w,LivingEntity target,float actual,int school){
        if(actual<=0||!p.isAlive()||!Careers.qualified(p,w)||!CombatRules.canHarmDead(p,target))return;
        int job=Careers.weaponJob(w),n=EnhancementData.level(w);boolean proc=ready(p,"starrpg_job_trait_ready",40);
        float steal=job==7?0.10F:job==5?0.05F:job==6?0.05F:job==3&&school==5?0.10F:job==3&&school==6?0.05F:0;
        if(steal>0&&ready(p,"starrpg_job_siphon_ready",20)){
            float heal=Math.min(2,actual*steal);p.heal(heal);if(heal>0)CombatVisuals.burst(p,ParticleTypes.HEART,3);
        }
        if(!proc||!target.isAlive())return;
        if(job==0||job==1||job==5||job==2){EnhancementEffects.applyRuneBleed(target,p,60,1+Math.min(25,n)*0.08F);CombatVisuals.burst(target,ParticleTypes.DAMAGE_INDICATOR,6);}
        else if(job==4)target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS,40,0));
        else if(job==7)target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,30,0));
        else if(job==6)target.addEffect(new MobEffectInstance(MobEffects.GLOWING,60,0));
        else if(job==8)target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,20,0));
        else if(job==9)target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS,30,0));
        else if(job==3)switch(school){
            case 1->target.igniteForSeconds(3);
            case 2->{target.clearFire();target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,40,0));}
            case 3->target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,30,1));
            case 4->target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS,40,0));
            case 5->target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,20,0));
            case 6->target.addEffect(new MobEffectInstance(MobEffects.GLOWING,60,0));
            default->target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS,20,0));
        }
        if(p.level() instanceof ServerLevel level)ArcaneSigil.spawn(level,target.position().add(0,0.1,0),p.getLookAngle(),0,job==3?MagicSchools.color(school):WeaponArt.color(WeaponArt.kind(w)),0.65F,14);
    }
    public static String description(int job){return switch(job){
        case 0,1,2->"고유: 출혈 3초 / 2초 간격";
        case 5->"고유: 출혈 3초 + 실제 피해 5% 흡혈";
        case 6->"고유: 실제 피해 5% 회복 + 발광";
        case 7->"고유: 실제 피해 10% 흡혈 + 둔화";
        case 4,9->"고유: 적중 시 약화 / 2초 간격";
        case 8->"고유: 적중 시 둔화 / 2초 간격";
        case 3->"고유: 직업 속성 효과 / 어둠·빛은 흡혈";
        default->"";};}
    @SubscribeEvent public static void tooltip(net.neoforged.neoforge.event.entity.player.ItemTooltipEvent e){
        int job=Careers.weaponJob(e.getItemStack());if(job<0)return;
        e.getToolTip().add(Component.literal(description(job)).withStyle(net.minecraft.ChatFormatting.LIGHT_PURPLE));
        e.getToolTip().add(Component.literal("해당 직업 필요 · 흡혈은 실제 체력 피해 기준 / 초당 최대 2 HP").withStyle(net.minecraft.ChatFormatting.GRAY));
        int n=EnhancementData.level(e.getItemStack());
        if(n>0)e.getToolTip().add(Component.literal("일반 적대 몹 사냥 피해 +"+(Math.min(25,n)*8)+"% (충전 공격 / 보스·PvP 제외)").withStyle(net.minecraft.ChatFormatting.GREEN));
    }
}
