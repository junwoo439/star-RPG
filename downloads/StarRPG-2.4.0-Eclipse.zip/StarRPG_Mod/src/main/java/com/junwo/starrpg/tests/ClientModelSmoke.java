package com.junwo.starrpg.tests;

import com.junwo.starrpg.*;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.*;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

@EventBusSubscriber(modid=StarRPG.MODID,value=Dist.CLIENT)
public final class ClientModelSmoke {
    private static int ticks,stage;private static boolean checked;
    private static Item[] weapons(){return new Item[]{StarRPG.FIRE_STAFF.get(),StarRPG.WATER_STAFF.get(),StarRPG.ICE_STAFF.get(),StarRPG.EARTH_STAFF.get(),StarRPG.DARK_STAFF.get(),StarRPG.LIGHT_STAFF.get()};}
    @SubscribeEvent public static void tick(ClientTickEvent.Post event){
        if(!Boolean.getBoolean("starrpg.clientSmoke"))return;
        var mc=Minecraft.getInstance();if(mc.getOverlay()!=null||mc.screen==null)return;
        if(!checked){
            for(Item weapon:weapons()){
                var model=mc.getItemRenderer().getModel(new ItemStack(weapon),null,null,0);
                if(model==mc.getModelManager().getMissingModel()||!model.isCustomRenderer()
                    ||!(net.neoforged.neoforge.client.extensions.common.IClientItemExtensions.of(weapon).getCustomRenderer() instanceof ArtisanItemRenderer))throw new IllegalStateException("Wrong weapon renderer: "+weapon);
                StarRPG.LOGGER.info("CLIENT_GRIP_CHECK PASSED: {}",weapon);
            }
            for(var weapon:new Item[]{Items.IRON_SWORD,Items.IRON_AXE,Items.BOW,Items.CROSSBOW,Items.TRIDENT})
                if(net.neoforged.neoforge.client.extensions.common.IClientItemExtensions.of(weapon).getCustomRenderer() instanceof ArtisanItemRenderer)throw new IllegalStateException("Vanilla weapon overridden");
            checked=true;mc.options.guiScale().set(1);mc.getWindow().setWindowed(1280,800);mc.resizeDisplay();mc.setScreen(new Preview(0));return;
        }
        if(++ticks>=80&&stage==0){stage=1;Screenshot.grab(mc.gameDirectory,"starrpg-2.3-staffs.png",mc.getMainRenderTarget(),message->{StarRPG.LOGGER.info("CLIENT_GRIP_SCREENSHOT: {}",message.getString());mc.execute(()->mc.setScreen(new Preview(1)));});}
        if(ticks>=160&&stage==1){stage=2;Screenshot.grab(mc.gameDirectory,"starrpg-2.3-effects.png",mc.getMainRenderTarget(),message->{StarRPG.LOGGER.info("CLIENT_EFFECT_SCREENSHOT: {}",message.getString());mc.execute(mc::stop);});}
    }
    private static final class Preview extends Screen {
        private final int mode;
        Preview(int mode){super(Component.literal("StarRPG renderer verification"));this.mode=mode;}
        @Override public void render(GuiGraphics g,int x,int y,float partial){
            g.fillGradient(0,0,width,height,0xFF101C2C,0xFF160C20);
            g.drawCenteredString(font,mode==0?"StarRPG 2.3 - six exclusive elemental staffs":"StarRPG 2.3 - luminous weapon trails and ultimate effects",width/2,12,0xF0D8FF);
            if(mode==0)grips(g);else effects(g);
            g.drawCenteredString(font,mode==0?"Actual item display transforms; cyan cross marks the hand origin (renderer preview)":"Original transparent art, tinted and animated on crossed planes / layered circles",width/2,height-15,0xA9C7D3);
        }
        private void grips(GuiGraphics g){
            String[] names={"Fire / Phoenix","Water / Tide","Ice / Crystal","Earth / Stone","Dark / Abyss","Light / Sun"};
            var mc=Minecraft.getInstance();var buffer=mc.renderBuffers().bufferSource();
            for(int i=0;i<6;i++){
                int col=(width-50)/3,row=(height-65)/2,bx=25+(i%3)*col,by=32+(i/3)*row;
                g.fill(bx,by,bx+col-10,by+row-8,0xFF091322);g.drawCenteredString(font,names[i],bx+(col-10)/2,by+5,0xDBE8F0);
                for(int view=0;view<2;view++){
                    int cx=bx+col/4+view*col/2,cy=by+row-42;g.fill(cx-5,cy,cx+6,cy+1,0xFF52DDEE);g.fill(cx,cy-5,cx+1,cy+6,0xFF52DDEE);g.flush();
                    g.pose().pushPose();g.pose().translate(cx,cy,100);g.pose().scale(135,-135,135);g.pose().mulPose(Axis.YP.rotationDegrees(75));g.pose().mulPose(Axis.XP.rotationDegrees(-8));
                    var w=new ItemStack(weapons()[i]);var context=view==0?ItemDisplayContext.THIRD_PERSON_RIGHT_HAND:ItemDisplayContext.FIRST_PERSON_RIGHT_HAND;
                    mc.getItemRenderer().renderStatic(w,context,15728880,net.minecraft.client.renderer.texture.OverlayTexture.NO_OVERLAY,g.pose(),buffer,null,0);buffer.endBatch();g.pose().popPose();
                    g.drawCenteredString(font,view==0?"Third person":"First person",cx,by+row-23,0xA5B8C9);
                }
            }
        }
        private void effects(GuiGraphics g){
            int[] styles={17,18,19,20,21,22,23,24,25,26,27,28,29,1,11,16};
            int[] colors={0xFF8BD6,0xFFA349,0x6ADFFF,0x65FFBB,0xFFCE72,0xA0EFFF,0xB68BFF,0xFF7225,0x4DB9FF,0xA6F7FF,0xD7AD65,0xAB55FF,0xFFF2A1,0x82DCFF,0xFFD966,0x97FFC8};
            String[] names={"Sweeping crescent","Diagonal slash","Spear piercing trail","Alternating fist","Hammer shockwave","Arrow / spell trail","Soul harvest","Fire ultimate","Water ultimate","Ice ultimate","Earth ultimate","Dark ultimate","Light ultimate","Cast circles","Protective ward","Healing bloom"};
            var buffer=Minecraft.getInstance().renderBuffers().bufferSource();
            for(int i=0;i<16;i++){
                int col=(width-40)/4,row=(height-60)/4,bx=20+(i%4)*col,by=30+(i/4)*row;
                g.fill(bx,by,bx+col-8,by+row-8,0xFF081221);g.flush();g.pose().pushPose();g.pose().translate(bx+(col-8)/2,by+row-32,110);float size=styles[i]>=17&&styles[i]<=23?68:styles[i]==24||styles[i]==29?16:32;g.pose().scale(size,-size,size);
                g.pose().mulPose(Axis.XP.rotationDegrees(styles[i]>=17&&styles[i]<=23?35:12));g.pose().mulPose(Axis.YP.rotationDegrees(styles[i]==19||styles[i]==22?65:25));
                if(styles[i]==1||styles[i]==2||styles[i]==10||styles[i]==11||styles[i]==12||styles[i]==14)g.pose().translate(0,1.6,0);
                ArcaneSigilRenderer.draw(g.pose(),buffer,styles[i],colors[i],1.2F,styles[i]>=17&&styles[i]<=23?5:14,styles[i]>=17&&styles[i]<=23?12:44,0,0);buffer.endBatch();g.pose().popPose();
                g.drawCenteredString(font,names[i],bx+(col-8)/2,by+row-22,colors[i]);
            }
        }
    }
}
