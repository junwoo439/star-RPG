package com.junwo.starrpg.bestiary;

import com.junwo.starrpg.*;
import java.util.*;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.*;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.bus.api.*;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.registries.*;
import net.neoforged.neoforge.event.entity.*;

@EventBusSubscriber(modid=StarRPG.MODID,bus=EventBusSubscriber.Bus.MOD)
public final class BestiaryRegistry {
    public static final DeferredRegister<EntityType<?>> ENTITIES=DeferredRegister.create(Registries.ENTITY_TYPE,StarRPG.MODID);
    public static final DeferredRegister.Items ITEMS=DeferredRegister.createItems(StarRPG.MODID);
    public static final Map<BestiaryKind,DeferredHolder<EntityType<?>,EntityType<BestiaryMob>>> TYPES=new EnumMap<>(BestiaryKind.class);
    public static final Map<BestiaryKind,DeferredItem<net.neoforged.neoforge.common.DeferredSpawnEggItem>> EGGS=new EnumMap<>(BestiaryKind.class);
    public static final DeferredItem<BossContractItem> CONTRACT=ITEMS.registerItem("boss_contract",BossContractItem::new,new Item.Properties().stacksTo(16));
    static {
        for(var k:BestiaryKind.values()){
            var type=ENTITIES.register(k.id,()->{
                var builder=EntityType.Builder.<BestiaryMob>of((t,l)->new BestiaryMob(t,l,k),MobCategory.MONSTER).sized(k.width(),k.height()).clientTrackingRange(10).updateInterval(2);
                if(k.move==BestiaryKind.Move.FIRE||k.family==BestiaryKind.Family.FIEND)builder.fireImmune();
                return builder.build("starrpg:"+k.id);
            });TYPES.put(k,type);
            EGGS.put(k,ITEMS.registerItem(k.id+"_spawn_egg",p->new net.neoforged.neoforge.common.DeferredSpawnEggItem(type,k.color,k.boss?0xFFD76A:0x252C34,p),new Item.Properties()));
        }
    }
    public static void register(IEventBus bus){ENTITIES.register(bus);ITEMS.register(bus);}
    @SubscribeEvent public static void attributes(EntityAttributeCreationEvent e){for(var k:BestiaryKind.values())e.put(TYPES.get(k).get(),BestiaryMob.attributes(k).build());}
    @SubscribeEvent public static void placements(RegisterSpawnPlacementsEvent e){for(var k:BestiaryKind.values())e.register(TYPES.get(k).get(),k.aquatic()?SpawnPlacementTypes.IN_WATER:SpawnPlacementTypes.ON_GROUND,Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,(t,l,reason,pos,random)->BestiarySpawns.allowed(k,l,reason,pos,random),RegisterSpawnPlacementsEvent.Operation.REPLACE);}
}
