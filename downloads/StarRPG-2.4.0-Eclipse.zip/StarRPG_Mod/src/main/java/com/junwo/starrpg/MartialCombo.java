package com.junwo.starrpg;

import java.util.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;

/** Three actual alternating punches, cancelable by death, job/weapon change or control effects. */
@EventBusSubscriber(modid=StarRPG.MODID)
public final class MartialCombo {
    private record Combo(ItemStack weapon,float damage,long next,int left){}
    private static final Map<UUID,Combo> ACTIVE=new HashMap<>();
    public static boolean start(Player p,float damage){
        if(ACTIVE.containsKey(p.getUUID()))return false;
        var w=p.getMainHandItem();strike(p,damage*.45F);ACTIVE.put(p.getUUID(),new Combo(w,damage*.45F,p.level().getGameTime()+6,2));
        p.getPersistentData().putLong("starrpg_professional_ready",p.level().getGameTime()+120);
        w.hurtAndBreak(1,p,EquipmentSlot.MAINHAND);CareerMilestones.onSkill(p);return true;
    }
    private static void strike(Player p,float damage){
        WeaponMotion.swing(p);p.swing(net.minecraft.world.InteractionHand.MAIN_HAND,true);
        var target=WeaponAbilities.target(p,2.8,.3);if(target==null)return;
        int immunity=target.invulnerableTime;target.invulnerableTime=0;JobWeaponTraits.skillDamage(p,target,damage);target.invulnerableTime=Math.max(immunity,target.invulnerableTime);
    }
    @SubscribeEvent public static void tick(PlayerTickEvent.Post e){
        var p=e.getEntity();if(p.level().isClientSide())return;var c=ACTIVE.get(p.getUUID());if(c==null)return;
        if(!p.isAlive()||p.isSpectator()||ControlEffects.stunned(p)||p.getMainHandItem()!=c.weapon||Careers.profile(p).selected!=8||p.containerMenu!=p.inventoryMenu){cancel(p);return;}
        if(p.level().getGameTime()<c.next)return;strike(p,c.damage);
        if(c.left<=1)cancel(p);else ACTIVE.put(p.getUUID(),new Combo(c.weapon,c.damage,p.level().getGameTime()+6,c.left-1));
    }
    public static void cancel(Player p){ACTIVE.remove(p.getUUID());}
    @SubscribeEvent public static void logout(PlayerEvent.PlayerLoggedOutEvent e){cancel(e.getEntity());}
    @SubscribeEvent public static void dimension(PlayerEvent.PlayerChangedDimensionEvent e){cancel(e.getEntity());}
    @SubscribeEvent public static void death(LivingDeathEvent e){if(e.getEntity() instanceof Player p)cancel(p);}
    @SubscribeEvent public static void stop(ServerStoppedEvent e){ACTIVE.clear();}
}
