package com.junwo.starrpg.bestiary;

import com.junwo.starrpg.*;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.effect.*;
import net.minecraft.world.phys.*;
import net.minecraft.world.level.ClipContext;
import net.minecraft.sounds.SoundEvents;

public final class BestiaryCombat {
    public static boolean valid(BestiaryMob m,LivingEntity t){return t!=null&&m.isAlive()&&!m.isNoAi()&&t.isAlive()&&t!=m&&!m.isAlliedTo(t)&&!t.isAlliedTo(m)&&(!(t instanceof Player p)||!p.isCreative()&&!p.isSpectator());}
    public static boolean radial(BestiaryKind.Move move){return switch(move){case SLAM,WEB,SCREAM,TIDE,WIND->true;default->false;};}
    public static double reach(BestiaryMob m){return m.heavyAttack?m.kind.reach():Math.max(2.2,m.getBbWidth()+.7);}
    public static boolean inAttack(BestiaryMob m,LivingEntity t){
        if(!valid(m,t))return false;double range=reach(m);var d=t.position().subtract(m.attackOrigin);
        if(d.lengthSqr()>range*range||Math.abs(d.y)>Math.max(2.2,m.getBbHeight()))return false;
        if(!(m.heavyAttack&&radial(m.kind.move))&&d.multiply(1,0,1).normalize().dot(m.attackDirection)<.60)return false;
        return m.level().clip(new ClipContext(m.attackOrigin.add(0,Math.min(1.5,m.getBbHeight()),0),t.getEyePosition(),ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,m)).getType()==HitResult.Type.MISS;
    }
    public static void telegraph(BestiaryMob m){
        if(!(m.level() instanceof ServerLevel l))return;
        boolean can=!m.heavyAttack||m.kind.parryable();int color=can?0xFFC84D:0xFF3E45;
        ArcaneSigil.spawn(l,m.attackOrigin.add(0,.08,0),m.attackDirection,m.heavyAttack&&radial(m.kind.move)?38:37,color,(float)reach(m),m.duration());
    }
    public static void resolve(BestiaryMob m){
        if(!(m.level() instanceof ServerLevel l)||!m.isAlive())return;
        double range=reach(m);var targets=l.getEntitiesOfClass(LivingEntity.class,new AABB(m.attackOrigin,m.attackOrigin).inflate(range),t->(t instanceof Player||t==m.getTarget())&&inAttack(m,t));
        targets.sort(java.util.Comparator.comparingDouble(t->t.distanceToSqr(m.attackOrigin)));
        int hits=0;
        for(var t:targets){
            if(hits++>=6||m.phase()==BestiaryMob.STAGGER)break;
            float before=t.getHealth();m.parryableImpact=!m.heavyAttack||m.kind.parryable();
            boolean hurt;
            try{hurt=t.hurt(m.damageSources().mobAttack(m),(float)m.getAttributeValue(Attributes.ATTACK_DAMAGE)*(m.heavyAttack?2.2F:.45F));}
            finally{m.parryableImpact=false;}
            if(m.phase()==BestiaryMob.STAGGER)break;
            if(hurt&&t.getHealth()<before&&m.heavyAttack){
                long now=l.getGameTime();
                if(t.getPersistentData().getLong("starrpg_heavy_stun_guard")<=now){t.addEffect(new MobEffectInstance(ModEffects.STUN,m.kind.boss?12:8,0));t.getPersistentData().putLong("starrpg_heavy_stun_guard",now+100);}
                switch(m.kind.move){
                    case FIRE->t.igniteForSeconds(3);
                    case POISON,WEB->t.addEffect(new MobEffectInstance(MobEffects.POISON,40,0));
                    case FROST,HEX->t.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,40,1));
                    case DRAIN->m.heal(Math.min(4,(before-t.getHealth())*.2F));
                    case LIGHT->t.addEffect(new MobEffectInstance(MobEffects.GLOWING,60,0));
                    case SLAM,WIND,TIDE,LUNGE->{t.knockback(.55,m.getX()-t.getX(),m.getZ()-t.getZ());t.hurtMarked=true;}
                    default->{}
                }
            }
        }
        if(m.phase()==BestiaryMob.STAGGER)return;
        int style=!m.heavyAttack?17:switch(m.kind.move){case SLAM->21;case LUNGE,BITE->19;case FIRE->7;case FROST->4;case LIGHTNING->3;case LIGHT->6;case TIDE->8;case WIND->5;case DRAIN,HEX,SCREAM->15;case WEB,POISON->16;default->23;};
        var point=m.attackOrigin.add(m.attackDirection.scale(radial(m.kind.move)?0:Math.min(2,range*.5))).add(0,style==17||style==19?1:.1,0);
        ArcaneSigil.spawn(l,point,m.attackDirection,style,m.kind.color,(float)Math.min(4,m.heavyAttack?range*.7:1.1),m.heavyAttack?24:12);
        m.playSound(m.heavyAttack?SoundEvents.PLAYER_ATTACK_STRONG:SoundEvents.PLAYER_ATTACK_WEAK,.7F,m.heavyAttack?.6F:1.2F);
    }
}
