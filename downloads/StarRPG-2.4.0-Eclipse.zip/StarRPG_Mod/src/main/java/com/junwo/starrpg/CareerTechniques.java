package com.junwo.starrpg;

import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.effect.*;
import net.minecraft.server.level.ServerLevel;
import net.neoforged.bus.api.*;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.*;

/** Real profession mechanics. Secondary damage cannot recursively generate more procs. */
@EventBusSubscriber(modid=StarRPG.MODID)
public final class CareerTechniques {
    private static final String UNTIL="starrpg_technique_until",CHARGES="starrpg_technique_charges",READY="starrpg_technique_ready";
    public static void clear(Player p){p.getPersistentData().remove(UNTIL);p.getPersistentData().remove(CHARGES);}
    public static void activate(Player p,int job){
        p.getPersistentData().putLong(UNTIL,p.level().getGameTime()+120);
        p.getPersistentData().putInt(CHARGES,3);
        p.getPersistentData().putLong(READY,p.level().getGameTime());
        // G now grants three empowered hits in addition to each profession's survival tool.
    }
    public static boolean empowered(Player p){return p.getPersistentData().getLong(UNTIL)>p.level().getGameTime()&&p.getPersistentData().getInt(CHARGES)>0;}
    public static String promotionText(int job){return switch(job){
        case 0->"5회: 후방 관통 / 10·15회: 대상 2·3명";
        case 1->"5·10·15회: 후방 피해 +15·20·25%";
        case 2->"5회: 도탄 / 10·15회: 피해·표적 증가";
        case 4->"5회: 파쇄 충격 / 10·15회: 범위 강화";
        case 5->"5회: 주변 베기 / 10·15회: 피해 증가";
        case 7->"5회: 수확 회복 / 10·15회: 3·4 HP";
        case 8->"5회: 연환 추가타 / 10·15회: 충격 강화";
        default->"5회: 원소 추가타 / 10·15회: 범위·회복 강화";
    };}
    @SubscribeEvent public static void damage(LivingIncomingDamageEvent e){
        if(e.getEntity().level().isClientSide()||e.getSource().is(CombatRules.RUNE)||!(e.getSource().getEntity() instanceof Player p))return;
        var w=JobWeaponTraits.weapon(e.getSource(),p);if(!Careers.qualified(p,w)||!CombatRules.canHarm(p,e.getEntity()))return;
        if(CombatRules.primary(e.getSource())&&!CombatRules.charged(e.getSource()))return;
        if(e.getSource().getDirectEntity() instanceof AbstractArrow a&&a.getPersistentData().contains("starrpg_shot_power")&&a.getPersistentData().getFloat("starrpg_shot_power")<0.9)return;
        int job=Careers.profile(p).selected,n=Math.min(3,CareerMilestones.count(Careers.profile(p).rank()));
        if(job==1&&SpecialWeaponEffects.behind(p,e.getEntity()))e.setAmount(e.getAmount()*(1+(n>0?0.1F+n*0.05F:0)+(empowered(p)&&p.getPersistentData().getLong(READY)<=p.level().getGameTime()?0.2F:0)));
        else if(job==7&&e.getEntity().getHealth()<e.getEntity().getMaxHealth()*0.3&&n>0)e.setAmount(e.getAmount()*(1+n*0.05F));
        else if(empowered(p)&&p.getPersistentData().getLong(READY)<=p.level().getGameTime())e.setAmount(e.getAmount()*1.15F);
    }
    @SubscribeEvent public static void before(LivingDamageEvent.Pre e){if(!e.getSource().is(CombatRules.RUNE))e.getEntity().getPersistentData().putFloat("starrpg_tech_before",e.getEntity().getHealth());}
    @SubscribeEvent public static void hit(LivingDamageEvent.Post e){
        if(e.getNewDamage()<=0||e.getEntity().level().isClientSide()||e.getSource().is(CombatRules.RUNE)||!(e.getSource().getEntity() instanceof Player p))return;
        if(CombatRules.primary(e.getSource())&&!CombatRules.charged(e.getSource()))return;
        if(e.getSource().getDirectEntity() instanceof AbstractArrow a&&a.getPersistentData().contains("starrpg_shot_power")&&a.getPersistentData().getFloat("starrpg_shot_power")<0.9)return;
        if(!Careers.qualified(p,JobWeaponTraits.weapon(e.getSource(),p)))return;
        proc(p,e.getEntity(),Math.max(0,Math.min(e.getNewDamage(),e.getEntity().getPersistentData().getFloat("starrpg_tech_before")-e.getEntity().getHealth())));
    }
    public static void proc(Player p,LivingEntity target,float damage){
        if(damage<=0||!p.isAlive()||!Careers.qualified(p,p.getMainHandItem())||!CombatRules.canHarmDead(p,target))return;
        int n=Math.min(3,CareerMilestones.count(Careers.profile(p).rank())),job=Careers.profile(p).selected;
        boolean boost=empowered(p);long now=p.level().getGameTime();
        if((n==0&&!boost)||p.getPersistentData().getLong(READY)>now)return;
        p.getPersistentData().putLong(READY,now+(boost?20:Math.max(60,140-n*20)));
        if(boost)p.getPersistentData().putInt(CHARGES,p.getPersistentData().getInt(CHARGES)-1);
        float extra=Math.min(12,2+n+damage*0.12F);int school=MagicSchools.ofJob(job);
        if(job==7||job==11||job==15)p.heal(Math.min(1+n,Math.max(0,damage)*0.2F));
        if(job==8){int immunity=target.invulnerableTime;target.invulnerableTime=0;CombatRules.runeDamage(p,target,extra);target.invulnerableTime=Math.max(immunity,target.invulnerableTime);}
        if(job==12&&target.isAlive()&&!target.getType().is(MonsterProgression.BOSSES))target.addEffect(new MobEffectInstance(ModEffects.ROOT,20,0));
        double radius=job==0?3.5:2.0+n*0.25;
        var candidates=p.level().getEntitiesOfClass(LivingEntity.class,target.getBoundingBox().inflate(radius),t->t!=target&&CombatRules.canHarm(p,t)&&p.hasLineOfSight(t)&&target.hasLineOfSight(t)&&t.distanceToSqr(target)<=radius*radius);
        candidates.sort(java.util.Comparator.comparingDouble(t->t.distanceToSqr(target)));
        int limit=job==0?Math.max(1,n):job==2?Math.max(1,n-1):3;
        for(var other:candidates.stream().filter(t->job!=0||t.position().subtract(target.position()).normalize().dot(target.position().subtract(p.position()).normalize())>0.65).limit(limit).toList()){
            if(job==1||job==7||job==8)break;
            CombatRules.runeDamage(p,other,extra);
            if(job==10)other.igniteForSeconds(2);
            if(job==4||job==11||job==13)other.knockback(0.3,p.getX()-other.getX(),p.getZ()-other.getZ());
            if(job==14&&!other.getType().is(MonsterProgression.BOSSES)){var d=target.position().subtract(other.position()).normalize().scale(0.25);other.setDeltaMovement(other.getDeltaMovement().add(d));other.hurtMarked=true;}
        }
        int style=job==0||job==2?19:job==4?21:job==8?20:Careers.mage(job)?MagicSchools.impactStyle(school):17;
        ArcaneSigil.spawn((ServerLevel)p.level(),target.position().add(0,0.8,0),p.getLookAngle(),style,Careers.mage(job)?MagicSchools.color(school):WeaponArt.color(WeaponArt.kind(p.getMainHandItem())),1.1F,16);
    }
}
