package com.junwo.starrpg;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.*;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Visual state only. The client never supplies a target, damage or the alternating hand. */
public record WeaponMotionPayload(int entity,int side) implements CustomPacketPayload {
    public static final Type<WeaponMotionPayload> TYPE=new Type<>(ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,"weapon_motion"));
    public static final StreamCodec<ByteBuf,WeaponMotionPayload> STREAM_CODEC=StreamCodec.composite(ByteBufCodecs.VAR_INT,WeaponMotionPayload::entity,ByteBufCodecs.VAR_INT,WeaponMotionPayload::side,WeaponMotionPayload::new);
    @Override public Type<? extends CustomPacketPayload> type(){return TYPE;}
    public static void handle(WeaponMotionPayload m,IPayloadContext c){c.enqueueWork(()->{
        var e=c.player().level().getEntity(m.entity);if(e==null)return;
        e.getPersistentData().putLong("starrpg_motion_tick",e.level().getGameTime());
        e.getPersistentData().putInt("starrpg_motion_side",m.side==1?1:0);
    });}
}
