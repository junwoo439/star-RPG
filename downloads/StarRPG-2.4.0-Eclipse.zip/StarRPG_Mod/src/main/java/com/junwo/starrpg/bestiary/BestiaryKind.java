package com.junwo.starrpg.bestiary;

/** Stable bestiary IDs. Families share rig geometry; species have distinct proportions/palettes/attacks. */
public enum BestiaryKind {
    DIRE_BEAR("dire_bear","거대 곰",Family.BEAST,Body.BEAR,Habitat.FOREST,0,32,5,0x795132,false,false,Move.SWEEP),
    DIRE_WOLF("dire_wolf","흉포한 늑대",Family.BEAST,Body.WOLF,Habitat.FOREST,0,22,4,0x8998A5,false,false,Move.LUNGE),
    WILD_BOAR("wild_boar","돌진 멧돼지",Family.BEAST,Body.BOAR,Habitat.PLAINS,0,26,4,0x765644,false,false,Move.LUNGE),
    GIANT_ANT("giant_ant","거대 개미",Family.BEAST,Body.ANT,Habitat.DESERT,1,22,3,0x9B4728,false,false,Move.BITE),
    GIANT_SPIDER("giant_spider","거대 거미",Family.BEAST,Body.SPIDER,Habitat.FOREST,1,28,4,0x665379,false,false,Move.WEB),
    REEF_SHARK("reef_shark","암초 상어",Family.BEAST,Body.SHARK,Habitat.OCEAN,2,36,5,0x6A99AD,false,false,Move.LUNGE),
    HYENA("hyena","굶주린 하이에나",Family.BEAST,Body.WOLF,Habitat.SAVANNA,0,20,3,0xB59859,false,false,Move.BITE),
    ELDER_BEAR("elder_bear","고대 야수왕",Family.BEAST,Body.BEAR,Habitat.FOREST,3,220,8,0xA48756,true,false,Move.SLAM),
    GOBLIN("goblin","고블린",Family.HUMANOID,Body.SMALL,Habitat.FOREST,0,18,3,0x7CAC4B,false,false,Move.BITE),
    ORC("orc","오크",Family.HUMANOID,Body.HUMANOID,Habitat.PLAINS,1,32,5,0x4E8052,false,false,Move.SWEEP),
    KOBOLD("kobold","코볼트",Family.HUMANOID,Body.SMALL,Habitat.DESERT,0,18,3,0xB48D65,false,false,Move.LUNGE),
    TROLL("troll","트롤",Family.HUMANOID,Body.GIANT,Habitat.SWAMP,3,65,6,0x50705E,false,false,Move.SLAM),
    OGRE("ogre","오거",Family.HUMANOID,Body.GIANT,Habitat.MOUNTAIN,4,80,7,0xAE907B,false,false,Move.SLAM),
    CORRUPT_GUARD("corrupt_guard","부패한 경비병",Family.HUMANOID,Body.ARMORED,Habitat.PLAINS,1,30,4,0x677A7B,false,false,Move.SWEEP),
    OGRE_WARLORD("ogre_warlord","오거 군주",Family.HUMANOID,Body.GIANT,Habitat.MOUNTAIN,4,280,9,0x955147,true,false,Move.SWEEP),
    GRAVE_SKELETON("grave_skeleton","무덤 해골병",Family.UNDEAD,Body.SKELETON,Habitat.DARK,0,20,3,0xD8D2B5,false,false,Move.LUNGE),
    ROTTING_ZOMBIE("rotting_zombie","부패한 망자",Family.UNDEAD,Body.HUMANOID,Habitat.SWAMP,0,24,3,0x727B4C,false,false,Move.BITE),
    VAMPIRE("vampire","뱀파이어",Family.UNDEAD,Body.ROBED,Habitat.DARK,3,40,5,0x985575,false,false,Move.DRAIN),
    LICH("lich","영원의 리치",Family.UNDEAD,Body.ROBED,Habitat.DARK,5,320,8,0x70D9D4,true,false,Move.HEX),
    BANSHEE("banshee","밴시",Family.UNDEAD,Body.GHOST,Habitat.DARK,2,26,4,0x9BCAC4,false,false,Move.SCREAM),
    GEIST("geist","게이스트",Family.UNDEAD,Body.GHOST,Habitat.DARK,1,20,3,0x9F97C6,false,false,Move.DRAIN),
    RED_DRAGON("red_dragon","적룡",Family.DRAGON,Body.DRAGON,Habitat.BADLANDS,8,540,11,0xC34C32,true,false,Move.FIRE),
    BLUE_DRAGON("blue_dragon","청룡",Family.DRAGON,Body.DRAGON,Habitat.DESERT,9,560,11,0x487CCB,true,false,Move.LIGHTNING),
    GREEN_DRAGON("green_dragon","녹룡",Family.DRAGON,Body.DRAGON,Habitat.FOREST,8,520,10,0x4C9748,true,false,Move.POISON),
    BLACK_DRAGON("black_dragon","흑룡",Family.DRAGON,Body.DRAGON,Habitat.SWAMP,10,620,12,0x55546B,true,false,Move.POISON),
    WHITE_DRAGON("white_dragon","백룡",Family.DRAGON,Body.DRAGON,Habitat.SNOW,8,520,10,0xBFDBEC,true,false,Move.FROST),
    GOLD_DRAGON("gold_dragon","금룡",Family.DRAGON,Body.DRAGON,Habitat.MOUNTAIN,12,700,12,0xE8BD49,true,true,Move.LIGHT),
    SILVER_DRAGON("silver_dragon","은룡",Family.DRAGON,Body.DRAGON,Habitat.SNOW,10,580,11,0xBBCEDA,true,true,Move.FROST),
    BRONZE_DRAGON("bronze_dragon","청동룡",Family.DRAGON,Body.DRAGON,Habitat.COAST,10,580,11,0xA58B54,true,true,Move.LIGHTNING),
    BRASS_DRAGON("brass_dragon","황동룡",Family.DRAGON,Body.DRAGON,Habitat.DESERT,9,550,10,0xCF9B4E,true,true,Move.FIRE),
    COPPER_DRAGON("copper_dragon","구리룡",Family.DRAGON,Body.DRAGON,Habitat.BADLANDS,9,550,10,0xB66D48,true,true,Move.POISON),
    WYVERN("wyvern","와이번",Family.DRAGON,Body.WYVERN,Habitat.MOUNTAIN,3,48,6,0xA68E5A,false,false,Move.LUNGE),
    BASILISK("basilisk","바실리스크",Family.DRAGON,Body.LIZARD,Habitat.DESERT,3,42,5,0x84914E,false,false,Move.HEX),
    COCKATRICE("cockatrice","코카트리스",Family.DRAGON,Body.BIRD,Habitat.SAVANNA,2,30,4,0xBFA463,false,false,Move.SCREAM),
    HYDRA("hydra","삼두 히드라",Family.DRAGON,Body.HYDRA,Habitat.SWAMP,7,500,10,0x648D48,true,false,Move.POISON),
    SUCCUBUS("succubus","몽마 술사",Family.FIEND,Body.WINGED,Habitat.NETHER,3,38,5,0xB66395,false,false,Move.HEX),
    INCUBUS("incubus","몽마 기사",Family.FIEND,Body.WINGED,Habitat.NETHER,3,42,6,0x8E5CA8,false,false,Move.DRAIN),
    BEELZEBUB("beelzebub","벨제부브",Family.FIEND,Body.INSECT,Habitat.NETHER,8,480,10,0x79933C,true,false,Move.POISON),
    DEMOGORGON("demogorgon","데모고곤",Family.FIEND,Body.TWIN,Habitat.NETHER,10,620,12,0x975B52,true,false,Move.SLAM),
    AASIMAR("aasimar","아시마르 수호병",Family.CELESTIAL,Body.WINGED,Habitat.MOUNTAIN,4,48,5,0xD3C47E,false,true,Move.LIGHT),
    SOLAR("solar","태양의 솔라",Family.CELESTIAL,Body.WINGED,Habitat.MOUNTAIN,10,560,11,0xF0DB8F,true,true,Move.LIGHT),
    FIRE_ELEMENTAL("fire_elemental","불의 정령",Family.ELEMENTAL,Body.ELEMENTAL,Habitat.NETHER,2,34,5,0xF48330,false,false,Move.FIRE),
    EARTH_ELEMENTAL("earth_elemental","흙의 정령",Family.ELEMENTAL,Body.GOLEM,Habitat.MOUNTAIN,2,46,5,0xA38A60,false,false,Move.SLAM),
    WATER_ELEMENTAL("water_elemental","물의 정령",Family.ELEMENTAL,Body.ELEMENTAL,Habitat.COAST,2,34,4,0x56B2D7,false,false,Move.TIDE),
    AIR_ELEMENTAL("air_elemental","바람의 정령",Family.ELEMENTAL,Body.ELEMENTAL,Habitat.PLAINS,2,28,4,0xB6E7E0,false,false,Move.WIND),
    CLOUD_GIANT("cloud_giant","구름 거인",Family.GIANT,Body.GIANT,Habitat.MOUNTAIN,5,85,7,0xB8C9D3,false,false,Move.WIND),
    FIRE_GIANT("fire_giant","화염 거인",Family.GIANT,Body.GIANT,Habitat.NETHER,5,90,8,0xA55835,false,false,Move.FIRE),
    FROST_GIANT("frost_giant","서리 거인",Family.GIANT,Body.GIANT,Habitat.SNOW,5,90,8,0x81B7CD,false,false,Move.FROST),
    STORM_GIANT("storm_giant","폭풍 거신",Family.GIANT,Body.GIANT,Habitat.MOUNTAIN,7,440,10,0x7B8FCD,true,false,Move.LIGHTNING),
    STONE_GOLEM("stone_golem","석재 골렘",Family.CONSTRUCT,Body.GOLEM,Habitat.MOUNTAIN,2,55,6,0x8B8F85,false,false,Move.SLAM),
    GARGOYLE("gargoyle","가고일",Family.CONSTRUCT,Body.WINGED,Habitat.DARK,2,38,5,0x8C89A0,false,false,Move.LUNGE),
    ANIMATED_ARMOR("animated_armor","움직이는 갑옷",Family.CONSTRUCT,Body.ARMORED,Habitat.DARK,1,30,4,0x91A3A5,false,false,Move.SWEEP),
    ANCIENT_GOLEM("ancient_golem","고대 수호 골렘",Family.CONSTRUCT,Body.GOLEM,Habitat.MOUNTAIN,6,400,10,0x69888B,true,false,Move.SLAM);
    public enum Family {BEAST,HUMANOID,UNDEAD,DRAGON,FIEND,CELESTIAL,ELEMENTAL,GIANT,CONSTRUCT}
    public enum Body {BEAR,WOLF,BOAR,ANT,SPIDER,SHARK,SMALL,HUMANOID,GIANT,ARMORED,SKELETON,ROBED,GHOST,DRAGON,WYVERN,LIZARD,BIRD,HYDRA,WINGED,INSECT,TWIN,ELEMENTAL,GOLEM}
    public enum Habitat {FOREST,PLAINS,DESERT,OCEAN,SAVANNA,MOUNTAIN,SWAMP,DARK,BADLANDS,SNOW,COAST,NETHER}
    public enum Move {SWEEP,LUNGE,BITE,WEB,SLAM,DRAIN,HEX,SCREAM,FIRE,LIGHTNING,POISON,FROST,LIGHT,TIDE,WIND}
    public final String id,name;public final Family family;public final Body body;public final Habitat habitat;
    public final int minTier,color;public final float health,damage;public final boolean boss,neutral;public final Move move;
    BestiaryKind(String id,String name,Family family,Body body,Habitat habitat,int tier,float hp,float damage,int color,boolean boss,boolean neutral,Move move){this.id=id;this.name=name;this.family=family;this.body=body;this.habitat=habitat;minTier=tier;health=hp;this.damage=damage;this.color=color;this.boss=boss;this.neutral=neutral;this.move=move;}
    public float scale(){return switch(body){case DRAGON,HYDRA->2;case GIANT,GOLEM,TWIN->boss?1.8F:1.3F;case BEAR->boss?1.6F:1;case SMALL->.7F;default->boss?1.5F:1;};}
    public float width(){return switch(body){case DRAGON,HYDRA->4.6F;case BEAR,WOLF,BOAR,LIZARD->1.1F*scale();case SPIDER,ANT,SHARK,INSECT->1.5F*scale();case GIANT,GOLEM,TWIN->1.0F*scale();default->.65F*scale();};}
    public float height(){return switch(body){case BEAR,WOLF,BOAR,LIZARD,SPIDER,ANT,SHARK,INSECT->1.0F*scale();case DRAGON,HYDRA->3.6F;default->1.9F*scale();};}
    public boolean aquatic(){return body==Body.SHARK;}
    public boolean parryable(){return switch(move){case SWEEP,LUNGE,BITE,DRAIN->true;default->false;};}
    public int windup(){return boss?36:parryable()?24:30;}
    public double reach(){return switch(move){case LUNGE->5;case FIRE,POISON,FROST,LIGHTNING,LIGHT,HEX,SCREAM->boss?9:6;case SLAM,TIDE,WIND,WEB->boss?5:3.5;default->boss?5:3;};}
    public static java.util.List<BestiaryKind> bosses(){return java.util.Arrays.stream(values()).filter(k->k.boss).toList();}
}
