package com.junwo.starrpg;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.monster.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.effect.*;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.EntityTickEvent;

/** A telegraphed, bounded extra skill per hostile family, including safe modded fallbacks. */
@EventBusSubscriber(modid=StarRPG.MODID)
public final class MonsterAbilities {
    public enum Trait {
        VENOM("독성 압박",5,280), WIND("돌풍",7,240), SOLAR("태양 섬광",10,320), STONE("암석 방벽",5,300),
        GRASP("썩은 손길",3,240), FROST("서리 사격",10,260), WEB("거미줄 압박",5,240),
        BLAST("폭발 전조",4,300), EMBER("불씨 포격",10,280), SOUL("영혼 침식",8,320),
        WARP("공간 압박",7,260), HEX("쇠약 저주",8,320), RAID("습격의 함성",5,260),
        TIDE("해류 압박",8,280), SKY("급강하",8,240), SLIME("점액 파동",4,260),
        FANG("돌진",4,240), SHELL("껍질 방어",10,300), SONIC("진동 충격",8,360),
        SWARM("군집 쇄도",3,240), FURY("야수 포효",4,280), ARCANE("마력 맥동",8,320);
        public final String label;public final double range;public final int cooldown;
        Trait(String label,double range,int cooldown){this.label=label;this.range=range;this.cooldown=cooldown;}
    }
    public static Trait trait(LivingEntity mob){
        String id=BuiltInRegistries.ENTITY_TYPE.getKey(mob.getType()).getPath();
        if(id.equals("bogged")||id.contains("foliaath")||id.contains("mosquito"))return Trait.VENOM;
        if(id.equals("breeze"))return Trait.WIND;
        if(id.equals("naga"))return BuiltInRegistries.ENTITY_TYPE.getKey(mob.getType()).getNamespace().equals("mowziesmobs")?Trait.VENOM:Trait.FANG;
        if(id.contains("umvuthi"))return Trait.SOLAR;
        if(id.contains("umvuthana"))return Trait.RAID;
        if(id.contains("sculptor")||id.contains("golem"))return Trait.STONE;
        if(id.contains("ice_")||id.contains("snow_")||id.contains("winter_"))return Trait.FROST;
        if(id.contains("minotaur")||id.contains("minoshroom")||id.contains("zoglin")||id.contains("pinch_beetle"))return Trait.FANG;
        if(id.contains("giant")||id.contains("troll")||id.contains("elokosa"))return Trait.FURY;
        if(id.contains("redcap"))return Trait.BLAST;
        if(id.contains("death_tome"))return Trait.HEX;
        if(id.contains("broodling"))return Trait.WEB;
        if(id.contains("borer")||id.contains("kobold"))return Trait.SWARM;
        if(id.contains("roving_cube")||id.contains("harbinger_cube"))return Trait.SHELL;
        if(id.contains("warden"))return Trait.SONIC;
        if(id.contains("enderman")||id.contains("endermite"))return Trait.WARP;
        if(id.contains("shulker")||id.contains("crab"))return Trait.SHELL;
        if(id.contains("wither")||id.contains("soul")||id.contains("lich"))return Trait.SOUL;
        if(id.contains("witch")||id.contains("evoker")||id.contains("illusion")||id.contains("naga"))return Trait.HEX;
        if(id.contains("drowned")||id.contains("guardian")||id.contains("serpent"))return Trait.TIDE;
        if(id.contains("blaze")||id.contains("ghast")||id.contains("magma")||id.contains("fire")||id.contains("hydra"))return Trait.EMBER;
        if(id.contains("creeper"))return Trait.BLAST;
        if(id.contains("spider"))return Trait.WEB;
        if(id.contains("skeleton")||id.contains("stray")||id.contains("snow")||id.contains("frost"))return Trait.FROST;
        if(id.contains("zombie")||id.contains("husk"))return Trait.GRASP;
        if(id.contains("pillager")||id.contains("vindicator")||id.contains("piglin"))return Trait.RAID;
        if(id.contains("slime"))return Trait.SLIME;
        if(id.contains("phantom")||id.contains("vex")||id.contains("dragon")||mob instanceof FlyingMob)return Trait.SKY;
        if(id.contains("hoglin")||id.contains("ravager")||id.contains("boar"))return Trait.FANG;
        if(id.contains("silverfish")||id.contains("mite")||id.contains("goblin"))return Trait.SWARM;
        if(id.contains("wolf")||id.contains("yeti")||id.contains("beast")||id.contains("ferrous")||id.contains("wrought"))return Trait.FURY;
        return Trait.ARCANE;
    }
    public static boolean valid(Mob mob,Player p,Trait t){return mob.isAlive()&&!mob.isNoAi()&&p.isAlive()&&!p.isCreative()&&!p.isSpectator()
        &&!mob.isAlliedTo(p)&&!p.isAlliedTo(mob)&&mob.distanceToSqr(p)<=t.range*t.range&&mob.hasLineOfSight(p);}
    @SubscribeEvent public static void tick(EntityTickEvent.Post event){
        if(event.getEntity() instanceof Mob mob&&mob.level() instanceof ServerLevel&&mob.tickCount%10==0)update(mob);
    }
    public static void update(Mob mob){
        var data=mob.getPersistentData();
        // Dragons and some mod bosses drive their own attack targets outside Mob#getTarget.
        Player target=mob.getTarget() instanceof Player selected?selected:null;
        if(target==null&&mob.getType().is(MonsterProgression.BOSSES))target=mob.level().players().stream()
            .filter(candidate->valid(mob,candidate,trait(mob))).min(java.util.Comparator.comparingDouble(candidate->mob.distanceToSqr(candidate))).orElse(null);
        final Player p=target;
        if(mob instanceof com.junwo.starrpg.bestiary.BestiaryMob||!Config.MOB_SCALING.get()||!Config.MOB_TRAITS.get()||!MonsterProgression.eligible(mob)||MonsterProgression.tier(mob)<1
            ||p==null||!valid(mob,p,trait(mob))){data.remove("starrpg_trait_cast");data.remove("starrpg_trait_target");return;}
        Trait t=trait(mob);long now=mob.level().getGameTime();if(data.getLong("starrpg_trait_ready")>now)return;
        if(!data.contains("starrpg_trait_cast")){
            data.putLong("starrpg_trait_cast",now+20);data.putUUID("starrpg_trait_target",p.getUUID());
            CombatVisuals.ringAt((ServerLevel)mob.level(),mob.position(),Math.min(4,t.range),ParticleTypes.WAX_ON,18);return;
        }
        if(!data.hasUUID("starrpg_trait_target")||!data.getUUID("starrpg_trait_target").equals(p.getUUID())){data.remove("starrpg_trait_cast");data.remove("starrpg_trait_target");return;}
        if(now<data.getLong("starrpg_trait_cast"))return;
        data.remove("starrpg_trait_cast");data.remove("starrpg_trait_target");data.putLong("starrpg_trait_ready",now+t.cooldown);
        // Victim-wide grace prevents a crowd from chaining crowd control.
        if(p.getPersistentData().getLong("starrpg_monster_trait_guard")>now)return;
        p.getPersistentData().putLong("starrpg_monster_trait_guard",now+100);
        CombatVisuals.line((ServerLevel)mob.level(),mob.getEyePosition(),p.position().add(0,1,0),t==Trait.EMBER?ParticleTypes.FLAME:t==Trait.SOUL?ParticleTypes.SOUL:ParticleTypes.ENCHANTED_HIT,16);
        switch(t){
            case GRASP,WEB,SLIME,TIDE->p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,30,0));
            case FROST->p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,40,0));
            case VENOM->p.addEffect(new MobEffectInstance(MobEffects.POISON,40,0));
            case WIND->{p.knockback(0.5,mob.getX()-p.getX(),mob.getZ()-p.getZ());p.hurtMarked=true;return;}
            case STONE->{mob.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,60,0));p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,20,0));return;}
            case HEX->p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS,40,0));
            case SOUL->p.addEffect(new MobEffectInstance(MobEffects.WITHER,40,0));
            case SHELL->{mob.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,60,0));return;}
            case RAID,FURY->{mob.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,60,0));return;}
            case SKY,FANG,SWARM->{var dir=p.position().subtract(mob.position()).multiply(1,0,1).normalize();mob.setDeltaMovement(dir.scale(0.65).add(0,0.25,0));mob.hurtMarked=true;return;}
            case WARP->{p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS,30,0));mob.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED,40,0));return;}
            default->{}
        }
        // This is ordinary mob damage: armor, shields, teams and native damage hooks still apply.
        if(t==Trait.SOLAR||t==Trait.BLAST||t==Trait.EMBER||t==Trait.SONIC||t==Trait.ARCANE)
            p.hurt(mob.damageSources().mobAttack(mob),2.5F);
    }
}
