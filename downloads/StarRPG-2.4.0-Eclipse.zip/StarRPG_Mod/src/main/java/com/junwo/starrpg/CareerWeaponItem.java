package com.junwo.starrpg;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.*;

/** Specialist weapons share sword rune pools while retaining independent job/skill identity. */
public final class CareerWeaponItem extends SwordItem {
    public final int job;
    public CareerWeaponItem(Properties properties,int job,int damage,float speed){
        super(Tiers.IRON,properties.attributes(SwordItem.createAttributes(Tiers.IRON,damage,speed)));this.job=job;
    }
    @Override public void appendHoverText(ItemStack s,TooltipContext c,List<Component> lines,TooltipFlag flag){
        super.appendHoverText(s,c,lines,flag);
        lines.add(Component.literal(Careers.NAMES[Careers.canonical(job)]+" 전용 능력 · "+Careers.ABILITIES[Careers.canonical(job)]));
        lines.add(Component.literal("검 룬 사용 · 무한 강화 / 강화 실패 시 단계 유지"));
        lines.add(Component.literal("5·10·15회 전직: 추가 능력 / 매 5회 능력치 성장"));
    }
}
