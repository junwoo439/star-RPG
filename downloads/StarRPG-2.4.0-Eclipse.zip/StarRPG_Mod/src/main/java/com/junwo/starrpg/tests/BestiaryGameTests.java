package com.junwo.starrpg.tests;

import com.junwo.starrpg.*;
import com.junwo.starrpg.bestiary.*;
import net.minecraft.gametest.framework.*;
import net.minecraft.core.*;
import net.minecraft.core.registries.*;
import net.minecraft.resources.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.*;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.common.damagesource.DamageContainer;

@GameTestHolder(StarRPG.MODID)
@PrefixGameTestTemplate(false)
public class BestiaryGameTests {
    private static BestiaryMob mob(GameTestHelper h,BestiaryKind k){var m=BestiaryRegistry.TYPES.get(k).get().create(h.getLevel());m.setPos(h.absoluteVec(new Vec3(3,2,3)));m.setNoGravity(true);return m;}
    private static Player player(GameTestHelper h,BestiaryMob m){var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(m.position().add(0,0,1.5));p.setYRot(180);p.setXRot(0);p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(Items.IRON_SWORD));return p;}
    private static LivingEntity target(GameTestHelper h,BestiaryMob m){var c=EntityType.COW.create(h.getLevel());c.setPos(m.position().add(0,0,1.8));c.setNoAi(true);c.setNoGravity(true);c.getAttribute(Attributes.MAX_HEALTH).setBaseValue(200);c.setHealth(200);h.getLevel().addFreshEntity(c);m.setTarget(c);return c;}
    private static LivingIncomingDamageEvent incoming(BestiaryMob m,Player p){return new LivingIncomingDamageEvent(p,new DamageContainer(m.damageSources().mobAttack(m),10));}
    @GameTest(template="empty") public static void everySpeciesHasRegisteredAttributesEggLootAndCorrectBossClassification(GameTestHelper h){
        h.assertTrue(BestiaryKind.values().length==53&&BestiaryKind.bosses().size()==19,"Incomplete roster");
        for(var k:BestiaryKind.values()){
            var m=mob(h,k);if(k.move==BestiaryKind.Move.FIRE||k.family==BestiaryKind.Family.FIEND)h.assertTrue(m.fireImmune(),"Fire species burns: "+k.id);h.assertTrue(m.getMaxHealth()==k.health&&m.getHealth()==k.health,"Incorrect fresh health: "+k.id);
            h.assertTrue(m.getType().is(MonsterProgression.BOSSES)==k.boss&&MonsterProgression.eligible(m),"Boss/scaling classification: "+k.id);
            h.assertTrue(BestiaryRegistry.EGGS.get(k).get().getType(new ItemStack(BestiaryRegistry.EGGS.get(k).get()))==m.getType(),"Wrong egg: "+k.id);
            h.assertTrue(h.getLevel().getServer().reloadableRegistries().getLootTable(ResourceKey.create(Registries.LOOT_TABLE,ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,"entities/"+k.id)))!=net.minecraft.world.level.storage.loot.LootTable.EMPTY,"Missing loot: "+k.id);
        }h.succeed();
    }
    @GameTest(template="empty") public static void customBossScalingPreservesWoundsAndStageBand(GameTestHelper h){
        var m=mob(h,BestiaryKind.LICH);MonsterProgression.applyTier(m,3);h.assertTrue(Math.abs(m.getMaxHealth()-464)<.1,"Wrong boss scaling");m.setHealth(90);MonsterProgression.upgradeTier(m,100);h.assertTrue(m.getHealth()==90&&MonsterProgression.tier(m)==100,"Healing or tier cap");
        for(int offset=0;offset<3;offset++)h.assertTrue(MonsterProgression.tierFor(5,offset)==5-offset,"Difficulty band");h.succeed();
    }
    @GameTest(template="hook_arena") public static void heavyHasNoEarlyDamageThenDamageStunAndRecovery(GameTestHelper h){
        var m=mob(h,BestiaryKind.ORC);var t=target(h,m);m.startAttack(t,true);
        for(int i=0;i<m.kind.windup()-1;i++)m.combatTick();h.assertTrue(t.getHealth()==200&&m.phase()==BestiaryMob.HEAVY,"Early hit");
        m.combatTick();h.assertTrue(t.getHealth()<190&&t.hasEffect(ModEffects.STUN)&&m.phase()==BestiaryMob.ACTIVE,"Missing heavy damage/stun");
        float after=t.getHealth();for(int i=0;i<4;i++)m.combatTick();h.assertTrue(t.getHealth()==after&&m.phase()==BestiaryMob.RECOVERY&&m.remaining()>=30,"Repeat hit or no punish window");t.discard();h.succeed();
    }
    @GameTest(template="hook_arena") public static void quickAttackIsWeakAndDoesNotStun(GameTestHelper h){
        var m=mob(h,BestiaryKind.ORC);var t=target(h,m);m.startAttack(t,false);for(int i=0;i<10;i++)m.combatTick();
        h.assertTrue(t.getHealth()<200&&t.getHealth()>196&&!t.hasEffect(ModEffects.STUN),"Quick attack too strong/stunning");t.discard();h.succeed();
    }
    @GameTest(template="hook_arena") public static void dodgeLockedConeAndWallsPreventDamage(GameTestHelper h){
        var m=mob(h,BestiaryKind.ORC);var t=target(h,m);m.startAttack(t,true);t.setPos(m.position().add(2,0,0));for(int i=0;i<m.kind.windup();i++)m.combatTick();h.assertTrue(t.getHealth()==200,"Attack tracked target after windup");
        t.setPos(m.position().add(0,0,2));m.startAttack(t,true);var pos=m.blockPosition().offset(0,1,1);h.getLevel().setBlockAndUpdate(pos,Blocks.STONE.defaultBlockState());h.assertTrue(!BestiaryCombat.inAttack(m,t),"Attack through solid wall");h.getLevel().setBlockAndUpdate(pos,Blocks.AIR.defaultBlockState());
        t.setPos(m.position().add(0,0,10));h.assertTrue(!BestiaryCombat.inAttack(m,t),"Out of range hit");t.discard();h.succeed();
    }
    @GameTest(template="hook_arena") public static void radialAttackHitsBehindButCannotStunlock(GameTestHelper h){
        var m=mob(h,BestiaryKind.ANCIENT_GOLEM);var t=target(h,m);m.startAttack(t,true);t.setPos(m.position().add(0,0,-2));h.assertTrue(BestiaryCombat.inAttack(m,t),"Radial misses rear");BestiaryCombat.resolve(m);h.assertTrue(t.hasEffect(ModEffects.STUN),"Heavy no stun");t.removeEffect(ModEffects.STUN);t.invulnerableTime=0;BestiaryCombat.resolve(m);h.assertTrue(!t.hasEffect(ModEffects.STUN),"Chain stun ignored guard");t.discard();h.succeed();
    }
    @GameTest(template="hook_arena") public static void cancelledTargetAndReloadNeverFireDeferredAttacks(GameTestHelper h){
        var m=mob(h,BestiaryKind.LICH);var t=target(h,m);m.startAttack(t,true);m.setTarget(null);m.combatTick();h.assertTrue(m.phase()==BestiaryMob.RECOVERY&&t.getHealth()==200,"Invalid target still attacked");
        m.setTarget(t);m.startAttack(t,true);var tag=new CompoundTag();m.saveWithoutId(tag);var restored=mob(h,BestiaryKind.LICH);restored.load(tag);h.assertTrue(restored.phase()==BestiaryMob.IDLE&&restored.nextAttack>h.getLevel().getGameTime(),"Reload attack exploited");t.discard();h.succeed();
    }
    @GameTest(template="hook_arena") public static void parryCancelsFrontalMeleeAndAllowsOneRiposte(GameTestHelper h){
        var m=mob(h,BestiaryKind.ORC);var p=player(h,m);h.assertTrue(ParrySystem.open(p),"Parry refused");m.parryableImpact=true;var e=incoming(m,p);ParrySystem.defend(e);
        h.assertTrue(e.isCanceled()&&m.phase()==BestiaryMob.STAGGER&&m.remaining()==36,"Parry did not interrupt");h.assertTrue(!ParrySystem.open(p),"Parry spam");
        var hit=new LivingIncomingDamageEvent(m,new DamageContainer(p.damageSources().playerAttack(p),10));ParrySystem.riposte(hit);h.assertTrue(hit.getAmount()==12.5F,"Riposte missing");var next=new LivingIncomingDamageEvent(m,new DamageContainer(p.damageSources().playerAttack(p),10));ParrySystem.riposte(next);h.assertTrue(next.getAmount()==10,"Riposte repeated");h.succeed();
    }
    @GameTest(template="hook_arena") public static void lateRearAndUnparryableHitsBypassParry(GameTestHelper h){
        var m=mob(h,BestiaryKind.ANCIENT_GOLEM);var p=player(h,m);ParrySystem.open(p);m.parryableImpact=false;var e=incoming(m,p);ParrySystem.defend(e);h.assertTrue(!e.isCanceled(),"Red attack parried");
        m.parryableImpact=true;p.setYRot(0);e=incoming(m,p);ParrySystem.defend(e);h.assertTrue(!e.isCanceled(),"Rear attack parried");p.setYRot(180);p.getPersistentData().putLong(ParrySystem.END,h.getLevel().getGameTime());e=incoming(m,p);ParrySystem.defend(e);h.assertTrue(!e.isCanceled(),"Expired window accepted");h.succeed();
    }
    @GameTest(template="empty") public static void parryRejectsUnarmedStunnedAndChangingEquipment(GameTestHelper h){
        var m=mob(h,BestiaryKind.ORC);var p=player(h,m);p.setItemInHand(InteractionHand.MAIN_HAND,ItemStack.EMPTY);h.assertTrue(!ParrySystem.open(p),"Unarmed parry");p.setItemInHand(InteractionHand.OFF_HAND,new ItemStack(Items.SHIELD));h.assertTrue(ParrySystem.open(p),"Offhand shield rejected");p.setItemInHand(InteractionHand.OFF_HAND,ItemStack.EMPTY);m.parryableImpact=true;var e=incoming(m,p);ParrySystem.defend(e);h.assertTrue(!e.isCanceled(),"Unequip exploit");p.getPersistentData().remove(ParrySystem.READY);p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(Items.IRON_SWORD));p.addEffect(new net.minecraft.world.effect.MobEffectInstance(ModEffects.STUN,20));h.assertTrue(!ParrySystem.open(p),"Stun parry exploit");h.succeed();
    }
    @GameTest(template="empty") public static void naturalSpawnUnlocksAndBossSpacing(GameTestHelper h){
        var l=h.getLevel();var d=WorldDifficulty.get(l.getServer());int before=d.tier();try{
            d.setTier(0);h.assertTrue(BestiarySpawns.stage(BestiaryKind.GOBLIN,l)&&!BestiarySpawns.stage(BestiaryKind.RED_DRAGON,l),"Early boss unlocked");d.setTier(8);h.assertTrue(BestiarySpawns.stage(BestiaryKind.RED_DRAGON,l),"Boss never unlocks");
            var m=mob(h,BestiaryKind.RED_DRAGON);l.addFreshEntity(m);h.assertTrue(BestiarySpawns.bossNearby(l,m.blockPosition())&&!BestiarySpawns.bossNearby(l,m.blockPosition().offset(300,0,0)),"Boss spacing incorrect");m.discard();
        }finally{d.setTier(before);}h.succeed();
    }
    @GameTest(template="hook_arena") public static void contractCyclesAndFailedSummonDoesNotConsume(GameTestHelper h){
        h.assertTrue(h.getLevel().getRecipeManager().byKey(ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,"boss_contract")).isPresent(),"Contract recipe missing");
        var s=new ItemStack(BestiaryRegistry.CONTRACT.get(),2);var ids=new java.util.HashSet<BestiaryKind>();for(int i=0;i<19;i++){ids.add(BossContractItem.selected(s));BossContractItem.cycle(s);}h.assertTrue(ids.size()==19&&BossContractItem.selected(s)==BestiaryKind.ELDER_BEAR,"Contract selection misses bosses");
        var m=mob(h,BestiaryKind.ORC);var p=player(h,m);var d=WorldDifficulty.get(h.getLevel().getServer());int before=d.tier();try{d.setTier(0);h.assertTrue(!BossContractItem.summon(h.getLevel(),p,s,m.blockPosition())&&s.getCount()==2,"Failed summon consumed item");}finally{d.setTier(before);}h.succeed();
    }
    @GameTest(template="hook_arena") public static void contractSuccessConsumesExactlyOnceAndBlocksSecondBoss(GameTestHelper h){
        var l=h.getLevel();var d=WorldDifficulty.get(l.getServer());int before=d.tier();var m=mob(h,BestiaryKind.ORC);var p=player(h,m);var pos=m.blockPosition();var s=new ItemStack(BestiaryRegistry.CONTRACT.get(),2);try{
            d.setTier(3);for(int x=-2;x<=2;x++)for(int z=-2;z<=2;z++){l.setBlockAndUpdate(pos.offset(x,-1,z),Blocks.STONE.defaultBlockState());for(int y=0;y<4;y++)l.setBlockAndUpdate(pos.offset(x,y,z),Blocks.AIR.defaultBlockState());}
            h.assertTrue(BossContractItem.summon(l,p,s,pos)&&s.getCount()==1,"Valid summon failed");h.assertTrue(!BossContractItem.summon(l,p,s,pos)&&s.getCount()==1,"Duplicate/consumption exploit");
            l.getEntitiesOfClass(BestiaryMob.class,new net.minecraft.world.phys.AABB(pos).inflate(5),b->b.kind.boss).forEach(Entity::discard);
        }finally{d.setTier(before);}h.succeed();
    }
    @GameTest(template="empty") public static void sharkBreathesWaterAndCustomMobsDoNotGainHiddenLegacyTraits(GameTestHelper h){
        var shark=mob(h,BestiaryKind.REEF_SHARK);h.assertTrue(shark.canBreatheUnderwater()&&shark.getNavigation() instanceof net.minecraft.world.entity.ai.navigation.WaterBoundPathNavigation,"Shark cannot survive/navigate water");
        var m=mob(h,BestiaryKind.ORC);var p=player(h,m);m.setTarget(p);MonsterProgression.applyTier(m,5);MonsterAbilities.update(m);h.assertTrue(!m.getPersistentData().contains("starrpg_trait_cast"),"Hidden instant legacy trait");h.succeed();
    }
    @GameTest(template="empty") public static void biomeModifiersActuallyContainBossesAndOrdinarySpecies(GameTestHelper h){
        var registry=h.getLevel().registryAccess().registryOrThrow(Registries.BIOME);var forest=registry.get(net.minecraft.world.level.biome.Biomes.FOREST);var list=forest.getMobSettings().getMobs(MobCategory.MONSTER).unwrap();
        h.assertTrue(list.stream().anyMatch(s->s.type==BestiaryRegistry.TYPES.get(BestiaryKind.GOBLIN).get())&&list.stream().anyMatch(s->s.type==BestiaryRegistry.TYPES.get(BestiaryKind.ELDER_BEAR).get()),"Natural spawns not injected");var desert=registry.get(net.minecraft.world.level.biome.Biomes.DESERT);h.assertTrue(desert.getMobSettings().getMobs(MobCategory.MONSTER).unwrap().stream().noneMatch(s->s.type==BestiaryRegistry.TYPES.get(BestiaryKind.ELDER_BEAR).get()),"Wrong habitat");h.succeed();
    }
    @GameTest(template="hook_arena",timeoutTicks=130) public static void realGoalSchedulerPerformsTelegraphedAttack(GameTestHelper h){
        var m=mob(h,BestiaryKind.ORC);var t=target(h,m);h.getLevel().addFreshEntity(m);
        h.runAfterDelay(35,()->h.assertTrue(t.getHealth()==200,"Spawn grace skipped"));
        h.runAfterDelay(100,()->{h.assertTrue(t.getHealth()<200,"AI never attacked target");m.discard();t.discard();h.succeed();});
    }
    @GameTest(template="hook_arena",timeoutTicks=100) public static void neutralGuardianOnlyRetaliatesAfterBeingHit(GameTestHelper h){
        var m=mob(h,BestiaryKind.AASIMAR);var p=player(h,m);h.getLevel().addFreshEntity(m);
        h.runAfterDelay(20,()->{h.assertTrue(m.getTarget()==null,"Neutral guardian started combat");m.hurt(p.damageSources().playerAttack(p),2);});
        h.runAfterDelay(40,()->{h.assertTrue(m.getTarget()==p,"Neutral guardian cannot retaliate");m.discard();h.succeed();});
    }

}
