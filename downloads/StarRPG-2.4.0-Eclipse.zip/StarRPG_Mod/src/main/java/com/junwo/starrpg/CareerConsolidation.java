package com.junwo.starrpg;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;

/** Idempotent, free save migration. Never treated as a paid career change. */
public final class CareerConsolidation {
    public static boolean migrate(CareerData.Profile p){
        boolean changed=false;
        for(int old:new int[]{3,6,9}){
            int next=Careers.canonical(old);
            if(p.ranks[old]>0||p.xp[old]>0||p.mastery[old]>0||p.bosses[old]>0){
                p.ranks[next]=Math.max(p.ranks[next],p.ranks[old]);p.xp[next]=Math.max(p.xp[next],p.xp[old]);
                p.mastery[next]=Math.max(p.mastery[next],p.mastery[old]);p.bosses[next]=Math.max(p.bosses[next],p.bosses[old]);
                p.ranks[old]=p.xp[old]=p.mastery[old]=p.bosses[old]=0;changed=true;
            }
            if(p.selected==old){p.selected=next;changed=true;}
        }
        return changed;
    }
    public static Item staff(int school){return switch(school){case 1->StarRPG.FIRE_STAFF.get();case 2->StarRPG.WATER_STAFF.get();case 3->StarRPG.ICE_STAFF.get();case 4->StarRPG.EARTH_STAFF.get();case 5->StarRPG.DARK_STAFF.get();case 6->StarRPG.LIGHT_STAFF.get();default->StarRPG.MAGIC_STAFF.get();};}
    public static ItemStack convert(ItemStack stack,int job){
        Item replacement=null;
        if(stack.is(StarRPG.MAGIC_STAFF.get())&&Careers.mage(job))replacement=staff(MagicSchools.ofJob(Careers.canonical(job)));
        else if(stack.is(StarRPG.AEGIS_BLADE.get()))replacement=StarRPG.STAR_SPEAR.get();
        return replacement==null?stack:stack.transmuteCopy(replacement);
    }
    public static void inventory(Player p){
        int job=Careers.profile(p).selected;boolean changed=false;
        for(int i=0;i<p.getInventory().getContainerSize();i++){
            var old=p.getInventory().getItem(i);var next=convert(old,job);
            if(next!=old){p.getInventory().setItem(i,next);changed=true;}
        }
        if(changed){p.getInventory().setChanged();p.containerMenu.broadcastChanges();}
    }
}
