package com.junwo.starrpg;

/** Texture-space grip positions: x/y in the cell, y measured from the top. */
public final class WeaponPresentation {
    public record Grip(float x,float y,float scale,float depth,float cropRight){}
    public static Grip grip(int kind){return switch(kind){
        case 2->new Grip(0.47F,0.78F,0.72F,0.022F,1); // dagger: short blade, grip below guard
        case 3->new Grip(0.50F,0.78F,0.96F,0.065F,1); // hammer: heavier head and handle
        case 4->new Grip(0.50F,0.73F,1.16F,0.030F,1);
        case 5->new Grip(0.50F,0.70F,1.36F,0.028F,1);
        case 6->new Grip(0.50F,0.80F,1.13F,0.040F,1);
        case 7->new Grip(0.50F,0.76F,1.00F,0.035F,1);
        case 8->new Grip(0.47F,0.73F,1.20F,0.030F,1);
        case 9->new Grip(0.27F,0.68F,0.66F,0.065F,0.5F); // show one gauntlet in a hand
        case 10->new Grip(0.50F,0.78F,0.96F,0.055F,1);
        default->new Grip(0.5F,0.75F,1,0.025F,1);
    };}
    public static boolean held(net.minecraft.world.item.ItemDisplayContext context){return switch(context){
        case FIRST_PERSON_LEFT_HAND,FIRST_PERSON_RIGHT_HAND,THIRD_PERSON_LEFT_HAND,THIRD_PERSON_RIGHT_HAND->true;
        default->false;
    };}
}
