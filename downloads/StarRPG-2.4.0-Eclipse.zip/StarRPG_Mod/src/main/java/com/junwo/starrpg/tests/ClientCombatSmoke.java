package com.junwo.starrpg.tests;

import com.junwo.starrpg.*;
import net.minecraft.client.*;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.core.BlockPos;
import net.minecraft.world.*;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.*;
import net.minecraft.world.level.levelgen.presets.WorldPresets;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/** Opt-in visual test creates its own new world; never opens a user's save. Excluded from release JAR. */
@EventBusSubscriber(modid=StarRPG.MODID,value=Dist.CLIENT)
public final class ClientCombatSmoke {
    private static boolean started,configured;private static int tick;
    @SubscribeEvent public static void tick(ClientTickEvent.Post event){
        if(!Boolean.getBoolean("starrpg.worldSmoke"))return;var mc=Minecraft.getInstance();
        if(!started&&mc.screen instanceof TitleScreen&&mc.getOverlay()==null){
            started=true;mc.options.guiScale().set(2);mc.options.renderDistance().set(4);mc.options.simulationDistance().set(4);mc.getWindow().setWindowed(1280,800);mc.resizeDisplay();
            mc.createWorldOpenFlows().createFreshLevel("starrpg-visual-230-"+System.currentTimeMillis(),new LevelSettings("StarRPG visual test",GameType.CREATIVE,false,Difficulty.PEACEFUL,true,new GameRules(),WorldDataConfiguration.DEFAULT),new WorldOptions(230,false,false),WorldPresets::createNormalWorldDimensions,mc.screen);return;
        }
        if(mc.player==null||mc.level==null||mc.getSingleplayerServer()==null)return;
        var server=mc.getSingleplayerServer();var id=mc.player.getUUID();
        if(!configured){configured=true;mc.options.hideGui=false;mc.setScreen(null);server.execute(()->{
            var p=server.getPlayerList().getPlayer(id);if(p==null)return;var l=p.serverLevel();
            for(int x=-14;x<=14;x++)for(int z=-14;z<=14;z++)l.setBlock(new BlockPos(x,180,z),(x+z)%2==0?Blocks.GRAY_CONCRETE.defaultBlockState():Blocks.LIGHT_GRAY_CONCRETE.defaultBlockState(),3);
            l.setDayTime(6000);l.getGameRules().getRule(GameRules.RULE_DAYLIGHT).set(false,server);p.teleportTo(l,0,181,0,0,0);p.getInventory().clearContent();
            Careers.profile(p).selected=8;Careers.profile(p).ranks[8]=1;p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(StarRPG.STAR_GAUNTLET.get()));
        });return;}
        tick++;
        if(tick==94||tick==216||tick==276)server.execute(()->WeaponMotion.swing(server.getPlayerList().getPlayer(id)));
        if(tick==100)grab("gauntlets-first");
        if(tick==120){mc.options.setCameraType(CameraType.THIRD_PERSON_FRONT);mc.player.setXRot(5);}
        if(tick==160)grab("gauntlets-third");
        if(tick==180){mc.options.setCameraType(CameraType.FIRST_PERSON);server.execute(()->{var p=server.getPlayerList().getPlayer(id);Careers.profile(p).selected=0;Careers.profile(p).ranks[0]=1;p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(StarRPG.STAR_SPEAR.get()));});}
        if(tick==220)grab("spear-first");
        if(tick==240)mc.options.setCameraType(CameraType.THIRD_PERSON_FRONT);
        if(tick==280)grab("spear-third");
        if(tick==300){mc.options.setCameraType(CameraType.FIRST_PERSON);mc.player.setXRot(15);server.execute(()->{var p=server.getPlayerList().getPlayer(id);Careers.profile(p).selected=12;Careers.profile(p).ranks[12]=1;p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(StarRPG.ICE_STAFF.get()));});}
        if(tick==320)server.execute(()->{var p=server.getPlayerList().getPlayer(id);ArcaneSigil.spawn(p.serverLevel(),new Vec3(0,181.1,7),new Vec3(0,0,1),26,MagicSchools.color(3),3,44);});
        if(tick==340)grab("ice-ultimate-world");
        if(tick==360)server.execute(()->{var p=server.getPlayerList().getPlayer(id);Careers.profile(p).selected=8;p.setMainArm(net.minecraft.world.entity.HumanoidArm.LEFT);p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(StarRPG.STAR_GAUNTLET.get()));});
        if(tick==400)grab("gauntlets-left-main");
        if(tick==420)server.execute(()->server.getPlayerList().getPlayer(id).setItemInHand(InteractionHand.OFF_HAND,new ItemStack(net.minecraft.world.item.Items.TORCH)));
        if(tick==460)grab("gauntlet-with-torch");
        if(tick==480){mc.player.setXRot(12);server.execute(()->{var p=server.getPlayerList().getPlayer(id);p.setMainArm(net.minecraft.world.entity.HumanoidArm.RIGHT);p.setItemInHand(InteractionHand.OFF_HAND,ItemStack.EMPTY);Careers.profile(p).selected=1;Careers.profile(p).ranks[1]=1;p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(StarRPG.STAR_DAGGER.get()));});}
        if(tick==500)server.execute(()->WeaponMotion.swing(server.getPlayerList().getPlayer(id)));
        if(tick==505)grab("dagger-trail-world");
        if(tick==540){StarRPG.LOGGER.info("WORLD_VISUAL_CHECK COMPLETE");mc.stop();}
        if(tick>800)mc.stop();
    }
    private static void grab(String name){var mc=Minecraft.getInstance();Screenshot.grab(mc.gameDirectory,"starrpg-2.3-"+name+".png",mc.getMainRenderTarget(),message->StarRPG.LOGGER.info("WORLD_VISUAL_SCREENSHOT {}",name));}
}
