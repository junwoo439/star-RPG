package com.junwo.starrpg.bestiary;

import com.junwo.starrpg.*;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.*;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/** One contract selects a boss; no client-supplied spawn coordinates or attributes. */
public final class BossContractItem extends Item {
    public BossContractItem(Properties p){super(p);}
    public static BestiaryKind selected(ItemStack s){int n=s.getOrDefault(DataComponents.CUSTOM_DATA,CustomData.EMPTY).copyTag().getInt("bossIndex");return BestiaryKind.bosses().get(Math.floorMod(n,BestiaryKind.bosses().size()));}
    public static void cycle(ItemStack s){CustomData.update(DataComponents.CUSTOM_DATA,s,t->t.putInt("bossIndex",(BestiaryKind.bosses().indexOf(selected(s))+1)%BestiaryKind.bosses().size()));}
    @Override public InteractionResultHolder<ItemStack> use(Level l,Player p,InteractionHand hand){
        var s=p.getItemInHand(hand);if(p.isShiftKeyDown()){if(!l.isClientSide()){cycle(s);p.displayClientMessage(Component.literal("소환 대상: "+selected(s).name+" · 월드 "+selected(s).minTier+"단계"),true);}return InteractionResultHolder.sidedSuccess(s,l.isClientSide());}
        if(!l.isClientSide())p.displayClientMessage(Component.literal("웅크리기 + 우클릭: 보스 선택 / 바닥 우클릭: 소환"),true);return InteractionResultHolder.pass(s);
    }
    @Override public InteractionResult useOn(UseOnContext c){
        var p=c.getPlayer();if(p==null)return InteractionResult.PASS;
        if(p.isShiftKeyDown()){if(!c.getLevel().isClientSide()){cycle(c.getItemInHand());p.displayClientMessage(Component.literal("소환 대상: "+selected(c.getItemInHand()).name),true);}return InteractionResult.sidedSuccess(c.getLevel().isClientSide());}
        if(c.getLevel() instanceof ServerLevel l)return summon(l,p,c.getItemInHand(),c.getClickedPos().relative(c.getClickedFace()))?InteractionResult.CONSUME:InteractionResult.FAIL;
        return InteractionResult.SUCCESS;
    }
    public static boolean summon(ServerLevel l,Player p,ItemStack s,BlockPos pos){
        if(!p.isAlive()||p.isSpectator()||!s.is(BestiaryRegistry.CONTRACT.get())||s.isEmpty()||p.distanceToSqr(pos.getX()+.5,pos.getY(),pos.getZ()+.5)>64)return false;
        var k=selected(s);
        if(l.getDifficulty()==Difficulty.PEACEFUL||!BestiarySpawns.stage(k,l)){p.displayClientMessage(Component.literal("평화로움에서는 소환할 수 없습니다. 필요한 월드 단계: "+k.minTier),true);return false;}
        if(BestiarySpawns.bossNearby(l,pos)){p.displayClientMessage(Component.literal("128블록 안에 이미 보스가 있습니다."),true);return false;}
        if(!l.hasChunkAt(pos)||!l.getWorldBorder().isWithinBounds(pos)||!l.getBlockState(pos.below()).isSolidRender(l,pos.below()))return false;
        var mob=BestiaryRegistry.TYPES.get(k).get().create(l);if(mob==null)return false;
        mob.moveTo(pos.getX()+.5,pos.getY(),pos.getZ()+.5,p.getYRot()+180,0);
        if(!l.noCollision(mob)||l.containsAnyLiquid(mob.getBoundingBox())||!l.getWorldBorder().isWithinBounds(mob.getBoundingBox())){p.displayClientMessage(Component.literal("보스가 설 수 있는 넓고 빈 바닥이 필요합니다."),true);return false;}
        mob.finalizeSpawn(l,l.getCurrentDifficultyAt(pos),MobSpawnType.TRIGGERED,null);mob.setPersistenceRequired();
        if(!k.neutral)mob.setTarget(p);
        if(!l.addFreshEntity(mob))return false;
        if(!p.isCreative())s.shrink(1);p.displayClientMessage(Component.literal(k.name+" 소환!"+(k.neutral?" 먼저 공격하기 전에는 중립입니다.":"")),false);return true;
    }
    @Override public void appendHoverText(ItemStack s,TooltipContext c,List<Component> text,TooltipFlag f){var k=selected(s);text.add(Component.literal(k.name+" · 필요 월드 단계 "+k.minTier));text.add(Component.literal("웅크리기+우클릭: 변경 / 바닥 우클릭: 소환"));text.add(Component.literal("보스 간 128블록 · 충분한 빈 공간 필요"));}
}
