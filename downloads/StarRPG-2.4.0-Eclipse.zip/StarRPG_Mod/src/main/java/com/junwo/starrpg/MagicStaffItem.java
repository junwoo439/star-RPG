package com.junwo.starrpg;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.world.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;

public final class MagicStaffItem extends Item {
    public final int school;
    public MagicStaffItem(Properties properties){this(properties,0);}
    public MagicStaffItem(Properties properties,int school){super(properties.durability(384));this.school=school;}
    @Override public InteractionResultHolder<ItemStack> use(Level level,Player player,InteractionHand hand){
        var stack=player.getItemInHand(hand);if(hand!=InteractionHand.MAIN_HAND)return InteractionResultHolder.pass(stack);
        if(level.isClientSide())return InteractionResultHolder.success(stack);
        boolean result=player.isShiftKeyDown()?MagicSystem.cycle(player):MagicSystem.cast(player);
        return result?InteractionResultHolder.consume(stack):InteractionResultHolder.fail(stack);
    }
    @Override public void appendHoverText(ItemStack stack,TooltipContext context,List<Component> lines,TooltipFlag flag){
        super.appendHoverText(stack,context,lines,flag);
        lines.add(Component.literal((school==0?"구형 지팡이 · 직업에 맞춰 자동 이전 · ":Careers.NAMES[school+9]+" 전용 · ")+"우클릭: "+new String[]{"공격 주문","범위 주문","보조 주문"}[MagicSystem.spell(stack)]));
        lines.add(Component.literal("Shift+우클릭: 주문 변경 / R: 속성 궁극기 / G: 원소 집중"));
        lines.add(Component.literal("기본 8 MP / 범위 18 MP / 보조 25 MP / R 40 MP"));
    }
}
