package com.junwo.starrpg.tests;

import com.junwo.starrpg.*;
import net.minecraft.gametest.framework.*;
import net.minecraft.world.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.level.GameType;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.gametest.*;

@GameTestHolder(StarRPG.MODID)
@PrefixGameTestTemplate(false)
public class PresentationAndResetGameTests {
    private static Player player(GameTestHelper h,int job){var p=h.makeMockPlayer(GameType.SURVIVAL);var c=Careers.profile(p);c.selected=job;if(job>=0)c.ranks[job]=1;StarWallet.get(p.getServer()).credit(p.getUUID(),10000);return p;}
    private static ItemStack gear(Item item,int n){var w=new ItemStack(item);EnhancementData.setLevel(w,n);return w;}
    @GameTest(template="empty") public static void switchingResetsAllOldWeaponsButPreservesOtherItemsAndRunes(GameTestHelper h){
        var p=player(h,1);var a=gear(StarRPG.STAR_DAGGER.get(),25);a.setDamageValue(17);a.set(DataComponents.CUSTOM_NAME,Component.literal("My dagger"));RuneDataHelper.setRuneEffect(a,RuneEffect.SWORD_STAR_SLASH);EnhancementData.recordFailure(a);
        ItemStack off=gear(StarRPG.STAR_DAGGER.get(),20),pack=gear(StarRPG.STAR_DAGGER.get(),5),other=gear(StarRPG.MAGIC_STAFF.get(),25),sword=gear(Items.IRON_SWORD,10),armor=gear(Items.IRON_HELMET,10);
        p.setItemInHand(InteractionHand.MAIN_HAND,a);p.setItemInHand(InteractionHand.OFF_HAND,off);p.getInventory().setItem(10,pack);p.getInventory().setItem(11,other);p.getInventory().setItem(12,sword);p.setItemSlot(EquipmentSlot.HEAD,armor);
        h.assertTrue(Careers.select(p,3),"Switch failed");
        h.assertTrue(EnhancementData.level(a)==0&&EnhancementData.level(off)==0&&EnhancementData.level(pack)==0&&EnhancementData.failures(a)==0,"Old inventory/offhand enhancement survived");
        h.assertTrue(a.getDamageValue()==17&&a.getHoverName().getString().equals("My dagger")&&RuneDataHelper.getRuneEffect(a)==RuneEffect.SWORD_STAR_SLASH,"Reset damaged other item data");
        h.assertTrue(EnhancementData.level(other)==25&&EnhancementData.level(sword)==10&&EnhancementData.level(armor)==10,"Reset unrelated weapon/armor");
        h.assertTrue(StarWallet.get(p.getServer()).balance(p.getUUID())==9500,"Switch charged wrong amount");h.succeed();
    }
    @GameTest(template="empty") public static void rangerResetsBowAndCrossbowAndMageSchoolsResetSharedStaff(GameTestHelper h){
        var p=player(h,2);ItemStack bow=gear(Items.BOW,25),crossbow=gear(Items.CROSSBOW,15);p.setItemInHand(InteractionHand.MAIN_HAND,bow);p.setItemInHand(InteractionHand.OFF_HAND,crossbow);
        h.assertTrue(Careers.select(p,10)&&EnhancementData.level(bow)==0&&EnhancementData.level(crossbow)==0,"Ranger weapon reset incomplete");
        var staff=gear(StarRPG.MAGIC_STAFF.get(),25);p.setItemInHand(InteractionHand.MAIN_HAND,staff);Careers.profile(p).switchReady=0;
        h.assertTrue(Careers.select(p,14)&&EnhancementData.level(staff)==0,"Element-to-element switch preserved shared staff enhancement");h.succeed();
    }
    @GameTest(template="empty") public static void rejectedSwitchPreviewAndFirstSelectionNeverResetGear(GameTestHelper h){
        var p=player(h,1);var w=gear(StarRPG.STAR_DAGGER.get(),25);p.setItemInHand(InteractionHand.MAIN_HAND,w);var c=Careers.profile(p);var menu=new MaterialShopMenu(1,p.getInventory());
        for(int j=0;j<Careers.COUNT;j++)menu.previewRank(j);h.assertTrue(EnhancementData.level(w)==25&&c.selected==1,"Preview changed equipment");
        h.assertTrue(!Careers.select(p,1)&&!Careers.select(p,99)&&EnhancementData.level(w)==25,"Same/invalid job reset gear");
        c.switchReady=p.level().getGameTime()+600;h.assertTrue(!Careers.select(p,3)&&EnhancementData.level(w)==25,"Cooldown rejection reset gear");c.switchReady=0;
        StarWallet.get(p.getServer()).debit(p.getUUID(),10000);h.assertTrue(!Careers.select(p,3)&&EnhancementData.level(w)==25,"Insufficient funds reset gear");
        var first=player(h,-1);var firstWeapon=gear(StarRPG.STAR_DAGGER.get(),25);first.setItemInHand(InteractionHand.MAIN_HAND,firstWeapon);h.assertTrue(Careers.select(first,1)&&EnhancementData.level(firstWeapon)==25,"First selection reset gear");h.succeed();
    }
    @GameTest(template="empty") public static void promotionKeepsEnhancementAndSavedProfessionProgress(GameTestHelper h){
        var p=player(h,1);var w=gear(StarRPG.STAR_DAGGER.get(),25);p.setItemInHand(InteractionHand.MAIN_HAND,w);var c=Careers.profile(p);c.xp[1]=300;c.mastery[1]=12;p.getInventory().add(new ItemStack(Items.ENDER_PEARL,8));
        h.assertTrue(Careers.advance(p)&&c.rank()==2&&EnhancementData.level(w)==25,"Same-career promotion reset weapon");
        h.assertTrue(Careers.select(p,3)&&c.ranks[1]==2,"Career switch erased rank history");h.succeed();
    }
    @GameTest(template="empty") public static void menuCarriedAndSaleWeaponResetWithoutTouchingStoredChests(GameTestHelper h){
        var p=player(h,1);var menu=new MaterialShopMenu(1,p.getInventory());p.containerMenu=menu;ItemStack carried=gear(StarRPG.STAR_DAGGER.get(),15),sale=gear(StarRPG.STAR_DAGGER.get(),25),stored=gear(StarRPG.STAR_DAGGER.get(),20);
        menu.setCarried(carried);menu.getSlot(0).set(sale);p.getEnderChestInventory().setItem(0,stored);
        h.assertTrue(menu.clickMenuButton(p,203)&&EnhancementData.level(carried)==0&&EnhancementData.level(sale)==0,"Menu slots bypassed carried reset");
        h.assertTrue(EnhancementData.level(stored)==20,"Reset searched stored chest items outside selected scope");h.succeed();
    }
    @GameTest(template="empty") public static void paintedSpellAtlasAndDistinctWeaponGripProfilesExist(GameTestHelper h)throws Exception{
        try(var in=StarRPG.class.getClassLoader().getResourceAsStream("assets/starrpg/textures/effect/spell_effects.png")){
            var image=javax.imageio.ImageIO.read(in);h.assertTrue(image!=null&&image.getColorModel().hasAlpha()&&image.getWidth()==image.getHeight(),"Effect atlas missing RGBA");
            for(int cell=0;cell<16;cell++){int count=0;for(int y=0;y<50;y++)for(int x=0;x<50;x++){int px=(int)((cell%4+(x+0.5)/50)*image.getWidth()/4),py=(int)((cell/4+(y+0.5)/50)*image.getHeight()/4);if((image.getRGB(px,py)>>>24)>100)count++;}h.assertTrue(count>50,"Empty effect cell "+cell);}
        }
        h.assertTrue(WeaponPresentation.grip(2).scale()<WeaponPresentation.grip(5).scale()&&WeaponPresentation.grip(9).cropRight()==0.5F,"Weapon grips still uniform");
        for(int k=2;k<=10;k++){var g=WeaponPresentation.grip(k);h.assertTrue(g.y()>0.5&&g.depth()>0,"Missing grip anchor/thickness "+k);}
        h.succeed();
    }
    @GameTest(template="hook_arena",timeoutTicks=80) public static void allSeventeenVisualStylesStayBoundedAndExpire(GameTestHelper h){
        var pos=h.absoluteVec(new net.minecraft.world.phys.Vec3(3,2,3));
        for(int style=0;style<=16;style++)ArcaneSigil.spawn(h.getLevel(),pos,new net.minecraft.world.phys.Vec3(0,0,1),style,0xFFFFFF,2,12);
        var initial=h.getLevel().getEntitiesOfClass(ArcaneSigil.class,new net.minecraft.world.phys.AABB(pos,pos).inflate(3));
        h.assertTrue(initial.stream().map(ArcaneSigil::style).distinct().count()==17,"Style IDs truncated");
        for(int i=0;i<80;i++)ArcaneSigil.spawn(h.getLevel(),pos,new net.minecraft.world.phys.Vec3(0,0,1),3,0xFFFFFF,2,12);
        h.assertTrue(h.getLevel().getEntitiesOfClass(ArcaneSigil.class,new net.minecraft.world.phys.AABB(pos,pos).inflate(3)).size()<=48,"Effect density cap broken");
        h.runAfterDelay(16,()->{h.assertTrue(initial.stream().allMatch(Entity::isRemoved),"Effects did not expire");h.succeed();});
    }
}
