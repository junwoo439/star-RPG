package com.junwo.starrpg.tests;

import com.junwo.starrpg.*;
import net.minecraft.gametest.framework.*;
import net.minecraft.world.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.*;
import net.minecraft.world.level.GameType;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.nbt.*;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.*;

@GameTestHolder(StarRPG.MODID)
@PrefixGameTestTemplate(false)
public class CombatPresentationGameTests {
    private static Player player(GameTestHelper h,int job,Item item){var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(2.5,2,2.5)));p.setYRot(0);p.setXRot(0);var c=Careers.profile(p);c.selected=job;c.ranks[job]=1;p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(item));return p;}
    private static LivingEntity cow(GameTestHelper h,Vec3 at){var m=EntityType.COW.create(h.getLevel());m.setPos(at);m.setNoAi(true);m.setNoGravity(true);m.getAttribute(Attributes.MAX_HEALTH).setBaseValue(100);m.setHealth(100);h.getLevel().addFreshEntity(m);return m;}
    @GameTest(template="empty") public static void consolidatedSaveMigratesBestProgressOnceWithoutAddingRanks(GameTestHelper h){
        var c=new CareerData.Profile();c.selected=6;c.ranks[6]=30;c.ranks[15]=20;c.xp[6]=200;c.xp[15]=500;c.mastery[9]=80;c.ranks[9]=12;c.ranks[0]=14;c.ranks[3]=70;
        h.assertTrue(CareerConsolidation.migrate(c)&&c.selected==15&&c.rank()==30&&c.xp()==500&&c.ranks[0]==14&&c.mastery[0]==80&&c.ranks[10]==70,"Bad merged progress");
        h.assertTrue(!CareerConsolidation.migrate(c)&&c.ranks[6]==0&&c.ranks[9]==0&&c.ranks[3]==0,"Migration not idempotent");
        h.assertTrue(Careers.ACTIVE.length==13&&java.util.Arrays.stream(Careers.ACTIVE).distinct().count()==13&&java.util.Arrays.stream(Careers.ACTIVE).allMatch(Careers::active),"Duplicate/retired menu careers");h.succeed();
    }
    @GameTest(template="empty") public static void eachElementHasExclusiveStaffRecipeRunesAndInfiniteEnhancement(GameTestHelper h){
        for(int s=1;s<=6;s++){
            var item=CareerConsolidation.staff(s);var p=player(h,s+9,item);var id=BuiltInRegistries.ITEM.getKey(item);
            h.assertTrue(h.getLevel().getRecipeManager().byKey(id).isPresent()&&RuneWeaponType.forItem(p.getMainHandItem())==RuneWeaponType.STAFF&&EnhancementData.unlimited(p.getMainHandItem()),"Incomplete elemental item "+s);
            h.assertTrue(Careers.qualified(p,p.getMainHandItem())&&MagicSystem.cast(p),"Own staff rejected "+s);
            p.getPersistentData().putLong("starrpg_spell_ready",0);float mana=MagicSystem.mana(p);p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(CareerConsolidation.staff(s%6+1)));
            h.assertTrue(!Careers.qualified(p,p.getMainHandItem())&&!MagicSystem.cast(p)&&MagicSystem.mana(p)==mana,"Foreign element cast or lost mana");
            h.getLevel().getEntitiesOfClass(MagicBolt.class,p.getBoundingBox().inflate(5),b->b.getOwner()==p).forEach(Entity::discard);
        }h.succeed();
    }
    @GameTest(template="empty") public static void legacyItemConversionPreservesAllComponentsAndDoesNotDuplicate(GameTestHelper h){
        var p=player(h,12,StarRPG.MAGIC_STAFF.get());var old=p.getMainHandItem();EnhancementData.setLevel(old,25);old.setDamageValue(31);old.set(DataComponents.CUSTOM_NAME,Component.literal("Old rune staff"));
        var before=old.getComponentsPatch();CareerConsolidation.inventory(p);var converted=p.getMainHandItem();
        h.assertTrue(converted.is(StarRPG.ICE_STAFF.get())&&converted.getComponentsPatch().equals(before)&&p.getInventory().countItem(StarRPG.MAGIC_STAFF.get())==0,"Item data loss/duplication");
        CareerConsolidation.inventory(p);h.assertTrue(p.getMainHandItem()==converted&&p.getInventory().countItem(StarRPG.ICE_STAFF.get())==1,"Conversion repeated");
        var scepter=new ItemStack(StarRPG.SUN_SCEPTER.get());EnhancementData.setLevel(scepter,25);h.assertTrue(EnhancementData.level(CareerConsolidation.convert(scepter,15))==25,"Priest enhancement lost");h.succeed();
    }
    @GameTest(template="empty") public static void switchingElementOnlyResetsThePreviousElement(GameTestHelper h){
        var p=player(h,10,StarRPG.FIRE_STAFF.get());var old=p.getMainHandItem();EnhancementData.setLevel(old,25);var ice=new ItemStack(StarRPG.ICE_STAFF.get());EnhancementData.setLevel(ice,20);p.setItemInHand(InteractionHand.OFF_HAND,ice);
        StarWallet.get(p.getServer()).credit(p.getUUID(),1000);CareerTechniques.activate(p,10);
        h.assertTrue(Careers.select(p,12)&&EnhancementData.level(old)==0&&EnhancementData.level(ice)==20&&!CareerTechniques.empowered(p),"Wrong element reset or old G carried over");h.succeed();
    }
    @GameTest(template="hook_arena") public static void spearPromotionPiercesBehindTargetButNotAlliesOrSideTargets(GameTestHelper h){
        var p=player(h,0,StarRPG.STAR_SPEAR.get());LivingEntity first=cow(h,p.position().add(0,0,2)),behind=cow(h,p.position().add(0,0,3.5)),side=cow(h,p.position().add(2,0,2));
        var pet=EntityType.WOLF.create(h.getLevel());pet.setTame(true,true);pet.setPos(p.position().add(0,0,3));h.getLevel().addFreshEntity(pet);float hp=pet.getHealth();
        CareerTechniques.proc(p,first,10);h.assertTrue(behind.getHealth()==100,"Promotion proc before unlocking");Careers.profile(p).ranks[0]=6;CareerTechniques.proc(p,first,10);
        h.assertTrue(behind.getHealth()<100&&side.getHealth()==100&&pet.getHealth()==hp,"Pierce geometry or pet protection wrong");float after=behind.getHealth();behind.invulnerableTime=0;CareerTechniques.proc(p,first,10);h.assertTrue(behind.getHealth()==after,"Promotion proc ignored cooldown");h.succeed();
    }
    @GameTest(template="hook_arena") public static void gHasThreeRealHitsAndCannotRecurseOnSecondaryDamage(GameTestHelper h){
        var p=player(h,8,StarRPG.STAR_GAUNTLET.get());var target=cow(h,p.position().add(0,0,2));CareerTechniques.activate(p,8);
        for(int i=0;i<3;i++){p.getPersistentData().putLong("starrpg_technique_ready",0);target.invulnerableTime=0;float before=target.getHealth();CareerTechniques.proc(p,target,10);h.assertTrue(target.getHealth()<before,"G only cosmetic");}
        h.assertTrue(!CareerTechniques.empowered(p)&&p.getPersistentData().getInt("starrpg_technique_charges")==0,"Wrong empowered charge count");
        p.getPersistentData().putLong("starrpg_technique_ready",0);float before=target.getHealth();CareerTechniques.proc(p,target,10);h.assertTrue(target.getHealth()==before,"Fourth free empowered hit");h.succeed();
    }
    @GameTest(template="hook_arena") public static void alternatingVisualPunchesNeverCreateAnOffhandItem(GameTestHelper h){
        var p=player(h,8,StarRPG.STAR_GAUNTLET.get());WeaponMotion.swing(p);int first=p.getPersistentData().getInt("starrpg_motion_side");
        WeaponMotion.swing(p);h.assertTrue(p.getPersistentData().getInt("starrpg_motion_side")==first,"Swing rate limit missing");
        p.getPersistentData().putLong("starrpg_motion_ready",0);WeaponMotion.swing(p);
        h.assertTrue(p.getPersistentData().getInt("starrpg_motion_side")!=first&&p.getOffhandItem().isEmpty()&&p.getInventory().countItem(StarRPG.STAR_GAUNTLET.get())==1,"Not alternating or duplicated glove");h.succeed();
    }
    @GameTest(template="empty") public static void effectVisibilityUsesCameraDistanceAtHighAndDistantWorldCoordinates(GameTestHelper h){
        var effect=new ArcaneSigil(ModEntities.ARCANE_SIGIL.get(),h.getLevel());effect.setPos(120000,181,-80000);
        h.assertTrue(effect.withinView(120000,182,-80007)&&!effect.withinView(120000,182,-80100),"World coordinates wrongly hide nearby effects");h.succeed();
    }
    @GameTest(template="hook_arena",timeoutTicks=35) public static void martialUltimateHasThreeTimedAlternatingHits(GameTestHelper h){
        var p=player(h,8,StarRPG.STAR_GAUNTLET.get());var target=cow(h,p.position().add(0,0,2));
        h.assertTrue(WeaponAbilities.activate(p)&&target.getHealth()<100,"First martial strike missing");float first=target.getHealth();int hand=p.getPersistentData().getInt("starrpg_motion_side");
        h.runAfterDelay(7,()->{MartialCombo.tick(new net.neoforged.neoforge.event.tick.PlayerTickEvent.Post(p));h.assertTrue(target.getHealth()<first&&p.getPersistentData().getInt("starrpg_motion_side")!=hand,"Second strike did not alternate");float second=target.getHealth();
            h.runAfterDelay(7,()->{MartialCombo.tick(new net.neoforged.neoforge.event.tick.PlayerTickEvent.Post(p));h.assertTrue(target.getHealth()<second&&p.getPersistentData().getInt("starrpg_motion_side")==hand,"Third strike missing");float third=target.getHealth();
                h.runAfterDelay(7,()->{MartialCombo.tick(new net.neoforged.neoforge.event.tick.PlayerTickEvent.Post(p));h.assertTrue(target.getHealth()==third,"Extra fourth martial strike");h.succeed();});});});
    }
    @GameTest(template="hook_arena",timeoutTicks=25) public static void unequippingGauntletsCancelsPendingMartialHits(GameTestHelper h){
        var p=player(h,8,StarRPG.STAR_GAUNTLET.get());var target=cow(h,p.position().add(0,0,2));WeaponAbilities.activate(p);float after=target.getHealth();p.setItemInHand(InteractionHand.MAIN_HAND,ItemStack.EMPTY);
        h.runAfterDelay(7,()->{MartialCombo.tick(new net.neoforged.neoforge.event.tick.PlayerTickEvent.Post(p));h.assertTrue(target.getHealth()==after,"Unarmed queued hit completed");h.succeed();});
    }
    @GameTest(template="empty") public static void sixStaffPaintingsHaveOpaqueDistinctSilhouettes(GameTestHelper h)throws Exception{
        try(var in=StarRPG.class.getClassLoader().getResourceAsStream("assets/starrpg/textures/art/elemental_staffs.png")){
            var image=javax.imageio.ImageIO.read(in);h.assertTrue(image!=null&&image.getColorModel().hasAlpha(),"Staff texture absent");
            var hashes=new java.util.HashSet<Integer>();for(int cell=0;cell<6;cell++){int solid=0,hash=1;for(int y=0;y<50;y++)for(int x=0;x<50;x++){int rgb=image.getRGB((int)((cell%3+(x+.5)/50)*image.getWidth()/3),(int)((cell/3+(y+.5)/50)*image.getHeight()/2));if((rgb>>>24)>96)solid++;hash=hash*31+rgb;}h.assertTrue(solid>80,"Transparent staff "+cell);hashes.add(hash);}h.assertTrue(hashes.size()==6,"Staff images identical");
        }h.succeed();
    }
}
