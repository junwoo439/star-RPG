package com.junwo.starrpg.bestiary;

import com.junwo.starrpg.*;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.LightLayer;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.phys.AABB;

public final class BestiarySpawns {
    public static boolean stage(BestiaryKind k,ServerLevel l){return WorldDifficulty.get(l.getServer()).tier()>=k.minTier;}
    public static boolean bossNearby(ServerLevel l,BlockPos p){return !l.getEntitiesOfClass(BestiaryMob.class,new AABB(p).inflate(128),m->m.isAlive()&&m.kind.boss).isEmpty();}
    public static boolean allowed(BestiaryKind k,ServerLevelAccessor a,MobSpawnType reason,BlockPos p,RandomSource r){
        if(a.getDifficulty()==Difficulty.PEACEFUL)return false;
        if(reason!=MobSpawnType.NATURAL&&reason!=MobSpawnType.CHUNK_GENERATION)return true;
        var l=a.getLevel();
        if(!Config.BESTIARY_SPAWNS.get()||!stage(k,l))return false;
        if(k.boss&&(!Config.BESTIARY_BOSSES.get()||r.nextInt(Config.BOSS_SPAWN_RARITY.get())!=0||bossNearby(l,p)))return false;
        if(k.aquatic())return a.getFluidState(p).is(FluidTags.WATER)&&a.getFluidState(p.above()).is(FluidTags.WATER);
        if(!a.getBlockState(p.below()).isSolidRender(a,p.below())||!a.getFluidState(p).isEmpty())return false;
        // Wildlife and neutral guardians can inhabit daylight; undead/raiders prefer darkness.
        return k.boss||k.neutral||k.family==BestiaryKind.Family.BEAST||k.habitat==BestiaryKind.Habitat.NETHER||a.getBrightness(LightLayer.SKY,p)<8||!l.isDay();
    }
}
