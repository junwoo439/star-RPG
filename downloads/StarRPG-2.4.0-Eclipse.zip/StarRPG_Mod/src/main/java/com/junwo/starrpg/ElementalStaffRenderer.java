package com.junwo.starrpg;

import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/** UV windows preserve the original six-staff painting without resampling or atlas pollution. */
public final class ElementalStaffRenderer {
    public static final ResourceLocation ATLAS=ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,"textures/art/elemental_staffs.png");
    public static void draw(PoseStack p,MultiBufferSource b,int school,boolean held,int light){
        int cell=Math.clamp(school,1,6)-1;float center=new float[]{344,767,1197}[cell%3];
        float u=(center-128)/1536,v=(cell/3==0?0:505)/1024F,du=256/1536F,dv=(cell/3==0?500:510)/1024F;
        float height=held?1.0F:.65F,width=height*.5F;
        p.pushPose();if(held)p.translate(0,.55,0);
        var out=b.getBuffer(RenderType.entityTranslucent(ATLAS));float[][] a={{-width,-height,u,v+dv},{width,-height,u+du,v+dv},{width,height,u+du,v},{-width,height,u,v}};
        for(int side=0;side<2;side++)for(int i=0;i<4;i++){var t=a[side==0?i:3-i];out.addVertex(p.last(),t[0],t[1],side==0?.025F:-.025F).setColor(255,255,255,255).setUv(t[2],t[3]).setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(p.last(),0,0,side==0?1:-1);}
        if(held)WeaponModels.box(p,b,-.022F,-.84F,-.025F,.044F,1.05F,.05F,0x6E6B78,light);
        p.popPose();
    }
}
