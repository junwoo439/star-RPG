package com.junwo.starrpg.bestiary;

import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.model.EntityModel;
import java.util.*;
import static com.junwo.starrpg.bestiary.CreatureMesh.*;

/** Detailed original voxel anatomy, material atlas, jointed jaws/wings/limbs and species silhouettes. */
public final class BestiaryModel extends EntityModel<BestiaryMob> {
    private final BestiaryKind kind;private final Node root=new Node("root",0,0,0,0,0,0);
    private final Map<String,Node> bones=new LinkedHashMap<>();
    private static final int IVORY=0xF4D9A4,IRON=0xB6BAC9,DARK=0x28252C;
    public BestiaryModel(BestiaryKind k){kind=k;switch(k.body){
        case DRAGON,WYVERN,HYDRA->dragon();case BEAR,WOLF,BOAR,LIZARD->beast();case ANT,SPIDER,INSECT->insect();case SHARK->shark();case ELEMENTAL->elemental();default->humanoid();
    }root.collect(bones);}
    private int skin(){return kind.color;}private int dark(){return mix(skin(),0x242332,.5F);}private int light(){return mix(skin(),0xF9E8C3,.35F);}
    private void box(Node n,float x,float y,float z,float w,float h,float d,int mat,int color){n.box(x,y,z,w,h,d,mat,color);}
    private void eye(Node parent,String name,float x,float y,float z,int color,boolean side){
        var n=parent.node(name,x,y,z);n.box(-1.2F,-1.2F,-.3F,2.4F,2.4F,.6F,LEATHER,0x16131A);
        n.box(-.85F,-.8F,-.6F,1.7F,1.6F,.4F,HORN,color,true);n.box(-.2F,-.7F,-.85F,.4F,1.4F,.3F,LEATHER,0x171119);if(side)n.yRot=r(x<0?-65:65);
    }
    private void horn(Node parent,String name,float x,float y,float z,float side){
        var n=parent.node(name,x,y,z,r(-32),0,r(side*15));n.box(-1.3F,-5,-1.3F,2.6F,5,2.6F,HORN,mix(IVORY,DARK,.15F));
        var tip=n.node(name+"Tip",0,-4,0,r(-30),0,r(side*12));tip.box(-.7F,-5,-.7F,1.4F,5,1.4F,HORN,IVORY);
    }
    private void claws(Node foot,float z,int count){for(int i=0;i<count;i++)foot.node("claw"+i,(i-(count-1)/2F)*1.6F,1,z,r(20),0,0).box(-.45F,-.5F,-3,.9F,1,3.2F,HORN,IVORY);}
    private Node dragonHead(String name,float x,float y,float z,float angle){
        var neck=root.node(name+"Neck",x,y+4,z+8,r(-22),angle,0);neck.box(-4,-5,-8,8,10,14,SCALES,skin());neck.box(-3,3,-9,6,1,14,BELLY,light());
        var h=root.node(name,x,y,z,0,angle,0);h.box(-5,-7,-5,10,8,11,SCALES,skin());h.box(-4,-4,-12,8,4,9,SCALES,skin());h.box(-3.8F,-.4F,-11.8F,7.6F,.6F,12,LEATHER,0x762331);
        for(int side:new int[]{-1,1}){
            h.node(name+"Brow"+side,side*4,-5.5F,-4,0,0,r(side*12)).box(-2,-1,-3,4,2,6,SCALES,dark());
            eye(h,name+"Eye"+side,side*4.3F,-3.5F,-5.5F,kind.move==BestiaryKind.Move.FROST?0x8AF9FF:0xF4E73A,true);
            horn(h,name+"Horn"+side,side*4,-6,4,side);h.node(name+"Cheek"+side,side*4,0,4,r(-30),0,r(side*50)).box(-1,-4,-1,2,4,2,HORN,IVORY);
            h.box(side*2-0.6F,-4.2F,-11.9F,1.2F,1,1,LEATHER,DARK);
            for(int t=0;t<5;t++)h.box(side*3.1F-.45F,-.5F,-10+t*2,.9F,2,.9F,HORN,IVORY);
        }
        var jaw=h.node(name+"Jaw",0,.6F,1,r(12),0,0);jaw.box(-3.8F,0,-12,7.6F,2,14,SCALES,dark());jaw.box(-3.2F,-.1F,-11.4F,6.4F,.3F,11,LEATHER,0xAB3440);
        for(int side:new int[]{-1,1})for(int t=0;t<4;t++)jaw.box(side*3-.4F,-1.8F,-10+t*2.7F,.8F,2,.8F,HORN,IVORY);
        jaw.box(-1,-.25F,-8,2,.4F,7,LEATHER,0xE15B69);return h;
    }
    private void dragon(){
        root.node("body",0,11,0).box(-7,-6,-10,14,13,24,SCALES,skin()).box(-5.8F,6,-9,11.6F,.8F,24,BELLY,mix(light(),0xE4BB70,.35F));
        root.node("haunch",0,14,12).box(-6,-5,-4,12,10,13,SCALES,skin());
        dragonHead("head",0,4,-21,0);
        if(kind.body==BestiaryKind.Body.HYDRA){dragonHead("head2",-10,5,-14,r(-18));dragonHead("head3",10,5,-14,r(18));}
        else {wing(root,"wingL",-1,kind.body==BestiaryKind.Body.WYVERN?1.1F:1,false);wing(root,"wingR",1,kind.body==BestiaryKind.Body.WYVERN?1.1F:1,false);}
        for(int i=0;i<4;i++){
            if(kind.body==BestiaryKind.Body.WYVERN&&i<2)continue;float side=i%2==0?-1:1;
            var leg=root.node("leg"+i,side*6,13,i<2?-7:12,r(i<2?-12:18),0,r(side*-8));leg.box(-2.5F,-1,-3,5,7,6,SCALES,dark());
            var foot=leg.node("foot"+i,0,7,-1,r(i<2?12:-18),0,0);foot.box(-2.4F,0,-5,4.8F,4,8,SCALES,skin());claws(foot,-4,3);
        }
        var tail=root.node("tail",0,14,21,r(-6),0,0);tail.box(-3,-3,0,6,6,10,SCALES,skin());
        var t2=tail.node("tail2",0,0,9,r(-8),r(10),0);t2.box(-2.2F,-2,0,4.4F,4,11,SCALES,skin());
        var t3=t2.node("tail3",0,0,10,r(-10),r(14),0);t3.box(-1.3F,-1.3F,0,2.6F,2.6F,12,SCALES,dark());
        t3.triangle(new float[]{0,-1,5},new float[]{-4,0,11},new float[]{0,0,16},MEMBRANE,skin());t3.triangle(new float[]{0,-1,5},new float[]{4,0,11},new float[]{0,0,16},MEMBRANE,skin());
        for(int i=0;i<8;i++){var n=root.node("spine"+i,0,5,i*4-11);n.triangle(new float[]{-1,0,0},new float[]{0,-5,2},new float[]{1,0,4},HORN,dark());}
    }
    private void wing(Node parent,String name,int side,float scale,boolean feathers){
        var w=parent.node(name,side*6,6,-4,r(-8),r(side*-8),r(side*8));
        float[][] points={{0,0,0},{side*13*scale,-5,2},{side*31*scale,-10,8},{side*25*scale,3,18},{side*15*scale,6,23},{side*6*scale,9,20},{0,5,10}};
        int color=mix(skin(),0xFFB86B,.35F);
        if(feathers){for(int i=0;i<8;i++){var feather=w.node(name+"Feather"+i,side*(4+i*2.7F),0,2+i,0,r(side*-20),r(side*-25));feather.box(-1.4F,-1,-1,2.8F,1,17-i*.9F,FEATHER,kind.family==BestiaryKind.Family.CELESTIAL?0xFFF4D6:light());}}
        else {for(int i=2;i<6;i++)w.triangle(points[0],points[i],points[i+1],MEMBRANE,color);w.triangle(points[0],points[1],points[2],MEMBRANE,color);}
        beam(w,name+"Arm",points[0],points[1],2.2F,SCALES,dark());beam(w,name+"Forearm",points[1],points[2],1.7F,SCALES,dark());
        for(int i=3;i<6;i++)beam(w,name+"Finger"+i,points[1],points[i],1.1F,SCALES,dark());
        horn(w,name+"Thumb",side*13*scale,-5,2,side);
    }
    private void beast(){
        boolean bear=kind.body==BestiaryKind.Body.BEAR,boar=kind.body==BestiaryKind.Body.BOAR,lizard=kind.body==BestiaryKind.Body.LIZARD;
        int mat=lizard?SCALES:bear?SHAG:FUR;float bulk=bear?14:boar?12:8;
        root.node("body",0,13,0).box(-bulk/2,-5,-10,bulk,11,22,mat,skin()).box(-bulk*.35F,4,-7,bulk*.7F,2,16,mat,light());
        if(bear||boar)root.node("shoulder",0,11,-5).box(-bulk/2-1,-5,-5,bulk+2,10,10,mat,dark());
        var h=root.node("head",0,12,-12);h.box(-4,-5,-4,8,8,8,mat,skin());h.box(-3,-1,-9,6,4,6,mat,light());h.box(-2.5F,-.8F,-9.5F,5,2,1,LEATHER,DARK);
        for(int side:new int[]{-1,1}){eye(h,"eye"+side,side*2.5F,-2.5F,-4.4F,0xE9CF65,false);h.node("ear"+side,side*3,-5,0,0,0,r(side*20)).box(-1,-3,-1,2,3,2,mat,dark());}
        var jaw=h.node("headJaw",0,3,-3,r(5),0,0);jaw.box(-2.6F,0,-5,5.2F,1.4F,7,mat,dark());
        if(boar)for(int side:new int[]{-1,1})horn(h,"tusk"+side,side*3.5F,3,-7,-side);
        else for(int side:new int[]{-1,1})jaw.box(side*2-.4F,-1.8F,-3,.8F,2,1,HORN,IVORY);
        for(int i=0;i<4;i++){float side=i%2==0?-1:1;var leg=root.node("leg"+i,side*(bulk/2-1),17,i<2?-7:8);leg.box(-1.7F,0,-2,3.4F,6,4,mat,dark());var foot=leg.node("foot"+i,0,5,-1);foot.box(-2,0,-2,4,2,5,mat,skin());if(!boar)claws(foot,-2,3);}
        var tail=root.node("tail",0,14,11,r(-20),r(8),0);tail.box(-1.5F,-1.5F,0,3,3,bear?3:boar?5:12,mat,dark());
        if(lizard){for(int i=0;i<7;i++){var n=root.node("crest"+i,0,7,i*3-7);n.triangle(new float[]{0,0,0},new float[]{0,-4,2},new float[]{0,0,4},MEMBRANE,0xD1D566);}}
    }
    private void insect(){
        boolean spider=kind.body==BestiaryKind.Body.SPIDER;int count=spider?8:6;
        root.node("body",0,15,6).box(-5,-4,-4,10,8,13,CHITIN,skin());root.node("thorax",0,16,-3).box(-3,-3,-3,6,6,6,CHITIN,dark());
        var h=root.node("head",0,16,-8);h.box(-3.7F,-3,-4,7.4F,6,7,CHITIN,skin());
        for(int i=0;i<(spider?8:2);i++)eye(h,"eye"+i,(i%4-1.5F)*1.8F,-1.5F+(i/4)*2,-4.4F,spider?0xFF5342:0xE9D36A,false);
        for(int side:new int[]{-1,1}){h.node("fang"+side,side*2,2,-4,r(-15),r(side*18),0).box(-.7F,0,-3,1.4F,4,3,HORN,IVORY);
            beam(h,"antenna"+side,new float[]{side*2,-3,0},new float[]{side*5,-7,-6},.7F,CHITIN,dark());}
        for(int i=0;i<count;i++){int side=i%2==0?-1:1;var leg=root.node("leg"+i,side*3,16,(i/2)*4-6);beam(leg,"upper"+i,new float[]{0,0,0},new float[]{side*7,-3,-2},1.4F,CHITIN,dark());beam(leg,"lower"+i,new float[]{side*7,-3,-2},new float[]{side*10,8,-4},1,CHITIN,skin());}
        if(kind.body==BestiaryKind.Body.INSECT){wing(root,"wingL",-1,.65F,false);wing(root,"wingR",1,.65F,false);}
    }
    private void shark(){
        root.node("body",0,15,0).box(-5,-4,-9,10,8,18,HIDE,skin()).box(-4,3,-8,8,1,17,HIDE,0xE2E8DA);
        var h=root.node("head",0,15,-9);h.box(-4,-3,-7,8,6,8,HIDE,skin());h.box(-3,-2,-10,6,4,4,HIDE,skin());
        var jaw=h.node("headJaw",0,2,-2,r(8),0,0);jaw.box(-3.2F,0,-7,6.4F,1,8,HIDE,0xDDDFCA);for(int i=0;i<5;i++)jaw.box(i-2,-1.4F,-6,.6F,1.5F,.6F,BONE,IVORY);
        for(int side:new int[]{-1,1})eye(h,"eye"+side,side*3.5F,-1,-5.5F,0xBBCDC7,true);
        var fin=root.node("dorsal",0,11,-2);fin.triangle(new float[]{0,0,-3},new float[]{0,-10,1},new float[]{0,0,9},HIDE,dark());
        for(int side:new int[]{-1,1}){var w=root.node(side<0?"wingL":"wingR",side*4,17,-3);w.triangle(new float[]{0,0,0},new float[]{side*12,2,5},new float[]{0,1,8},HIDE,skin());}
        var tail=root.node("tail",0,15,9);tail.box(-2.5F,-2.5F,0,5,5,8,HIDE,skin());var t=tail.node("tail2",0,0,7);t.box(-1,-1,0,2,2,7,HIDE,skin());t.triangle(new float[]{0,0,3},new float[]{0,-10,10},new float[]{0,0,8},HIDE,dark());t.triangle(new float[]{0,0,3},new float[]{0,7,10},new float[]{0,0,8},HIDE,dark());
        for(int i=0;i<3;i++)root.node("gill"+i,0,14,-7+i*1.4F).box(-5.05F,-2,0,10.1F,4,.3F,HIDE,dark());
    }
    private void elemental(){
        root.node("body",0,9,0).box(-4,-5,-3,8,10,6,STONE,skin());var h=root.node("head",0,1,0,r(15),r(45),0);h.box(-3,-3,-3,6,6,6,STONE,light());
        root.node("core",0,8,-3.4F,r(15),0,r(45)).box(-1.8F,-1.8F,-1,3.6F,3.6F,2,HORN,light(),true);
        for(int i=0;i<6;i++){var n=root.node("orbit"+i,0,17,0,0,r(i*60),0);n.node("shard"+i,5,-i*.6F,0,r(i*15),0,r(45)).box(-1.5F,-2,-1.5F,3,4,3,STONE,skin());}
        for(int side:new int[]{-1,1})root.node(side<0?"armL":"armR",side*7,5,0,r(-15),0,r(side*-15)).box(-2,0,-2,4,10,4,STONE,skin());
    }
    private void humanoid(){
        boolean giant=kind.body==BestiaryKind.Body.GIANT||kind.body==BestiaryKind.Body.TWIN,golem=kind.body==BestiaryKind.Body.GOLEM;
        boolean robe=kind.body==BestiaryKind.Body.ROBED||kind.body==BestiaryKind.Body.GHOST,bones=kind.body==BestiaryKind.Body.SKELETON;
        int mat=kind.body==BestiaryKind.Body.ARMORED?METAL:golem||kind.family==BestiaryKind.Family.CONSTRUCT?STONE:kind.family==BestiaryKind.Family.FIEND?SCALES:HIDE;
        float width=giant||golem?14:9,arm=giant||golem?6:3.5F;
        var torso=root.node("body",0,0,0,r(giant?8:0),0,0);
        if(bones){torso.box(-1,0,-1,2,12,2,BONE,IVORY);for(int i=0;i<4;i++)torso.box(-4,i*2.5F,-2,8,1,4,BONE,IVORY);}
        else torso.box(-width/2,0,-3.5F,width,12,7,robe?CLOTH:mat,robe?dark():skin());
        if(!bones&&!robe){torso.box(-width/2-.3F,1,-4,width+.6F,6,1,METAL,golem?light():0x6B7584);torso.box(-width/2-.2F,10,-3.8F,width+.4F,2,7.6F,LEATHER,0x5B3826);torso.box(-1,10,-4.3F,2,2,1,METAL,0xD9B662);}
        if(robe){torso.box(-5,8,-4,10,14,8,CLOTH,dark());for(int i=0;i<3;i++)torso.box(-4+i*3.2F,9,-4.2F,1,12,.4F,METAL,light());}
        if(kind.body==BestiaryKind.Body.TWIN){humanoidHead("head",-5,-1,0,mat);humanoidHead("head2",5,-1,0,mat);}else humanoidHead("head",0,0,0,mat);
        for(int side:new int[]{-1,1}){
            var a=root.node(side<0?"armL":"armR",side*(width/2+arm/2),2,0,r(-7),0,r(side*-7));a.box(-arm/2,-1,-arm/2,arm,8,arm,bones?BONE:robe?CLOTH:mat,bones?IVORY:robe?dark():skin());
            a.node("forearm"+side,0,6,0,r(-12),0,0).box(-arm/2,0,-arm/2,arm,6,arm,bones?BONE:METAL,bones?IVORY:0x73818E);
            a.box(-arm/2,11,-arm/2,arm,3,arm,bones?BONE:mat,bones?IVORY:skin());
            if(!robe&&!bones)a.node("pauldron"+side,0,-1,0,0,0,r(side*12)).box(-arm/2-1,-2,-arm/2-1,arm+2,4,arm+2,METAL,golem?light():0x7A7F8C);
            if(kind.body!=BestiaryKind.Body.GHOST){var leg=root.node("leg"+(side<0?0:1),side*width*.25F,12,0);leg.box(-2,0,-2,4,10,4,bones?BONE:MAIL,bones?IVORY:dark());leg.box(-2.2F,8,-3.5F,4.4F,4,6,bones?BONE:METAL,bones?IVORY:0x626B7B);}
        }
        if(kind.body==BestiaryKind.Body.WINGED||kind.body==BestiaryKind.Body.BIRD){wing(root,"wingL",-1,.65F,kind.family==BestiaryKind.Family.CELESTIAL||kind.body==BestiaryKind.Body.BIRD);wing(root,"wingR",1,.65F,kind.family==BestiaryKind.Family.CELESTIAL||kind.body==BestiaryKind.Body.BIRD);}
        if(golem){root.node("core",0,5,-4.4F,0,0,r(45)).box(-2,-2,-.5F,4,4,1,HORN,0x62EDDF,true);for(int i=0;i<4;i++)root.node("rune"+i,0,4+i*2.3F,-4.6F,0,0,r(45)).box(-.4F,-.4F,-.2F,.8F,.8F,.4F,HORN,0x7EFFE0,true);}
        else if(kind.body!=BestiaryKind.Body.GHOST&&kind.body!=BestiaryKind.Body.BIRD)weapon(robe);
    }
    private void humanoidHead(String name,float x,float y,float z,int mat){
        boolean skull=kind.body==BestiaryKind.Body.SKELETON||kind.body==BestiaryKind.Body.ROBED;
        var h=root.node(name,x,y,z);h.box(-3.6F,-7,-3.6F,7.2F,7,7.2F,skull?BONE:mat,skull?IVORY:skin());
        if(kind.body==BestiaryKind.Body.ROBED||kind.body==BestiaryKind.Body.GHOST){h.box(-4.7F,-8.5F,-4.3F,9.4F,2,9,CLOTH,dark());for(int side:new int[]{-1,1})h.box(side<0?-4.7F:3.7F,-7,-4.4F,1,9,9,CLOTH,dark());h.box(-4,-7,3,8,9,1.5F,CLOTH,dark());}
        for(int side:new int[]{-1,1}){eye(h,name+"Eye"+side,side*1.9F,-4,-3.9F,kind.family==BestiaryKind.Family.UNDEAD?0x68FFEC:0xE8DD74,false);
            if(kind.family==BestiaryKind.Family.FIEND)horn(h,name+"Horn"+side,side*3,-7,0,side);
            if(kind==BestiaryKind.ORC||kind.body==BestiaryKind.Body.GIANT)h.node("tusk"+side,side*2.3F,0,-4,r(10),0,0).box(-.5F,-2.8F,-.5F,1,3,1,HORN,IVORY);
            if(kind.body==BestiaryKind.Body.SMALL)h.node("ear"+side,side*3.5F,-3,0,0,0,r(side*-25)).box(side<0?-4:0,-1,-1,4,2,2,HIDE,skin());}
        if(skull){h.box(-.6F,-2.5F,-3.9F,1.2F,1.5F,.7F,LEATHER,DARK);for(int i=0;i<5;i++)h.box(-2.5F+i,-1,-3.8F,.65F,1.5F,.5F,BONE,IVORY);}
        else h.box(-1,-2.8F,-5,2,3,2,HIDE,dark());
        if(kind.body==BestiaryKind.Body.BIRD){h.box(-2,-3,-8,4,3,5,HORN,0xD7AE4D);h.node("crest",0,-7,0,r(20),0,0).box(-1,-4,-2,2,4,5,FEATHER,0xB63A38);}
        if(kind.boss){h.box(-4,-7,-4,8,1.3F,8,METAL,0xDDB968);for(int side:new int[]{-1,1})h.node("crown"+side,side*3,-7,-3,0,0,r(side*12)).box(-.6F,-3,-.6F,1.2F,3,1.2F,METAL,0xE8C274);}
    }
    private void weapon(boolean staff){
        // The weapon is attached to the hand, so winding up moves the entire grip consistently.
        var arm=root.children.stream().filter(n->n.name.equals("armL")).findFirst().orElseThrow();var w=arm.node("weapon",0,staff?10:12,-1,r(staff?0:85),0,0);
        w.box(-.7F,-12,-.7F,1.4F,24,1.4F,WOOD,0x855D3B);
        if(staff){w.node("crystal",0,-14,0,r(20),r(45),r(45)).box(-2,-2,-2,4,4,4,HORN,light(),true);w.box(-3,-12,-1.2F,6,1.5F,2.4F,METAL,0xD3B579);}
        else if(kind.body==BestiaryKind.Body.GIANT){w.box(-3.5F,-13,-3.5F,7,10,7,WOOD,0x8F6747);for(int i=0;i<3;i++)w.box(-3.8F,-12+i*3.2F,-3.8F,7.6F,1.2F,7.6F,METAL,IRON);}
        else {w.box(-2,-15,-.8F,4,14,1.6F,METAL,IRON);w.box(-4,-1,-1,8,1.5F,2,METAL,0xC5A65B);}
    }
    @Override public void setupAnim(BestiaryMob m,float swing,float amount,float age,float yaw,float pitch){
        root.reset();float progress=m.progress(age-m.tickCount);boolean prep=m.phase()==BestiaryMob.HEAVY||m.phase()==BestiaryMob.QUICK;
        float lift=prep?progress:m.phase()==BestiaryMob.ACTIVE?-0.7F:m.phase()==BestiaryMob.RECOVERY?-.15F:0;
        for(var e:bones.entrySet()){
            String n=e.getKey();var b=e.getValue();
            if(n.matches("leg[0-7]"))b.xRot+=(float)Math.cos(swing*.65+(n.charAt(3)%2)*Math.PI)*amount*.6F;
            if(n.equals("head")||n.equals("head2")||n.equals("head3")){b.yRot+=r(Math.clamp(yaw,-25,25));b.xRot+=r(pitch)*.3F-(prep?progress*.3F:0);if(m.phase()==BestiaryMob.ACTIVE)b.dz=-3;}
            if(n.endsWith("Jaw"))b.xRot+=(prep?progress*.65F:(float)Math.sin(age*.05)*.04F);
            if(n.equals("armL")||n.equals("armR"))b.xRot-=lift*2.3F;
            if(n.equals("wingL")||n.equals("wingR"))b.zRot+=(n.endsWith("L")?1:-1)*((float)Math.sin(age*.09)*.07F+(prep?progress*.4F:0));
            if(n.startsWith("tail"))b.yRot+=(float)Math.sin(age*.075+n.length())*.12F;
            if(n.startsWith("orbit"))b.yRot+=age*.025F;
        }
        if(prep&&kind.body==BestiaryKind.Body.BEAR)for(String n:new String[]{"leg0","leg1"})bones.get(n).xRot-=progress*1.2F;
        if(m.phase()==BestiaryMob.STAGGER){root.zRot=(float)Math.sin(age*1.3)*.07F;root.xRot=.16F;}
        if(kind.body==BestiaryKind.Body.ELEMENTAL||kind.body==BestiaryKind.Body.GHOST)root.dy=(float)Math.sin(age*.1)*1.5F;
    }
    @Override public void renderToBuffer(PoseStack p,VertexConsumer v,int light,int overlay,int color){root.render(p,v,light,overlay);}
}
