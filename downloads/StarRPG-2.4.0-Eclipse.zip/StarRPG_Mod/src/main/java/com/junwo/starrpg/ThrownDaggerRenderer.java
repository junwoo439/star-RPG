package com.junwo.starrpg;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.client.renderer.texture.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;

/** World-oriented end-over-end blade, rather than a camera-facing flat item. */
public final class ThrownDaggerRenderer extends EntityRenderer<ThrownDagger> {
    private final net.minecraft.client.renderer.entity.ItemRenderer items;
    public ThrownDaggerRenderer(EntityRendererProvider.Context context){super(context);items=context.getItemRenderer();}
    @Override public ResourceLocation getTextureLocation(ThrownDagger e){return TextureAtlas.LOCATION_BLOCKS;}
    @Override public void render(ThrownDagger e,float yaw,float tick,PoseStack pose,MultiBufferSource buffers,int light){
        WeaponTrailVfx.draw(pose,buffers,19,0x63FFC5,.65F,5,12,-e.getYRot(),-e.getXRot());
        pose.pushPose();pose.mulPose(Axis.YP.rotationDegrees(e.getYRot()+90));
        pose.mulPose(Axis.ZP.rotationDegrees((e.tickCount+tick)*(e.returning()?-42:58)));
        pose.scale(1.35F,1.35F,1.35F);
        items.renderStatic(e.getItem(),ItemDisplayContext.GROUND,e.returning()?15728880:light,OverlayTexture.NO_OVERLAY,pose,buffers,e.level(),e.getId());
        pose.popPose();super.render(e,yaw,tick,pose,buffers,light);
    }
}
