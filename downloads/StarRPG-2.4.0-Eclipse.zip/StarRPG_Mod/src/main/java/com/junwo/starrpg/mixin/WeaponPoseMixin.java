package com.junwo.starrpg.mixin;

import com.junwo.starrpg.TwoHandedPresentation;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Applies after vanilla arm animation; PlayerModel then copies these poses to sleeves. */
@Mixin(HumanoidModel.class)
public abstract class WeaponPoseMixin {
    @Inject(method="setupAnim(Lnet/minecraft/world/entity/LivingEntity;FFFFF)V",at=@At("TAIL"))
    private void starrpg$pairedPose(LivingEntity entity,float walk,float speed,float age,float yaw,float pitch,CallbackInfo ci){
        TwoHandedPresentation.pose((HumanoidModel<?>)(Object)this,entity,age);
    }
}
