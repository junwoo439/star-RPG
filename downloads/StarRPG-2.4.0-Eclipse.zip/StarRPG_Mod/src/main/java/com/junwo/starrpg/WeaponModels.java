package com.junwo.starrpg;

import com.mojang.blaze3d.vertex.*;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/** Solid hand equipment: the glove encloses the fist and the spear has a cylindrical-looking shaft. */
public final class WeaponModels {
    private static final ResourceLocation METAL=ResourceLocation.withDefaultNamespace("textures/block/iron_block.png");
    public static void box(PoseStack p,MultiBufferSource buffers,float x,float y,float z,float sx,float sy,float sz,int rgb,int light){
        var out=buffers.getBuffer(RenderType.entityCutoutNoCull(METAL));
        float[][] v={{x,y,z},{x+sx,y,z},{x+sx,y+sy,z},{x,y+sy,z},{x,y,z+sz},{x+sx,y,z+sz},{x+sx,y+sy,z+sz},{x,y+sy,z+sz}};
        int[][] faces={{0,3,2,1},{4,5,6,7},{0,4,7,3},{1,2,6,5},{0,1,5,4},{3,7,6,2}};
        float[][] normals={{0,0,-1},{0,0,1},{-1,0,0},{1,0,0},{0,-1,0},{0,1,0}},uv={{0,1},{1,1},{1,0},{0,0}};
        for(int f=0;f<6;f++)for(int i=0;i<4;i++){var a=v[faces[f][i]];out.addVertex(p.last(),a[0],a[1],a[2]).setColor((rgb>>16)&255,(rgb>>8)&255,rgb&255,255).setUv(uv[i][0],uv[i][1]).setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(p.last(),normals[f][0],normals[f][1],normals[f][2]);}
    }
    public static void glove(PoseStack p,MultiBufferSource b,int light){
        box(p,b,-.14F,-.18F,-.12F,.28F,.25F,.24F,0x375760,light);
        box(p,b,-.16F,.02F,-.14F,.32F,.20F,.31F,0x90B4AA,light);
        for(int i=0;i<4;i++)box(p,b,-.15F+i*.078F,.14F,-.17F,.068F,.095F,.10F,0xD8E5D7,light);
        box(p,b,-.10F,.055F,-.157F,.20F,.09F,.025F,0x35EFBC,15728880);
        box(p,b,-.15F,-.14F,-.13F,.30F,.045F,.26F,0xC1AE62,light);
    }
    public static void spear(PoseStack p,MultiBufferSource b,int light){
        box(p,b,-.035F,-.7F,-.035F,.07F,2.05F,.07F,0x39566D,light);
        for(int i=0;i<5;i++)box(p,b,-.041F,-.1F+i*.09F,-.041F,.082F,.045F,.082F,0xA18862,light);
        box(p,b,-.10F,1.12F,-.06F,.20F,.08F,.12F,0xC4DCE9,light);
        p.pushPose();p.translate(0,1.43,0);p.scale(.48F,1,.30F);p.mulPose(Axis.ZP.rotationDegrees(45));box(p,b,-.22F,-.22F,-.08F,.44F,.44F,.16F,0xB0E7FF,light);p.popPose();
        box(p,b,-.025F,1.2F,-.065F,.05F,.39F,.025F,0x5BE6FF,15728880);
    }
}
