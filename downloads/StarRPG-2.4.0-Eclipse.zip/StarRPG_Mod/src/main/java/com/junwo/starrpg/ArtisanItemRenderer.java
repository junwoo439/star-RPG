package com.junwo.starrpg;

import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.*;

/** Uses the original painted atlas directly; does not lower the block atlas mipmap level. */
public final class ArtisanItemRenderer extends BlockEntityWithoutLevelRenderer {
    public static final ResourceLocation ATLAS=ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,"textures/art/weapons_and_sigils.png");
    public ArtisanItemRenderer(){super(Minecraft.getInstance().getBlockEntityRenderDispatcher(),Minecraft.getInstance().getEntityModels());}
    @Override public void renderByItem(ItemStack stack,ItemDisplayContext context,PoseStack pose,MultiBufferSource buffers,int light,int overlay){
        int kind=WeaponArt.kind(stack);if(kind<0)return;pose.pushPose();pose.translate(0.5,0.5,0.5);
        boolean held=WeaponPresentation.held(context);
        if(kind==5&&(context==ItemDisplayContext.THIRD_PERSON_LEFT_HAND||context==ItemDisplayContext.THIRD_PERSON_RIGHT_HAND)&&TwoHandedPresentation.hideHeldSpear()){pose.popPose();return;}
        if(held&&(kind==9||kind==5)){if(kind==9)WeaponModels.glove(pose,buffers,light);else WeaponModels.spear(pose,buffers,light);pose.popPose();return;}
        if(stack.getItem() instanceof MagicStaffItem staff&&staff.school>0){ElementalStaffRenderer.draw(pose,buffers,staff.school,held,light);pose.popPose();return;}
        var grip=WeaponPresentation.grip(kind);
        float crop=held?grip.cropRight():1,depth=grip.depth();
        if(held){pose.scale(grip.scale(),grip.scale(),grip.scale());pose.translate(-(grip.x()-crop*0.5F)*1.32F,-(0.5F-grip.y())*1.32F,0);}
        var out=buffers.getBuffer(RenderType.entityTranslucent(ATLAS));
        face(pose,out,kind,crop,depth,light,false);face(pose,out,kind,crop,-depth,light,true);
        for(var edge:edges(kind,crop)){
            float x0=edge.x0,y0=edge.y0,x1=edge.x1,y1=edge.y1;
            var part=pose.last();float nx=y1-y0,ny=x0-x1,len=(float)Math.sqrt(nx*nx+ny*ny);if(len==0)continue;
            float[][] points={{x0,y0,-depth},{x1,y1,-depth},{x1,y1,depth},{x0,y0,depth}};
            for(var pt:points)out.addVertex(part,pt[0],pt[1],pt[2]).setColor(230,230,230,255).setUv(edge.u,edge.v).setOverlay(overlay).setLight(light).setNormal(part,nx/len,ny/len,0);
        }
        pose.popPose();
    }
    private record Edge(float x0,float y0,float x1,float y1,float u,float v){}
    private static final java.util.Map<Integer,java.util.List<Edge>> EDGES=new java.util.HashMap<>();
    public static void clearMeshes(){EDGES.clear();}
    private static java.util.List<Edge> edges(int kind,float crop){return EDGES.computeIfAbsent(kind+(crop<1?16:0),key->{
        var result=new java.util.ArrayList<Edge>();
        try(var in=Minecraft.getInstance().getResourceManager().open(ATLAS)){
            var img=javax.imageio.ImageIO.read(in);int cells=64,width=Math.round(cells*crop);boolean[][] solid=new boolean[cells][width];
            for(int y=0;y<cells;y++)for(int x=0;x<width;x++){
                int px=Math.min(img.getWidth()-1,(int)((kind%4+(x+0.5)/cells)*img.getWidth()/4));
                int py=Math.min(img.getHeight()-1,(int)((kind/4+(y+0.5)/cells)*img.getHeight()/4));solid[y][x]=(img.getRGB(px,py)>>>24)>=96;
            }
            for(int y=0;y<cells;y++)for(int x=0;x<width;x++)if(solid[y][x]){
                float l=(x/(float)cells-crop*0.5F)*1.32F,r=l+1.32F/cells,t=(0.5F-y/(float)cells)*1.32F,b=t-1.32F/cells;
                float u=(kind%4+(x+0.5F)/cells)/4,v=(kind/4+(y+0.5F)/cells)/4;
                if(y==0||!solid[y-1][x])result.add(new Edge(l,t,r,t,u,v));
                if(y==cells-1||!solid[y+1][x])result.add(new Edge(r,b,l,b,u,v));
                if(x==0||!solid[y][x-1])result.add(new Edge(l,b,l,t,u,v));
                if(x==width-1||!solid[y][x+1])result.add(new Edge(r,t,r,b,u,v));
            }
        }catch(java.io.IOException e){StarRPG.LOGGER.warn("Cannot create weapon edge mesh",e);}return java.util.List.copyOf(result);
    });}
    private static void face(PoseStack pose,VertexConsumer out,int kind,float crop,float z,int light,boolean reverse){
        float l=-0.66F*crop,r=0.66F*crop,u=kind%4*0.25F,v=kind/4*0.25F;
        float[][] points=reverse?new float[][]{{l,-0.66F,u,v+0.25F},{l,0.66F,u,v},{r,0.66F,u+0.25F*crop,v},{r,-0.66F,u+0.25F*crop,v+0.25F}}
            :new float[][]{{l,-0.66F,u,v+0.25F},{r,-0.66F,u+0.25F*crop,v+0.25F},{r,0.66F,u+0.25F*crop,v},{l,0.66F,u,v}};
        for(var pt:points)out.addVertex(pose.last(),pt[0],pt[1],z).setColor(255,255,255,255).setUv(pt[2],pt[3]).setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(pose.last(),0,0,reverse?-1:1);
    }
    public static void quad(PoseStack pose,VertexConsumer out,int cell,float radius,int rgb,float alpha,int light,float z,boolean reverse){
        float u=(cell%4)*0.25F,v=(cell/4)*0.25F;var p=pose.last();
        float[][] vertices=reverse?new float[][]{{-radius,-radius,u,v+.25F},{-radius,radius,u,v},{radius,radius,u+.25F,v},{radius,-radius,u+.25F,v+.25F}}
            :new float[][]{{-radius,-radius,u,v+.25F},{radius,-radius,u+.25F,v+.25F},{radius,radius,u+.25F,v},{-radius,radius,u,v}};
        for(var a:vertices)out.addVertex(p,a[0],a[1],z).setColor((rgb>>16)&255,(rgb>>8)&255,rgb&255,(int)(Math.clamp(alpha,0,1)*255))
            .setUv(a[2],a[3]).setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(p,0,0,reverse?-1:1);
    }
}
