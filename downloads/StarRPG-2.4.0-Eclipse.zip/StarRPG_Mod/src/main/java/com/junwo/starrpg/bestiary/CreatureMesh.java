package com.junwo.starrpg.bestiary;

import com.mojang.blaze3d.vertex.*;
import com.mojang.math.Axis;
import java.util.*;
import net.minecraft.world.phys.Vec3;

/** Articulated original mesh with per-surface atlas materials, tint and emissive eyes. */
public final class CreatureMesh {
    public static final int SCALES=0,BELLY=1,MEMBRANE=2,HORN=3,METAL=4,MAIL=5,STONE=6,CLOTH=7,FUR=8,SHAG=9,HIDE=10,BONE=11,WOOD=12,CHITIN=13,FEATHER=14,LEATHER=15;
    public static final class Node {
        public final String name;public final float px,py,pz,bx,by,bz;
        public float xRot,yRot,zRot,dx,dy,dz;
        public final List<Node> children=new ArrayList<>();private final List<Face> faces=new ArrayList<>();
        public Node(String name,float x,float y,float z,float rx,float ry,float rz){this.name=name;px=x;py=y;pz=z;bx=rx;by=ry;bz=rz;reset();}
        public Node node(String name,float x,float y,float z){return node(name,x,y,z,0,0,0);}
        public Node node(String name,float x,float y,float z,float rx,float ry,float rz){var n=new Node(name,x,y,z,rx,ry,rz);children.add(n);return n;}
        public void reset(){xRot=bx;yRot=by;zRot=bz;dx=dy=dz=0;children.forEach(Node::reset);}
        public Node box(float x,float y,float z,float w,float h,float d,int tile,int color){return box(x,y,z,w,h,d,tile,color,false);}
        public Node box(float x,float y,float z,float w,float h,float d,int tile,int color,boolean glow){
            float X=x+w,Y=y+h,Z=z+d;
            quad(tile,color,glow,new float[][]{{x,y,z},{X,y,z},{X,Y,z},{x,Y,z}});
            quad(tile,color,glow,new float[][]{{X,y,Z},{x,y,Z},{x,Y,Z},{X,Y,Z}});
            quad(tile,color,glow,new float[][]{{x,y,Z},{x,y,z},{x,Y,z},{x,Y,Z}});
            quad(tile,color,glow,new float[][]{{X,y,z},{X,y,Z},{X,Y,Z},{X,Y,z}});
            quad(tile,color,glow,new float[][]{{x,y,Z},{X,y,Z},{X,y,z},{x,y,z}});
            quad(tile,color,glow,new float[][]{{x,Y,z},{X,Y,z},{X,Y,Z},{x,Y,Z}});return this;
        }
        private void quad(int tile,int color,boolean glow,float[][] points){faces.add(new Face(points,tile,color,glow));}
        public void triangle(float[] a,float[] b,float[] c,int tile,int color){quad(tile,color,false,new float[][]{a,b,c,c});quad(tile,color,false,new float[][]{c,b,a,a});}
        public void render(PoseStack p,VertexConsumer v,int light,int overlay){
            p.pushPose();p.translate((px+dx)/16,(py+dy)/16,(pz+dz)/16);p.mulPose(Axis.ZP.rotation(zRot));p.mulPose(Axis.YP.rotation(yRot));p.mulPose(Axis.XP.rotation(xRot));
            for(var f:faces)f.render(p,v,light,overlay);for(var n:children)n.render(p,v,light,overlay);p.popPose();
        }
        public void collect(Map<String,Node> map){map.put(name,this);children.forEach(n->n.collect(map));}
    }
    private record Face(float[][] points,int tile,int color,boolean glow){
        void render(PoseStack p,VertexConsumer v,int light,int overlay){
            var a=points[0];var b=points[1];var c=points[2];var normal=new Vec3(b[0]-a[0],b[1]-a[1],b[2]-a[2]).cross(new Vec3(c[0]-a[0],c[1]-a[1],c[2]-a[2])).normalize();
            float u=(tile%4)*.25F+.002F,w=.246F,t=(tile/4)*.25F+.002F;
            for(int i=0;i<4;i++){var q=points[i];v.addVertex(p.last(),q[0]/16,q[1]/16,q[2]/16).setColor(0xFF000000|color).setUv(u+(i==1||i==2?w:0),t+(i>=2?w:0)).setOverlay(overlay).setLight(glow?15728880:light).setNormal(p.last(),(float)-normal.x,(float)-normal.y,(float)-normal.z);}
        }
    }
    public static Node beam(Node p,String name,float[] a,float[] b,float thick,int tile,int color){
        float dx=b[0]-a[0],dy=b[1]-a[1],dz=b[2]-a[2],len=(float)Math.sqrt(dx*dx+dy*dy+dz*dz);
        var n=p.node(name,a[0],a[1],a[2],(float)Math.acos(Math.clamp(dy/len,-1,1)),(float)Math.atan2(dx,dz),0);n.box(-thick/2,0,-thick/2,thick,len,thick,tile,color);return n;
    }
    public static float r(float degrees){return degrees*(float)Math.PI/180;}
    public static int mix(int a,int b,float f){return ((int)(((a>>16)&255)*(1-f)+((b>>16)&255)*f)<<16)|((int)(((a>>8)&255)*(1-f)+((b>>8)&255)*f)<<8)|(int)((a&255)*(1-f)+(b&255)*f);}
}
