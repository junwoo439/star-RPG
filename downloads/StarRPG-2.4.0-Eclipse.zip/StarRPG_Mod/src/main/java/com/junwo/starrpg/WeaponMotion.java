package com.junwo.starrpg;

import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerLevel;
import net.neoforged.bus.api.*;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.event.entity.player.AttackEntityEvent;

@EventBusSubscriber(modid=StarRPG.MODID)
public final class WeaponMotion {
    @SubscribeEvent public static void arrowTrail(net.neoforged.neoforge.event.tick.EntityTickEvent.Post e){
        if(!(e.getEntity() instanceof net.minecraft.world.entity.projectile.AbstractArrow a)||a instanceof GiantArrow||a instanceof ThrownDagger
            ||!(a.level() instanceof ServerLevel l)||!(a.getOwner() instanceof Player)||a.tickCount%4!=0||a.getDeltaMovement().lengthSqr()<.1)return;
        var w=a.getWeaponItem();if(w==null||Careers.weaponJob(w)!=2)return;
        ArcaneSigil.spawn(l,a.position(),a.getDeltaMovement(),22,w.getItem() instanceof net.minecraft.world.item.CrossbowItem?0xFFB65C:0x6DEBFF,.45F,10);
    }
    @SubscribeEvent(priority=EventPriority.LOWEST) public static void attack(AttackEntityEvent e){if(!e.isCanceled())swing(e.getEntity());}
    public static void swing(Player p){
        if(!(p.level() instanceof ServerLevel l)||!p.isAlive()||p.isSpectator()||ControlEffects.stunned(p)||p.containerMenu!=p.inventoryMenu)return;
        int kind=WeaponArt.kind(p.getMainHandItem());
        if(kind<0||kind==4||kind==11||kind==12||!WeaponAwakening.allowed(p,p.getMainHandItem()))return;
        long now=l.getGameTime();var data=p.getPersistentData();if(data.getLong("starrpg_motion_ready")>now)return;
        data.putLong("starrpg_motion_ready",now+5);int side=1-data.getInt("starrpg_motion_side");data.putInt("starrpg_motion_side",side);
        data.putLong("starrpg_motion_tick",now);PacketDistributor.sendToPlayersTrackingEntityAndSelf(p,new WeaponMotionPayload(p.getId(),side));
        int style=kind==5||kind==13?19:kind==9?20:kind==3?18:side==0?17:18;
        var at=p.getEyePosition().add(p.getLookAngle().scale(kind==5?1.8:1.1)).add(0,-0.25,0);
        ArcaneSigil.spawn(l,at,p.getLookAngle(),style,WeaponArt.color(kind),kind==2?0.9F:kind==5?1.7F:1.35F,12);
    }
}
