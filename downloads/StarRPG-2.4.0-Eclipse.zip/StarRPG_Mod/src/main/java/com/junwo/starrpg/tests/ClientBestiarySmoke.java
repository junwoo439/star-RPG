package com.junwo.starrpg.tests;

import com.junwo.starrpg.*;
import com.junwo.starrpg.bestiary.*;
import net.minecraft.client.*;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.core.BlockPos;
import net.minecraft.world.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.*;
import net.minecraft.world.level.levelgen.presets.WorldPresets;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;

/** Opt-in visual verification, isolated newly-created world, excluded from release JAR. */
@EventBusSubscriber(modid=StarRPG.MODID,value=Dist.CLIENT)
public final class ClientBestiarySmoke {
    private static boolean started,configured;private static int tick,group;
    private static final BestiaryKind[][] GROUPS={
        {BestiaryKind.DIRE_BEAR,BestiaryKind.GIANT_SPIDER,BestiaryKind.REEF_SHARK},
        {BestiaryKind.GOBLIN,BestiaryKind.OGRE_WARLORD,BestiaryKind.LICH},
        {BestiaryKind.RED_DRAGON,BestiaryKind.HYDRA,BestiaryKind.GOLD_DRAGON},
        {BestiaryKind.BEELZEBUB,BestiaryKind.SOLAR,BestiaryKind.DEMOGORGON},
        {BestiaryKind.FIRE_ELEMENTAL,BestiaryKind.STORM_GIANT,BestiaryKind.ANCIENT_GOLEM},
        {BestiaryKind.ORC,BestiaryKind.ANCIENT_GOLEM,BestiaryKind.WHITE_DRAGON},
        {BestiaryKind.RED_DRAGON}};
    @SubscribeEvent public static void tick(net.neoforged.neoforge.client.event.ClientTickEvent.Post e){
        if(!Boolean.getBoolean("starrpg.bestiarySmoke"))return;var mc=Minecraft.getInstance();
        if(!started&&mc.screen instanceof TitleScreen&&mc.getOverlay()==null){
            started=true;mc.options.guiScale().set(2);mc.options.renderDistance().set(4);mc.options.simulationDistance().set(5);mc.getWindow().setWindowed(1280,800);mc.resizeDisplay();
            mc.createWorldOpenFlows().createFreshLevel("starrpg-bestiary-240-"+System.currentTimeMillis(),new LevelSettings("StarRPG bestiary visual test",GameType.CREATIVE,false,Difficulty.NORMAL,true,new GameRules(),WorldDataConfiguration.DEFAULT),new WorldOptions(240,false,false),WorldPresets::createNormalWorldDimensions,mc.screen);return;
        }
        if(mc.player==null||mc.level==null||mc.getSingleplayerServer()==null)return;
        var server=mc.getSingleplayerServer();var id=mc.player.getUUID();
        if(!configured){configured=true;mc.options.hideGui=false;mc.setScreen(null);server.execute(()->{
            var p=server.getPlayerList().getPlayer(id);var l=p.serverLevel();for(int x=-20;x<=20;x++)for(int z=-12;z<=25;z++)l.setBlock(new BlockPos(x,180,z),(x+z)%2==0?Blocks.GRAY_CONCRETE.defaultBlockState():Blocks.LIGHT_GRAY_CONCRETE.defaultBlockState(),3);
            l.setDayTime(6000);l.getGameRules().getRule(GameRules.RULE_DAYLIGHT).set(false,server);l.getGameRules().getRule(GameRules.RULE_DOMOBSPAWNING).set(false,server);WorldDifficulty.get(server).setTier(0);p.teleportTo(l,0,183,-7,0,8);p.getInventory().clearContent();p.setNoGravity(true);p.getAbilities().flying=true;p.onUpdateAbilities();
        });return;}
        if(tick==0&&(mc.player.getY()<182||Math.abs(mc.player.getX())>2||Math.abs(mc.player.getZ()+7)>2))return;
        if(++tick==30){for(var k:BestiaryKind.values()){var m=BestiaryRegistry.TYPES.get(k).get().create(mc.level);if(!(mc.getEntityRenderDispatcher().getRenderer(m) instanceof BestiaryRenderer))throw new IllegalStateException("Missing bestiary renderer "+k.id);}StarRPG.LOGGER.info("BESTIARY_RENDERERS_53_OK");}
        if(tick%100==40&&group<GROUPS.length){int selected=group;server.execute(()->{
            var p=server.getPlayerList().getPlayer(id);var l=p.serverLevel();l.getEntitiesOfClass(BestiaryMob.class,p.getBoundingBox().inflate(60)).forEach(Entity::discard);
            if(selected==6)p.teleportTo(l,8,183,-6,35,5);
            for(int i=0;i<GROUPS[selected].length;i++){
                var k=GROUPS[selected][i];var m=BestiaryRegistry.TYPES.get(k).get().create(l);m.moveTo(selected==6?0:(i-1)*8,181,6,180,0);m.setYRot(155);m.yBodyRot=m.yBodyRotO=m.yHeadRot=m.yHeadRotO=155;m.setNoGravity(true);m.setCustomName(net.minecraft.network.chat.Component.literal(k.name));m.setCustomNameVisible(true);
                if(selected>=5){var target=EntityType.COW.create(l);target.setPos(m.position().add(0,0,-2));m.setTarget(target);m.startAttack(target,true);for(int n=0;n<k.windup()-5;n++)m.combatTick();}
                m.setNoAi(true);l.addFreshEntity(m);
                if(selected==6)l.getEntitiesOfClass(ArcaneSigil.class,m.getBoundingBox().inflate(20)).forEach(Entity::discard);
            }
        });}
        if(tick%100==60&&group==5)server.execute(()->{var p=server.getPlayerList().getPlayer(id);for(var m:p.serverLevel().getEntitiesOfClass(BestiaryMob.class,p.getBoundingBox().inflate(50)))BestiaryCombat.telegraph(m);});
        if(tick%100==65&&group<GROUPS.length){int selected=group++;Screenshot.grab(mc.gameDirectory,"starrpg-2.4-bestiary-"+selected+".png",mc.getMainRenderTarget(),message->StarRPG.LOGGER.info("BESTIARY_SCREENSHOT {}",selected));}
        if(group==GROUPS.length&&tick%100==85){StarRPG.LOGGER.info("BESTIARY_WORLD_VISUAL_COMPLETE");mc.stop();}
        if(tick>1000)mc.stop();
    }
}
