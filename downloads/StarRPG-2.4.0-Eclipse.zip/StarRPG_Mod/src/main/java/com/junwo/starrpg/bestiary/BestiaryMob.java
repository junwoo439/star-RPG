package com.junwo.starrpg.bestiary;

import com.junwo.starrpg.*;
import net.minecraft.network.syncher.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.*;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.*;
import net.minecraft.world.entity.ai.navigation.*;
import net.minecraft.world.entity.ai.control.SmoothSwimmingMoveControl;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.sounds.*;

public final class BestiaryMob extends Monster {
    public static final int IDLE=0,QUICK=1,HEAVY=2,ACTIVE=3,RECOVERY=4,STAGGER=5;
    private static final EntityDataAccessor<Integer> PHASE=SynchedEntityData.defineId(BestiaryMob.class,EntityDataSerializers.INT),LEFT=SynchedEntityData.defineId(BestiaryMob.class,EntityDataSerializers.INT),TOTAL=SynchedEntityData.defineId(BestiaryMob.class,EntityDataSerializers.INT);
    public final BestiaryKind kind;
    public Vec3 attackOrigin=Vec3.ZERO,attackDirection=new Vec3(0,0,1),attackPoint=Vec3.ZERO;
    public boolean heavyAttack,parryableImpact;
    private int attackCounter;public long nextAttack;private int lifeTicks;
    private final ServerBossEvent bar=new ServerBossEvent(net.minecraft.network.chat.Component.empty(),BossEvent.BossBarColor.RED,BossEvent.BossBarOverlay.PROGRESS);
    public BestiaryMob(EntityType<? extends Monster> t,Level l,BestiaryKind k){
        super(t,l);kind=k;xpReward=k.boss?80:8;
        if(k.aquatic()){navigation=new WaterBoundPathNavigation(this,l);moveControl=new SmoothSwimmingMoveControl(this,85,10,.04F,.1F,true);}
    }
    public static AttributeSupplier.Builder attributes(BestiaryKind k){return Monster.createMonsterAttributes().add(Attributes.MAX_HEALTH,k.health).add(Attributes.ATTACK_DAMAGE,k.damage).add(Attributes.MOVEMENT_SPEED,k.body==BestiaryKind.Body.SMALL?.30:.24).add(Attributes.FOLLOW_RANGE,k.boss?36:24).add(Attributes.KNOCKBACK_RESISTANCE,k.boss?.7:k.body==BestiaryKind.Body.GOLEM?.4:0).add(Attributes.ARMOR,k.family==BestiaryKind.Family.CONSTRUCT?5:0);}
    @Override protected void defineSynchedData(SynchedEntityData.Builder b){super.defineSynchedData(b);b.define(PHASE,0);b.define(LEFT,0);b.define(TOTAL,1);}
    @Override protected void registerGoals(){
        goalSelector.addGoal(0,new FloatGoal(this){@Override public boolean canUse(){return kind!=null&&!kind.aquatic()&&super.canUse();}});goalSelector.addGoal(1,new BestiaryCombatGoal(this));
        goalSelector.addGoal(6,new RandomStrollGoal(this,.8){@Override public boolean canUse(){return kind!=null&&!kind.aquatic()&&super.canUse();}});
        goalSelector.addGoal(6,new RandomSwimmingGoal(this,1,40){@Override public boolean canUse(){return kind!=null&&kind.aquatic()&&super.canUse();}});goalSelector.addGoal(7,new LookAtPlayerGoal(this,Player.class,8));goalSelector.addGoal(8,new RandomLookAroundGoal(this));
        targetSelector.addGoal(1,new HurtByTargetGoal(this));
        targetSelector.addGoal(2,new NearestAttackableTargetGoal<>(this,Player.class,10,true,false,p->kind!=null&&!kind.neutral));
    }
    public int phase(){return entityData.get(PHASE);}public int remaining(){return entityData.get(LEFT);}public int duration(){return entityData.get(TOTAL);}
    public float progress(float partial){return Math.clamp(1-(remaining()-partial)/(float)Math.max(1,duration()),0,1);}
    public void phase(int phase,int ticks){entityData.set(PHASE,phase);entityData.set(LEFT,ticks);entityData.set(TOTAL,Math.max(1,ticks));}
    public void startAttack(LivingEntity target,boolean heavy){
        if(level().isClientSide()||!BestiaryCombat.valid(this,target))return;
        heavyAttack=heavy;attackOrigin=position();attackPoint=target.position();attackDirection=target.position().subtract(position()).multiply(1,0,1).normalize();
        phase(heavy?HEAVY:QUICK,heavy?kind.windup():10);getNavigation().stop();
        setYRot((float)Math.toDegrees(Math.atan2(-attackDirection.x,attackDirection.z)));yBodyRot=getYRot();
        BestiaryCombat.telegraph(this);playSound(heavy?SoundEvents.IRON_GOLEM_REPAIR:SoundEvents.PLAYER_ATTACK_WEAK,.6F,heavy?.6F:1.3F);
    }
    public void stagger(int ticks){phase(STAGGER,ticks);nextAttack=level().getGameTime()+ticks+12;getNavigation().stop();setDeltaMovement(0,getDeltaMovement().y,0);}
    public boolean nextHeavy(){return ++attackCounter%3==0||kind.move.ordinal()>=BestiaryKind.Move.HEX.ordinal()&&attackCounter%2==0;}
    public void combatTick(){
        if(phase()==IDLE)return;
        if(!isAlive()||ControlEffects.stunned(this)||ControlEffects.rooted(this)){phase(RECOVERY,20);nextAttack=level().getGameTime()+30;return;}
        if(phase()==QUICK||phase()==HEAVY){
            if(!BestiaryCombat.valid(this,getTarget())||getTarget().distanceToSqr(attackOrigin)>Math.pow(kind.reach()+8,2)){phase(RECOVERY,16);nextAttack=level().getGameTime()+24;return;}
            getNavigation().stop();setDeltaMovement(0,getDeltaMovement().y,0);
        }
        int left=remaining()-1;entityData.set(LEFT,Math.max(0,left));if(left>0)return;
        switch(phase()){
            case QUICK,HEAVY->{phase(ACTIVE,4);if(heavyAttack&&kind.move==BestiaryKind.Move.LUNGE)setDeltaMovement(attackDirection.scale(.8).add(0,.12,0));BestiaryCombat.resolve(this);}
            case ACTIVE->{phase(RECOVERY,heavyAttack?32:18);nextAttack=level().getGameTime()+remaining()+8;}
            case RECOVERY,STAGGER->phase(IDLE,0);
        }
    }
    @Override public void tick(){
        super.tick();if(level().isClientSide())return;lifeTicks++;
        if(kind.aquatic()&&!isInWater()&&tickCount%20==0)hurt(damageSources().dryOut(),2);
        if(kind.boss){
            bar.setName(net.minecraft.network.chat.Component.literal(kind.name+" · "+MonsterProgression.tier(this)+"단계"+(phase()==HEAVY?(kind.parryable()?" · 강공격 / 패링 가능":" · 강공격 / 회피"):phase()==STAGGER?" · 반격 기회":"")));
            bar.setProgress(Math.clamp(getHealth()/getMaxHealth(),0,1));bar.setVisible(isAlive());
        }
    }
    public int lifeTicks(){return lifeTicks;}
    @Override public void startSeenByPlayer(ServerPlayer p){super.startSeenByPlayer(p);if(kind.boss)bar.addPlayer(p);}
    @Override public void stopSeenByPlayer(ServerPlayer p){super.stopSeenByPlayer(p);bar.removePlayer(p);}
    @Override public void remove(RemovalReason reason){bar.removeAllPlayers();super.remove(reason);}
    @Override public boolean removeWhenFarAway(double d){return !kind.boss&&!hasCustomName();}
    @Override public void travel(Vec3 v){if(kind!=null&&kind.aquatic()&&isInWater()&&isEffectiveAi()){moveRelative(getSpeed(),v);move(MoverType.SELF,getDeltaMovement());setDeltaMovement(getDeltaMovement().scale(.9));}else super.travel(v);}
    @Override public boolean causeFallDamage(float d,float m,DamageSource s){return kind.body!=BestiaryKind.Body.DRAGON&&kind.body!=BestiaryKind.Body.WYVERN&&kind.body!=BestiaryKind.Body.GHOST&&super.causeFallDamage(d,m,s);}
    @Override protected SoundEvent getHurtSound(DamageSource s){return kind.family==BestiaryKind.Family.CONSTRUCT?SoundEvents.IRON_GOLEM_HURT:kind.family==BestiaryKind.Family.DRAGON?SoundEvents.ENDER_DRAGON_HURT:SoundEvents.RAVAGER_HURT;}
    @Override protected SoundEvent getDeathSound(){return kind.family==BestiaryKind.Family.CONSTRUCT?SoundEvents.IRON_GOLEM_DEATH:SoundEvents.RAVAGER_DEATH;}
    @Override public void addAdditionalSaveData(CompoundTag tag){super.addAdditionalSaveData(tag);tag.putInt("bestiaryAttacks",attackCounter);}
    @Override public void readAdditionalSaveData(CompoundTag tag){super.readAdditionalSaveData(tag);attackCounter=Math.max(0,tag.getInt("bestiaryAttacks"));phase(IDLE,0);nextAttack=level().getGameTime()+40;}
}
