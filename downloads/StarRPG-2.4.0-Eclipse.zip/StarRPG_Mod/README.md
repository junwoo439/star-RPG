# StarRPG 2.4.0 — 몬스터와 보스 전투

53종 몬스터(보스 19종), 지역별 자연 출현과 소환 계약서, 공격 준비 동작/범위 예고, V 패링과 반격을 추가했습니다. 용의 턱·이빨·뿔·날개막·꼬리와 몬스터 재질/의상을 새로 제작했습니다. 자세한 수치와 지역은 [BALANCE-2.4.md](BALANCE-2.4.md), [BESTIARY-2.4.csv](BESTIARY-2.4.csv), 확인 순서는 [TESTING-2.4.md](TESTING-2.4.md)를 참고하세요.

JDK 21 → `setup-eclipse.bat` (외부 모드 함께 사용 시 `setup-adventure-eclipse.bat`) → Eclipse에서 내부 **StarRPG_Mod** 폴더를 Existing Gradle Project로 가져오기 → Gradle Refresh/F5 → **StarRPG Client** → 싱글플레이.

---

이하 문서는 이전 버전의 기능 기록입니다. 현재 실행·테스트 안내는 위의 2.4 문서를 사용하세요.

# StarRPG

Minecraft 1.21.1 / NeoForge 21.1.235용 장비 강화·무기/방어구 룬·월드 공통 난이도·장비/낚싯대 좀비 모드.
기록된 이전 버전: **2.3.0**.

## Eclipse에서 게임 실행

**[Eclipse 실행 안내](ECLIPSE.md)**를 따라 Existing Gradle Project로 가져오고
`Run > Run Configurations > Java Application > StarRPG Client`를 실행하세요.
게임의 싱글플레이에서 테스트할 수 있습니다. JDK 21이 필요합니다.

Windows 명령줄 실행:

```bat
gradlew.bat runClient
```

클라이언트 월드와 설정은 `run-client/`에 저장됩니다.
변경 내용, 밸런스 설정, 기존 강화 장비 이전 방법은 [BALANCE-2.3.md](BALANCE-2.3.md)를 참조하세요.

## 빌드 및 개발자 테스트

```bash
bash gradlew build
bash gradlew runGameTestServer
```

Windows에서는 `gradlew.bat`를 사용합니다. 배포 파일은 `build/libs/starrpg-2.3.0.jar`입니다.
GameTest는 별도의 `run-gametest/`를 사용합니다.

2.3.0 변경 내용과 빠른 확인 순서는 [TESTING-2.3.md](TESTING-2.3.md)를 참고하세요.

이번 버전은 **3D 공격 궤적·원소별 궁극기, 양손 건틀릿/장창과 실제 좌우 삼연타, 역할 중복을 정리한 13개 직업, 원소별 전용 지팡이 6종, 실제 전직 추가타**를 포함합니다. 높은 고도에서 커스텀 이펙트가 사라지던 거리 계산도 수정했습니다. 직업 통합은 기록과 장비를 보존하며, 직접 다른 직업으로 변경할 때만 이전 직업 소지 무기를 +0으로 초기화합니다.

일반 룬 결과는 일반 70% / 희귀 25% / 에픽 4.9% / 레전더리 0.1%입니다. 모든 입력 룬이 결과 등급을 보장하지 않으며 재각인 때 등급이 낮아질 수 있습니다. 룬 확률·수치는 [BALANCE-1.8.md](BALANCE-1.8.md), 전체 룬은 [RUNE-EFFECTS-1.8.csv](RUNE-EFFECTS-1.8.csv), 플레이 확인 순서는 [TESTING-2.3.md](TESTING-2.3.md)에 있습니다.

**Shift+H:** 상점·판매·직업·마법 / **R:** 무기 스킬 / **G:** 직업 능력. 지팡이 우클릭은 선택 주문, Shift+우클릭은 주문 변경입니다. 장비 강화는 설치한 **인챈트 테이블 우클릭**, 룬 각인은 **룬 각인 도구**를 사용합니다. 별조각은 강화 재료로 유지합니다.

별가루 기본 구매 가격은 40 G, 별조각은 400 G입니다. 전체 판매 가격은 [SELL-PRICES-2.3.csv](SELL-PRICES-2.3.csv)에 있습니다. 기존 월드와 프로젝트는 백업한 뒤 업데이트하세요.

외부 모드는 [MODS-1.5.1.md](MODS-1.5.1.md)를 따릅니다. setup-adventure-eclipse.bat으로 Twilight Forest 4.8.3802, Mowzie 1.8.2, GeckoLib 4.9.2를 설치하고 Eclipse 실행을 준비합니다. Ice and Fire는 호환 공식 빌드가 없어 제외했습니다. 생활직은 보류했습니다.

외부 Twilight Forest·Mowzie·GeckoLib과 함께 자동 GameTest **174개 통과**. 실제 클라이언트의 새 테스트 월드에서 1/3인칭 양손 무기와 높은 고도의 이펙트를 확인했습니다. TESTING-2.3.md를 참고하세요. 배포 ZIP은 실행에 불필요한 art/ 원화·스크린샷을 제외하며 게임용 텍스처는 모두 포함합니다. Windows Eclipse와 실제 다인 PvP 체감은 별도 확인이 필요합니다.

**Shift+R:** 무기 각성기 (+15). +20·25에서 추가 발전합니다. 무기 설명에서 모든 해금을 확인하세요. 전체 단계표는 [WEAPON-UNLOCKS-2.0.csv](WEAPON-UNLOCKS-2.0.csv)에 있습니다.
