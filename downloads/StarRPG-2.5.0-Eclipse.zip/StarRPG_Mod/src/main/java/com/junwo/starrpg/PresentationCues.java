package com.junwo.starrpg;

import net.minecraft.server.level.*;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.network.PacketDistributor;

/** Server-confirmed presentation only: never awards items, changes stats or delays an action. */
public final class PresentationCues {
    public static final int GUARD=0,PARRY=1,UPGRADE=2,FAILURE=3,ADVANCE=4,SELECT=5;
    public static int enhancementColor(int level){return level<5?0xDCE8F2:level<10?0x62FFA9:level<15?0x56BFFF:level<20?0xBC7CFF:level<25?0xFFD46A:0xFF7955;}
    public static int careerColor(int job){return Careers.mage(job)?MagicSchools.color(MagicSchools.ofJob(job)):switch(job){case 1,8->0x62FFA9;case 4->0xFFB54F;case 5->0xFF655F;case 7->0xBE78FF;default->0x72DBFF;};}
    public static void mark(LivingEntity e,int cue,int value,int color){
        var tag=e.getPersistentData();String key=cue<=PARRY?"starrpg_guard_":"starrpg_ceremony_";
        tag.putLong(key+"tick",e.level().getGameTime());tag.putInt(key+"kind",cue);tag.putInt(key+"value",Math.max(0,value));tag.putInt(key+"color",color&0xFFFFFF);
    }
    public static void play(Player p,int cue,int value,int color){
        if(!(p.level() instanceof ServerLevel l)||cue<GUARD||cue>SELECT)return;
        mark(p,cue,value,color);
        if(p instanceof ServerPlayer)PacketDistributor.sendToPlayersTrackingEntityAndSelf(p,new PresentationCuePayload(p.getId(),cue,value,color));
        var at=cue<=PARRY?p.getEyePosition().add(p.getLookAngle().scale(1.3)):p.position().add(0,.06,0);
        ArcaneSigil.spawn(l,at,p.getLookAngle(),45+cue,color,cue<=PARRY?.42F:cue==ADVANCE?2.5F:1.65F,cue==GUARD?10:cue==PARRY?20:60);
    }
}
