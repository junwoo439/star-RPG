package com.junwo.starrpg;

import com.mojang.blaze3d.vertex.*;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;

/** Original transparent artwork plus actual 3-D ribbons, faceted crystals and timed spell stages. */
public final class CinematicVfx {
    public static final ResourceLocation ATLAS=ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,"textures/effect/cinematic_atlas.png");
    private static float clamp(float n){return Math.clamp(n,0,1);}
    private static int count(){return 4+VisualOptions.quality()*3;}
    private static void vertex(PoseStack p,VertexConsumer v,Vec3 q,int color,float alpha){v.addVertex(p.last(),(float)q.x,(float)q.y,(float)q.z).setColor((color>>16)&255,(color>>8)&255,color&255,(int)(clamp(alpha)*255));}
    public static void sprite(PoseStack p,MultiBufferSource b,int cell,float w,float h,int color,float alpha){
        var v=b.getBuffer(SpellRenderType.EMISSION);float u=cell%4*.25F+.002F,t=cell/4*.25F+.002F,s=.246F;
        float[][] q={{-w,-h,u,t+s},{w,-h,u+s,t+s},{w,h,u+s,t},{-w,h,u,t}};
        for(var x:q)v.addVertex(p.last(),x[0],x[1],0).setColor((color>>16)&255,(color>>8)&255,color&255,(int)(clamp(alpha)*255)).setUv(x[2],x[3]).setOverlay(OverlayTexture.NO_OVERLAY).setLight(15728880).setNormal(p.last(),0,0,1);
    }
    private static void floor(PoseStack p,MultiBufferSource b,int cell,float r,float y,float angle,int color,float alpha){p.pushPose();p.translate(0,y,0);p.mulPose(Axis.XP.rotationDegrees(90));p.mulPose(Axis.ZP.rotation(angle));sprite(p,b,cell,r,r,color,alpha);p.popPose();}
    private static void cross(PoseStack p,MultiBufferSource b,int cell,float w,float h,int color,float alpha){for(int i=0;i<2;i++){p.pushPose();p.mulPose(Axis.YP.rotationDegrees(i*90));sprite(p,b,cell,w,h,color,alpha*(i==0?1:.7F));p.popPose();}}
    public static void line(PoseStack p,MultiBufferSource b,Vec3 a,Vec3 z,float width,int color,float alpha){
        var d=z.subtract(a);if(d.lengthSqr()<.00001)return;var side=d.cross(Math.abs(d.normalize().y)>.9?new Vec3(1,0,0):new Vec3(0,1,0)).normalize();var out=b.getBuffer(SpellRenderType.GEOMETRY);
        // Crossed ribbons stay visible when looking along either side of a vertical beam.
        for(var axis:new Vec3[]{side,d.cross(side).normalize()})for(int layer=0;layer<3;layer++){var offset=axis.scale(width*(layer==0?2.8:layer==1?1:.23));int c=layer==2?0xFFFFEF:color;float f=alpha*(layer==0?.10F:layer==1?.4F:.85F);for(var q:new Vec3[]{a.subtract(offset),a.add(offset),z.add(offset),z.subtract(offset)})vertex(p,out,q,c,f);}
    }
    private static void helix(PoseStack p,MultiBufferSource b,float radius,float height,float turns,float phase,int color,float alpha,float width){
        int n=24+VisualOptions.quality()*12;Vec3 last=null;for(int i=0;i<=n;i++){float f=i/(float)n,a=phase+f*turns*6.2832F,rad=radius*(.35F+.65F*f);var q=new Vec3(Math.cos(a)*rad,f*height,Math.sin(a)*rad);if(last!=null)line(p,b,last,q,width*(.4F+(float)Math.sin(f*Math.PI)),color,alpha);last=q;}
    }
    public static void crystal(PoseStack p,MultiBufferSource b,float width,float height,int color,float alpha){
        var out=b.getBuffer(SpellRenderType.GEOMETRY);Vec3 top=new Vec3(0,height,0),bottom=new Vec3(0,-height*.2,0);int[] colors={color,0xD8FFFF,color,0xFFFFFF};
        for(int i=0;i<4;i++){double a=i*Math.PI/2,c=(i+1)*Math.PI/2;var x=new Vec3(Math.cos(a)*width,height*.2,Math.sin(a)*width);var z=new Vec3(Math.cos(c)*width,height*.2,Math.sin(c)*width);for(var tip:new Vec3[]{top,bottom}){vertex(p,out,tip,colors[i],alpha*.45F);vertex(p,out,x,colors[i],alpha*.45F);vertex(p,out,z,colors[i],alpha*.45F);vertex(p,out,tip,colors[i],alpha*.45F);}line(p,b,x,top,width*.035F,color,alpha);line(p,b,x,z,width*.025F,color,alpha);}
    }
    private static void motes(PoseStack p,MultiBufferSource b,int cell,int color,float r,float age,float alpha,boolean inward){
        int n=count();for(int i=0;i<n;i++){float phase=(age*.025F+i/(float)n)%1,a=i*2.39996F+age*.025F,rad=r*(inward?1-phase:phase);p.pushPose();p.translate(Math.cos(a)*rad,.2+Math.sin(phase*Math.PI)*r*.8,Math.sin(a)*rad);p.mulPose(Axis.YP.rotation(a));cross(p,b,cell,r*.07F,r*.12F,color,alpha*(float)Math.sin(phase*Math.PI));p.popPose();}
    }
    public static void seal(PoseStack p,MultiBufferSource b,float r,float age,int color,float alpha){
        floor(p,b,0,r,.04F,age*.018F,color,alpha*.8F);floor(p,b,0,r*.62F,.065F,-age*.026F,color,alpha*.6F);
        if(VisualOptions.quality()>0)for(int i=0;i<6;i++){double a=i*Math.PI/3+age*.012;p.pushPose();p.translate(Math.cos(a)*r*.78,.08,Math.sin(a)*r*.78);floor(p,b,14,r*.12F,0,(float)-a,color,alpha*.65F);p.popPose();}
    }
    private static void lightning(PoseStack p,MultiBufferSource b,float r,float age,int color,float alpha){
        for(int branch=0;branch<count()/2;branch++){Vec3 last=new Vec3(Math.cos(branch*2)*r*.6,r*3,Math.sin(branch*2)*r*.6);for(int i=1;i<=9;i++){float f=i/9F;var q=new Vec3(Math.sin(i*3.7+age*.17+branch)*r*.25,(1-f)*r*3,Math.cos(i*2.6+age*.13+branch)*r*.25);line(p,b,last,q,r*.028F,color,alpha);last=q;}}
    }
    private static void school(PoseStack p,MultiBufferSource b,int school,float r,float age,float t,int color,float alpha,boolean large){
        seal(p,b,r,age,color,alpha*.8F);float burst=1-(float)Math.pow(1-Math.min(1,t*3),3);int n=count();
        switch(school){
            case 1->{
                for(int i=0;i<n;i++){double a=i*2.4+age*.025;float h=r*(.7F+(i%3)*.22F)*(1-.35F*t);p.pushPose();p.translate(Math.cos(a)*r*.55,h*.8,Math.sin(a)*r*.55);p.mulPose(Axis.YP.rotation((float)a));cross(p,b,2,r*.38F,h,color,alpha);p.popPose();}
                helix(p,b,r*.65F,r*2.6F,2,-age*.11F,color,alpha*.65F,r*.045F);motes(p,b,15,0xFFD69C,r*1.2F,age,alpha,false);
                if(large){p.pushPose();p.translate(0,r*1.5,0);for(int side:new int[]{-1,1}){p.pushPose();p.mulPose(Axis.ZP.rotationDegrees(side*25));p.translate(side*r*.55,0,0);if(side<0)p.scale(-1,1,1);sprite(p,b,8,r,r*.7F,0xFFD18A,alpha*.7F);p.popPose();}p.popPose();}
            }
            case 2->{
                for(int i=0;i<3;i++)helix(p,b,r*(.65F+i*.12F),r*1.7F,1.7F,age*.09F+i*2.1F,color,alpha,r*.045F);
                for(int i=0;i<3;i++)floor(p,b,10,r*(.6F+burst*.5F+i*.13F),.07F+i*.04F,age*.015F+i,color,alpha*.6F);
                motes(p,b,12,0xD1FAFF,r*1.3F,age,alpha,false);
            }
            case 3->{
                for(int i=0;i<n;i++){double a=i*6.2832/n;p.pushPose();p.translate(Math.cos(a)*r*.65,0,Math.sin(a)*r*.65);p.mulPose(Axis.YP.rotation((float)-a));p.mulPose(Axis.ZP.rotationDegrees(12));crystal(p,b,r*.19F,r*(.8F+(i%3)*.4F)*burst,color,alpha);p.popPose();}
                floor(p,b,11,r*1.05F,.08F,0,color,alpha*.8F);motes(p,b,12,0xCBFFFF,r*1.2F,age,alpha,false);
            }
            case 4->{
                floor(p,b,11,r*1.15F,.09F,0,0xFFC97B,alpha);
                for(int i=0;i<n;i++){double a=i*2.4;p.pushPose();p.translate(Math.cos(a)*r*.7,Math.sin(t*Math.PI)*r*(.3+(i%3)*.12),Math.sin(a)*r*.7);p.mulPose(Axis.YP.rotation(age*.03F+i));p.mulPose(Axis.ZP.rotation(.35F));crystal(p,b,r*.23F,r*(.5F+(i%2)*.4F),color,alpha*.7F);p.popPose();}
                for(int i=0;i<4;i++){p.pushPose();p.translate(Math.cos(i*1.57)*r*.6,r*.3,Math.sin(i*1.57)*r*.6);cross(p,b,6,r*.55F,r*.4F,0xC0A481,alpha*.18F);p.popPose();}
            }
            case 5->{
                for(int i=0;i<3;i++){p.pushPose();p.mulPose(Axis.YP.rotationDegrees(i*60));p.mulPose(Axis.ZP.rotationDegrees(30));helix(p,b,r,r*1.8F,1.4F,-age*.07F+i*2,color,alpha*.7F,r*.055F);p.popPose();}
                motes(p,b,9,color,r,age,alpha,true);p.pushPose();p.translate(0,r*.8,0);cross(p,b,6,r*.6F,r*.7F,0x35204D,alpha*.65F);p.popPose();
            }
            case 6->{
                line(p,b,new Vec3(0,0,0),new Vec3(0,r*(large?4:2.8),0),r*.09F,0xFFF3C9,alpha);
                for(int i=0;i<3;i++){p.pushPose();p.translate(0,r*(.55+i*.5),0);floor(p,b,0,r*(.75F-i*.12F),0,age*(i%2==0?.035F:-.035F),color,alpha*.75F);p.popPose();}
                for(int side:new int[]{-1,1}){p.pushPose();p.translate(side*r*.4,r,0);p.mulPose(Axis.ZP.rotationDegrees(side*-25));if(side<0)p.scale(-1,1,1);sprite(p,b,8,r*.8F,r*.6F,color,alpha*.8F);p.popPose();}motes(p,b,7,color,r,age,alpha,false);
            }
        }
    }
    private static void weapon(PoseStack p,MultiBufferSource b,int style,float r,float age,float t,int color,float alpha){
        switch(style){
            case 17,18->{
                p.mulPose(Axis.ZP.rotationDegrees(style==17?-18:55));
                WeaponTrailVfx.arc(p,b,r,-2.2F+t*2.5F,2.8F,color,alpha*.8F);
                p.mulPose(Axis.XP.rotationDegrees(90));p.mulPose(Axis.ZP.rotation(-1.3F+t*2.5F));
                sprite(p,b,1,r*1.3F,r*.9F,color,alpha);if(VisualOptions.quality()>0){p.translate(0,0,.025);p.mulPose(Axis.ZP.rotation(-.22F));sprite(p,b,1,r*1.1F,r*.72F,0xFFE5FC,alpha*.45F);}
            }
            case 19,22->{
                Vec3 start=new Vec3(0,0,-r),end=new Vec3(0,0,r*(style==19?2.2:3));line(p,b,start,end,r*.055F,color,alpha);
                p.pushPose();p.mulPose(Axis.XP.rotationDegrees(90));helix(p,b,r*.25F,r*2.4F,2,age*.18F,color,alpha*.8F,r*.018F);p.popPose();
                p.pushPose();p.translate(0,0,r);sprite(p,b,13,r*.35F,r*.7F,color,alpha);p.popPose();
            }
            case 20->{p.translate(0,0,t*r);for(int i=0;i<4;i++){p.pushPose();p.translate((i-1.5)*r*.2,0,0);crystal(p,b,r*.14F,r*.5F,color,alpha*.35F);p.popPose();}p.pushPose();p.mulPose(Axis.XP.rotationDegrees(90));floor(p,b,7,r*(.5F+t),0,age*.04F,color,alpha*.35F);p.popPose();}
            case 21->{for(int i=0;i<3;i++)floor(p,b,11,r*(.4F+t*.7F)*(1-i*.16F),i*.03F+.03F,0,color,alpha*(1-i*.2F));motes(p,b,12,color,r,age,alpha,false);}
            case 23->{for(int i=0;i<3;i++){p.pushPose();p.mulPose(Axis.YP.rotationDegrees(i*60));p.mulPose(Axis.ZP.rotationDegrees(30));p.translate(0,r*.35,0);sprite(p,b,1,r,r*.75F,color,alpha*.75F);p.popPose();}motes(p,b,9,color,r,age,alpha,true);}
        }
    }
    private static void breath(PoseStack p,MultiBufferSource b,int style,float range,float age,int color,float alpha){
        int rays=3+VisualOptions.quality();
        for(int j=0;j<rays;j++){
            float angle=(j/(float)(rays-1)-.5F)*1.35F;Vec3 start=new Vec3(0,1.3,range*.28),last=start;
            for(int i=1;i<=9;i++){float t=i/9F;var end=new Vec3(Math.sin(angle)*range*t,(1-t)*1.3,range*(.28+(Math.cos(angle)-.28)*t));
                if(style==43)end=end.add(Math.sin(i*5+age*.15)*.14,Math.cos(i*4+age*.13)*.12,0);
                line(p,b,last,end,range*(style==43?.012F:.022F)*(1+t),color,alpha*(style==43||style==44?.7F:.12F));
                if(i%2==0){p.pushPose();p.translate(end.x,end.y,end.z);p.mulPose(Axis.YP.rotation(angle));cross(p,b,style==40?2:style==41?12:style==42?6:style==43?3:7,range*(.04F+t*.08F),range*(.07F+t*.10F),color,alpha*(1-t*.5F));p.popPose();}last=end;
            }
        }
    }
    private static void ceremony(PoseStack p,MultiBufferSource b,int style,int color,float r,float age,float alpha){
        float fall=Math.clamp(age/25,0,1),height=8*(1-fall*fall)+.8F;
        if(age<28){var at=new Vec3((1-fall)*r*.7,height,0);line(p,b,at,at.add(.25,2,0),r*.035F,color,alpha*.65F);p.pushPose();p.translate(at.x,at.y,0);p.mulPose(Axis.YP.rotation(age*.06F));cross(p,b,7,r*.27F,r*.27F,color,alpha);crystal(p,b,r*.09F,r*.22F,color,alpha);p.popPose();}
        if(age>16){float bloom=Math.min(1,(age-16)/14);seal(p,b,r*bloom,age,color,alpha*.75F);}
        if(age>25){motes(p,b,7,color,r*(style==49?1.4F:1),age-25,alpha,style==48);
            if(style!=48)for(int i=0;i<(style==49?3:1);i++)helix(p,b,r*(.6F+i*.16F),r*(style==49?2.4F:1.2F),1.5F,age*.08F+i*2,color,alpha*.55F,r*.025F);
            if(style==49){p.pushPose();p.translate(0,r*1.5,0);floor(p,b,0,r*.7F,0,-age*.03F,color,alpha*.8F);p.popPose();}
        }
    }
    public static void draw(PoseStack p,MultiBufferSource b,int style,int color,float r,float age,int life,float yaw,float pitch){
        if(!Float.isFinite(r)||!Float.isFinite(age)||life<=0||age<0||age>=life)return;
        float t=clamp(age/life),alpha=Math.min(1,age/3)*Math.min(1,(life-age)/Math.min(12,life*.35F));if(alpha<=0)return;
        p.pushPose();
        if(style>=47&&style<=50){ceremony(p,b,style,color,r,age,alpha);p.popPose();return;}
        if(style==45||style==46){
            if(style==45&&age>=5){p.popPose();return;}
            p.mulPose(Axis.YP.rotationDegrees(-yaw));p.mulPose(Axis.XP.rotationDegrees(pitch));
            sprite(p,b,14,r*(style==46?1+t:.7F),r*(style==46?1+t:.7F),color,alpha*.4F);
            if(style==46){sprite(p,b,7,r*.9F,r*.9F,color,alpha*.4F);for(int i=0;i<8;i++){double a=i*Math.PI/4;line(p,b,new Vec3(Math.cos(a)*r*.3,Math.sin(a)*r*.3,0),new Vec3(Math.cos(a)*r*(.6+t),Math.sin(a)*r*(.6+t),0),r*.025F,color,alpha*.55F);}}
            p.popPose();return;
        }
        if(style>=40&&style<=44){p.mulPose(Axis.YP.rotationDegrees(-yaw));breath(p,b,style,r,age,color,alpha);p.popPose();return;}
        if(style>=17&&style<=23){p.mulPose(Axis.YP.rotationDegrees(-yaw));p.mulPose(Axis.XP.rotationDegrees(pitch));weapon(p,b,style,r,age,t,color,alpha);p.popPose();return;}
        if(style>=31&&style<=36){seal(p,b,r*(.55F+t*.45F),age,color,alpha);helix(p,b,r*.7F,r*2,2,-age*.08F,color,alpha*.55F,r*.025F);motes(p,b,12,color,r,age,alpha,true);p.popPose();return;}
        if(style>=24&&style<=29){school(p,b,style-23,r,age,t,color,alpha,true);p.popPose();return;}
        switch(style){
            case 0->seal(p,b,r,age,color,alpha);
            case 1->{p.mulPose(Axis.YP.rotationDegrees(-yaw));p.mulPose(Axis.XP.rotationDegrees(pitch));for(int i=0;i<3;i++){p.pushPose();p.translate(0,0,i*1.15);p.mulPose(Axis.ZP.rotation(age*(i%2==0?.03F:-.03F)));sprite(p,b,0,r*(1-i*.12F),r*(1-i*.12F),color,alpha*(1-i*.12F));p.popPose();}}
            case 3->{seal(p,b,r,age,color,alpha*.7F);lightning(p,b,r,age,color,alpha);}
            case 4->school(p,b,3,r,age,t,color,alpha,false);
            case 5->{seal(p,b,r,age,color,alpha*.6F);for(int i=0;i<3;i++)helix(p,b,r*(.7F+i*.15F),r*2.2F,2.2F,age*.12F+i*2,color,alpha*.8F,r*.04F);motes(p,b,15,color,r,age,alpha,false);}
            case 6->school(p,b,6,r,age,t,color,alpha,false);
            case 7->school(p,b,1,r,age,t,color,alpha,false);
            case 8->school(p,b,2,r,age,t,color,alpha,false);
            case 9->school(p,b,4,r,age,t,color,alpha,false);
            case 15->school(p,b,5,r,age,t,color,alpha,false);
            case 16->{seal(p,b,r,age,color,alpha);motes(p,b,8,color,r,age,alpha,false);line(p,b,Vec3.ZERO,new Vec3(0,r*1.7,0),r*.04F,color,alpha*.6F);}
            default->{p.mulPose(Axis.YP.rotationDegrees(-yaw));p.mulPose(Axis.XP.rotationDegrees(pitch));p.mulPose(Axis.ZP.rotation(age*.04F));sprite(p,b,style==11?14:style==12?7:style==13?1:0,r,r,color,alpha);motes(p,b,7,color,r*.7F,age,alpha,false);}
        }p.popPose();
    }
}
