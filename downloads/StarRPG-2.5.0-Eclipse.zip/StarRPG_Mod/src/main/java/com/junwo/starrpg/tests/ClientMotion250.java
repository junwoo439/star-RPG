package com.junwo.starrpg.tests;

import com.junwo.starrpg.*;
import com.junwo.starrpg.bestiary.*;
import net.minecraft.client.*;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.item.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.*;
import net.minecraft.world.level.levelgen.presets.WorldPresets;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;

/** Actual first/third-person rendering and confirmed menu actions in a new disposable world. */
@EventBusSubscriber(modid=StarRPG.MODID,value=Dist.CLIENT)
public final class ClientMotion250 {
    private static boolean started,configured;private static int tick;private static BestiaryMob opponent;
    @SubscribeEvent public static void tick(net.neoforged.neoforge.client.event.ClientTickEvent.Post e){
        if(!Boolean.getBoolean("starrpg.motion250"))return;var mc=Minecraft.getInstance();
        if(!started&&mc.screen instanceof TitleScreen&&mc.getOverlay()==null){
            started=true;mc.options.hideGui=false;mc.options.guiScale().set(2);mc.options.renderDistance().set(4);mc.options.simulationDistance().set(5);mc.getWindow().setWindowed(1280,800);mc.resizeDisplay();
            mc.createWorldOpenFlows().createFreshLevel("starrpg-motion-250-"+System.currentTimeMillis(),new LevelSettings("StarRPG motion verification",GameType.CREATIVE,false,Difficulty.NORMAL,true,new GameRules(),WorldDataConfiguration.DEFAULT),new WorldOptions(251,false,false),WorldPresets::createNormalWorldDimensions,mc.screen);return;
        }
        if(mc.player==null||mc.level==null||mc.getSingleplayerServer()==null)return;
        var server=mc.getSingleplayerServer();var id=mc.player.getUUID();
        if(!configured){configured=true;mc.setScreen(null);server.execute(()->{var p=server.getPlayerList().getPlayer(id);var l=p.serverLevel();
            for(int x=-18;x<=18;x++)for(int z=-12;z<=22;z++)l.setBlock(new BlockPos(x,180,z),((x+z)%4==0?Blocks.POLISHED_BLACKSTONE:Blocks.DEEPSLATE_TILES).defaultBlockState(),3);
            for(int x=-16;x<=16;x+=4)for(int y=181;y<=187;y++)l.setBlock(new BlockPos(x,y,18),(y==187?Blocks.SEA_LANTERN:Blocks.DEEPSLATE_BRICKS).defaultBlockState(),3);
            l.setDayTime(6000);l.getGameRules().getRule(GameRules.RULE_DAYLIGHT).set(false,server);l.getGameRules().getRule(GameRules.RULE_DOMOBSPAWNING).set(false,server);WorldDifficulty.get(server).setTier(0);p.teleportTo(l,0,183,-6,0,8);p.setNoGravity(true);p.getAbilities().flying=true;p.onUpdateAbilities();});return;}
        if(tick==0&&(mc.player.getY()<182||Math.abs(mc.player.getZ()+6)>2))return;
        tick++;if(tick==20){StarRPG.LOGGER.info("MOTION250_READY");tick+=Math.clamp(Integer.getInteger("starrpg.motion250.start",0),0,16)*100;}int stage=(tick-1)/100,step=tick%100;
        if(step==25){mc.options.hideGui=stage<3;mc.options.setCameraType(stage==5||stage>=10&&stage<=13?CameraType.THIRD_PERSON_FRONT:CameraType.FIRST_PERSON);server.execute(()->{
            var p=server.getPlayerList().getPlayer(id);var l=p.serverLevel();p.closeContainer();l.getEntitiesOfClass(BestiaryMob.class,p.getBoundingBox().inflate(60)).forEach(Entity::discard);p.getInventory().clearContent();opponent=null;
            if(stage<3){BestiaryKind[] kinds=stage==0?new BestiaryKind[]{BestiaryKind.GOBLIN,BestiaryKind.ORC,BestiaryKind.LICH}:stage==1?new BestiaryKind[]{BestiaryKind.RED_DRAGON}:new BestiaryKind[]{BestiaryKind.VAMPIRE,BestiaryKind.ANCIENT_GOLEM,BestiaryKind.BANSHEE};p.teleportTo(l,stage==1?5:0,183,stage==1?-3:-6,stage==1?35:0,8);
                for(int i=0;i<kinds.length;i++){var m=BestiaryRegistry.TYPES.get(kinds[i]).get().create(l);m.moveTo(kinds.length==1?0:(i-1)*5,181,3,160,0);m.yBodyRot=m.yBodyRotO=m.yHeadRot=m.yHeadRotO=160;m.setNoAi(true);m.setNoGravity(true);l.addFreshEntity(m);}}
            else{p.setGameMode(GameType.SURVIVAL);p.setNoGravity(false);p.getAbilities().flying=false;p.onUpdateAbilities();p.teleportTo(l,0,181,-2,0,0);p.setHealth(p.getMaxHealth());
                if(stage<=5){p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(Items.IRON_SWORD));p.setItemInHand(InteractionHand.OFF_HAND,new ItemStack(Items.SHIELD));opponent=BestiaryRegistry.TYPES.get(BestiaryKind.ORC).get().create(l);opponent.moveTo(stage==5?1.8:0,181,.2,180,0);opponent.yBodyRot=opponent.yBodyRotO=opponent.yHeadRot=opponent.yHeadRotO=180;opponent.setNoAi(true);l.addFreshEntity(opponent);}
                else if(stage<=13){int index=(stage-6)%4;Item[] items={StarRPG.STAR_DAGGER.get(),StarRPG.WAR_HAMMER.get(),StarRPG.STAR_SPEAR.get(),StarRPG.STAR_GAUNTLET.get()};int[] jobs={1,4,0,8};var c=Careers.profile(p);c.selected=jobs[index];c.ranks[c.selected]=1;p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(items[index]));}
            }
        });}
        if(stage>=3&&stage<=5&&step==55)server.execute(()->ParrySystem.open(server.getPlayerList().getPlayer(id)));
        if((stage==4||stage==5)&&step==57)server.execute(()->{var p=server.getPlayerList().getPlayer(id);opponent.parryableImpact=true;p.hurt(opponent.damageSources().mobAttack(opponent),6);});
        if(stage>=6&&stage<=13&&(step==50||step==70||step==90))server.execute(()->{var p=server.getPlayerList().getPlayer(id);WeaponMotion.swing(p);p.swing(InteractionHand.MAIN_HAND,true);});
        if((stage==14||stage==15)&&step==35)server.execute(()->{var p=server.getPlayerList().getPlayer(id);p.openMenu(new SimpleMenuProvider((n,inv,who)->new EnhancementMenu(n,inv),Component.literal("장비 강화")));var m=(EnhancementMenu)p.containerMenu;var w=new ItemStack(StarRPG.STAR_DAGGER.get());EnhancementData.setLevel(w,stage==14?24:20);if(stage==14)for(int i=0;i<20;i++)EnhancementData.recordFailure(w);m.getSlot(0).set(w);m.getSlot(1).set(new ItemStack(StarRPG.STAR_DUST.get(),64));m.getSlot(2).set(new ItemStack(StarRPG.STAR_FRAGMENT.get(),64));m.broadcastChanges();});
        if((stage==14||stage==15)&&step==55)server.execute(()->{var p=server.getPlayerList().getPlayer(id);var m=(EnhancementMenu)p.containerMenu;if(stage==15){long seed=0;while(true){p.getRandom().setSeed(seed);if(p.getRandom().nextInt(100)>=EnhancementMenu.getSuccessChance(m.getSlot(0).getItem()))break;seed++;}p.getRandom().setSeed(seed);}if(!m.clickMenuButton(p,0))throw new IllegalStateException("Showcase enhancement rejected");});
        if(stage==16&&step==35)server.execute(()->{var p=server.getPlayerList().getPlayer(id);var c=Careers.profile(p);c.selected=10;c.ranks[10]=1;c.xp[10]=Careers.xpCost(1);c.mastery[10]=Careers.masteryCost(1);p.getInventory().add(new ItemStack(Careers.material(10),Careers.materialCount(1)));StarWallet.get(server).credit(p.getUUID(),Careers.goldCost(1));p.openMenu(new SimpleMenuProvider((n,inv,who)->new MaterialShopMenu(n,inv),Component.literal("직업·전직")));});
        if(stage==16&&step==45&&mc.player.containerMenu instanceof MaterialShopMenu menu){menu.clientTab=2;mc.setScreen(new MaterialShopScreen(menu,mc.player.getInventory(),Component.literal("직업·전직")));var button=mc.screen.children().stream().filter(w->w instanceof Button b&&b.getMessage().getString().equals(Careers.NAMES[10])).findFirst();button.ifPresent(w->((Button)w).onPress());}
        if(stage==16&&step==55)server.execute(()->{var p=server.getPlayerList().getPlayer(id);if(!Careers.advance(p))throw new IllegalStateException("Showcase promotion rejected");p.containerMenu.broadcastChanges();});
        int capture=stage==3?60:stage==4||stage==5?61:stage>=6&&stage<=13?56:stage>=14?88:73;
        if(step==capture)Screenshot.grab(mc.gameDirectory,"starrpg-2.5-motion-"+stage+".png",mc.getMainRenderTarget(),message->StarRPG.LOGGER.info("MOTION250_SCREENSHOT {}",stage));
        if(tick>=Math.clamp(Integer.getInteger("starrpg.motion250.stages",17),1,17)*100){mc.options.hideGui=false;mc.options.setCameraType(CameraType.FIRST_PERSON);StarRPG.LOGGER.info("MOTION250_COMPLETE");mc.stop();}
    }
}
