package com.junwo.starrpg;

public enum RuneEffect {

    // ===== 검: 일반 =====
    SWORD_WEAK_ABSORPTION(
            "미약한 흡수",
            RuneRarity.COMMON,
            RuneWeaponType.SWORD
    ),
    SWORD_STAR_SLASH(
            "별빛 절단",
            RuneRarity.COMMON,
            RuneWeaponType.SWORD
    ),
    SWORD_CHASE(
            "추격",
            RuneRarity.COMMON,
            RuneWeaponType.SWORD
    ),
    SWORD_GUARD_RESPONSE(
            "수호 반응",
            RuneRarity.COMMON,
            RuneWeaponType.SWORD
    ),

    // ===== 검: 희귀 =====
    SWORD_STAR_HEAL(
            "별빛 회복",
            RuneRarity.RARE,
            RuneWeaponType.SWORD
    ),
    SWORD_CONTINUOUS_SLASH(
            "연속 참격",
            RuneRarity.RARE,
            RuneWeaponType.SWORD
    ),
    SWORD_METEOR_FRAGMENT(
            "유성 파편",
            RuneRarity.RARE,
            RuneWeaponType.SWORD
    ),
    SWORD_DUEL_WILL(
            "결투의 의지",
            RuneRarity.RARE,
            RuneWeaponType.SWORD
    ),

    // ===== 검: 에픽 =====
    SWORD_METEOR_STRIKE(
            "유성 검격",
            RuneRarity.EPIC,
            RuneWeaponType.SWORD
    ),
    SWORD_STAR_BIND(
            "별의 속박",
            RuneRarity.EPIC,
            RuneWeaponType.SWORD
    ),
    SWORD_HALF_MOON(
            "반월",
            RuneRarity.EPIC,
            RuneWeaponType.SWORD
    ),
    SWORD_LIFE_TRANSFER(
            "생명 전환",
            RuneRarity.EPIC,
            RuneWeaponType.SWORD
    ),

    // ===== 검: 레전더리 =====
    SWORD_CELESTIAL_COLLAPSE(
            "천체 붕괴",
            RuneRarity.LEGENDARY,
            RuneWeaponType.SWORD
    ),
    SWORD_RADIANCE(
            "광휘",
            RuneRarity.LEGENDARY,
            RuneWeaponType.SWORD
    ),
    SWORD_STAR_OATH(
            "별의 맹세",
            RuneRarity.LEGENDARY,
            RuneWeaponType.SWORD
    ),
    SWORD_ECLIPSE(
            "일식",
            RuneRarity.LEGENDARY,
            RuneWeaponType.SWORD
    ),

    // ===== 검: 신화 =====
    SWORD_SUPERNOVA(
            "초신성",
            RuneRarity.MYTHIC,
            RuneWeaponType.SWORD
    ),
    SWORD_TIME_SLASH(
            "시간 절단",
            RuneRarity.MYTHIC,
            RuneWeaponType.SWORD
    ),
    SWORD_CONSTELLATION(
            "별자리의 검",
            RuneRarity.MYTHIC,
            RuneWeaponType.SWORD
    ),
    SWORD_SKY_JUDGMENT(
            "천공의 심판",
            RuneRarity.MYTHIC,
            RuneWeaponType.SWORD
    ),

    // ===== 도끼: 일반 =====
    AXE_SHOCK(
            "충격",
            RuneRarity.COMMON,
            RuneWeaponType.AXE
    ),
    AXE_CRACK_TRACE(
            "균열의 흔적",
            RuneRarity.COMMON,
            RuneWeaponType.AXE
    ),
    AXE_WEIGHT(
            "중압",
            RuneRarity.COMMON,
            RuneWeaponType.AXE
    ),
    AXE_BREAK(
            "파쇄",
            RuneRarity.COMMON,
            RuneWeaponType.AXE
    ),

    // ===== 도끼: 희귀 =====
    AXE_CRACK(
            "균열",
            RuneRarity.RARE,
            RuneWeaponType.AXE
    ),
    AXE_HUNTER(
            "사냥꾼",
            RuneRarity.RARE,
            RuneWeaponType.AXE
    ),
    AXE_SMASH(
            "강타",
            RuneRarity.RARE,
            RuneWeaponType.AXE
    ),
    AXE_BATTLE_INSTINCT(
            "전투 본능",
            RuneRarity.RARE,
            RuneWeaponType.AXE
    ),

    // ===== 도끼: 에픽 =====
    AXE_EXECUTION(
            "처형",
            RuneRarity.EPIC,
            RuneWeaponType.AXE
    ),
    AXE_SHATTER(
            "분쇄",
            RuneRarity.EPIC,
            RuneWeaponType.AXE
    ),
    AXE_EXPLOSION(
            "폭렬 타격",
            RuneRarity.EPIC,
            RuneWeaponType.AXE
    ),
    AXE_BLOOD_TRACE(
            "피의 추적",
            RuneRarity.EPIC,
            RuneWeaponType.AXE
    ),

    // ===== 도끼: 레전더리 =====
    AXE_BLOOD_OATH(
            "피의 맹세",
            RuneRarity.LEGENDARY,
            RuneWeaponType.AXE
    ),
    AXE_EARTH_SMASH(
            "대지 강타",
            RuneRarity.LEGENDARY,
            RuneWeaponType.AXE
    ),
    AXE_DEATH_MARK(
            "죽음의 낙인",
            RuneRarity.LEGENDARY,
            RuneWeaponType.AXE
    ),
    AXE_BERSERKER_RAGE(
            "광전사의 분노",
            RuneRarity.LEGENDARY,
            RuneWeaponType.AXE
    ),

    // ===== 도끼: 신화 =====
    AXE_DOOM_MARK(
            "멸망의 표식",
            RuneRarity.MYTHIC,
            RuneWeaponType.AXE
    ),
    AXE_FINAL_BLOW(
            "종말의 강타",
            RuneRarity.MYTHIC,
            RuneWeaponType.AXE
    ),
    AXE_BLOOD_STORM(
            "피의 폭풍",
            RuneRarity.MYTHIC,
            RuneWeaponType.AXE
    ),
    AXE_GIANT_STRENGTH(
            "거인의 힘",
            RuneRarity.MYTHIC,
            RuneWeaponType.AXE
    ),

    HELMET_COMMON("정화", RuneRarity.COMMON, RuneWeaponType.HELMET),
    HELMET_RARE("정화", RuneRarity.RARE, RuneWeaponType.HELMET),
    HELMET_EPIC("정화", RuneRarity.EPIC, RuneWeaponType.HELMET),
    HELMET_LEGENDARY("정화", RuneRarity.LEGENDARY, RuneWeaponType.HELMET),
    HELMET_MYTHIC("정화", RuneRarity.MYTHIC, RuneWeaponType.HELMET),
    CHESTPLATE_COMMON("별빛 장막", RuneRarity.COMMON, RuneWeaponType.CHESTPLATE),
    CHESTPLATE_RARE("별빛 장막", RuneRarity.RARE, RuneWeaponType.CHESTPLATE),
    CHESTPLATE_EPIC("별빛 장막", RuneRarity.EPIC, RuneWeaponType.CHESTPLATE),
    CHESTPLATE_LEGENDARY("별빛 장막", RuneRarity.LEGENDARY, RuneWeaponType.CHESTPLATE),
    CHESTPLATE_MYTHIC("별빛 장막", RuneRarity.MYTHIC, RuneWeaponType.CHESTPLATE),
    LEGGINGS_COMMON("닻의 의지", RuneRarity.COMMON, RuneWeaponType.LEGGINGS),
    LEGGINGS_RARE("닻의 의지", RuneRarity.RARE, RuneWeaponType.LEGGINGS),
    LEGGINGS_EPIC("닻의 의지", RuneRarity.EPIC, RuneWeaponType.LEGGINGS),
    LEGGINGS_LEGENDARY("닻의 의지", RuneRarity.LEGENDARY, RuneWeaponType.LEGGINGS),
    LEGGINGS_MYTHIC("닻의 의지", RuneRarity.MYTHIC, RuneWeaponType.LEGGINGS),
    BOOTS_COMMON("별걸음", RuneRarity.COMMON, RuneWeaponType.BOOTS),
    BOOTS_RARE("별걸음", RuneRarity.RARE, RuneWeaponType.BOOTS),
    BOOTS_EPIC("별걸음", RuneRarity.EPIC, RuneWeaponType.BOOTS),
    BOOTS_LEGENDARY("별걸음", RuneRarity.LEGENDARY, RuneWeaponType.BOOTS),
    BOOTS_MYTHIC("별걸음", RuneRarity.MYTHIC, RuneWeaponType.BOOTS),
    HELMET_SENTRY_COMMON("추적자", RuneRarity.COMMON, RuneWeaponType.HELMET, 1),
    HELMET_SENTRY_RARE("추적자", RuneRarity.RARE, RuneWeaponType.HELMET, 1),
    HELMET_SENTRY_EPIC("추적자", RuneRarity.EPIC, RuneWeaponType.HELMET, 1),
    HELMET_SENTRY_LEGENDARY("추적자", RuneRarity.LEGENDARY, RuneWeaponType.HELMET, 1),
    HELMET_SENTRY_MYTHIC("추적자", RuneRarity.MYTHIC, RuneWeaponType.HELMET, 1),
    HELMET_FOCUS_COMMON("집중", RuneRarity.COMMON, RuneWeaponType.HELMET, 2),
    HELMET_FOCUS_RARE("집중", RuneRarity.RARE, RuneWeaponType.HELMET, 2),
    HELMET_FOCUS_EPIC("집중", RuneRarity.EPIC, RuneWeaponType.HELMET, 2),
    HELMET_FOCUS_LEGENDARY("집중", RuneRarity.LEGENDARY, RuneWeaponType.HELMET, 2),
    HELMET_FOCUS_MYTHIC("집중", RuneRarity.MYTHIC, RuneWeaponType.HELMET, 2),
    HELMET_COMPOSURE_COMMON("평정", RuneRarity.COMMON, RuneWeaponType.HELMET, 3),
    HELMET_COMPOSURE_RARE("평정", RuneRarity.RARE, RuneWeaponType.HELMET, 3),
    HELMET_COMPOSURE_EPIC("평정", RuneRarity.EPIC, RuneWeaponType.HELMET, 3),
    HELMET_COMPOSURE_LEGENDARY("평정", RuneRarity.LEGENDARY, RuneWeaponType.HELMET, 3),
    HELMET_COMPOSURE_MYTHIC("평정", RuneRarity.MYTHIC, RuneWeaponType.HELMET, 3),
    CHESTPLATE_MELEE_COMMON("근접 방호", RuneRarity.COMMON, RuneWeaponType.CHESTPLATE, 1),
    CHESTPLATE_MELEE_RARE("근접 방호", RuneRarity.RARE, RuneWeaponType.CHESTPLATE, 1),
    CHESTPLATE_MELEE_EPIC("근접 방호", RuneRarity.EPIC, RuneWeaponType.CHESTPLATE, 1),
    CHESTPLATE_MELEE_LEGENDARY("근접 방호", RuneRarity.LEGENDARY, RuneWeaponType.CHESTPLATE, 1),
    CHESTPLATE_MELEE_MYTHIC("근접 방호", RuneRarity.MYTHIC, RuneWeaponType.CHESTPLATE, 1),
    CHESTPLATE_FIRE_COMMON("내열", RuneRarity.COMMON, RuneWeaponType.CHESTPLATE, 2),
    CHESTPLATE_FIRE_RARE("내열", RuneRarity.RARE, RuneWeaponType.CHESTPLATE, 2),
    CHESTPLATE_FIRE_EPIC("내열", RuneRarity.EPIC, RuneWeaponType.CHESTPLATE, 2),
    CHESTPLATE_FIRE_LEGENDARY("내열", RuneRarity.LEGENDARY, RuneWeaponType.CHESTPLATE, 2),
    CHESTPLATE_FIRE_MYTHIC("내열", RuneRarity.MYTHIC, RuneWeaponType.CHESTPLATE, 2),
    CHESTPLATE_LAST_STAND_COMMON("위기 방벽", RuneRarity.COMMON, RuneWeaponType.CHESTPLATE, 3),
    CHESTPLATE_LAST_STAND_RARE("위기 방벽", RuneRarity.RARE, RuneWeaponType.CHESTPLATE, 3),
    CHESTPLATE_LAST_STAND_EPIC("위기 방벽", RuneRarity.EPIC, RuneWeaponType.CHESTPLATE, 3),
    CHESTPLATE_LAST_STAND_LEGENDARY("위기 방벽", RuneRarity.LEGENDARY, RuneWeaponType.CHESTPLATE, 3),
    CHESTPLATE_LAST_STAND_MYTHIC("위기 방벽", RuneRarity.MYTHIC, RuneWeaponType.CHESTPLATE, 3),
    LEGGINGS_VITALITY_COMMON("생명력", RuneRarity.COMMON, RuneWeaponType.LEGGINGS, 1),
    LEGGINGS_VITALITY_RARE("생명력", RuneRarity.RARE, RuneWeaponType.LEGGINGS, 1),
    LEGGINGS_VITALITY_EPIC("생명력", RuneRarity.EPIC, RuneWeaponType.LEGGINGS, 1),
    LEGGINGS_VITALITY_LEGENDARY("생명력", RuneRarity.LEGENDARY, RuneWeaponType.LEGGINGS, 1),
    LEGGINGS_VITALITY_MYTHIC("생명력", RuneRarity.MYTHIC, RuneWeaponType.LEGGINGS, 1),
    LEGGINGS_BULWARK_COMMON("버팀목", RuneRarity.COMMON, RuneWeaponType.LEGGINGS, 2),
    LEGGINGS_BULWARK_RARE("버팀목", RuneRarity.RARE, RuneWeaponType.LEGGINGS, 2),
    LEGGINGS_BULWARK_EPIC("버팀목", RuneRarity.EPIC, RuneWeaponType.LEGGINGS, 2),
    LEGGINGS_BULWARK_LEGENDARY("버팀목", RuneRarity.LEGENDARY, RuneWeaponType.LEGGINGS, 2),
    LEGGINGS_BULWARK_MYTHIC("버팀목", RuneRarity.MYTHIC, RuneWeaponType.LEGGINGS, 2),
    LEGGINGS_RECOVERY_COMMON("재정비", RuneRarity.COMMON, RuneWeaponType.LEGGINGS, 3),
    LEGGINGS_RECOVERY_RARE("재정비", RuneRarity.RARE, RuneWeaponType.LEGGINGS, 3),
    LEGGINGS_RECOVERY_EPIC("재정비", RuneRarity.EPIC, RuneWeaponType.LEGGINGS, 3),
    LEGGINGS_RECOVERY_LEGENDARY("재정비", RuneRarity.LEGENDARY, RuneWeaponType.LEGGINGS, 3),
    LEGGINGS_RECOVERY_MYTHIC("재정비", RuneRarity.MYTHIC, RuneWeaponType.LEGGINGS, 3),
    BOOTS_ESCAPE_COMMON("탈출", RuneRarity.COMMON, RuneWeaponType.BOOTS, 1),
    BOOTS_ESCAPE_RARE("탈출", RuneRarity.RARE, RuneWeaponType.BOOTS, 1),
    BOOTS_ESCAPE_EPIC("탈출", RuneRarity.EPIC, RuneWeaponType.BOOTS, 1),
    BOOTS_ESCAPE_LEGENDARY("탈출", RuneRarity.LEGENDARY, RuneWeaponType.BOOTS, 1),
    BOOTS_ESCAPE_MYTHIC("탈출", RuneRarity.MYTHIC, RuneWeaponType.BOOTS, 1),
    BOOTS_AQUATIC_COMMON("물결", RuneRarity.COMMON, RuneWeaponType.BOOTS, 2),
    BOOTS_AQUATIC_RARE("물결", RuneRarity.RARE, RuneWeaponType.BOOTS, 2),
    BOOTS_AQUATIC_EPIC("물결", RuneRarity.EPIC, RuneWeaponType.BOOTS, 2),
    BOOTS_AQUATIC_LEGENDARY("물결", RuneRarity.LEGENDARY, RuneWeaponType.BOOTS, 2),
    BOOTS_AQUATIC_MYTHIC("물결", RuneRarity.MYTHIC, RuneWeaponType.BOOTS, 2),
    BOOTS_PATHFINDER_COMMON("개척자", RuneRarity.COMMON, RuneWeaponType.BOOTS, 3),
    BOOTS_PATHFINDER_RARE("개척자", RuneRarity.RARE, RuneWeaponType.BOOTS, 3),
    BOOTS_PATHFINDER_EPIC("개척자", RuneRarity.EPIC, RuneWeaponType.BOOTS, 3),
    BOOTS_PATHFINDER_LEGENDARY("개척자", RuneRarity.LEGENDARY, RuneWeaponType.BOOTS, 3),
    BOOTS_PATHFINDER_MYTHIC("개척자", RuneRarity.MYTHIC, RuneWeaponType.BOOTS, 3),
    BOW_HUNTER_COMMON("사냥꾼의 조준", RuneRarity.COMMON, RuneWeaponType.BOW, 0),
    BOW_HUNTER_RARE("사냥꾼의 조준", RuneRarity.RARE, RuneWeaponType.BOW, 0),
    BOW_HUNTER_EPIC("사냥꾼의 조준", RuneRarity.EPIC, RuneWeaponType.BOW, 0),
    BOW_HUNTER_LEGENDARY("사냥꾼의 조준", RuneRarity.LEGENDARY, RuneWeaponType.BOW, 0),
    BOW_HUNTER_MYTHIC("사냥꾼의 조준", RuneRarity.MYTHIC, RuneWeaponType.BOW, 0),
    BOW_FROST_COMMON("서리깃", RuneRarity.COMMON, RuneWeaponType.BOW, 1),
    BOW_FROST_RARE("서리깃", RuneRarity.RARE, RuneWeaponType.BOW, 1),
    BOW_FROST_EPIC("서리깃", RuneRarity.EPIC, RuneWeaponType.BOW, 1),
    BOW_FROST_LEGENDARY("서리깃", RuneRarity.LEGENDARY, RuneWeaponType.BOW, 1),
    BOW_FROST_MYTHIC("서리깃", RuneRarity.MYTHIC, RuneWeaponType.BOW, 1),
    BOW_MARK_COMMON("별빛 표식", RuneRarity.COMMON, RuneWeaponType.BOW, 2),
    BOW_MARK_RARE("별빛 표식", RuneRarity.RARE, RuneWeaponType.BOW, 2),
    BOW_MARK_EPIC("별빛 표식", RuneRarity.EPIC, RuneWeaponType.BOW, 2),
    BOW_MARK_LEGENDARY("별빛 표식", RuneRarity.LEGENDARY, RuneWeaponType.BOW, 2),
    BOW_MARK_MYTHIC("별빛 표식", RuneRarity.MYTHIC, RuneWeaponType.BOW, 2),
    BOW_FRAGMENT_COMMON("별파편", RuneRarity.COMMON, RuneWeaponType.BOW, 3),
    BOW_FRAGMENT_RARE("별파편", RuneRarity.RARE, RuneWeaponType.BOW, 3),
    BOW_FRAGMENT_EPIC("별파편", RuneRarity.EPIC, RuneWeaponType.BOW, 3),
    BOW_FRAGMENT_LEGENDARY("별파편", RuneRarity.LEGENDARY, RuneWeaponType.BOW, 3),
    BOW_FRAGMENT_MYTHIC("별파편", RuneRarity.MYTHIC, RuneWeaponType.BOW, 3),
    CROSSBOW_IMPACT_COMMON("관통 충격", RuneRarity.COMMON, RuneWeaponType.CROSSBOW, 0),
    CROSSBOW_IMPACT_RARE("관통 충격", RuneRarity.RARE, RuneWeaponType.CROSSBOW, 0),
    CROSSBOW_IMPACT_EPIC("관통 충격", RuneRarity.EPIC, RuneWeaponType.CROSSBOW, 0),
    CROSSBOW_IMPACT_LEGENDARY("관통 충격", RuneRarity.LEGENDARY, RuneWeaponType.CROSSBOW, 0),
    CROSSBOW_IMPACT_MYTHIC("관통 충격", RuneRarity.MYTHIC, RuneWeaponType.CROSSBOW, 0),
    CROSSBOW_SIEGE_COMMON("공성", RuneRarity.COMMON, RuneWeaponType.CROSSBOW, 1),
    CROSSBOW_SIEGE_RARE("공성", RuneRarity.RARE, RuneWeaponType.CROSSBOW, 1),
    CROSSBOW_SIEGE_EPIC("공성", RuneRarity.EPIC, RuneWeaponType.CROSSBOW, 1),
    CROSSBOW_SIEGE_LEGENDARY("공성", RuneRarity.LEGENDARY, RuneWeaponType.CROSSBOW, 1),
    CROSSBOW_SIEGE_MYTHIC("공성", RuneRarity.MYTHIC, RuneWeaponType.CROSSBOW, 1),
    CROSSBOW_REPULSE_COMMON("충격탄", RuneRarity.COMMON, RuneWeaponType.CROSSBOW, 2),
    CROSSBOW_REPULSE_RARE("충격탄", RuneRarity.RARE, RuneWeaponType.CROSSBOW, 2),
    CROSSBOW_REPULSE_EPIC("충격탄", RuneRarity.EPIC, RuneWeaponType.CROSSBOW, 2),
    CROSSBOW_REPULSE_LEGENDARY("충격탄", RuneRarity.LEGENDARY, RuneWeaponType.CROSSBOW, 2),
    CROSSBOW_REPULSE_MYTHIC("충격탄", RuneRarity.MYTHIC, RuneWeaponType.CROSSBOW, 2),
    CROSSBOW_WEAKEN_COMMON("무력화", RuneRarity.COMMON, RuneWeaponType.CROSSBOW, 3),
    CROSSBOW_WEAKEN_RARE("무력화", RuneRarity.RARE, RuneWeaponType.CROSSBOW, 3),
    CROSSBOW_WEAKEN_EPIC("무력화", RuneRarity.EPIC, RuneWeaponType.CROSSBOW, 3),
    CROSSBOW_WEAKEN_LEGENDARY("무력화", RuneRarity.LEGENDARY, RuneWeaponType.CROSSBOW, 3),
    CROSSBOW_WEAKEN_MYTHIC("무력화", RuneRarity.MYTHIC, RuneWeaponType.CROSSBOW, 3),
    TRIDENT_TIDE_COMMON("해류", RuneRarity.COMMON, RuneWeaponType.TRIDENT, 0),
    TRIDENT_TIDE_RARE("해류", RuneRarity.RARE, RuneWeaponType.TRIDENT, 0),
    TRIDENT_TIDE_EPIC("해류", RuneRarity.EPIC, RuneWeaponType.TRIDENT, 0),
    TRIDENT_TIDE_LEGENDARY("해류", RuneRarity.LEGENDARY, RuneWeaponType.TRIDENT, 0),
    TRIDENT_TIDE_MYTHIC("해류", RuneRarity.MYTHIC, RuneWeaponType.TRIDENT, 0),
    TRIDENT_EXECUTION_COMMON("심해 사냥", RuneRarity.COMMON, RuneWeaponType.TRIDENT, 1),
    TRIDENT_EXECUTION_RARE("심해 사냥", RuneRarity.RARE, RuneWeaponType.TRIDENT, 1),
    TRIDENT_EXECUTION_EPIC("심해 사냥", RuneRarity.EPIC, RuneWeaponType.TRIDENT, 1),
    TRIDENT_EXECUTION_LEGENDARY("심해 사냥", RuneRarity.LEGENDARY, RuneWeaponType.TRIDENT, 1),
    TRIDENT_EXECUTION_MYTHIC("심해 사냥", RuneRarity.MYTHIC, RuneWeaponType.TRIDENT, 1),
    TRIDENT_STORM_COMMON("뇌전", RuneRarity.COMMON, RuneWeaponType.TRIDENT, 2),
    TRIDENT_STORM_RARE("뇌전", RuneRarity.RARE, RuneWeaponType.TRIDENT, 2),
    TRIDENT_STORM_EPIC("뇌전", RuneRarity.EPIC, RuneWeaponType.TRIDENT, 2),
    TRIDENT_STORM_LEGENDARY("뇌전", RuneRarity.LEGENDARY, RuneWeaponType.TRIDENT, 2),
    TRIDENT_STORM_MYTHIC("뇌전", RuneRarity.MYTHIC, RuneWeaponType.TRIDENT, 2),
    TRIDENT_RECOVERY_COMMON("회생", RuneRarity.COMMON, RuneWeaponType.TRIDENT, 3),
    TRIDENT_RECOVERY_RARE("회생", RuneRarity.RARE, RuneWeaponType.TRIDENT, 3),
    TRIDENT_RECOVERY_EPIC("회생", RuneRarity.EPIC, RuneWeaponType.TRIDENT, 3),
    TRIDENT_RECOVERY_LEGENDARY("회생", RuneRarity.LEGENDARY, RuneWeaponType.TRIDENT, 3),
    TRIDENT_RECOVERY_MYTHIC("회생", RuneRarity.MYTHIC, RuneWeaponType.TRIDENT, 3);

    private final String koreanName;
    private final RuneRarity rarity;
    private final RuneWeaponType weaponType;
    private final int variant;

    RuneEffect(
            String koreanName,
            RuneRarity rarity,
            RuneWeaponType weaponType
    ) {
        this(koreanName, rarity, weaponType, 0);
    }

    RuneEffect(String koreanName, RuneRarity rarity, RuneWeaponType weaponType, int variant) {
        this.variant = variant;
        this.koreanName = koreanName;
        this.rarity = rarity;
        this.weaponType = weaponType;
    }

    public int getVariant() { return variant; }

    public String getKoreanName() {
        return koreanName;
    }

    public RuneRarity getRarity() {
        return rarity;
    }

    public RuneWeaponType getWeaponType() {
        return weaponType;
    }
}