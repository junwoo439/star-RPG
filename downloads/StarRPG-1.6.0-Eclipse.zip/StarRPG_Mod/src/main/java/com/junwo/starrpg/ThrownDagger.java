package com.junwo.starrpg;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.*;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.*;

/** A real, saved projectile owns the thrown item until it drops it exactly once. */
public final class ThrownDagger extends AbstractArrow implements ItemSupplier {
    private double travelled;private boolean settled;
    public ThrownDagger(EntityType<? extends ThrownDagger> type,Level level){super(type,level);}
    public ThrownDagger(Level level,Player p,ItemStack stack){super(ModEntities.THROWN_DAGGER.get(),p,level,stack,stack);pickup=p.hasInfiniteMaterials()?Pickup.CREATIVE_ONLY:Pickup.ALLOWED;}
    @Override protected ItemStack getDefaultPickupItem(){return new ItemStack(StarRPG.STAR_DAGGER.get());}
    @Override public ItemStack getItem(){return getPickupItem();}
    @Override protected boolean canHitEntity(Entity entity){return super.canHitEntity(entity)&&(!(getOwner() instanceof Player p)||!(entity instanceof LivingEntity living)||CombatRules.canHarm(p,living));}
    @Override protected void onHitEntity(EntityHitResult hit){
        if(!level().isClientSide() && getOwner() instanceof Player p && hit.getEntity() instanceof LivingEntity target && CombatRules.canHarm(p,target)){
            var stack=getPickupItem();float damage=4+EnhancementData.level(stack)*0.6F;
            if(SpecialWeaponEffects.behind(p,target))damage*=1.2F;
            target.hurt(new net.minecraft.world.damagesource.DamageSource(level().registryAccess().registryOrThrow(net.minecraft.core.registries.Registries.DAMAGE_TYPE).getHolderOrThrow(WeaponAbilities.DAGGER_DAMAGE),this,p),damage);
        }
        settle();
    }
    @Override protected void onHitBlock(BlockHitResult hit){super.onHitBlock(hit);settle();}
    public void settle(){
        if(level().isClientSide()||settled||isRemoved())return;settled=true;
        if(pickup==Pickup.ALLOWED){var drop=spawnAtLocation(getPickupItem(),0.1F);if(drop!=null)drop.setDefaultPickUpDelay();}discard();
    }
    @Override public void tick(){if(!level().isClientSide()){travelled+=getDeltaMovement().length();if(travelled>=10||tickCount>=200){settle();return;}}super.tick();}
    @Override public void addAdditionalSaveData(CompoundTag tag){super.addAdditionalSaveData(tag);tag.putDouble("starrpg_travel",travelled);}
    @Override public void readAdditionalSaveData(CompoundTag tag){super.readAdditionalSaveData(tag);travelled=tag.getDouble("starrpg_travel");}
}
