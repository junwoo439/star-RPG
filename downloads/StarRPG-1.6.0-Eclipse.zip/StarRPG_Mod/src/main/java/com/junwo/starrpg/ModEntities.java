package com.junwo.starrpg;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.*;
import net.neoforged.neoforge.registries.*;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(Registries.ENTITY_TYPE, StarRPG.MODID);
    public static final DeferredHolder<EntityType<?>,EntityType<ThrownDagger>> THROWN_DAGGER=ENTITIES.register("thrown_dagger",
        ()->EntityType.Builder.<ThrownDagger>of(ThrownDagger::new,MobCategory.MISC).sized(0.25F,0.25F).clientTrackingRange(8).updateInterval(1).build("starrpg:thrown_dagger"));
    public static final DeferredHolder<EntityType<?>,EntityType<GiantArrow>> GIANT_ARROW=ENTITIES.register("giant_arrow",
        ()->EntityType.Builder.<GiantArrow>of(GiantArrow::new,MobCategory.MISC).sized(0.9F,0.9F).clientTrackingRange(8).updateInterval(1).build("starrpg:giant_arrow"));
    public static final DeferredHolder<EntityType<?>, EntityType<ZombieHook>> ZOMBIE_HOOK = ENTITIES.register("zombie_hook",
            () -> EntityType.Builder.<ZombieHook>of(ZombieHook::new, MobCategory.MISC)
                    .sized(0.25F, 0.25F).clientTrackingRange(4).updateInterval(1).noSave().build("starrpg:zombie_hook"));
}
