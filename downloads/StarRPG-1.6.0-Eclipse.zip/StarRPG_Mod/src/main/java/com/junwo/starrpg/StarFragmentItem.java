package com.junwo.starrpg;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class StarFragmentItem extends Item {

    public StarFragmentItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack itemStack = player.getItemInHand(hand);

        if (!level.isClientSide() && player instanceof ServerPlayer serverPlayer) {
        	serverPlayer.openMenu(new SimpleMenuProvider(
        	        (containerId, playerInventory, openedPlayer) ->
        	                new EnhancementMenu(containerId, playerInventory),
        	        Component.literal("별조각 강화")
        	));
        }

        return InteractionResultHolder.sidedSuccess(itemStack, level.isClientSide());
    }
}