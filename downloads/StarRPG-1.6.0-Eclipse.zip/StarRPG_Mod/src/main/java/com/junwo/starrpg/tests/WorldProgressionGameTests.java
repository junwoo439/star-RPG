package com.junwo.starrpg.tests;

import com.junwo.starrpg.*;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.*;

@GameTestHolder(StarRPG.MODID)
@PrefixGameTestTemplate(false)
public class WorldProgressionGameTests {
    @GameTest(template="empty") public static void existingEnemyUpgradesWithoutHealing(GameTestHelper h) {
        Zombie zombie=EntityType.ZOMBIE.create(h.getLevel());
        MonsterProgression.applyTier(zombie,1);zombie.setHealth(8);
        MonsterProgression.upgradeTier(zombie,5);
        h.assertTrue(zombie.getMaxHealth()==42.5F && zombie.getHealth()==8,"Difficulty increase healed enemy or stacked stats");
        CompoundTag tag=new CompoundTag();zombie.saveWithoutId(tag);
        Zombie restored=EntityType.ZOMBIE.create(h.getLevel());restored.load(tag);
        MonsterProgression.upgradeTier(restored,5);
        h.assertTrue(restored.getMaxHealth()==42.5F && restored.getHealth()==8,"Reload stacked modifiers/healed");
        MonsterProgression.upgradeTier(restored,0);
        h.assertTrue(MonsterProgression.tier(restored)==5,"Existing enemy downgraded");h.succeed();
    }
    @GameTest(template="empty") public static void lateZombiesHavePartialGearWithoutRerolls(GameTestHelper h) {
        Zombie zombie=EntityType.ZOMBIE.create(h.getLevel());zombie.getPersistentData().putInt("starrpg_hook_roll",99);
        ZombieEquipment.equip(zombie,5);
        h.assertTrue(zombie.getMainHandItem().is(Items.IRON_SWORD) && !zombie.getMainHandItem().isEnchanted(),"Missing iron sword or vanilla enchantment retained");
        int pieces=0;
        for(EquipmentSlot slot:new EquipmentSlot[]{EquipmentSlot.HEAD,EquipmentSlot.CHEST,EquipmentSlot.LEGS,EquipmentSlot.FEET}) {
            if(!zombie.getItemBySlot(slot).isEmpty()) { pieces++;h.assertTrue(!zombie.getItemBySlot(slot).isEnchanted(),"Vanilla enchantment retained"); }
        }
        h.assertTrue(pieces>=2 && pieces<=3,"Zombie has full armor or too few pieces");
        zombie.getMainHandItem().setDamageValue(100);
        CompoundTag tag=new CompoundTag();zombie.saveWithoutId(tag);
        Zombie restored=EntityType.ZOMBIE.create(h.getLevel());restored.load(tag);ZombieEquipment.equip(restored,5);
        h.assertTrue(restored.getMainHandItem().getDamageValue()==100,"Reload repaired/rerolled generated gear");
        h.assertTrue(tag.getList("HandDropChances",5).getFloat(0)==0,"Generated weapon can be farmed");h.succeed();
    }
    @GameTest(template="empty") public static void zombieEquipmentPreservesExistingItems(GameTestHelper h) {
        Zombie zombie=EntityType.ZOMBIE.create(h.getLevel());
        zombie.setItemSlot(EquipmentSlot.MAINHAND,new ItemStack(Items.NETHERITE_AXE));
        zombie.setItemSlot(EquipmentSlot.HEAD,new ItemStack(Items.CARVED_PUMPKIN));
        zombie.getPersistentData().putInt("starrpg_hook_roll",0);ZombieEquipment.equip(zombie,5);
        h.assertTrue(zombie.getMainHandItem().is(Items.NETHERITE_AXE) && zombie.getItemBySlot(EquipmentSlot.HEAD).is(Items.CARVED_PUMPKIN),"Replaced player/native gear");
        Zombie fisher=EntityType.ZOMBIE.create(h.getLevel());fisher.getPersistentData().putInt("starrpg_hook_roll",0);
        ZombieEquipment.equip(fisher,1);h.assertTrue(!fisher.getMainHandItem().is(Items.FISHING_ROD),"Hook before tier 2");
        ZombieEquipment.equip(fisher,2);h.assertTrue(fisher.getMainHandItem().is(Items.FISHING_ROD),"Tier 2 fisher missing rod");h.succeed();
    }
    @GameTest(template="empty") public static void helmetVisionNeverEntersFlickerWindow(GameTestHelper h) {
        Player player=h.makeMockPlayer(GameType.SURVIVAL);
        // Upgrade from the old 3-second helmet effect as well as testing repeated refreshes.
        player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION,60,0,false,false,true));
        for(int i=0;i<1200;i++) {
            HelmetNightVision.update(player,true);
            var effect=player.getEffect(MobEffects.NIGHT_VISION);
            h.assertTrue(effect!=null && effect.getDuration()>=300,"Helmet effect entered flashing window");
            effect.tick(player,()->{});
        }
        HelmetNightVision.update(player,false);
        h.assertTrue(!player.hasEffect(MobEffects.NIGHT_VISION),"Helmet vision remained after unequip");h.succeed();
    }
    @GameTest(template="empty") public static void helmetDoesNotRemoveLongPotionOrInfiniteVision(GameTestHelper h) {
        Player player=h.makeMockPlayer(GameType.SURVIVAL);
        HelmetNightVision.update(player,true);
        player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION,2400,0));
        HelmetNightVision.update(player,false);
        h.assertTrue(player.hasEffect(MobEffects.NIGHT_VISION) && player.getEffect(MobEffects.NIGHT_VISION).getDuration()==2400,"Helmet removed potion");
        player.removeEffect(MobEffects.NIGHT_VISION);
        player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION,-1,0));
        HelmetNightVision.update(player,true);HelmetNightVision.update(player,false);
        h.assertTrue(player.getEffect(MobEffects.NIGHT_VISION).isInfiniteDuration(),"Helmet removed infinite vision");h.succeed();
    }
    @GameTest(template="empty") public static void hookPullsTowardZombieAndPreventsChainPulls(GameTestHelper h) {
        Zombie zombie=h.spawn(EntityType.ZOMBIE,1,2,1);zombie.setItemSlot(EquipmentSlot.MAINHAND,new ItemStack(Items.FISHING_ROD));
        Player player=h.makeMockPlayer(GameType.SURVIVAL);player.setPos(zombie.position().add(2,0,0));zombie.setTarget(player);
        h.assertTrue(zombie.hasLineOfSight(player),"Test arena obstructed hook sightline");
        h.assertTrue(zombie.getTarget()==player,"Test zombie rejected its target");
        h.assertTrue(ZombieHook.pull(zombie,player),"Valid hook did not pull: noAI="+zombie.isNoAi()+", alive="+player.isAlive()+", creative="+player.isCreative()+", distance="+zombie.distanceToSqr(player));
        h.assertTrue(player.getDeltaMovement().x<0 && player.getDeltaMovement().length()<1,"Pull direction/force wrong");
        h.assertTrue(!ZombieHook.pull(zombie,player),"Chain pull immunity missing");
        Player creative=h.makeMockPlayer(GameType.CREATIVE);creative.setPos(player.position());zombie.setTarget(creative);
        h.assertTrue(!ZombieHook.pull(zombie,creative),"Hook pulled creative player");h.succeed();
    }
    @GameTest(template="empty") public static void hookCannotPullThroughWall(GameTestHelper h) {
        Zombie zombie=h.spawn(EntityType.ZOMBIE,1,2,1);zombie.setItemSlot(EquipmentSlot.MAINHAND,new ItemStack(Items.FISHING_ROD));
        Player player=h.makeMockPlayer(GameType.SURVIVAL);player.setPos(zombie.position().add(3,0,0));zombie.setTarget(player);
        h.setBlock(new BlockPos(2,3,1),Blocks.STONE);
        h.assertTrue(!ZombieHook.pull(zombie,player),"Hook pulled through wall");h.succeed();
    }
    @GameTest(template="empty",timeoutTicks=60) public static void hookProjectileCollidesAndExpires(GameTestHelper h) {
        Zombie zombie=h.spawn(EntityType.ZOMBIE,1,2,1);zombie.setNoAi(true);
        h.setBlock(new BlockPos(3,3,1),Blocks.STONE);
        ZombieHook blocked=new ZombieHook(h.getLevel(),zombie);blocked.shoot(1,0,0,1.2F,0);h.getLevel().addFreshEntity(blocked);
        ZombieHook missed=new ZombieHook(h.getLevel(),zombie);missed.setPos(zombie.position().add(0,6,0));missed.shoot(0,1,0,1,0);h.getLevel().addFreshEntity(missed);
        h.runAfterDelay(5,()->h.assertTrue(blocked.isRemoved(),"Hook passed through solid block"));
        h.runAfterDelay(25,()->{h.assertTrue(missed.isRemoved(),"Missed projectile never expired");h.succeed();});
    }

    @GameTest(template="hook_arena",timeoutTicks=60) public static void rodAttackHasWindupAndCooldown(GameTestHelper h) {
        Zombie zombie=h.spawn(EntityType.ZOMBIE,2,2,3);zombie.removeFreeWill();zombie.setNoGravity(true);
        zombie.setItemSlot(EquipmentSlot.MAINHAND,new ItemStack(Items.FISHING_ROD));
        Player player=h.makeMockPlayer(GameType.SURVIVAL);player.setPos(zombie.position().add(6,0,0));zombie.setTarget(player);
        ZombieHookAttack.update(zombie);
        h.assertTrue(zombie.getPersistentData().contains("starrpg_hook_cast"),"Rod never started windup");
        h.runAfterDelay(10,()->h.assertTrue(h.getLevel().getEntitiesOfClass(ZombieHook.class,zombie.getBoundingBox().inflate(14)).isEmpty(),"Hook fired without warning"));
        h.runAfterDelay(22,()->{
            h.assertTrue(!h.getLevel().getEntitiesOfClass(ZombieHook.class,zombie.getBoundingBox().inflate(14)).isEmpty(),"Rod did not launch projectile");
            long cooldown=zombie.getPersistentData().getLong("starrpg_hook_cooldown");
            h.assertTrue(cooldown>h.getLevel().getGameTime()+100,"Missing hook cooldown");
            ZombieHookAttack.update(zombie);
            h.assertTrue(!zombie.getPersistentData().contains("starrpg_hook_cast"),"Started a second cast during cooldown");h.succeed();
        });
    }
}
