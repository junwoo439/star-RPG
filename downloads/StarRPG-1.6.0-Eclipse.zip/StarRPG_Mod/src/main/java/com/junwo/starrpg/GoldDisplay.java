package com.junwo.starrpg;

import java.util.*;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.world.BossEvent;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;

@EventBusSubscriber(modid=StarRPG.MODID)
public final class GoldDisplay {
    private static final Map<UUID,ServerBossEvent> BARS=new HashMap<>();
    @SubscribeEvent public static void tick(ServerTickEvent.Post e){
        if(e.getServer().getTickCount()%10!=0)return;
        for(var p:e.getServer().getPlayerList().getPlayers()){
            var bar=BARS.computeIfAbsent(p.getUUID(),id->new ServerBossEvent(Component.literal("골드"),BossEvent.BossBarColor.YELLOW,BossEvent.BossBarOverlay.PROGRESS));
            if(!bar.getPlayers().contains(p)){bar.removeAllPlayers();bar.addPlayer(p);}
            bar.setVisible(Config.ECONOMY_ENABLED.get());bar.setProgress(1);
            var name=Component.literal("골드 "+String.format(java.util.Locale.ROOT,"%,d",StarWallet.get(p.server).balance(p.getUUID()))+" G  |  Shift+H 메뉴");
            if(!bar.getName().equals(name))bar.setName(name);
        }
    }
    @SubscribeEvent public static void logout(PlayerEvent.PlayerLoggedOutEvent e){var bar=BARS.remove(e.getEntity().getUUID());if(bar!=null)bar.removeAllPlayers();}
    @SubscribeEvent public static void stop(ServerStoppedEvent e){BARS.values().forEach(ServerBossEvent::removeAllPlayers);BARS.clear();}
}
