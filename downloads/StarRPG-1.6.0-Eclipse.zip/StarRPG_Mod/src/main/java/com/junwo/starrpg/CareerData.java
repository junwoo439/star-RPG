package com.junwo.starrpg;

import java.util.*;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

public final class CareerData extends SavedData {
    public static final class Profile {
        public int selected=-1; public int[] ranks=new int[4],xp=new int[4],bosses=new int[4];public long switchReady;
        public int rank(){return selected<0?0:ranks[selected];}
        public int xp(){return selected<0?0:xp[selected];}
        public int bosses(){return selected<0?0:bosses[selected];}
    }
    private final Map<UUID,Profile> profiles=new HashMap<>();
    public Profile profile(UUID id){return profiles.computeIfAbsent(id,k->new Profile());}
    public static CareerData get(MinecraftServer server){return server.overworld().getDataStorage().computeIfAbsent(new Factory<>(CareerData::new,CareerData::load),"starrpg_careers");}
    public static CareerData load(CompoundTag tag,HolderLookup.Provider lookup){
        var data=new CareerData();for(Tag raw:tag.getList("profiles",Tag.TAG_COMPOUND)){
            var t=(CompoundTag)raw;if(!t.hasUUID("id"))continue;var p=data.profile(t.getUUID("id"));p.selected=Math.clamp(t.getInt("selected"),-1,3);
            for(int i=0;i<4;i++){p.ranks[i]=Math.clamp(t.getInt("rank"+i),0,3);p.xp[i]=Math.clamp(t.getInt("xp"+i),0,1000000);p.bosses[i]=Math.clamp(t.getInt("boss"+i),0,10000);}
            p.switchReady=Math.max(0,t.getLong("switchReady"));
        }return data;
    }
    @Override public CompoundTag save(CompoundTag tag,HolderLookup.Provider lookup){
        var list=new ListTag();profiles.forEach((id,p)->{var t=new CompoundTag();t.putUUID("id",id);t.putInt("selected",p.selected);t.putLong("switchReady",p.switchReady);
            for(int i=0;i<4;i++){t.putInt("rank"+i,p.ranks[i]);t.putInt("xp"+i,p.xp[i]);t.putInt("boss"+i,p.bosses[i]);}list.add(t);});tag.put("profiles",list);return tag;
    }
}
