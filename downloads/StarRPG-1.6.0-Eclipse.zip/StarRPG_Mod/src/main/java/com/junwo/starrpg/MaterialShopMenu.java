package com.junwo.starrpg;

import net.minecraft.world.entity.player.*;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.SimpleContainer;

public final class MaterialShopMenu extends AbstractContainerMenu {
    private final Player owner;
    private final ContainerData data=new SimpleContainerData(15);
    private final SimpleContainer sale=new SimpleContainer(1);
    public int clientTab;
    public MaterialShopMenu(int id, Inventory inventory) {
        super(ModMenus.MATERIAL_SHOP.get(),id);owner=inventory.player;
        addSlot(new Slot(sale,0,25,79){@Override public boolean isActive(){return !owner.level().isClientSide()||clientTab==1;}});
        for(int row=0;row<3;row++)for(int col=0;col<9;col++)addSlot(new Slot(inventory,col+row*9+9,79+col*18,142+row*18));
        for(int col=0;col<9;col++)addSlot(new Slot(inventory,col,79+col*18,202));
        addDataSlots(data);refresh();
    }
    private void refresh() {
        if(owner.level().isClientSide()||owner.getServer()==null)return;
        int balance=StarWallet.get(owner.getServer()).balance(owner.getUUID());data.set(0,balance&65535);data.set(1,(balance>>>16)&65535);
        for(var p:Economy.Product.values())data.set(2+p.ordinal(),p.price());data.set(5,Config.ECONOMY_ENABLED.get()?1:0);
        var c=Careers.profile(owner);data.set(6,c.selected);data.set(7,c.rank());data.set(8,c.xp()&65535);data.set(9,c.xp()>>>16);data.set(10,c.bosses());
        data.set(11,SellPrices.unit(sale.getItem(0)));var element=BowElements.get(owner.getMainHandItem());data.set(12,element==null?-1:element.ordinal());
        data.set(13,owner.getMainHandItem().getItem() instanceof net.minecraft.world.item.BowItem?1:0);
        data.set(14,owner.isCreative()||owner.isSpectator()?0:1);
    }
    public int balance(){return (data.get(0)&65535)|((data.get(1)&65535)<<16);}
    public int price(int product){return data.get(2+product);}public boolean enabled(){return data.get(5)==1;}
    public int job(){return data.get(6);}public int rank(){return data.get(7);}public int xp(){return(data.get(8)&65535)|((data.get(9)&65535)<<16);}
    public int bosses(){return data.get(10);}public int sellPrice(){return data.get(11);}public int element(){return data.get(12);}public boolean holdingBow(){return data.get(13)==1;}
    public boolean canSell(){return data.get(14)==1;}public ItemStack saleItem(){return sale.getItem(0);}
    @Override public void broadcastChanges(){refresh();super.broadcastChanges();}
    @Override public boolean clickMenuButton(Player player,int button){
        if(player!=owner||player.level().isClientSide()||!player.isAlive()||ControlEffects.stunned(player))return false;
        boolean success=false;
        if(button>=0&&button<6){var product=Economy.Product.values()[button/2];int count=button%2==0?1:8;var result=Economy.buy(player,product,count);player.displayClientMessage(Economy.feedback(result,product,count),false);success=result==Economy.Purchase.OK;}
        else if(button==20||button==21){success=SellPrices.sell(player,sale.getItem(0),button==20?1:sale.getItem(0).getCount());sale.setChanged();}
        else if(button>=40&&button<=43)success=Careers.select(player,button-40);
        else if(button==50)success=Careers.advance(player);
        else if(button>=60&&button<=63)success=BowElements.engrave(player,button-60);
        broadcastChanges();return success;
    }
    @Override public boolean stillValid(Player player){return player==owner&&player.isAlive();}
    @Override public void removed(Player player){super.removed(player);if(!player.level().isClientSide())clearContainer(player,sale);}
    @Override public ItemStack quickMoveStack(Player player,int index){
        if(index<0||index>=slots.size())return ItemStack.EMPTY;var slot=slots.get(index);if(!slot.hasItem())return ItemStack.EMPTY;
        var stack=slot.getItem();var copy=stack.copy();if(index==0){if(!moveItemStackTo(stack,1,37,true))return ItemStack.EMPTY;}
        else if(!moveItemStackTo(stack,0,1,false))return ItemStack.EMPTY;
        if(stack.isEmpty())slot.setByPlayer(ItemStack.EMPTY);else slot.setChanged();slot.onTake(player,stack);return copy;
    }
}
