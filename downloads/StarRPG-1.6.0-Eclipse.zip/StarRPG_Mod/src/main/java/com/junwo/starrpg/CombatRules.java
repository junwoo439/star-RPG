package com.junwo.starrpg;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;

@net.neoforged.fml.common.EventBusSubscriber(modid = StarRPG.MODID)
public final class CombatRules {
    private record AttackContext(long tick, float strength) {}
    private static final java.util.Map<java.util.UUID, AttackContext> ATTACKS = new java.util.HashMap<>();
    @net.neoforged.bus.api.SubscribeEvent
    public static void attack(net.neoforged.neoforge.event.entity.player.AttackEntityEvent event) {
        Player player = event.getEntity();
        if (!player.level().isClientSide()) ATTACKS.put(player.getUUID(),
                new AttackContext(player.level().getGameTime(), player.getAttackStrengthScale(0.5F)));
    }
    private static float strength(DamageSource source) {
        if (!(source.getEntity() instanceof Player player)) return 0;
        AttackContext context = ATTACKS.get(player.getUUID());
        return context == null || context.tick() != player.level().getGameTime() ? 1.0F : context.strength();
    }
    public static float attackScale(DamageSource source) { float strength = strength(source); return 0.2F + strength * strength * 0.8F; }
    public static boolean charged(DamageSource source) { return strength(source) >= 0.9F; }
    public static void pruneState(long now) { ATTACKS.entrySet().removeIf(e -> now - e.getValue().tick() > 20); }
    public static void clearState() { ATTACKS.clear(); }

    public static final ResourceKey<DamageType> RUNE = ResourceKey.create(Registries.DAMAGE_TYPE,
            ResourceLocation.fromNamespaceAndPath(StarRPG.MODID, "rune"));
    public static boolean primary(DamageSource source) {
        return source.is(DamageTypes.PLAYER_ATTACK) && source.getDirectEntity() instanceof Player;
    }
    public static boolean canHarm(Player player, LivingEntity target) {
        if (target == player || !target.isAlive() || player.isAlliedTo(target) || target.isAlliedTo(player)) return false;
        if (target instanceof TamableAnimal pet && pet.isTame()) return false;
        if (target instanceof net.minecraft.world.entity.animal.horse.AbstractHorse horse && horse.isTamed()) return false;
        if (target instanceof Player other) {
            if (other.isCreative() || other.isSpectator() || !player.canHarmPlayer(other)) return false;
            if (player instanceof ServerPlayer sp && !sp.server.isPvpAllowed()) return false;
        }
        return true;
    }
    public static void runeDamage(Player player, LivingEntity target, float damage) {
        if (!canHarm(player, target)) return;
        DamageSource source = new DamageSource(player.level().registryAccess()
                .registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(RUNE), player);
        target.hurt(source, damage);
    }
}
