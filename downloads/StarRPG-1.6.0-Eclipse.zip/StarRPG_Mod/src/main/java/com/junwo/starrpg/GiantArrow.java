package com.junwo.starrpg;

import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;

public final class GiantArrow extends AbstractArrow {
    public GiantArrow(EntityType<? extends GiantArrow> type,Level level){super(type,level);}
    public GiantArrow(Level level,Player p,ItemStack ammo,ItemStack bow){super(ModEntities.GIANT_ARROW.get(),p,level,ammo,bow);setBaseDamage(3.2);pickup=p.hasInfiniteMaterials()?Pickup.CREATIVE_ONLY:Pickup.ALLOWED;}
    @Override public byte getPierceLevel(){return (byte)2;}
    @Override protected void doPostHurtEffects(LivingEntity target){
        super.doPostHurtEffects(target);
        var contents=getPickupItemStackOrigin().getOrDefault(net.minecraft.core.component.DataComponents.POTION_CONTENTS,net.minecraft.world.item.alchemy.PotionContents.EMPTY);
        contents.potion().ifPresent(potion->{for(var effect:potion.value().getEffects())target.addEffect(new net.minecraft.world.effect.MobEffectInstance(effect.getEffect(),Math.max(effect.mapDuration(t->t/8),1),effect.getAmplifier(),effect.isAmbient(),effect.isVisible()),getEffectSource());});
        for(var effect:contents.customEffects())target.addEffect(new net.minecraft.world.effect.MobEffectInstance(effect),getEffectSource());
        if(getPickupItemStackOrigin().is(Items.SPECTRAL_ARROW))target.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.GLOWING,200,0),getEffectSource());
    }
    @Override protected ItemStack getDefaultPickupItem(){return new ItemStack(Items.ARROW);}
    @Override protected boolean canHitEntity(Entity entity){return super.canHitEntity(entity)&&(!(getOwner() instanceof Player p)||!(entity instanceof LivingEntity living)||CombatRules.canHarm(p,living));}
}
