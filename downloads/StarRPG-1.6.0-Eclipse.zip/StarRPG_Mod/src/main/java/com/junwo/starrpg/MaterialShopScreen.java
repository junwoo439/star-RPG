package com.junwo.starrpg;

import java.util.*;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

public final class MaterialShopScreen extends AbstractContainerScreen<MaterialShopMenu> {
    private final List<Button> pageButtons=new ArrayList<>();
    private final List<Integer> ids=new ArrayList<>();
    public MaterialShopScreen(MaterialShopMenu m,Inventory i,Component t){super(m,i,t);imageWidth=320;imageHeight=230;}
    @Override protected void init(){super.init();build();}
    private void action(String text,int id,int x,int y,int width){
        var b=Button.builder(Component.literal(text),button->{if(minecraft!=null&&minecraft.gameMode!=null)minecraft.gameMode.handleInventoryButtonClick(menu.containerId,id);}).bounds(leftPos+x,topPos+y,width,18).build();
        if(id>=40&&id<=43)b.setTooltip(net.minecraft.client.gui.components.Tooltip.create(Component.literal(new String[]{
            "전직 단계당 최대 체력 +2, 방어력 +1. G: 저항 I, 4~6초 / 재사용 20초",
            "전직 단계당 이동속도 +2%. G: 전방 돌진 / 재사용 12초",
            "전직 단계당 화살 피해 +3%. G: 6초간 화살 피해 +10% / 재사용 20초",
            "G: 시야 앞 12칸 마법 공격, 피해 6/8/10 / 재사용 8초"}[id-40])));
        pageButtons.add(addRenderableWidget(b));ids.add(id);
    }
    private void build(){
        clearWidgets();pageButtons.clear();ids.clear();String[] names={"상점","판매","직업·전직","활 속성"};
        for(int i=0;i<4;i++){final int tab=i;var b=addRenderableWidget(Button.builder(Component.literal(names[i]),button->{menu.clientTab=tab;build();}).bounds(leftPos+8+i*77,topPos+27,74,18).build());b.active=i!=menu.clientTab;}
        switch(menu.clientTab){
            case 0->{for(int i=0;i<3;i++){action("1개",i*2,204,58+i*25,46);action("8개",i*2+1,258,58+i*25,46);}}
            case 1->{action("1개 판매",20,158,79,68);action("전량 판매",21,233,79,72);}
            case 2->{for(int i=0;i<4;i++)action(Careers.NAMES[i],40+i,8+i*77,71,74);action("다음 전직",50,237,112,68);}
            case 3->{String[] n={"얼음","전기","어둠","빛"};for(int i=0;i<4;i++)action(n[i],60+i,8+i*77,79,74);}
        }
        updateButtons();
    }
    private void updateButtons(){for(int i=0;i<ids.size();i++){int id=ids.get(i);boolean active=true;
        if(id<6)active=menu.enabled()&&menu.price(id/2)>0&&menu.balance()>=menu.price(id/2)*(id%2==0?1:8);
        else if(id==20||id==21)active=menu.enabled()&&menu.canSell()&&menu.sellPrice()>0&&!menu.saleItem().isEmpty();
        else if(id>=40&&id<=43)active=menu.job()!=id-40;
        else if(id==50)active=menu.rank()>0&&menu.rank()<3;
        else if(id>=60)active=menu.holdingBow()&&menu.element()!=id-60&&menu.enabled();pageButtons.get(i).active=active;
    }}
    @Override protected void containerTick(){super.containerTick();updateButtons();}
    @Override protected void renderBg(GuiGraphics g,float t,int x,int y){
        g.fill(leftPos,topPos,leftPos+imageWidth,topPos+imageHeight,0xFF16212C);g.fill(leftPos+2,topPos+2,leftPos+imageWidth-2,topPos+imageHeight-2,0xFF263644);
        for(var slot:menu.slots)if(slot.isActive())g.fill(leftPos+slot.x-1,topPos+slot.y-1,leftPos+slot.x+17,topPos+slot.y+17,0xFF101820);
        if(menu.clientTab==0)for(var p:Economy.Product.values())g.renderItem(p.stack(1),leftPos+12,topPos+59+p.ordinal()*25);
    }
    private void text(GuiGraphics g,String s,int x,int y,int color){g.drawString(font,s,x,y,color,false);}
    @Override protected void renderLabels(GuiGraphics g,int x,int y){
        text(g,"StarRPG",8,10,0xFFFFFF);text(g,String.format(java.util.Locale.ROOT,"%,d G",menu.balance()),190,10,0xFFD978);
        switch(menu.clientTab){
            case 0->{for(var p:Economy.Product.values())text(g,p.label+"  "+menu.price(p.ordinal())+" G",35,64+p.ordinal()*25,0xFFFFFF);}
            case 1->{text(g,"판매할 아이템을 왼쪽 칸에 넣으세요.",8,55,0xFFFFFF);text(g,"개당 "+menu.sellPrice()+" G",54,80,0xFFD978);text(g,"전량 "+menu.sellPrice()*menu.saleItem().getCount()+" G",54,93,0xFFD978);text(g,menu.canSell()?"내구도 반영 · 내용물 있는 보관함은 판매 불가":"판매는 생존·모험 모드에서 가능합니다.",8,116,0xBCD0E0);}
            case 2->{String name=menu.job()<0?"미선택":Careers.NAMES[menu.job()]+" "+menu.rank()+"차";
                text(g,name+" | XP "+menu.xp()+" | 보스 "+menu.bosses(),8,54,0xFFFFFF);
                text(g,"첫 선택 무료 · 교체 500 G · 직업별 성장 보존",8,94,0xBCD0E0);
                text(g,menu.rank()==1?"2차: XP 300 / 보스 1 / 1,000 G":menu.rank()==2?"3차: XP 1200 / 보스 3 / 3,000 G":menu.rank()==3?"최종 전직 완료 · G키로 직업 능력":"전사: 방어 / 척후병: 기동 / 사수: 사격 / 마법사",8,116,0xFFD978);}
            case 3->{text(g,"주 손에 활을 들고 속성을 선택하세요.",8,54,0xFFFFFF);text(g,"현재: "+(menu.element()<0?"없음":BowElements.Element.values()[menu.element()].label),8,66,0xFFD978);text(g,"비용: 일반 룬 1개 + 200 G / 기존 룬 유지",8,104,0xBCD0E0);text(g,"속박 1초 · 기절 0.5초 · 반전 1초 / 재사용 8초",8,117,0xBCD0E0);}
        }
    }
    @Override public void render(GuiGraphics g,int x,int y,float t){super.render(g,x,y,t);renderTooltip(g,x,y);}
}
