package com.junwo.starrpg;

import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.*;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.common.util.FakePlayer;
import net.neoforged.neoforge.event.entity.living.*;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

@EventBusSubscriber(modid=StarRPG.MODID)
public final class Careers {
    public static final String[] NAMES={"전사","척후병","사수","마법사"};
    public static CareerData.Profile profile(Player p){return CareerData.get(p.getServer()).profile(p.getUUID());}
    public static boolean select(Player p,int id){
        if(p.level().isClientSide()||p.getServer()==null||id<0||id>3||!p.isAlive()||ControlEffects.stunned(p))return false;
        var data=CareerData.get(p.getServer());var v=data.profile(p.getUUID());long now=p.getServer().overworld().getGameTime();
        if(v.selected==id)return false;
        if(v.switchReady>now){p.sendSystemMessage(Component.literal("직업 교체는 30초마다 가능합니다."));return false;}
        if(v.selected>=0 && (!Config.ECONOMY_ENABLED.get()||!StarWallet.get(p.getServer()).debit(p.getUUID(),500))){p.sendSystemMessage(Component.literal("직업 교체에 500 G가 필요합니다."));return false;}
        v.selected=id;v.ranks[id]=Math.max(1,v.ranks[id]);v.switchReady=now+600;data.setDirty();updateAttributes(p);
        p.sendSystemMessage(Component.literal(NAMES[id]+" 선택. 해당 직업의 전직·경험치는 보존됩니다. G키: 직업 능력"));return true;
    }
    public static boolean advance(Player p){
        if(p.level().isClientSide()||p.getServer()==null||!p.isAlive()||ControlEffects.stunned(p))return false;
        var v=profile(p);int r=v.rank();if(r<1||r>=3)return false;
        int xp=r==1?300:1200,bosses=r==1?1:3,cost=r==1?1000:3000;
        if(v.xp()<xp||v.bosses()<bosses){p.sendSystemMessage(Component.literal("전직 조건: 경험치 "+xp+", 보스 "+bosses+"회, "+cost+" G"));return false;}
        if(!Config.ECONOMY_ENABLED.get()||!StarWallet.get(p.getServer()).debit(p.getUUID(),cost)){p.sendSystemMessage(Component.literal("전직 비용이 부족합니다."));return false;}
        v.ranks[v.selected]++;CareerData.get(p.getServer()).setDirty();updateAttributes(p);p.sendSystemMessage(Component.literal(NAMES[v.selected]+" "+v.rank()+"차 전직 완료!"));return true;
    }
    public static void gain(Player p,boolean boss,int tier){
        var v=profile(p);if(v.selected<0)return;
        v.xp[v.selected]=Math.min(1000000,v.xp()+ (boss?60:10+Math.clamp(tier,0,5)));
        if(boss)v.bosses[v.selected]=Math.min(10000,v.bosses()+1);CareerData.get(p.getServer()).setDirty();
    }
    @SubscribeEvent(priority=EventPriority.LOWEST) public static void death(LivingDropsEvent e){
        var mob=e.getEntity();if(mob.level().isClientSide()||!(e.getSource().getEntity() instanceof Player p)||p.getServer()==null||p.isCreative()||p.isSpectator()||p instanceof FakePlayer||!MonsterProgression.eligible(mob)||p.isAlliedTo(mob)||mob.isAlliedTo(p)||mob.getPersistentData().getBoolean("starrpg_career_paid"))return;
        mob.getPersistentData().putBoolean("starrpg_career_paid",true);gain(p,mob.getType().is(MonsterProgression.BOSSES),MonsterProgression.tier(mob));
    }
    private static void attr(Player p,net.minecraft.core.Holder<Attribute> attribute,String key,double value,AttributeModifier.Operation operation){
        var a=p.getAttribute(attribute);if(a==null)return;var id=ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,key);
        if(value==0){a.removeModifier(id);return;}var old=a.getModifier(id);if(old==null||old.amount()!=value)a.addOrUpdateTransientModifier(new AttributeModifier(id,value,operation));
    }
    public static void updateAttributes(Player p){
        var v=profile(p);int rank=v.rank();
        attr(p,Attributes.MAX_HEALTH,"career_health",v.selected==0?rank*2:0,AttributeModifier.Operation.ADD_VALUE);
        attr(p,Attributes.ARMOR,"career_armor",v.selected==0?rank:0,AttributeModifier.Operation.ADD_VALUE);
        attr(p,Attributes.MOVEMENT_SPEED,"career_speed",v.selected==1?rank*0.02:0,AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
        p.setHealth(Math.min(p.getHealth(),p.getMaxHealth()));
    }
    @SubscribeEvent public static void tick(PlayerTickEvent.Post e){if(!e.getEntity().level().isClientSide()&&e.getEntity().getServer()!=null&&e.getEntity().tickCount%20==0)updateAttributes(e.getEntity());}
    public static double arrowBonus(Player p){var v=profile(p);return v.selected==2?v.rank()*0.03+(p.getPersistentData().getLong("starrpg_focus_until")>p.level().getGameTime()?0.10:0):0;}
    public static boolean cast(Player p){
        if(p.level().isClientSide()||!p.isAlive()||p.isSpectator()||ControlEffects.rooted(p)||p.containerMenu!=p.inventoryMenu)return false;
        var v=profile(p);if(v.selected<0)return false;long now=p.level().getGameTime();
        if(p.getPersistentData().getLong("starrpg_career_ready")>now){p.displayClientMessage(Component.literal("직업 능력 재사용 대기 중"),true);return false;}
        switch(v.selected){
            case 0 -> p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,60+v.rank()*20,0));
            case 1 -> {p.setDeltaMovement(p.getDeltaMovement().add(p.getLookAngle().multiply(1,0,1).normalize().scale(0.7+v.rank()*0.1)).add(0,0.12,0));p.hurtMarked=true;}
            case 2 -> p.getPersistentData().putLong("starrpg_focus_until",now+120);
            case 3 -> {
                var target=WeaponAbilities.target(p,12,0.9);
                if(target==null){p.displayClientMessage(Component.literal("시야 안 12칸에 마법 대상이 없습니다."),true);return false;}
                var from=p.getEyePosition();var to=target.getEyePosition();var delta=to.subtract(from);
                for(int i=0;i<20;i++){var pos=from.add(delta.scale(i/20.0));((ServerLevel)p.level()).sendParticles(ParticleTypes.END_ROD,pos.x,pos.y,pos.z,1,0,0,0,0);}
                CombatRules.runeDamage(p,target,4+v.rank()*2);
            }
        }
        p.getPersistentData().putLong("starrpg_career_ready",now+(v.selected==3?160:v.selected==1?240:400));p.displayClientMessage(Component.literal(NAMES[v.selected]+" 능력 사용"),true);return true;
    }
}
