package com.junwo.starrpg;

import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.*;
import net.minecraft.world.item.component.CustomData;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.entity.player.ItemTooltipEvent;

@EventBusSubscriber(modid=StarRPG.MODID)
public final class BowElements {
    public enum Element { ICE("얼음 · 1초 속박"), LIGHTNING("전기 · 0.5초 기절"), DARK("어둠 · 1초 이동 반전"), LIGHT("빛 · 1초 시점 반전");
        public final String label;Element(String s){label=s;}
    }
    public static Element get(ItemStack stack) {
        if(!(stack.getItem() instanceof BowItem))return null;
        var data=stack.getOrDefault(DataComponents.CUSTOM_DATA,CustomData.EMPTY).copyTag();
        try{return Element.valueOf(data.getString("starrpg_bow_element"));}catch(IllegalArgumentException e){return null;}
    }
    public static boolean set(ItemStack stack,Element element) {
        if(!(stack.getItem() instanceof BowItem) || element==null)return false;
        CustomData.update(DataComponents.CUSTOM_DATA,stack,t->t.putString("starrpg_bow_element",element.name()));return true;
    }
    public static boolean engrave(Player p,int index) {
        if(index<0 || index>=Element.values().length || p.level().isClientSide() || p.getServer()==null || !(p.getMainHandItem().getItem() instanceof BowItem))return false;
        Element element=Element.values()[index];
        if(get(p.getMainHandItem())==element){p.sendSystemMessage(Component.literal("이미 같은 속성입니다."));return false;}
        int slot=-1;for(int i=0;i<p.getInventory().items.size();i++)if(p.getInventory().getItem(i).is(StarRPG.COMMON_RUNE.get())){slot=i;break;}
        var wallet=StarWallet.get(p.getServer());
        if(slot<0 || wallet.balance(p.getUUID())<200){p.sendSystemMessage(Component.literal("일반 룬 1개와 200 G가 필요합니다."));return false;}
        if(!Config.ECONOMY_ENABLED.get() || !wallet.debit(p.getUUID(),200))return false;
        p.getInventory().getItem(slot).shrink(1);set(p.getMainHandItem(),element);p.getInventory().setChanged();
        p.sendSystemMessage(Component.literal("활 속성 각인: "+element.label+" (기존 장비 룬 유지)"));return true;
    }
    @SubscribeEvent public static void tooltip(ItemTooltipEvent e) {
        if(e.getItemStack().getItem() instanceof BowItem)e.getToolTip().add(Component.literal("R: 대형 화살 / 완전 당김 0.9초 / 기본 피해 +10%"));
        if(e.getItemStack().getItem() instanceof CrossbowItem)e.getToolTip().add(Component.literal("R: 5초 고정 사격, R로 취소 / 발사 간격 0.5초 / 스킬 피해 60%"));
        var element=get(e.getItemStack());if(element!=null){e.getToolTip().add(Component.literal("활 속성: "+element.label));e.getToolTip().add(Component.literal("충전 명중 / 공통 재사용 8초 / 피격 후 제어 면역 3초"));}
    }
    @SubscribeEvent public static void hit(LivingDamageEvent.Post e) {
        if(e.getNewDamage()<=0 || !(e.getSource().getEntity() instanceof Player p) || !(e.getSource().getDirectEntity() instanceof AbstractArrow a))return;
        var weapon=a.getWeaponItem();if(weapon==null || !(weapon.getItem() instanceof BowItem))return;
        var element=get(weapon);if(element==null || a.getPersistentData().getFloat("starrpg_shot_power")<0.9)return;
        apply(p,e.getEntity(),element);
    }
    public static boolean apply(Player p,LivingEntity target,Element element) {
        if(p.level().isClientSide() || !CombatRules.canHarm(p,target))return false;
        long now=target.level().getGameTime();
        if(target.getPersistentData().getLong("starrpg_control_immune")>now || p.getPersistentData().getLong("starrpg_element_ready")>now)return false;
        int duration=target.getType().is(MonsterProgression.BOSSES)?20:element==Element.LIGHTNING?10:20;
        p.getPersistentData().putLong("starrpg_element_ready",now+160);
        target.getPersistentData().putLong("starrpg_control_immune",now+duration+60);
        if(target.getType().is(MonsterProgression.BOSSES)) {
            if(element==Element.ICE||element==Element.LIGHTNING){
                var speed=target.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED);
                if(speed!=null)speed.addOrUpdateTransientModifier(new net.minecraft.world.entity.ai.attributes.AttributeModifier(ControlEffects.BOSS_SLOW,-0.15,net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation.ADD_MULTIPLIED_BASE));
                target.getPersistentData().putLong("starrpg_boss_slow_until",now+20);
            }else target.getPersistentData().putLong("starrpg_boss_weaken_until",now+20);
        } else {
            var effect=switch(element){case ICE->ModEffects.ROOT;case LIGHTNING->ModEffects.STUN;case DARK->ModEffects.REVERSE_MOVE;case LIGHT->ModEffects.REVERSE_LOOK;};
            target.addEffect(new MobEffectInstance(effect,duration,0,false,true,false));
        }
        if(target instanceof Player other)other.displayClientMessage(Component.literal(element.label),true);
        return true;
    }
}
