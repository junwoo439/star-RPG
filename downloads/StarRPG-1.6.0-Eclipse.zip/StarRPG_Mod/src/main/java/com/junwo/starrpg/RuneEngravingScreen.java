package com.junwo.starrpg;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

public class RuneEngravingScreen
        extends AbstractContainerScreen<RuneEngravingMenu> {

    private Button engraveButton;
    private RuneWeaponType previewType;
    private RuneRarity previewRarity;

    public RuneEngravingScreen(
            RuneEngravingMenu menu,
            Inventory playerInventory,
            Component title
    ) {
        super(menu, playerInventory, title);

        this.imageWidth = 176;
        this.imageHeight = 201;
    }

    @Override
    protected void renderBg(
            GuiGraphics graphics,
            float partialTick,
            int mouseX,
            int mouseY
    ) {
        graphics.fill(
                this.leftPos,
                this.topPos,
                this.leftPos + this.imageWidth,
                this.topPos + this.imageHeight,
                0xFF24202E
        );

        drawSlot(graphics, this.leftPos + 52, this.topPos + 34);
        drawSlot(graphics, this.leftPos + 106, this.topPos + 34);

        for (int row = 0; row < 3; row++) {
            for (int column = 0; column < 9; column++) {
                drawSlot(
                        graphics,
                        this.leftPos + 8 + column * 18,
                        this.topPos + 118 + row * 18
                );
            }
        }

        for (int column = 0; column < 9; column++) {
            drawSlot(
                    graphics,
                    this.leftPos + 8 + column * 18,
                    this.topPos + 176
            );
        }
    }

    @Override
    protected void init() {
        super.init();

        this.engraveButton = this.addRenderableWidget(
                Button.builder(
                        Component.literal("각인/교체"),
                        button -> {
                            if (Minecraft.getInstance().gameMode != null) {
                                Minecraft.getInstance().gameMode
                                        .handleInventoryButtonClick(
                                                this.menu.containerId,
                                                0
                                        );
                            }
                        }
                ).bounds(
                        this.leftPos + 58,
                        this.topPos + 83,
                        60,
                        20
                ).build()
        );
    }

    @Override
    protected void renderLabels(
            GuiGraphics graphics,
            int mouseX,
            int mouseY
    ) {
        graphics.drawString(
                this.font,
                "별의 룬 각인",
                8,
                6,
                0xFFFFFF
        );

        graphics.drawString(
                this.font,
                "장비",
                56,
                18,
                0xFFFFFF
        );

        graphics.drawString(
                this.font,
                "별의 룬",
                103,
                18,
                0xFFFFFF
        );

        graphics.drawString(
                this.font,
                "4가지 효과 중 무작위 1개",
                30,
                62,
                0xAAAAAA
        );

        graphics.drawString(
                this.font,
                "동급 이상 룬 1개로 교체",
                26,
                73,
                0xAAAAAA
        );

        graphics.drawString(
                this.font,
                "인벤토리",
                8,
                107,
                0xFFFFFF
        );
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        RuneWeaponType type = RuneWeaponType.forItem(menu.getSlot(0).getItem());
        RuneRarity rarity = RuneItemHelper.getRarity(menu.getSlot(1).getItem());
        if (engraveButton != null && (type != previewType || rarity != previewRarity || engraveButton.getTooltip() == null)) {
            previewType = type; previewRarity = rarity;
            String text = "장비와 룬을 넣으면 각인 후보를 확인할 수 있습니다.";
            if (type != null && rarity != null) {
                StringBuilder lines = new StringBuilder("각인 후보 (각 25%)\n");
                for (RuneEffect effect : RuneEffectManager.getPossibleEffects(rarity, type)) {
                    lines.append(effect.getKoreanName()).append(": ").append(RuneEffectDescription.getDescriptionLines(effect).getFirst()).append("\n");
                }
                lines.append("재각인 시 같은 효과가 다시 나올 수 있습니다.");
                text = lines.toString();
            }
            engraveButton.setTooltip(net.minecraft.client.gui.components.Tooltip.create(Component.literal(text)));
        }
        super.render(graphics, mouseX, mouseY, partialTick);
        renderTooltip(graphics, mouseX, mouseY);
    }

    private void drawSlot(GuiGraphics graphics, int x, int y) {
        graphics.fill(x, y, x + 18, y + 18, 0xFF151515);
        graphics.fill(x + 1, y + 1, x + 17, y + 17, 0xFF888888);
        graphics.fill(x + 2, y + 2, x + 16, y + 16, 0xFF3F3F3F);
    }
}
