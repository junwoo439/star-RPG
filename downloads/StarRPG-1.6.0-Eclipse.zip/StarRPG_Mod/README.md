# StarRPG

Minecraft 1.21.1 / NeoForge 21.1.235용 장비 강화·무기/방어구 룬·월드 공통 난이도·장비/낚싯대 좀비 모드.
현재 버전: **1.6.0**.

## Eclipse에서 게임 실행

**[Eclipse 실행 안내](ECLIPSE.md)**를 따라 Existing Gradle Project로 가져오고
`Run > Run Configurations > Java Application > StarRPG Client`를 실행하세요.
게임의 싱글플레이에서 테스트할 수 있습니다. JDK 21이 필요합니다.

Windows 명령줄 실행:

```bat
gradlew.bat runClient
```

클라이언트 월드와 설정은 `run-client/`에 저장됩니다.
변경 내용, 밸런스 설정, 기존 강화 장비 이전 방법은 [BALANCE-1.6.md](BALANCE-1.6.md)를 참조하세요.

## 빌드 및 개발자 테스트

```bash
bash gradlew build
bash gradlew runGameTestServer
```

Windows에서는 `gradlew.bat`를 사용합니다. 배포 파일은 `build/libs/starrpg-1.6.0.jar`입니다.
GameTest는 별도의 `run-gametest/`를 사용합니다.

1.6.0 변경 내용과 빠른 확인 순서는 [TESTING-1.6.md](TESTING-1.6.md)를 참고하세요.

이번 버전은 무기 능력 개편, 활 전용 4속성, **Shift+H 통합 메뉴**, 아이템 판매, 골드 보스바, 전투 직업 4종과 2·3차 전직을 추가합니다. **R: 무기 능력 / G: 직업 능력 / 단검 우클릭: 투척**입니다.

판매 가격은 [SELL-PRICES-1.6.csv](SELL-PRICES-1.6.csv), 수치·전직 비용은 [BALANCE-1.6.md](BALANCE-1.6.md)에 있습니다. 기본 인챈트 제거가 기본으로 켜져 있으므로 기존 월드는 백업하고 새 월드에서 먼저 확인하세요. StarRPG 룬과 강화는 유지됩니다.

외부 모드 설치는 [MODS-1.5.1.md](MODS-1.5.1.md)를 따릅니다. `setup-adventure-eclipse.bat`으로 Twilight Forest 4.8.3802, Mowzie 1.8.2, GeckoLib 4.9.2 설치와 Eclipse 준비를 한 번에 실행합니다. 외부 JAR은 공식 배포처에서 내려받습니다. Ice and Fire는 호환 공식 빌드가 없어 제외했습니다. 생활직과 무한 전직은 보류했습니다.

검증: 외부 모드 3종과 함께 자동 테스트 **89개 통과**, 빌드 및 Eclipse 실행 구성 생성 성공. Windows 게임 화면과 실제 다인 PvP는 직접 확인하지 못했습니다.
