package com.junwo.starrpg;

import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.*;

/** A dodgeable, block-colliding hook; vanilla fishing bobbers only support player owners. */
public final class ZombieHook extends ThrowableItemProjectile {
    public ZombieHook(EntityType<? extends ZombieHook> type, Level level) { super(type, level); }
    public ZombieHook(Level level, Zombie owner) { super(ModEntities.ZOMBIE_HOOK.get(), owner, level); setNoGravity(true); }
    @Override protected Item getDefaultItem() { return Items.TRIPWIRE_HOOK; }

    @Override public void tick() {
        super.tick();
        if (!level().isClientSide() && (tickCount > 20 || getOwner() == null || !getOwner().isAlive())) discard();
    }
    @Override protected void onHitEntity(EntityHitResult hit) {
        super.onHitEntity(hit);
        if (!level().isClientSide() && getOwner() instanceof Zombie zombie && hit.getEntity() instanceof Player player)
            pull(zombie, player);
    }
    @Override protected void onHit(HitResult hit) {
        super.onHit(hit);
        if (!level().isClientSide()) discard();
    }

    public static boolean pull(Zombie zombie, Player player) {
        long now = player.level().getGameTime();
        var data = player.getPersistentData();
        if (!Config.MOB_SCALING.get() || !Config.ZOMBIE_HOOKS.get() || !zombie.isAlive() || zombie.isNoAi()
                || !zombie.getMainHandItem().is(Items.FISHING_ROD) || zombie.getTarget() != player
                || !player.isAlive() || player.isCreative() || player.isSpectator() || player.isPassenger()
                || zombie.isAlliedTo(player) || zombie.distanceToSqr(player) > 16 * 16
                || !zombie.hasLineOfSight(player)
                || (data.contains("starrpg_hook_immunity") && data.getLong("starrpg_hook_immunity") > now)) return false;
        Vec3 direction = zombie.position().subtract(player.position()).multiply(1,0,1).normalize();
        if (direction.lengthSqr() < 0.01) return false;
        player.setDeltaMovement(direction.scale(0.9).add(0,0.25,0));
        player.hurtMarked = true;
        player.hasImpulse = true;
        data.putLong("starrpg_hook_immunity", now + 60);
        if (player instanceof ServerPlayer serverPlayer) serverPlayer.connection.send(new ClientboundSetEntityMotionPacket(player));
        zombie.playSound(SoundEvents.FISHING_BOBBER_RETRIEVE, 1.0F, 0.8F);
        return true;
    }
}
