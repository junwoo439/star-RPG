package com.junwo.starrpg;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.*;

public final class StarDaggerItem extends SwordItem {
    public StarDaggerItem(Properties properties) {
        super(Tiers.IRON, properties.attributes(SwordItem.createAttributes(Tiers.IRON,1,-2.0F).withModifierAdded(
            net.minecraft.world.entity.ai.attributes.Attributes.ENTITY_INTERACTION_RANGE,
            new net.minecraft.world.entity.ai.attributes.AttributeModifier(net.minecraft.resources.ResourceLocation.fromNamespaceAndPath(StarRPG.MODID,"dagger_range"),-0.7,net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation.ADD_VALUE),net.minecraft.world.entity.EquipmentSlotGroup.MAINHAND)));
    }
    @Override public net.minecraft.world.InteractionResultHolder<ItemStack> use(net.minecraft.world.level.Level level,net.minecraft.world.entity.player.Player player,net.minecraft.world.InteractionHand hand){
        if(level.isClientSide())return net.minecraft.world.InteractionResultHolder.success(player.getItemInHand(hand));
        return WeaponAbilities.throwDagger(player,hand)?net.minecraft.world.InteractionResultHolder.consume(player.getItemInHand(hand)):net.minecraft.world.InteractionResultHolder.fail(player.getItemInHand(hand));
    }
    @Override public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> lines, TooltipFlag flag) {
        super.appendHoverText(stack,context,lines,flag);
        lines.add(Component.literal("충전된 후방 공격: 피해 +20% / 재사용 3초"));
        lines.add(Component.literal("R: 삼연격 / 우클릭: 회전 단검 투척·자동 귀환"));
        lines.add(Component.literal("검 룬 사용 / +10 이후 완만한 무한 성장"));
    }
}
