package com.junwo.starrpg.tests;

import com.junwo.starrpg.*;
import java.util.*;
import net.minecraft.gametest.framework.*;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.level.GameType;
import net.minecraft.world.effect.*;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.*;

@GameTestHolder(StarRPG.MODID)
@PrefixGameTestTemplate(false)
public class InfiniteCareersGameTests {
    private static Item[] weapons(){return new Item[]{StarRPG.STAR_SPEAR.get(),StarRPG.STAR_DAGGER.get(),Items.BOW,StarRPG.MAGIC_STAFF.get(),StarRPG.WAR_HAMMER.get(),StarRPG.BERSERKER_BLADE.get(),StarRPG.SUN_SCEPTER.get(),StarRPG.SOUL_SCYTHE.get(),StarRPG.STAR_GAUNTLET.get(),StarRPG.AEGIS_BLADE.get()};}
    private static Player player(GameTestHelper h,int job){var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(2.5,2,2.5)));p.setYRot(0);p.setXRot(0);var c=Careers.profile(p);c.selected=job;c.ranks[job]=1;p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(weapons()[job]));return p;}
    @GameTest(template="empty") public static void tenCareersHaveDistinctWeaponsMaterialsAndPersist(GameTestHelper h){
        var p=player(h,9);var c=Careers.profile(p);var materials=new HashSet<Item>();
        for(int j=0;j<10;j++){h.assertTrue(Careers.weaponJob(new ItemStack(weapons()[j]))==j,"Wrong job weapon "+j);materials.add(Careers.material(j));c.ranks[j]=70000+j;c.xp[j]=800000+j;c.mastery[j]=900000+j;}
        var saved=CareerData.get(p.getServer()).save(new CompoundTag(),h.getLevel().registryAccess());var loaded=CareerData.load(saved,h.getLevel().registryAccess()).profile(p.getUUID());var menu=new MaterialShopMenu(1,p.getInventory());
        h.assertTrue(materials.size()==10&&loaded.selected==9,"Job count/materials wrong");
        for(int j=0;j<10;j++)h.assertTrue(loaded.ranks[j]==70000+j&&menu.previewRank(j)==70000+j&&menu.previewXp(j)==800000+j&&menu.previewMastery(j)==900000+j,"High job data truncated");
        h.assertTrue(menu.price(20)==Economy.Product.SOUL_SAND.price(),"New product price overwrote job fields");h.succeed();
    }
    @GameTest(template="empty") public static void fourJobSaveMigratesWithoutReset(GameTestHelper h){
        var id=UUID.randomUUID();var p=new CompoundTag();p.putUUID("id",id);p.putInt("selected",3);p.putInt("rank3",76);p.putInt("xp3",5000);var entries=new ListTag();entries.add(p);var root=new CompoundTag();root.put("profiles",entries);
        var c=CareerData.load(root,h.getLevel().registryAccess()).profile(id);
        h.assertTrue(c.selected==3&&c.rank()==76&&c.xp()==5000&&c.ranks.length==10&&c.ranks[9]==0,"Old save lost progress");h.succeed();
    }
    @GameTest(template="empty") public static void previewNeverCommitsAndConfirmationChargesOnce(GameTestHelper h){
        var p=player(h,1);StarWallet.get(p.getServer()).credit(p.getUUID(),1000);var menu=new MaterialShopMenu(1,p.getInventory());int balance=menu.balance();
        for(int j=0;j<10;j++){menu.previewRank(j);menu.previewXp(j);menu.previewMaterials(j);}h.assertTrue(Careers.profile(p).selected==1&&StarWallet.get(p.getServer()).balance(p.getUUID())==balance,"Read-only preview changed career/currency");
        h.assertTrue(menu.clickMenuButton(p,49)&&Careers.profile(p).selected==9,"Tenth career not selectable");
        h.assertTrue(!menu.clickMenuButton(p,49)&&StarWallet.get(p.getServer()).balance(p.getUUID())==balance-500,"Confirm double charged");
        h.assertTrue(!menu.clickMenuButton(h.makeMockPlayer(GameType.SURVIVAL),40),"Foreign menu mutation accepted");h.succeed();
    }
    @GameTest(template="empty") public static void tutorialWeaponsStayUniversalAndHammerBelongsToSmith(GameTestHelper h){
        var p=player(h,3);p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(Items.IRON_SWORD));h.assertTrue(Careers.requireWeapon(p,p.getMainHandItem())&&WeaponAbilities.activate(p),"Tutorial sword requires warrior");WeaponAbilities.cancel(p);
        h.assertTrue(Careers.tutorial(new ItemStack(Items.IRON_AXE))&&!EnhancementData.unlimited(p.getMainHandItem()),"Tutorial rules wrong");
        p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(StarRPG.WAR_HAMMER.get()));p.setOnGround(true);h.assertTrue(!WeaponAbilities.activate(p),"Mage used smith hammer R");Careers.profile(p).selected=4;Careers.profile(p).ranks[4]=1;h.assertTrue(WeaponAbilities.activate(p),"Smith cannot use hammer R");WeaponAbilities.cancel(p);h.succeed();
    }
    @GameTest(template="empty") public static void infiniteEnhancementConsumesPityWithoutDestroying(GameTestHelper h){
        var p=player(h,1);var w=p.getMainHandItem();EnhancementData.setLevel(w,100);RuneDataHelper.setRuneEffect(w,RuneEffect.SWORD_STAR_SLASH);w.setDamageValue(20);
        for(int i=0;i<10;i++)EnhancementData.recordFailure(w);var menu=new EnhancementMenu(1,p.getInventory());menu.getSlot(0).set(w);menu.getSlot(1).set(new ItemStack(StarRPG.STAR_DUST.get(),64));menu.getSlot(2).set(new ItemStack(StarRPG.STAR_FRAGMENT.get(),64));
        int dust=EnhancementMenu.getRequiredDust(100),fragments=EnhancementMenu.getRequiredFragment(100);
        h.assertTrue(menu.clickMenuButton(p,0)&&EnhancementData.level(w)==101,"Beyond +10 upgrade failed with pity");
        h.assertTrue(menu.getSlot(1).getItem().getCount()==64-dust&&menu.getSlot(2).getItem().getCount()==64-fragments&&w.getDamageValue()==20&&RuneDataHelper.hasRuneEffect(w),"Upgrade lost data or wrong cost");
        long seed=0;while(true){p.getRandom().setSeed(seed);if(p.getRandom().nextInt(100)>=EnhancementMenu.getSuccessChance(w))break;seed++;}p.getRandom().setSeed(seed);
        menu.getSlot(1).set(new ItemStack(StarRPG.STAR_DUST.get(),64));menu.getSlot(2).set(new ItemStack(StarRPG.STAR_FRAGMENT.get(),64));
        h.assertTrue(menu.clickMenuButton(p,0)&&EnhancementData.level(w)==101&&!w.isEmpty()&&EnhancementData.failures(w)==1,"Failed infinite upgrade destroyed/reset item");h.succeed();
    }
    @GameTest(template="empty") public static void infiniteLevelsSaveAndNumericalLimitsNeverWrap(GameTestHelper h){
        for(Item item:weapons()){var w=new ItemStack(item);EnhancementData.setLevel(w,70000);var restored=ItemStack.parseOptional(h.getLevel().registryAccess(),(CompoundTag)w.save(h.getLevel().registryAccess()));h.assertTrue(EnhancementData.level(restored)==70000&&Double.isFinite(EnhancementData.power(restored)),"High enhancement lost on save");}
        var w=new ItemStack(StarRPG.MAGIC_STAFF.get());EnhancementData.setLevel(w,Integer.MAX_VALUE);h.assertTrue(EnhancementMenu.getSuccessChance(w)==0&&EnhancementMenu.getRequiredDust(Integer.MAX_VALUE)==64&&EnhancementMenu.getRequiredFragment(Integer.MAX_VALUE)==64,"Integer boundary overflow");
        for(Item item:List.of(Items.IRON_SWORD,Items.IRON_AXE,Items.IRON_HELMET)){var basic=new ItemStack(item);EnhancementData.setLevel(basic,100);h.assertTrue(EnhancementData.level(basic)==10,"Tutorial/armor limit changed");}h.succeed();
    }
    @GameTest(template="empty") public static void milestoneUnlocksOnlyAfterFivePromotions(GameTestHelper h){
        var p=player(h,0);var c=Careers.profile(p);p.setHealth(7);c.ranks[0]=5;Careers.updateAttributes(p);float before=p.getMaxHealth();
        c.ranks[0]=6;Careers.updateAttributes(p);h.assertTrue(CareerMilestones.count(5)==0&&CareerMilestones.count(6)==1&&p.getMaxHealth()>before&&p.getHealth()==7,"Milestone off-by-one or equip healing");
        c.ranks[0]=10;CareerMilestones.onSkill(p);h.assertTrue(!p.hasEffect(MobEffects.ABSORPTION),"Shield before ten promotions");
        c.ranks[0]=11;CareerMilestones.onSkill(p);h.assertTrue(p.hasEffect(MobEffects.ABSORPTION),"Ten-promotion skill missing");p.removeEffect(MobEffects.ABSORPTION);CareerMilestones.onSkill(p);h.assertTrue(!p.hasEffect(MobEffects.ABSORPTION),"Milestone shield spam");
        c.ranks[0]=16;p.getPersistentData().putLong("starrpg_milestone_ready",0);CareerMilestones.onSkill(p);h.assertTrue(p.hasEffect(MobEffects.DAMAGE_BOOST),"Fifteen-promotion awakening missing");
        p.setItemInHand(InteractionHand.MAIN_HAND,ItemStack.EMPTY);Careers.updateAttributes(p);h.assertTrue(p.getMaxHealth()==20,"Milestone leaked after unequip");h.assertTrue(CareerMilestones.stat(100000)>CareerMilestones.stat(1000),"Milestone stat capped");h.succeed();
    }
    @GameTest(template="hook_arena") public static void newWeaponSkillsHitAndRespectWallsCooldownsPets(GameTestHelper h){
        for(int job:new int[]{0,5,6,7,8,9}){
            var p=player(h,job);var enemy=EntityType.COW.create(h.getLevel());enemy.setPos(p.position().add(0,0,2));enemy.getAttribute(Attributes.MAX_HEALTH).setBaseValue(100);enemy.setHealth(100);enemy.setNoAi(true);enemy.setNoGravity(true);h.getLevel().addFreshEntity(enemy);
            var pet=EntityType.WOLF.create(h.getLevel());pet.setPos(p.position().add(1,0,2));pet.setTame(true,true);h.getLevel().addFreshEntity(pet);float hp=pet.getHealth();
            h.assertTrue(WeaponAbilities.activate(p)&&enemy.getHealth()<100&&pet.getHealth()==hp,"New skill failed/protected pet hit: "+job);
            h.assertTrue(!WeaponAbilities.activate(p),"R spam bypassed cooldown");enemy.discard();pet.discard();
        }h.succeed();
    }
    @GameTest(template="empty") public static void magicCooldownsExposeSharedSpellHealingAndMeteorTimers(GameTestHelper h){
        var p=player(h,3);h.assertTrue(MagicSystem.cooldown(p,"starrpg_spell_ready").equals("준비"),"Idle spell display wrong");h.assertTrue(MagicSystem.cast(p),"Spell failed");
        h.assertTrue(!MagicSystem.cooldown(p,"starrpg_spell_ready").equals("준비")&&MagicSystem.cooldown(p,"starrpg_heal_ready").equals("준비"),"Spell/heal timer mixed");var menu=new MaterialShopMenu(1,p.getInventory());h.assertTrue(!menu.cooldown(0).equals("준비")&&menu.cooldown(1).equals("준비"),"Menu cooldown desync");h.succeed();
    }
    @GameTest(template="empty") public static void worldAndEnemiesGrowPastFiveAndPersist(GameTestHelper h){
        var clock=new WorldDifficulty();clock.setTier(70000);var restored=WorldDifficulty.load(clock.save(new CompoundTag(),h.getLevel().registryAccess()),h.getLevel().registryAccess());h.assertTrue(restored.tier()==70000&&MonsterProgression.tierFor(70000,2)==69998,"World cap persists/truncates");
        var mob=EntityType.ZOMBIE.create(h.getLevel());MonsterProgression.applyTier(mob,20);float before=mob.getMaxHealth();mob.setHealth(8);MonsterProgression.upgradeTier(mob,100);h.assertTrue(mob.getMaxHealth()>before&&mob.getHealth()==8&&MonsterProgression.tier(mob)==100,"Unbounded upgrade stacked/healed/capped");var nbt=new CompoundTag();mob.saveWithoutId(nbt);var copy=EntityType.ZOMBIE.create(h.getLevel());copy.load(nbt);h.assertTrue(MonsterProgression.tier(copy)==100&&copy.getHealth()==8,"Enemy progression lost on save");h.succeed();
    }
    @GameTest(template="hook_arena") public static void everyHostileHasTraitAndExcludedAnimalsStayPassive(GameTestHelper h){
        int covered=0;var families=new HashSet<MonsterAbilities.Trait>();var lines=new ArrayList<String>();lines.add("entity,trait");
        for(var type:BuiltInRegistries.ENTITY_TYPE){var e=type.create(h.getLevel());if(e instanceof LivingEntity living&&MonsterProgression.eligible(living)){h.assertTrue(MonsterAbilities.trait(living)!=null,"No trait: "+type);covered++;families.add(MonsterAbilities.trait(living));lines.add(BuiltInRegistries.ENTITY_TYPE.getKey(type)+","+MonsterAbilities.trait(living).label);}if(e!=null)e.discard();}
        h.assertTrue(covered>40&&families.size()>=16,"Hostile coverage too low "+covered);h.assertTrue(!MonsterProgression.eligible(EntityType.COW.create(h.getLevel())),"Livestock gained hostile skills");
        try{java.nio.file.Files.write(java.nio.file.Path.of("../MONSTER-TRAITS-1.9.csv"),lines);}catch(java.io.IOException ex){throw new RuntimeException(ex);}h.succeed();
    }
    @GameTest(template="hook_arena") public static void monsterTelegraphCancelsAndVictimGuardStopsChains(GameTestHelper h){
        var p=player(h,1);var z=EntityType.ZOMBIE.create(h.getLevel());z.setPos(p.position().add(2,0,0));z.removeFreeWill();z.setTarget(p);MonsterProgression.applyTier(z,3);
        MonsterAbilities.update(z);h.assertTrue(!p.hasEffect(MobEffects.MOVEMENT_SLOWDOWN)&&z.getPersistentData().contains("starrpg_trait_cast"),"Trait had no warning");
        p.setPos(p.position().add(8,0,0));MonsterAbilities.update(z);h.assertTrue(!z.getPersistentData().contains("starrpg_trait_cast"),"Escaping didn't cancel cast");
        p.setPos(z.position().add(2,0,0));MonsterAbilities.update(z);z.getPersistentData().putLong("starrpg_trait_cast",0);MonsterAbilities.update(z);h.assertTrue(p.hasEffect(MobEffects.MOVEMENT_SLOWDOWN),"Completed grasp had no effect");p.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);z.getPersistentData().putLong("starrpg_trait_ready",0);MonsterAbilities.update(z);z.getPersistentData().putLong("starrpg_trait_cast",0);MonsterAbilities.update(z);h.assertTrue(!p.hasEffect(MobEffects.MOVEMENT_SLOWDOWN),"Victim chain immunity ignored");h.succeed();
    }
    @GameTest(template="empty") public static void newWeaponsHaveCraftingRecipesAndRuneSupport(GameTestHelper h){
        for(var item:weapons())if(item instanceof CareerWeaponItem){var id=BuiltInRegistries.ITEM.getKey(item);h.assertTrue(h.getLevel().getRecipeManager().byKey(id).isPresent(),"Missing recipe "+id);h.assertTrue(RuneWeaponType.forItem(new ItemStack(item))==RuneWeaponType.SWORD,"New weapon missing rune pool");}
        for(var product:Economy.Product.values())h.assertTrue(product.price()>SellPrices.unit(product.stack(1)),"Buy/sell arbitrage "+product);h.succeed();
    }
}
