package com.junwo.starrpg.tests;

import com.junwo.starrpg.*;
import java.util.*;
import net.minecraft.core.*;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.gametest.framework.*;
import net.minecraft.world.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.item.*;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.trading.*;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.*;
import net.neoforged.neoforge.common.damagesource.DamageContainer;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.gametest.*;

@GameTestHolder(StarRPG.MODID)
@PrefixGameTestTemplate(false)
public class RuneOverhaulGameTests {
    private static Player player(GameTestHelper h){return h.makeMockPlayer(GameType.SURVIVAL);}
    private static ItemStack gear(Item item,RuneEffect rune){var stack=new ItemStack(item);RuneDataHelper.setRuneEffect(stack,rune);return stack;}
    private static Player mage(GameTestHelper h,RuneEffect rune){var p=player(h);Careers.profile(p).selected=3;Careers.profile(p).ranks[3]=1;p.setItemInHand(InteractionHand.MAIN_HAND,gear(StarRPG.MAGIC_STAFF.get(),rune));return p;}
    @GameTest(template="empty") public static void rarityTicketsMatchEveryPublishedProbability(GameTestHelper h){
        int[][] expected={{7000,2500,490,10,0},{2000,6500,1400,99,1},{500,2000,7000,490,10},{10,490,2000,7000,500},{1,9,490,2500,7000}};
        for(var source:RuneRarity.values()){
            int[] counts=new int[5];for(int ticket=0;ticket<10000;ticket++)counts[RuneEffectManager.rarityAt(source,ticket).ordinal()]++;
            h.assertTrue(Arrays.equals(counts,expected[source.ordinal()]),"Wrong exact odds: "+source);
        }
        h.assertTrue(RuneEffectManager.rarityAt(RuneRarity.COMMON,6999)==RuneRarity.COMMON&&RuneEffectManager.rarityAt(RuneRarity.COMMON,7000)==RuneRarity.RARE&&RuneEffectManager.rarityAt(RuneRarity.COMMON,9990)==RuneRarity.LEGENDARY,"Boundary off by one");h.succeed();
    }
    private static long seedFor(RuneRarity source,RuneRarity target){for(long seed=0;seed<1000000;seed++)if(RuneEffectManager.rarityAt(source,net.minecraft.util.RandomSource.create(seed).nextInt(10000))==target)return seed;throw new IllegalStateException("No seed");}
    @GameTest(template="empty") public static void commonRuneCanActuallyRollLegendaryAndLegendaryCommon(GameTestHelper h){
        var p=player(h);var menu=new RuneEngravingMenu(1,p.getInventory());var item=gear(Items.BOW,RuneEffect.BOW_HUNTER_MYTHIC);EnhancementData.setLevel(item,8);menu.getSlot(0).set(item);
        menu.getSlot(1).set(new ItemStack(StarRPG.COMMON_RUNE.get()));p.getRandom().setSeed(seedFor(RuneRarity.COMMON,RuneRarity.LEGENDARY));
        h.assertTrue(menu.clickMenuButton(p,0)&&RuneDataHelper.getRuneEffect(item).getRarity()==RuneRarity.LEGENDARY&&menu.getSlot(1).getItem().isEmpty(),"Common input cannot roll legendary");
        menu.getSlot(1).set(new ItemStack(StarRPG.LEGENDARY_RUNE.get()));p.getRandom().setSeed(seedFor(RuneRarity.LEGENDARY,RuneRarity.COMMON));
        h.assertTrue(menu.clickMenuButton(p,0)&&RuneDataHelper.getRuneEffect(item).getRarity()==RuneRarity.COMMON&&EnhancementData.level(item)==8,"Legendary downgrade failed or erased enhancement");h.succeed();
    }
    @GameTest(template="empty") public static void allFourHundredEffectsHaveDescriptionsAndExport(GameTestHelper h)throws Exception{
        StringBuilder csv=new StringBuilder("id,type,rarity,name,effect\n");
        for(var type:RuneWeaponType.values())for(var rank:RuneRarity.values()){
            var pool=RuneEffectManager.getPossibleEffects(rank,type);h.assertTrue(pool.size()==8,"Incomplete pool "+type+rank);
            for(var rune:pool){var lines=RuneEffectDescription.getDescriptionLines(rune);h.assertTrue(!lines.isEmpty()&&!lines.getFirst().isBlank(),"Missing description "+rune);
                csv.append(rune.name()).append(',').append(type).append(',').append(rank).append(',').append(rune.getKoreanName()).append(',').append('"').append(String.join(" / ",lines).replace("\"","\"\"")).append('"').append('\n');}
        }
        java.nio.file.Files.writeString(java.nio.file.Path.of("../RUNE-EFFECTS-1.8.csv"),csv.toString());h.succeed();
    }
    @GameTest(template="empty") public static void bowControlsComeFromRunesAndLegacyClearsOnReroll(GameTestHelper h){
        var bow=gear(Items.BOW,RuneEffect.BOW_LIGHTNING_LEGENDARY);h.assertTrue(BowElements.get(bow)==BowElements.Element.LIGHTNING,"Rune does not supply bow element");
        var crossbow=gear(Items.CROSSBOW,RuneEffect.BOW_ICE_MYTHIC);h.assertTrue(BowElements.get(crossbow)==null,"Control applied to crossbow");
        var p=player(h);BowElements.set(bow,BowElements.Element.DARK);var menu=new RuneEngravingMenu(1,p.getInventory());menu.getSlot(0).set(bow);menu.getSlot(1).set(new ItemStack(StarRPG.COMMON_RUNE.get()));
        h.assertTrue(menu.clickMenuButton(p,0)&&!bow.getOrDefault(DataComponents.CUSTOM_DATA,net.minecraft.world.item.component.CustomData.EMPTY).copyTag().contains("starrpg_bow_element"),"Reroll retained second legacy element");
        h.assertTrue(!new MaterialShopMenu(2,p.getInventory()).clickMenuButton(p,60),"Old element button remains active");h.succeed();
    }
    @GameTest(template="empty") public static void runeBowHitAppliesControlAndRarityCooldown(GameTestHelper h){
        var p=player(h);var victim=EntityType.ZOMBIE.create(h.getLevel());victim.getAttribute(Attributes.ARMOR).setBaseValue(0);
        var arrow=new Arrow(h.getLevel(),p,new ItemStack(Items.ARROW),gear(Items.BOW,RuneEffect.BOW_ICE_MYTHIC));arrow.setDeltaMovement(0,0,3);RangedRuneEffects.prepare(arrow);
        victim.hurt(h.getLevel().damageSources().arrow(arrow,p),2);
        h.assertTrue(victim.hasEffect(ModEffects.ROOT)&&p.getPersistentData().getLong("starrpg_element_ready")==p.level().getGameTime()+120,"Bow rune not triggered or rarity cooldown wrong");h.succeed();
    }
    @GameTest(template="hook_arena") public static void enhancementTableReplacesInteractionAndRequiresBlock(GameTestHelper h){
        var p=player(h);BlockPos pos=h.absolutePos(new BlockPos(2,1,2));h.setBlock(2,1,2,Blocks.ENCHANTING_TABLE);p.setPos(Vec3.atCenterOf(pos).add(0,1,0));
        var event=new PlayerInteractEvent.RightClickBlock(p,InteractionHand.MAIN_HAND,pos,new BlockHitResult(Vec3.atCenterOf(pos),Direction.UP,pos,false));EnhancementTableAccess.open(event);h.assertTrue(event.isCanceled(),"Vanilla enchant UI still opened");
        var menu=new EnhancementMenu(1,p.getInventory(),ContainerLevelAccess.create(h.getLevel(),pos));var sword=new ItemStack(Items.IRON_SWORD);menu.getSlot(0).set(sword);menu.getSlot(1).set(new ItemStack(StarRPG.STAR_DUST.get(),2));
        h.assertTrue(menu.stillValid(p)&&menu.clickMenuButton(p,0)&&EnhancementData.level(sword)==1,"Table enhancement failed");
        h.setBlock(2,1,2,Blocks.AIR);h.assertTrue(!menu.stillValid(p)&&!menu.clickMenuButton(p,0)&&menu.getSlot(1).getItem().getCount()==1,"Removed table still consumes materials");h.succeed();
    }
    @GameTest(template="empty") public static void fragmentNoLongerOpensMenuAndForeignClicksRejected(GameTestHelper h){
        var p=player(h);var old=p.containerMenu;p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(StarRPG.STAR_FRAGMENT.get()));p.getMainHandItem().use(h.getLevel(),p,InteractionHand.MAIN_HAND);
        h.assertTrue(p.containerMenu==old,"Fragment still opens enhancement");
        var menu=new RuneEngravingMenu(1,p.getInventory());menu.getSlot(0).set(new ItemStack(Items.IRON_SWORD));menu.getSlot(1).set(new ItemStack(StarRPG.COMMON_RUNE.get()));h.assertTrue(!menu.clickMenuButton(player(h),0)&&menu.getSlot(1).getItem().getCount()==1,"Foreign player changed rune");h.succeed();
    }
    @GameTest(template="empty") public static void librarianBookBecomesMaterialWithoutRestockingExploit(GameTestHelper h){
        var book=new ItemStack(Items.ENCHANTED_BOOK);book.enchant(h.getLevel().registryAccess().registryOrThrow(Registries.ENCHANTMENT).getHolderOrThrow(Enchantments.MENDING),1);
        var original=new MerchantOffer(new ItemCost(Items.EMERALD,20),Optional.of(new ItemCost(Items.BOOK)),book,3,12,10,0.05F);
        var trade=VillagerRuneTrades.sanitize(original);h.assertTrue(trade.getResult().is(StarRPG.STAR_DUST.get())&&trade.getBaseCostA().getCount()==8&&trade.getUses()==3&&trade.getMaxUses()==4,"Invalid replacement trade");
        h.assertTrue(VillagerRuneTrades.sanitize(trade)==trade&&trade.getUses()==3,"Sanitize reset trade stock");h.succeed();
    }
    @GameTest(template="empty") public static void tradedGearLosesVanillaEnchantButKeepsRunesAndStock(GameTestHelper h){
        var sword=gear(Items.DIAMOND_SWORD,RuneEffect.SWORD_STAR_SLASH);EnhancementData.setLevel(sword,5);sword.enchant(h.getLevel().registryAccess().registryOrThrow(Registries.ENCHANTMENT).getHolderOrThrow(Enchantments.SHARPNESS),4);
        var offer=new MerchantOffer(new ItemCost(Items.EMERALD,20),Optional.empty(),sword,2,3,10,0.05F);
        h.assertTrue(VillagerRuneTrades.sanitize(offer)==offer&&!offer.getResult().isEnchanted()&&offer.getUses()==2&&EnhancementData.level(sword)==5&&RuneDataHelper.getRuneEffect(sword)==RuneEffect.SWORD_STAR_SLASH,"Equipment trade migration lost data");h.succeed();
    }
    @GameTest(template="empty") public static void staffManaRunesHaveRealEffects(GameTestHelper h){
        var p=mage(h,RuneEffect.STAFF_ECONOMY_MYTHIC);h.assertTrue(MagicSystem.manaCost(p,40)==32,"Economy rune has no effect");
        p.setItemSlot(EquipmentSlot.HEAD,gear(Items.IRON_HELMET,RuneEffect.HELMET_RESERVE_MYTHIC));h.assertTrue(MagicSystem.maxMana(p)==150,"Mana helmet missing");
        p.setItemInHand(InteractionHand.MAIN_HAND,gear(StarRPG.MAGIC_STAFF.get(),RuneEffect.STAFF_FLOW_MYTHIC));p.setItemSlot(EquipmentSlot.LEGS,gear(Items.IRON_LEGGINGS,RuneEffect.LEGGINGS_MANA_FLOW_MYTHIC));p.getPersistentData().putFloat("starrpg_mana",0);p.tickCount=20;MagicSystem.tick(new PlayerTickEvent.Post(p));
        h.assertTrue(Math.abs(MagicSystem.mana(p)-7)<0.001,"Mana regen runes missing");h.succeed();
    }
    @GameTest(template="empty") public static void staffRuneProjectileSnapshotAddsDamage(GameTestHelper h){
        var p=mage(h,RuneEffect.STAFF_FORCE_MYTHIC);var projectile=new MagicBolt(h.getLevel(),p,0,6);p.setItemInHand(InteractionHand.MAIN_HAND,ItemStack.EMPTY);
        var target=EntityType.COW.create(h.getLevel());MagicSystem.damage(p,target,6,projectile);
        h.assertTrue(Math.abs(target.getHealth()-1.5F)<0.001,"Fired staff rune lost after swap");h.succeed();
    }
    @GameTest(template="empty") public static void extendedArmorStatsRemoveAndDamageReductionsWork(GameTestHelper h){
        var p=player(h);double mining=p.getAttributeValue(Attributes.BLOCK_BREAK_SPEED);
        p.setItemSlot(EquipmentSlot.HEAD,gear(Items.IRON_HELMET,RuneEffect.HELMET_MINING_MYTHIC));p.setItemSlot(EquipmentSlot.LEGS,gear(Items.IRON_LEGGINGS,RuneEffect.LEGGINGS_TOUGHNESS_MYTHIC));ExtendedRuneEffects.tick(new PlayerTickEvent.Post(p));
        h.assertTrue(p.getAttributeValue(Attributes.BLOCK_BREAK_SPEED)>mining&&p.getAttributeValue(Attributes.ARMOR_TOUGHNESS)==2.5,"New passive armor effects missing");
        p.setItemSlot(EquipmentSlot.HEAD,ItemStack.EMPTY);p.setItemSlot(EquipmentSlot.LEGS,gear(Items.IRON_LEGGINGS,RuneEffect.LEGGINGS_FEATHER_MYTHIC));p.setItemSlot(EquipmentSlot.FEET,gear(Items.IRON_BOOTS,RuneEffect.BOOTS_FEATHER_MYTHIC));ExtendedRuneEffects.tick(new PlayerTickEvent.Post(p));
        var damage=new LivingIncomingDamageEvent(p,new DamageContainer(h.getLevel().damageSources().fall(),10));ExtendedRuneEffects.incoming(damage);
        h.assertTrue(p.getAttributeValue(Attributes.BLOCK_BREAK_SPEED)==mining&&p.getAttributeValue(Attributes.ARMOR_TOUGHNESS)==0&&Math.abs(damage.getAmount()-4)<0.001,"Armor stats stuck or fall guard wrong");h.succeed();
    }
    @GameTest(template="empty") public static void newMeleeExecutionActuallyAddsDamage(GameTestHelper h){
        var p=player(h);p.setItemInHand(InteractionHand.MAIN_HAND,gear(Items.IRON_SWORD,RuneEffect.SWORD_EXECUTE_MYTHIC));var target=EntityType.COW.create(h.getLevel());target.setHealth(3);
        target.hurt(h.getLevel().damageSources().playerAttack(p),1);h.assertTrue(target.getHealth()==0,"Execution rune is cosmetic only");h.succeed();
    }
    @GameTest(template="empty") public static void staffModelHasRealGeometryAndCorrectParent(GameTestHelper h)throws Exception{
        try(var stream=StarRPG.class.getClassLoader().getResourceAsStream("assets/starrpg/models/item/magic_staff.json")){
            var json=com.google.gson.JsonParser.parseReader(new java.io.InputStreamReader(stream,java.nio.charset.StandardCharsets.UTF_8)).getAsJsonObject();
            h.assertTrue(json.get("parent").getAsString().equals("minecraft:block/block")&&json.getAsJsonArray("elements").size()>=6,"Staff still inherits generated-item parent");
            for(var element:json.getAsJsonArray("elements"))h.assertTrue(element.getAsJsonObject().getAsJsonObject("faces").size()==6,"Staff has missing faces");
        }h.succeed();
    }
    @GameTest(template="empty") public static void materialPriceIncreaseAndDaggerRange(GameTestHelper h){
        h.assertTrue(Economy.Product.DUST.price()==40&&Economy.Product.FRAGMENT.price()==400,"Default material price did not rise");
        var dagger=new ItemStack(StarRPG.STAR_DAGGER.get());var mods=dagger.get(DataComponents.ATTRIBUTE_MODIFIERS);
        h.assertTrue(mods.modifiers().stream().anyMatch(e->e.attribute().equals(Attributes.ENTITY_INTERACTION_RANGE)&&e.modifier().amount()==-0.7),"Dagger range not shortened");h.succeed();
    }
}
