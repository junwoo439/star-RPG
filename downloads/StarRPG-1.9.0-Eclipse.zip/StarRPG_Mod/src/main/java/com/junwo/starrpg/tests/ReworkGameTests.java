package com.junwo.starrpg.tests;

import com.junwo.starrpg.*;
import java.util.*;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.*;
import net.minecraft.gametest.framework.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.*;
import net.minecraft.world.item.*;
import net.minecraft.world.item.component.*;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.GameType;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.player.AttackEntityEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.gametest.*;

@GameTestHolder(StarRPG.MODID)
@PrefixGameTestTemplate(false)
public class ReworkGameTests {
    private static Player player(GameTestHelper h){return h.makeMockPlayer(GameType.SURVIVAL);}
    private static void fund(Player p,int amount){var bank=StarWallet.get(p.getServer());int old=bank.balance(p.getUUID());if(old>0)bank.debit(p.getUUID(),old);bank.credit(p.getUUID(),amount);}
    @GameTest(template="empty") public static void allVanillaItemsHavePricesAndExportCatalog(GameTestHelper h)throws Exception{
        StringBuilder csv=new StringBuilder("item_id,base_gold,max_durability\n");int count=0;
        for(Item item:BuiltInRegistries.ITEM){if(item==Items.AIR)continue;int price=SellPrices.base(item);
            h.assertTrue(price>0,"Unpriced item: "+BuiltInRegistries.ITEM.getKey(item));
            csv.append(BuiltInRegistries.ITEM.getKey(item)).append(',').append(price).append(',').append(item.getDefaultInstance().getMaxDamage()).append('\n');count++;
        }
        h.assertTrue(count>1300,"Incomplete item registry");
        java.nio.file.Files.writeString(java.nio.file.Path.of("../SELL-PRICES-1.9.csv"),csv.toString());h.succeed();
    }
    @GameTest(template="empty") public static void salesRespectDamageContentsAndExactProceeds(GameTestHelper h){
        Player p=player(h);fund(p,100);var bank=StarWallet.get(p.getServer());var stack=new ItemStack(Items.DIAMOND,4);
        h.assertTrue(SellPrices.sell(p,stack,2)&&stack.getCount()==2&&bank.balance(p.getUUID())==200,"Sale charged wrong count/price");
        var sword=new ItemStack(Items.DIAMOND_SWORD);int full=SellPrices.unit(sword);sword.setDamageValue(sword.getMaxDamage()/2);h.assertTrue(SellPrices.unit(sword)<=full/2+1,"Damaged gear sold for full price");
        var box=new ItemStack(Items.SHULKER_BOX);box.set(DataComponents.CONTAINER,ItemContainerContents.fromItems(List.of(new ItemStack(Items.DIAMOND))));
        h.assertTrue(SellPrices.unit(box)==0&&!SellPrices.sell(p,box,1)&&box.getCount()==1,"Sold container contents");
        var bundle=new ItemStack(Items.BUNDLE);bundle.set(DataComponents.BUNDLE_CONTENTS,new BundleContents(List.of(new ItemStack(Items.DIAMOND))));h.assertTrue(SellPrices.unit(bundle)==0,"Sold filled bundle");h.succeed();
    }
    @GameTest(template="empty") public static void sellingCannotOverflowOrCreateBuySellProfit(GameTestHelper h){
        Player p=player(h);fund(p,StarWallet.MAX_BALANCE);var diamond=new ItemStack(Items.DIAMOND);h.assertTrue(!SellPrices.sell(p,diamond,1)&&diamond.getCount()==1,"Balance overflow consumed item");
        for(var product:Economy.Product.values())h.assertTrue(SellPrices.unit(product.stack(1))<product.price(),"Buy/sell money loop");
        var c=h.makeMockPlayer(GameType.CREATIVE);var stone=new ItemStack(Items.STONE);h.assertTrue(!SellPrices.sell(c,stone,1)&&stone.getCount()==1,"Creative cash generation");h.succeed();
    }
    @GameTest(template="empty") public static void salesBudgetPersistsAndResets(GameTestHelper h){
        var bank=new StarWallet();UUID id=UUID.randomUUID();bank.credit(id,1);bank.recordSale(id,9999,100);
        h.assertTrue(bank.canSell(id,1,100)&&!bank.canSell(id,2,100),"Sale cap incorrect");
        bank=StarWallet.load(bank.save(new CompoundTag(),h.getLevel().registryAccess()),h.getLevel().registryAccess());
        h.assertTrue(!bank.canSell(id,2,101)&&bank.canSell(id,10000,1300),"Sale cap reset on reload or failed interval");h.succeed();
    }
    @GameTest(template="empty") public static void menuReturnsUnsoldItems(GameTestHelper h){
        var p=new net.neoforged.neoforge.common.util.FakePlayer(h.getLevel(),new com.mojang.authlib.GameProfile(UUID.randomUUID(),"shop-test"));var menu=new MaterialShopMenu(1,p.getInventory());menu.getSlot(0).set(new ItemStack(Items.DIAMOND,3));menu.removed(p);
        h.assertTrue(p.getInventory().countItem(Items.DIAMOND)==3&&menu.getSlot(0).getItem().isEmpty(),"Closing shop lost or duplicated sale slot");h.succeed();
    }
    @GameTest(template="empty") public static void careerSelectionAdvancementAndSave(GameTestHelper h){
        Player p=player(h);fund(p,10000);h.assertTrue(Careers.select(p,0),"First career selection failed");var v=Careers.profile(p);
        h.assertTrue(v.rank()==1&&!Careers.advance(p),"Unqualified advancement accepted");
        for(int i=0;i<24;i++)Careers.gain(p,false,0);Careers.gain(p,true,0);v.mastery[0]=12;p.getInventory().add(new ItemStack(Items.IRON_INGOT,8));
        h.assertTrue(Careers.advance(p)&&v.rank()==2&&StarWallet.get(p.getServer()).balance(p.getUUID())==9000,"Second advancement wrong cost/rank");
        v.xp[0]=600;v.bosses[0]=3;v.mastery[0]=16;p.getInventory().add(new ItemStack(Items.IRON_INGOT,10));h.assertTrue(Careers.advance(p)&&v.rank()==3&&!Careers.advance(p),"Third advancement resource validation wrong");
        var saved=CareerData.get(p.getServer()).save(new CompoundTag(),h.getLevel().registryAccess());var loaded=CareerData.load(saved,h.getLevel().registryAccess()).profile(p.getUUID());
        h.assertTrue(loaded.rank()==3&&loaded.xp()==0&&loaded.bosses()==3,"Career data lost");h.succeed();
    }
    @GameTest(template="empty") public static void switchingCareersPreservesProgressAndRemovesStats(GameTestHelper h){
        Player p=player(h);fund(p,2000);p.setHealth(8);p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(StarRPG.STAR_SPEAR.get()));Careers.select(p,0);var v=Careers.profile(p);v.ranks[0]=3;v.xp[0]=1234;Careers.updateAttributes(p);
        h.assertTrue(p.getMaxHealth()==32&&p.getHealth()==8,"Career stat added health or wrong amount");
        h.assertTrue(!Careers.select(p,1),"Switch cooldown ignored");v.switchReady=0;
        h.assertTrue(Careers.select(p,1)&&p.getMaxHealth()==20&&p.getHealth()==8&&v.xp[0]==1234&&v.ranks[0]==3,"Career switch lost progress/stats");h.succeed();
    }
    @GameTest(template="empty") public static void bowElementsOnlyFitBowsAndPreserveRunes(GameTestHelper h){
        var bow=new ItemStack(Items.BOW);EnhancementData.setLevel(bow,7);RuneDataHelper.setRuneEffect(bow,RuneEffect.BOW_HUNTER_COMMON);
        h.assertTrue(BowElements.set(bow,BowElements.Element.ICE)&&BowElements.get(bow)==BowElements.Element.ICE,"Bow element missing");
        h.assertTrue(EnhancementData.level(bow)==7&&RuneDataHelper.getRuneEffect(bow)==RuneEffect.BOW_HUNTER_COMMON,"Element erased existing enhancements");
        for(Item item:List.of(Items.CROSSBOW,Items.TRIDENT,Items.IRON_SWORD,Items.IRON_HELMET))h.assertTrue(!BowElements.set(new ItemStack(item),BowElements.Element.ICE),"Element leaked to non-bow");h.succeed();
    }
    @GameTest(template="empty") public static void removedElementShopCannotChargeOrEngrave(GameTestHelper h){
        Player p=player(h);fund(p,1000);p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(Items.BOW));p.getInventory().items.set(2,new ItemStack(StarRPG.COMMON_RUNE.get(),2));
        h.assertTrue(!BowElements.engrave(p,0),"Removed element shop still grants element");
        h.assertTrue(StarWallet.get(p.getServer()).balance(p.getUUID())==1000&&p.getInventory().getItem(2).getCount()==2,"Removed shop consumed resources");
        p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(Items.CROSSBOW));h.assertTrue(!BowElements.engrave(p,1),"Crossbow accepted element");h.succeed();
    }
    @GameTest(template="empty") public static void controlImmunitySharedAcrossAttackersAndElements(GameTestHelper h){
        Player p=player(h),other=player(h),victim=player(h);
        h.assertTrue(BowElements.apply(p,victim,BowElements.Element.LIGHTNING)&&victim.hasEffect(ModEffects.STUN),"Stun did not apply");
        h.assertTrue(victim.getEffect(ModEffects.STUN).getDuration()==10,"Stun duration wrong");
        h.assertTrue(!BowElements.apply(other,victim,BowElements.Element.ICE),"Different attacker bypassed common immunity");
        var event=new AttackEntityEvent(victim,p);ControlEffects.attack(event);h.assertTrue(event.isCanceled(),"Stun did not stop melee");h.succeed();
    }
    @GameTest(template="empty") public static void bossesUseControlFallbackAndPetsAreProtected(GameTestHelper h){
        Player p=player(h);var boss=EntityType.WITHER.create(h.getLevel());
        h.assertTrue(BowElements.apply(p,boss,BowElements.Element.ICE)&&!boss.hasEffect(ModEffects.ROOT)&&boss.getAttribute(Attributes.MOVEMENT_SPEED).getModifier(ControlEffects.BOSS_SLOW)!=null,"Boss hard-locked or no fallback");
        var pet=EntityType.WOLF.create(h.getLevel());pet.setTame(true,true);p.getPersistentData().remove("starrpg_element_ready");h.assertTrue(!BowElements.apply(p,pet,BowElements.Element.ICE),"Element hurt tame pet");h.succeed();
    }
    @GameTest(template="empty") public static void vanillaEnchantRemovalPreservesStarData(GameTestHelper h){
        var item=new ItemStack(Items.DIAMOND_SWORD);EnhancementData.setLevel(item,6);RuneDataHelper.setRuneEffect(item,RuneEffect.SWORD_STAR_SLASH);
        item.enchant(h.getLevel().registryAccess().registryOrThrow(Registries.ENCHANTMENT).getHolderOrThrow(Enchantments.SHARPNESS),5);
        h.assertTrue(VanillaEnchantments.strip(item)&&!item.isEnchanted(),"Vanilla enchantment remained");
        h.assertTrue(EnhancementData.level(item)==6&&RuneDataHelper.getRuneEffect(item)==RuneEffect.SWORD_STAR_SLASH,"Removed StarRPG progression");h.succeed();
    }
    @GameTest(template="empty") public static void throwPreservesItemAndNeverDuplicates(GameTestHelper h){
        Player p=player(h);Careers.profile(p).selected=1;Careers.profile(p).ranks[1]=1;p.setPos(h.absoluteVec(new Vec3(1,3,1)));var dagger=new ItemStack(StarRPG.STAR_DAGGER.get());EnhancementData.setLevel(dagger,8);RuneDataHelper.setRuneEffect(dagger,RuneEffect.SWORD_STAR_SLASH);dagger.setDamageValue(20);p.setItemInHand(InteractionHand.MAIN_HAND,dagger);
        h.assertTrue(WeaponAbilities.throwDagger(p,InteractionHand.MAIN_HAND)&&p.getMainHandItem().isEmpty(),"Throw did not transfer inventory ownership");
        var thrown=h.getLevel().getEntitiesOfClass(ThrownDagger.class,p.getBoundingBox().inflate(2)).getFirst();
        var tag=new CompoundTag();thrown.saveWithoutId(tag);var restored=new ThrownDagger(ModEntities.THROWN_DAGGER.get(),h.getLevel());restored.load(tag);
        h.assertTrue(EnhancementData.level(restored.getItem())==8&&restored.getItem().getDamageValue()==20&&RuneDataHelper.getRuneEffect(restored.getItem())==RuneEffect.SWORD_STAR_SLASH,"Projectile save lost item metadata");
        int before=h.getLevel().getEntitiesOfClass(ItemEntity.class,p.getBoundingBox().inflate(3),e->e.getItem().is(StarRPG.STAR_DAGGER.get())).size();thrown.settle();thrown.settle();
        int after=h.getLevel().getEntitiesOfClass(ItemEntity.class,p.getBoundingBox().inflate(3),e->e.getItem().is(StarRPG.STAR_DAGGER.get())).size();h.assertTrue(after==before+1,"Projectile duplicated/lost recovery item");h.succeed();
    }
    @GameTest(template="empty") public static void skillCooldownAndWeaponSwapCancel(GameTestHelper h){
        Player p=player(h);Careers.profile(p).selected=1;Careers.profile(p).ranks[1]=1;p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(StarRPG.STAR_DAGGER.get()));
        h.assertTrue(WeaponAbilities.activate(p)&&!WeaponAbilities.activate(p),"Ability spam allowed");
        p.setItemInHand(InteractionHand.MAIN_HAND,ItemStack.EMPTY);WeaponAbilities.tick(new PlayerTickEvent.Post(p));
        p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(StarRPG.STAR_DAGGER.get()));h.assertTrue(!WeaponAbilities.activate(p)&&!p.hasEffect(ModEffects.COMBO),"Swap reset cooldown or retained animation");WeaponAbilities.cancel(p);h.succeed();
    }
    @GameTest(template="hook_arena",timeoutTicks=60) public static void daggerPerformsThreeActualHits(GameTestHelper h){
        Player p=player(h);Careers.profile(p).selected=1;Careers.profile(p).ranks[1]=1;p.setPos(h.absoluteVec(new Vec3(2.5,2,2.5)));p.setYRot(0);p.setXRot(0);p.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(4);
        p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(StarRPG.STAR_DAGGER.get()));var target=h.spawn(EntityType.COW,2,2,4);target.setNoAi(true);target.setNoGravity(true);
        h.assertTrue(WeaponAbilities.target(p,2.5,0.45)==target,"Combo target out of reach or blocked");
        h.assertTrue(WeaponAbilities.activate(p),"Combo start failed");WeaponAbilities.tick(new PlayerTickEvent.Post(p));
        h.runAfterDelay(6,()->WeaponAbilities.tick(new PlayerTickEvent.Post(p)));
        h.runAfterDelay(12,()->WeaponAbilities.tick(new PlayerTickEvent.Post(p)));
        h.runAfterDelay(14,()->{WeaponAbilities.cancel(p);h.assertTrue(target.getHealth()<4,"Combo did not land all three hits: "+target.getHealth());h.succeed();});
    }
    @GameTest(template="hook_arena",timeoutTicks=140) public static void crossbowBarrageUsesAmmoAndEnds(GameTestHelper h){
        Player p=player(h);Careers.profile(p).selected=2;Careers.profile(p).ranks[2]=1;p.setPos(h.absoluteVec(new Vec3(2,4,2)));p.setYRot(-90);p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(Items.CROSSBOW));p.getInventory().items.set(1,new ItemStack(Items.ARROW,20));
        h.assertTrue(WeaponAbilities.activate(p)&&p.hasEffect(ModEffects.BRACED),"Barrage failed to brace");
        for(int t=0;t<=100;t+=10){final int delay=t;h.runAfterDelay(delay,()->WeaponAbilities.tick(new PlayerTickEvent.Post(p)));}
        h.runAfterDelay(105,()->{h.assertTrue(p.getInventory().countItem(Items.ARROW)==10,"Barrage ammo not exactly ten shots");h.assertTrue(!p.hasEffect(ModEffects.BRACED),"Barrage never unlocked movement");WeaponAbilities.cancel(p);h.succeed();});
    }
    @GameTest(template="empty") public static void giantArrowHasRealSizeAndPiercingLimit(GameTestHelper h){
        Player p=player(h);var a=new GiantArrow(h.getLevel(),p,new ItemStack(Items.ARROW),new ItemStack(Items.BOW));
        h.assertTrue(a.getBbWidth()==0.9F&&a.getPierceLevel()==2,"Giant arrow has no real collision size/three-target limit");
        h.assertTrue(a.getWeaponItem().is(Items.BOW),"Giant arrow lost fired bow snapshot");h.succeed();
    }
    @GameTest(template="hook_arena") public static void hammerSweepHasFrontArcAndNoRecursiveHit(GameTestHelper h){
        Player p=player(h);p.setPos(h.absoluteVec(new Vec3(2.5,2,2.5)));p.setYRot(0);p.setXRot(0);p.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(6);p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(StarRPG.WAR_HAMMER.get()));
        var main=h.spawn(EntityType.COW,2,2,4);var side=h.spawn(EntityType.COW,3,2,4);var behind=h.spawn(EntityType.COW,2,2,1);
        main.hurt(h.getLevel().damageSources().playerAttack(p),1);
        h.assertTrue(main.getHealth()==9 && side.getHealth()<10 && behind.getHealth()==10,"Hammer sweep hit wrong arc or primary twice");h.succeed();
    }
    @GameTest(template="hook_arena",timeoutTicks=60) public static void hammerShockwaveHasWindupAndAirDodge(GameTestHelper h){
        Player p=player(h);Careers.profile(p).selected=4;Careers.profile(p).ranks[4]=1;p.setPos(h.absoluteVec(new Vec3(2.5,2,2.5)));p.setOnGround(true);p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(StarRPG.WAR_HAMMER.get()));
        h.setBlock(2,1,5,net.minecraft.world.level.block.Blocks.STONE);var ground=h.spawn(EntityType.COW,2,2,5);ground.setNoAi(true);ground.setOnGround(true);
        var air=h.spawn(EntityType.COW,3,4,4);air.setNoAi(true);air.setNoGravity(true);
        h.assertTrue(WeaponAbilities.activate(p),"Hammer cast failed");WeaponAbilities.tick(new PlayerTickEvent.Post(p));h.assertTrue(ground.getHealth()==10,"Shockwave hit without windup");
        for(int t=14;t<=28;t+=2)h.runAfterDelay(t,()->WeaponAbilities.tick(new PlayerTickEvent.Post(p)));
        h.runAfterDelay(30,()->{WeaponAbilities.cancel(p);h.assertTrue(ground.getHealth()==5 && air.getHealth()==10,"Shockwave repeat hit or no air dodge: "+ground.getHealth()+"/"+air.getHealth());h.succeed();});
    }
    @GameTest(template="hook_arena",timeoutTicks=50) public static void giantArrowHitsAtMostThreeTargets(GameTestHelper h){
        Player p=player(h);p.setPos(h.absoluteVec(new Vec3(1,2,2.5)));var targets=new java.util.ArrayList<LivingEntity>();
        for(int x:new int[]{3,6,9,12}){var mob=h.spawn(EntityType.COW,x,2,2);mob.setNoAi(true);mob.setNoGravity(true);mob.getAttribute(Attributes.MAX_HEALTH).setBaseValue(100);mob.setHealth(100);targets.add(mob);}
        var arrow=new GiantArrow(h.getLevel(),p,new ItemStack(Items.ARROW),new ItemStack(Items.BOW));arrow.setPos(h.absoluteVec(new Vec3(1,2.6,2.5)));arrow.setNoGravity(true);arrow.shoot(1,0,0,2,0);h.getLevel().addFreshEntity(arrow);
        h.runAfterDelay(15,()->{long hit=targets.stream().filter(m->m.getHealth()<100).count();h.assertTrue(hit==3&&targets.get(3).getHealth()==100,"Giant arrow piercing wrong: "+hit);h.succeed();});
    }
    @GameTest(template="empty",timeoutTicks=50) public static void bossFallbackExpires(GameTestHelper h){
        Player p=player(h);var boss=EntityType.WITHER.create(h.getLevel());double speed=boss.getAttributeValue(Attributes.MOVEMENT_SPEED);BowElements.apply(p,boss,BowElements.Element.ICE);
        h.assertTrue(boss.getAttributeValue(Attributes.MOVEMENT_SPEED)<speed,"Boss fallback not applied");
        h.runAfterDelay(22,()->{ControlEffects.tick(new net.neoforged.neoforge.event.tick.EntityTickEvent.Post(boss));h.assertTrue(boss.getAttributeValue(Attributes.MOVEMENT_SPEED)==speed,"Boss slowed forever");h.succeed();});
    }

}
