package com.junwo.starrpg;

import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;

@EventBusSubscriber(
        modid = StarRPG.MODID,
        bus = EventBusSubscriber.Bus.MOD
)
public class ModPayloads {

    @SubscribeEvent
    public static void registerPayloads(
            RegisterPayloadHandlersEvent event
    ) {
        event.registrar("5").playToServer(ActionPayload.TYPE,ActionPayload.STREAM_CODEC,ActionPayload::handle);
        event.registrar("5").playToServer(
                UseChestAbilityPayload.TYPE,
                UseChestAbilityPayload.STREAM_CODEC,
                UseChestAbilityPayload::handle
        );
    }
}