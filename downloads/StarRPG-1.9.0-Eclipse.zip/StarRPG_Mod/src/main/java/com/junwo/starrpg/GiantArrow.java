package com.junwo.starrpg;

import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;

public final class GiantArrow extends AbstractArrow {
    public GiantArrow(EntityType<? extends GiantArrow> type,Level level){super(type,level);}
    public GiantArrow(Level level,Player p,ItemStack ammo,ItemStack bow){super(ModEntities.GIANT_ARROW.get(),p,level,ammo,bow);setBaseDamage(3.2);pickup=p.hasInfiniteMaterials()?Pickup.CREATIVE_ONLY:Pickup.ALLOWED;}
    @Override public void tick(){
        if(!level().isClientSide()&&!inGround&&tickCount%2==0){
            var motion=getDeltaMovement();var side=motion.cross(new net.minecraft.world.phys.Vec3(0,1,0)).normalize();
            double phase=tickCount*0.8;
            for(int i=0;i<2;i++){double sign=i==0?1:-1;var pos=position().add(side.scale(Math.cos(phase)*0.25*sign)).add(0,Math.sin(phase)*0.25*sign,0);CombatVisuals.at((net.minecraft.server.level.ServerLevel)level(),pos,net.minecraft.core.particles.ParticleTypes.END_ROD,1,0);}
        }super.tick();
    }
    @Override public byte getPierceLevel(){return (byte)2;}
    @Override protected void doPostHurtEffects(LivingEntity target){
        super.doPostHurtEffects(target);
        var contents=getPickupItemStackOrigin().getOrDefault(net.minecraft.core.component.DataComponents.POTION_CONTENTS,net.minecraft.world.item.alchemy.PotionContents.EMPTY);
        contents.potion().ifPresent(potion->{for(var effect:potion.value().getEffects())target.addEffect(new net.minecraft.world.effect.MobEffectInstance(effect.getEffect(),Math.max(effect.mapDuration(t->t/8),1),effect.getAmplifier(),effect.isAmbient(),effect.isVisible()),getEffectSource());});
        for(var effect:contents.customEffects())target.addEffect(new net.minecraft.world.effect.MobEffectInstance(effect),getEffectSource());
        if(getPickupItemStackOrigin().is(Items.SPECTRAL_ARROW))target.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.GLOWING,200,0),getEffectSource());
    }
    @Override protected ItemStack getDefaultPickupItem(){return new ItemStack(Items.ARROW);}
    @Override protected boolean canHitEntity(Entity entity){return super.canHitEntity(entity)&&(!(getOwner() instanceof Player p)||!(entity instanceof LivingEntity living)||CombatRules.canHarm(p,living));}
}
