package com.junwo.starrpg;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.*;

/** A full-bright, rotating spell core remains visible even with reduced particles. */
public final class MagicBoltRenderer extends ThrownItemRenderer<MagicBolt> {
    public MagicBoltRenderer(EntityRendererProvider.Context context){super(context,1.8F,true);}
    @Override public void render(MagicBolt bolt,float yaw,float partial,PoseStack pose,MultiBufferSource buffers,int light){
        pose.pushPose();float scale=bolt.spellId()==1?1.3F:1;pose.scale(scale,scale,scale);
        pose.mulPose(Axis.YP.rotationDegrees((bolt.tickCount+partial)*12));super.render(bolt,yaw,partial,pose,buffers,15728880);pose.popPose();
    }
}
