package com.junwo.starrpg;

import java.util.List;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.living.*;

@EventBusSubscriber(modid=StarRPG.MODID)
public final class RangedRuneEffects {
    private record Shot(Player player,ItemStack weapon,RuneWeaponType type,RuneEffect rune,float scale,boolean charged) {}
    public static void prepare(AbstractArrow arrow) {
        if(!(arrow.getOwner() instanceof Player) || arrow.getPersistentData().contains("starrpg_shot_power"))return;
        ItemStack item=arrow.getWeaponItem();if(item==null)return;
        RuneWeaponType type=RuneWeaponType.forItem(item);if(type==null || !type.isRanged())return;
        float power=type==RuneWeaponType.BOW?(float)Math.clamp(arrow.getDeltaMovement().length()/3,0,1):1;
        arrow.getPersistentData().putFloat("starrpg_shot_power",power);
    }
    @SubscribeEvent public static void spawn(EntityJoinLevelEvent e) { if(!e.getLevel().isClientSide() && e.getEntity() instanceof AbstractArrow arrow)prepare(arrow); }
    private static Shot shot(DamageSource source) {
        if(!(source.getEntity() instanceof Player p))return null;
        ItemStack item;float power=1;
        if(source.getDirectEntity() instanceof AbstractArrow arrow) {
            item=arrow.getWeaponItem();
            if(arrow.getPersistentData().contains("starrpg_shot_power"))power=arrow.getPersistentData().getFloat("starrpg_shot_power");
        } else if(CombatRules.primary(source) && RuneWeaponType.forItem(p.getMainHandItem())==RuneWeaponType.TRIDENT) {
            item=p.getMainHandItem();power=(float)Math.sqrt(CombatRules.attackScale(source));
        } else return null;
        if(item==null)return null;
        var type=RuneWeaponType.forItem(item);if(type==null || !type.isRanged())return null;
        var rune=RuneDataHelper.getRuneEffect(item);if(rune!=null && rune.getWeaponType()!=type)rune=null;
        boolean charged=source.getDirectEntity() instanceof AbstractArrow?power>=0.9:CombatRules.charged(source);
        return new Shot(p,item,type,rune,power*power,charged);
    }
    @SubscribeEvent public static void incoming(LivingIncomingDamageEvent e) {
        Shot s=shot(e.getSource());if(s==null || !CombatRules.canHarm(s.player,e.getEntity()))return;
        float bonus=e.getSource().getDirectEntity() instanceof AbstractArrow?(float)EnhancementData.power(s.weapon)*0.5F*s.scale:0;
        if(s.rune!=null) {
            int g=s.rune.getRarity().ordinal()+1,v=s.rune.getVariant();var target=e.getEntity();
            bonus+=s.scale*switch(s.type) {
                case BOW -> v==0 && target.getHealth()>=target.getMaxHealth()*0.9F?g*0.6F:v==2 && target.hasEffect(MobEffects.GLOWING)?g*0.4F:0;
                case CROSSBOW -> v==0?g*0.4F:v==1 && target.getArmorValue()>=10?g:0;
                case TRIDENT -> v==0 && (s.player.isInWaterOrRain() || target.isInWaterOrRain())?g*0.6F:v==1 && target.getHealth()<=target.getMaxHealth()*0.5F?g*0.5F:0;
                default -> 0;
            };
        }
        e.setAmount(e.getAmount()+bonus);
    }
    @SubscribeEvent public static void before(LivingDamageEvent.Pre e) {
        Shot s=shot(e.getSource());if(s==null)return;
        e.getEntity().getPersistentData().putFloat("starrpg_ranged_before",e.getEntity().getHealth());
        e.getEntity().getPersistentData().putBoolean("starrpg_ranged_valid",CombatRules.canHarm(s.player,e.getEntity()));
    }
    private static boolean ready(Shot s,int ticks) {
        long now=s.player.level().getGameTime();String key="starrpg_ranged_"+s.type.name()+"_"+s.rune.getVariant();
        if(s.player.getPersistentData().getLong(key)>now)return false;
        s.player.getPersistentData().putLong(key,now+ticks);return true;
    }
    @SubscribeEvent public static void after(LivingDamageEvent.Post e) {
        Shot s=shot(e.getSource());if(s==null)return;
        var target=e.getEntity();var data=target.getPersistentData();
        float actual=Math.max(0,Math.min(e.getNewDamage(),data.getFloat("starrpg_ranged_before")-target.getHealth()));
        boolean allowed=data.getBoolean("starrpg_ranged_valid");data.remove("starrpg_ranged_before");data.remove("starrpg_ranged_valid");
        if(!allowed || actual<=0 || s.rune==null || !s.charged)return;
        int g=s.rune.getRarity().ordinal()+1,v=s.rune.getVariant();
        if(s.type==RuneWeaponType.BOW) {
            if(v==1 && target.isAlive() && ready(s,100))target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,20+g*10,0));
            if(v==2 && target.isAlive() && ready(s,40))target.addEffect(new MobEffectInstance(MobEffects.GLOWING,40+g*20,0));
            if(v==3 && ready(s,120))splash(s.player,target,g*0.4F);
        } else if(s.type==RuneWeaponType.CROSSBOW) {
            if(v==2 && target.isAlive() && ready(s,80))target.knockback(0.15+g*0.05,s.player.getX()-target.getX(),s.player.getZ()-target.getZ());
            if(v==3 && target.isAlive() && ready(s,120))target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS,20+g*10,0));
        } else if(s.type==RuneWeaponType.TRIDENT) {
            if(v==2 && ready(s,120))splash(s.player,target,g*0.4F);
            if(v==3 && ready(s,60))s.player.heal(Math.min(g*0.4F,actual*g*0.03F));
        }
    }
    private static void splash(Player p,LivingEntity center,float damage) {
        var targets=p.level().getEntitiesOfClass(LivingEntity.class,center.getBoundingBox().inflate(2.5),e->e!=center && CombatRules.canHarm(p,e));
        targets.sort(java.util.Comparator.comparingDouble(e->e.distanceToSqr(center)));
        targets.stream().limit(8).forEach(e->CombatRules.runeDamage(p,e,damage));
        if(p.level() instanceof net.minecraft.server.level.ServerLevel level)level.sendParticles(net.minecraft.core.particles.ParticleTypes.ELECTRIC_SPARK,center.getX(),center.getY()+0.5,center.getZ(),12,0.8,0.4,0.8,0.1);
    }
    private static String number(double value) { return String.format(java.util.Locale.ROOT, "%.1f", value); }
    public static List<String> description(RuneEffect e) {
        int g=e.getRarity().ordinal()+1,v=e.getVariant();
        return switch(e.getWeaponType()) {
            case BOW -> switch(v) {
                case 0 -> List.of("체력 90% 이상인 적에게 추가 피해 "+number(g*0.6F),"추가 피해는 활 충전량에 비례");
                case 1 -> List.of("90% 이상 충전 명중: 둔화 I, "+(1+g*0.5F)+"초","재사용 5초");
                case 2 -> List.of("90% 이상 충전 명중: 발광 "+(2+g)+"초 / 재사용 2초","발광 중인 적에게 추가 피해 "+number(g*0.4F));
                default -> List.of("90% 이상 충전 명중: 주변 적 피해 "+number(g*0.4F),"범위 2.5칸 / 최대 8마리 / 재사용 6초");
            };
            case CROSSBOW -> switch(v) {
                case 0 -> List.of("화살 추가 피해 "+number(g*0.4F),"방어력 계산 전에 적용");
                case 1 -> List.of("방어력 10 이상인 적에게 화살 추가 피해 "+g);
                case 2 -> List.of("화살 명중 시 적 밀쳐내기","재사용 4초 / 등급에 따라 힘 증가");
                default -> List.of("화살 명중: 나약함 I, "+(1+g*0.5F)+"초","재사용 6초 / 폭죽에는 적용 안 됨");
            };
            case TRIDENT -> switch(v) {
                case 0 -> List.of("나 또는 적이 물·비에 젖으면 추가 피해 "+number(g*0.6F),"근접·투척 모두 적용");
                case 1 -> List.of("체력 50% 이하인 적에게 추가 피해 "+number(g*0.5F),"근접·투척 모두 적용");
                case 2 -> List.of("충전 근접·투척 명중: 주변 적 피해 "+number(g*0.4F),"범위 2.5칸 / 최대 8마리 / 재사용 6초");
                default -> List.of("충전 근접·투척 실제 피해의 "+g*3+"% 회복","1회 최대 "+number(g*0.4F)+" HP / 재사용 3초");
            };
            default -> List.of();
        };
    }
}
