package com.junwo.starrpg;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.world.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;

public final class MagicStaffItem extends Item {
    public MagicStaffItem(Properties properties){super(properties.durability(384));}
    @Override public InteractionResultHolder<ItemStack> use(Level level,Player player,InteractionHand hand){
        var stack=player.getItemInHand(hand);if(hand!=InteractionHand.MAIN_HAND)return InteractionResultHolder.pass(stack);
        if(level.isClientSide())return InteractionResultHolder.success(stack);
        boolean result=player.isShiftKeyDown()?MagicSystem.cycle(player):MagicSystem.cast(player);
        return result?InteractionResultHolder.consume(stack):InteractionResultHolder.fail(stack);
    }
    @Override public void appendHoverText(ItemStack stack,TooltipContext context,List<Component> lines,TooltipFlag flag){
        super.appendHoverText(stack,context,lines,flag);
        lines.add(Component.literal("마법사 전용 · 우클릭: "+MagicSystem.SPELLS[MagicSystem.spell(stack)]));
        lines.add(Component.literal("Shift+우클릭: 주문 변경 / R: 유성 낙하 / G: 마나 집중"));
        lines.add(Component.literal("마나탄 8 MP / 화염구 18 MP / 회복 25 MP / 유성 40 MP"));
    }
}
