package com.junwo.starrpg;

import com.mojang.blaze3d.platform.InputConstants;

import net.minecraft.client.KeyMapping;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.settings.KeyConflictContext;
import org.lwjgl.glfw.GLFW;

@EventBusSubscriber(
        modid = StarRPG.MODID,
        value = Dist.CLIENT,
        bus = EventBusSubscriber.Bus.MOD
)
public class StarRPGKeyMappings {

    public static final KeyMapping CHEST_ABILITY =
            new KeyMapping(
                    "key.starrpg.chest_ability",
                    KeyConflictContext.IN_GAME,
                    InputConstants.Type.KEYSYM,
                    GLFW.GLFW_KEY_X,
                    "key.categories.starrpg"
            );

    public static final KeyMapping HUB = new KeyMapping("key.starrpg.hub",KeyConflictContext.IN_GAME,
            net.neoforged.neoforge.client.settings.KeyModifier.SHIFT,InputConstants.Type.KEYSYM,GLFW.GLFW_KEY_H,"key.categories.starrpg");
    public static final KeyMapping WEAPON = new KeyMapping("key.starrpg.weapon",KeyConflictContext.IN_GAME,InputConstants.Type.KEYSYM,GLFW.GLFW_KEY_R,"key.categories.starrpg");
    public static final KeyMapping CAREER = new KeyMapping("key.starrpg.career",KeyConflictContext.IN_GAME,InputConstants.Type.KEYSYM,GLFW.GLFW_KEY_G,"key.categories.starrpg");
    @SubscribeEvent
    public static void registerKeyMappings(
            RegisterKeyMappingsEvent event
    ) {
        event.register(CHEST_ABILITY);event.register(HUB);event.register(WEAPON);event.register(CAREER);
    }
}