package com.junwo.starrpg;

import net.minecraft.world.entity.player.*;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.SimpleContainer;

public final class MaterialShopMenu extends AbstractContainerMenu {
    private final Player owner;
    private final ContainerData data=new SimpleContainerData(128);
    private final SimpleContainer sale=new SimpleContainer(1);
    public int clientTab;
    public MaterialShopMenu(int id, Inventory inventory) {
        super(ModMenus.MATERIAL_SHOP.get(),id);owner=inventory.player;
        addSlot(new Slot(sale,0,25,79){@Override public boolean isActive(){return !owner.level().isClientSide()||clientTab==1;}});
        for(int row=0;row<3;row++)for(int col=0;col<9;col++)addSlot(new Slot(inventory,col+row*9+9,99+col*18,142+row*18){@Override public boolean isActive(){return !owner.level().isClientSide()||clientTab!=2;}});
        for(int col=0;col<9;col++)addSlot(new Slot(inventory,col,99+col*18,202){@Override public boolean isActive(){return !owner.level().isClientSide()||clientTab!=2;}});
        addDataSlots(data);refresh();
    }
    private void refresh() {
        if(owner.level().isClientSide()||owner.getServer()==null)return;
        int balance=StarWallet.get(owner.getServer()).balance(owner.getUUID());data.set(0,balance&65535);data.set(1,(balance>>>16)&65535);
        for(var p:Economy.Product.values())data.set(22+p.ordinal(),p.price());data.set(5,Config.ECONOMY_ENABLED.get()?1:0);
        var c=Careers.profile(owner);data.set(6,c.selected);data.set(7,c.rank()&65535);data.set(15,c.rank()>>>16);data.set(16,c.mastery()&65535);data.set(17,c.mastery()>>>16);data.set(8,c.xp()&65535);data.set(9,c.xp()>>>16);data.set(10,c.bosses());
        data.set(11,SellPrices.unit(sale.getItem(0)));var element=BowElements.get(owner.getMainHandItem());data.set(12,element==null?-1:element.ordinal());
        data.set(13,owner.getMainHandItem().getItem() instanceof net.minecraft.world.item.BowItem?1:0);
        data.set(14,owner.isCreative()||owner.isSpectator()?0:1);
        data.set(18,(int)MagicSystem.mana(owner));data.set(19,(int)MagicSystem.maxMana(owner));
        data.set(20,owner.getMainHandItem().getItem() instanceof MagicStaffItem?MagicSystem.spell(owner.getMainHandItem()):-1);
        for(int j=0;j<Careers.COUNT;j++){
            int base=52+j*6;data.set(base,c.ranks[j]&65535);data.set(base+1,c.ranks[j]>>>16);
            data.set(base+2,c.xp[j]&65535);data.set(base+3,c.xp[j]>>>16);
            data.set(base+4,c.mastery[j]&65535);data.set(base+5,c.mastery[j]>>>16);
            data.set(112+j,Math.min(32767,owner.getInventory().countItem(Careers.material(j))));
        }
        String[] keys={"starrpg_spell_ready","starrpg_heal_ready","starrpg_meteor_ready","starrpg_career_ready"};
        for(int i=0;i<4;i++)data.set(122+i,(int)Math.clamp(owner.getPersistentData().getLong(keys[i])-owner.level().getGameTime(),0,32767));
        data.set(21,c.selected>=0?Math.min(32767,owner.getInventory().countItem(Careers.material(c.selected))):0);
    }
    public int balance(){return (data.get(0)&65535)|((data.get(1)&65535)<<16);}
    public int price(int product){return data.get(22+product);}
    private int wide(int n){return(data.get(n)&65535)|((data.get(n+1)&65535)<<16);}
    public int previewRank(int job){return wide(52+job*6);}
    public int previewXp(int job){return wide(54+job*6);}
    public int previewMastery(int job){return wide(56+job*6);}
    public int previewMaterials(int job){return data.get(112+job);}
    public String cooldown(int i){return data.get(122+i)<=0?"준비":String.format(java.util.Locale.ROOT,"%.1f초",data.get(122+i)/20.0);}public boolean enabled(){return data.get(5)==1;}
    public int job(){return data.get(6);}public int rank(){return(data.get(7)&65535)|((data.get(15)&65535)<<16);}
    public int mastery(){return(data.get(16)&65535)|((data.get(17)&65535)<<16);}
    public int mana(){return data.get(18);}public int maxMana(){return data.get(19);}public int spell(){return data.get(20);}public int materials(){return data.get(21);}public int xp(){return(data.get(8)&65535)|((data.get(9)&65535)<<16);}
    public int bosses(){return data.get(10);}public int sellPrice(){return data.get(11);}public int element(){return data.get(12);}public boolean holdingBow(){return data.get(13)==1;}
    public boolean canSell(){return data.get(14)==1;}public ItemStack saleItem(){return sale.getItem(0);}
    @Override public void broadcastChanges(){refresh();super.broadcastChanges();}
    @Override public boolean clickMenuButton(Player player,int button){
        if(player!=owner||player.level().isClientSide()||!player.isAlive()||ControlEffects.stunned(player))return false;
        boolean success=false;
        if(button>=0&&button<6){var product=Economy.Product.values()[button/2];int count=button%2==0?1:8;var result=Economy.buy(player,product,count);player.displayClientMessage(Economy.feedback(result,product,count),false);success=result==Economy.Purchase.OK;}
        else if(button>=100&&button<100+Economy.Product.values().length*2){var product=Economy.Product.values()[(button-100)/2];int count=(button-100)%2==0?1:8;var result=Economy.buy(player,product,count);player.displayClientMessage(Economy.feedback(result,product,count),false);success=result==Economy.Purchase.OK;}
        else if(button==20||button==21){success=SellPrices.sell(player,sale.getItem(0),button==20?1:sale.getItem(0).getCount());sale.setChanged();}
        else if(button>=40&&button<40+Careers.COUNT)success=Careers.select(player,button-40);
        else if(button==50)success=Careers.advance(player);
        
        else if(button>=70&&button<=72)success=MagicSystem.choose(player,button-70);
        broadcastChanges();return success;
    }
    @Override public boolean stillValid(Player player){return player==owner&&player.isAlive();}
    @Override public void removed(Player player){super.removed(player);if(!player.level().isClientSide())clearContainer(player,sale);}
    @Override public ItemStack quickMoveStack(Player player,int index){
        if(index<0||index>=slots.size())return ItemStack.EMPTY;var slot=slots.get(index);if(!slot.hasItem())return ItemStack.EMPTY;
        var stack=slot.getItem();var copy=stack.copy();if(index==0){if(!moveItemStackTo(stack,1,37,true))return ItemStack.EMPTY;}
        else if(!moveItemStackTo(stack,0,1,false))return ItemStack.EMPTY;
        if(stack.isEmpty())slot.setByPlayer(ItemStack.EMPTY);else slot.setChanged();slot.onTake(player,stack);return copy;
    }
}
