package com.junwo.starrpg;

import java.util.*;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.world.BossEvent;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;

@EventBusSubscriber(modid=StarRPG.MODID)
public final class GoldDisplay {
    private static final Map<UUID,ServerBossEvent> BARS=new HashMap<>(),MANA=new HashMap<>();
    @SubscribeEvent public static void tick(ServerTickEvent.Post e){
        if(e.getServer().getTickCount()%10!=0)return;
        for(var p:e.getServer().getPlayerList().getPlayers()){
            var bar=BARS.computeIfAbsent(p.getUUID(),id->new ServerBossEvent(Component.literal("골드"),BossEvent.BossBarColor.YELLOW,BossEvent.BossBarOverlay.PROGRESS));
            if(!bar.getPlayers().contains(p)){bar.removeAllPlayers();bar.addPlayer(p);}
            bar.setVisible(Config.ECONOMY_ENABLED.get());bar.setProgress(1);
            var name=Component.literal("골드 "+String.format(java.util.Locale.ROOT,"%,d",StarWallet.get(p.server).balance(p.getUUID()))+" G  |  Shift+H 메뉴");
            if(!bar.getName().equals(name))bar.setName(name);
            var mana=MANA.computeIfAbsent(p.getUUID(),id->new ServerBossEvent(Component.literal("마나"),BossEvent.BossBarColor.PURPLE,BossEvent.BossBarOverlay.PROGRESS));
            if(!mana.getPlayers().contains(p)){mana.removeAllPlayers();mana.addPlayer(p);}
            mana.setVisible(Careers.profile(p).selected==3);
            if(Careers.profile(p).selected==3){float value=MagicSystem.mana(p),max=MagicSystem.maxMana(p);mana.setProgress(value/max);mana.setName(Component.literal("마나 "+(int)value+"/"+(int)max+" | "+(p.getMainHandItem().getItem() instanceof MagicStaffItem?MagicSystem.SPELLS[MagicSystem.spell(p.getMainHandItem())]:"마법사")+" | "+MagicSystem.cooldowns(p)));}
        }
    }
    @SubscribeEvent public static void logout(PlayerEvent.PlayerLoggedOutEvent e){var bar=BARS.remove(e.getEntity().getUUID());if(bar!=null)bar.removeAllPlayers();var mana=MANA.remove(e.getEntity().getUUID());if(mana!=null)mana.removeAllPlayers();}
    @SubscribeEvent public static void stop(ServerStoppedEvent e){BARS.values().forEach(ServerBossEvent::removeAllPlayers);BARS.clear();MANA.values().forEach(ServerBossEvent::removeAllPlayers);MANA.clear();}
}
