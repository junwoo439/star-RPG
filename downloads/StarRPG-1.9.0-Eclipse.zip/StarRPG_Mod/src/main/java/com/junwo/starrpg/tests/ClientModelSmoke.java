package com.junwo.starrpg.tests;

import com.junwo.starrpg.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.*;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/** Opt-in dev-only verification. Excluded from the distributed mod JAR with all test classes. */
@EventBusSubscriber(modid=StarRPG.MODID,value=Dist.CLIENT)
public final class ClientModelSmoke {
    private static int ticks;private static boolean checked,captured;
    @SubscribeEvent public static void tick(ClientTickEvent.Post event){
        if(!Boolean.getBoolean("starrpg.clientSmoke"))return;
        var mc=Minecraft.getInstance();if(mc.getOverlay()!=null||mc.screen==null)return;
        if(!checked){
            int faces=0;
            for(Item weapon:new Item[]{StarRPG.MAGIC_STAFF.get(),StarRPG.STAR_SPEAR.get(),StarRPG.BERSERKER_BLADE.get(),StarRPG.SUN_SCEPTER.get(),StarRPG.SOUL_SCYTHE.get(),StarRPG.STAR_GAUNTLET.get(),StarRPG.AEGIS_BLADE.get()}){
                var item=new ItemStack(weapon);var model=mc.getItemRenderer().getModel(item,null,null,0);var random=RandomSource.create(1);
                int quads=model.getQuads(null,null,random).size();for(var direction:Direction.values())quads+=model.getQuads(null,direction,random).size();
                if(model==mc.getModelManager().getMissingModel()||quads<18)throw new IllegalStateException("Weapon model missing/invisible: "+weapon+" faces="+quads);
                StarRPG.LOGGER.info("CLIENT_MODEL_CHECK PASSED: {} baked faces={}",weapon,quads);faces+=quads;
            }
            checked=true;
            mc.setScreen(new Preview(faces));return;
        }
        if(++ticks>=80&&!captured){captured=true;Screenshot.grab(mc.gameDirectory,"starrpg-1.9-model-check.png",mc.getMainRenderTarget(),message->{StarRPG.LOGGER.info("CLIENT_MODEL_SCREENSHOT: {}",message.getString());mc.execute(mc::stop);});}
    }
    private static final class Preview extends Screen {
        private final int faces;Preview(int faces){super(Component.literal("StarRPG model verification"));this.faces=faces;}
        @Override public void render(GuiGraphics g,int x,int y,float partial){
            g.fillGradient(0,0,width,height,0xFF251C37,0xFF101B29);
            g.drawCenteredString(font,"StarRPG 1.9 - actual client weapon models",width/2,14,0xF0D8FF);
            Item[] items={StarRPG.STAR_SPEAR.get(),StarRPG.BERSERKER_BLADE.get(),StarRPG.SUN_SCEPTER.get(),StarRPG.SOUL_SCYTHE.get(),StarRPG.STAR_GAUNTLET.get(),StarRPG.AEGIS_BLADE.get(),StarRPG.MAGIC_STAFF.get()};
            String[] names={"Spear","Greatblade","Sun scepter","Soul scythe","Gauntlet","Aegis blade","Magic staff"};
            for(int i=0;i<items.length;i++){int col=i%4,row=i/4;int bx=width/2-184+col*94,by=40+row*100;
                g.fill(bx,by,bx+88,by+92,0xFF121B28);g.pose().pushPose();g.pose().translate(bx+12,by+5,0);g.pose().scale(4,4,4);g.renderItem(new ItemStack(items[i]),0,0);g.pose().popPose();
                g.drawCenteredString(font,names[i],bx+44,by+76,0xDCC0FF);
            }
            g.drawCenteredString(font,"7 models verified / "+faces+" baked faces / no resource pack",width/2,height-15,0xADC4D4);
        }
    }
}
