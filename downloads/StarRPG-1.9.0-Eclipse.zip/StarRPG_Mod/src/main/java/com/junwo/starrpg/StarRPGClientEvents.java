package com.junwo.starrpg;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

@EventBusSubscriber(
        modid = StarRPG.MODID,
        value = Dist.CLIENT
)
public class StarRPGClientEvents {

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        if(net.minecraft.client.Minecraft.getInstance().player==null)return;
        while(StarRPGKeyMappings.HUB.consumeClick())PacketDistributor.sendToServer(new ActionPayload(0));
        while(StarRPGKeyMappings.WEAPON.consumeClick())PacketDistributor.sendToServer(new ActionPayload(1));
        while(StarRPGKeyMappings.CAREER.consumeClick())PacketDistributor.sendToServer(new ActionPayload(2));
        while (StarRPGKeyMappings.CHEST_ABILITY.consumeClick()) {
            PacketDistributor.sendToServer(
                    UseChestAbilityPayload.INSTANCE
            );
        }
    }
}