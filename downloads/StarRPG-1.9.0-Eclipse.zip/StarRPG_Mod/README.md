# StarRPG

Minecraft 1.21.1 / NeoForge 21.1.235용 장비 강화·무기/방어구 룬·월드 공통 난이도·장비/낚싯대 좀비 모드.
현재 버전: **1.9.0**.

## Eclipse에서 게임 실행

**[Eclipse 실행 안내](ECLIPSE.md)**를 따라 Existing Gradle Project로 가져오고
`Run > Run Configurations > Java Application > StarRPG Client`를 실행하세요.
게임의 싱글플레이에서 테스트할 수 있습니다. JDK 21이 필요합니다.

Windows 명령줄 실행:

```bat
gradlew.bat runClient
```

클라이언트 월드와 설정은 `run-client/`에 저장됩니다.
변경 내용, 밸런스 설정, 기존 강화 장비 이전 방법은 [BALANCE-1.9.md](BALANCE-1.9.md)를 참조하세요.

## 빌드 및 개발자 테스트

```bash
bash gradlew build
bash gradlew runGameTestServer
```

Windows에서는 `gradlew.bat`를 사용합니다. 배포 파일은 `build/libs/starrpg-1.9.0.jar`입니다.
GameTest는 별도의 `run-gametest/`를 사용합니다.

1.9.0 변경 내용과 빠른 확인 순서는 [TESTING-1.9.md](TESTING-1.9.md)를 참고하세요.

이번 버전은 **10개 직업·신규 무기 6종, 직업 미리보기와 별도 확정, 매 5회 전직 성장, 전문 무기 무한 강화, 월드 난이도 상한 해제, 22계열 몬스터 능력, 마법 쿨타임 표시, 23품목 상점**을 포함합니다. 망치는 대장장이 전용 능력으로 옮겼습니다. 일반 검·도끼와 방어구는 +10을 유지합니다.

일반 룬 결과는 일반 70% / 희귀 25% / 에픽 4.9% / 레전더리 0.1%입니다. 모든 입력 룬이 결과 등급을 보장하지 않으며 재각인 때 등급이 낮아질 수 있습니다. 룬 확률·수치는 [BALANCE-1.8.md](BALANCE-1.8.md), 전체 룬은 [RUNE-EFFECTS-1.8.csv](RUNE-EFFECTS-1.8.csv), 플레이 확인 순서는 [TESTING-1.9.md](TESTING-1.9.md)에 있습니다.

**Shift+H:** 상점·판매·직업·마법 / **R:** 무기 스킬 / **G:** 직업 능력. 지팡이 우클릭은 선택 주문, Shift+우클릭은 주문 변경입니다. 장비 강화는 설치한 **인챈트 테이블 우클릭**, 룬 각인은 **룬 각인 도구**를 사용합니다. 별조각은 강화 재료로 유지합니다.

별가루 기본 구매 가격은 40 G, 별조각은 400 G입니다. 전체 판매 가격은 [SELL-PRICES-1.9.csv](SELL-PRICES-1.9.csv)에 있습니다. 기존 월드와 프로젝트는 백업한 뒤 업데이트하세요.

외부 모드는 [MODS-1.5.1.md](MODS-1.5.1.md)를 따릅니다. setup-adventure-eclipse.bat으로 Twilight Forest 4.8.3802, Mowzie 1.8.2, GeckoLib 4.9.2를 설치하고 Eclipse 실행을 준비합니다. Ice and Fire는 호환 공식 빌드가 없어 제외했습니다. 생활직은 보류했습니다.

검증 결과: 외부 Twilight Forest / Mowzie / GeckoLib을 함께 로드한 자동 GameTest **133개 통과**, 빌드·Eclipse 실행 구성 생성 성공, 실제 클라이언트에서 신규 무기 6종과 지팡이 모델 표시 확인 완료. 확인 화면은 `art/validation/weapons-1.9.png`에 있습니다. Windows Eclipse와 실제 다인 PvP 체감은 별도 확인이 필요합니다.
